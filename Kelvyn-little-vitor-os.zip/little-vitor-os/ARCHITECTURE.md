# Arquitetura do Little Vitor OS

## Visão geral

```
┌──────────────────────────── Navegador ─────────────────────────────┐
│  React (UI)                                                        │
│   boot/ ─ desktop/ ─ wm/ ─ apps/            ← só leem/escrevem via │
│        │                                      o Kernel             │
│  ┌─────▼──────────────── Kernel (TS puro) ──────────────────────┐  │
│  │ EventBus ◄── todos os módulos publicam eventos               │  │
│  │ VFS ── UserManager ── ProcessManager ── SettingsService      │  │
│  │  │        │                 │                 │              │  │
│  │  │   /etc/passwd,shadow  tabela de PIDs   ~/.config/lvos     │  │
│  │ NotificationService ── NetworkManager ── PackageManager(LVP) │  │
│  │ Shell (lvsh) ── comandos ── usa VFS/Users/Procs/LVP          │  │
│  │ SyncEngine ── fetch + WebSocket ───────────────┐             │  │
│  └──────┬───────────────────────────────────────────────────────┘  │
│   StorageBackend: IndexedDB (metadados) + OPFS/IndexedDB (dados)   │
│  Apps LVP: <iframe sandbox="allow-scripts"> ⇄ postMessage bridge   │
└──────────────────────────────────────────────────────┼─────────────┘
                                                       │ HTTPS/WS
                               ┌───────────────────────▼────────────┐
                               │ server/: Node http + ws            │
                               │  auth (scrypt, cookie HttpOnly,    │
                               │  CSRF), files, settings, push      │
                               │  PostgreSQL                        │
                               └────────────────────────────────────┘
```

**Regra principal:** o núcleo (`src/kernel`, `src/core`) não importa React. Ele roda igual no navegador e no Node, por isso é testado com `node:test` sem navegador. A interface só observa `Store`s e chama métodos.

## Módulos (os 12 do prompt)

| # | Módulo | Onde | Responsabilidade |
|---|---|---|---|
| 1 | Kernel Simulation Layer | `kernel/kernel.ts`, `events.ts`, `store.ts` | Boot em etapas, liga os módulos, barramento de eventos, arquivos virtuais de `/proc` e `/dev` |
| 2 | Desktop Environment | `desktop/` | Barra superior, dock, menu, painéis, ícones, atalhos |
| 3 | Window Manager | `wm/windowManager.ts` (lógica) + `WindowFrame.tsx` | Geometria, foco, z-order, MRU, encaixe, minimizar/maximizar |
| 4 | Virtual File System | `core/vfs/` | Árvore em memória espelhada no backend de armazenamento; permissões; lixeira |
| 5 | Application Runtime | `apps/registry.tsx`, `desktop/session.ts` | Registro de apps, carregamento sob demanda (code splitting), abrir arquivo com o app padrão, isolamento de erros (ErrorBoundary por janela) |
| 6 | Process Manager | `core/process/` | PIDs, estados, sinais (TERM/KILL/INT/STOP/CONT), dono do processo |
| 7 | User Management | `core/users/` | `/etc/passwd`, `/etc/group`, `/etc/shadow`, login, bloqueio, limite de tentativas |
| 8 | Permission System | `core/vfs/permissions.ts` | Bits rwx, setuid/setgid/sticky, chmod simbólico e octal, `sudo` |
| 9 | Network Manager | `core/network/` | Estado real da conexão, interfaces virtuais, ping HTTP |
| 10 | System Settings | `core/settings/` + `apps/Settings.tsx` | JSON validado em `/etc/lvos/system.json` e `~/.config/lvos/settings.json` |
| 11 | Package Manager | `core/packages/` | LVP |
| 12 | Notification Service | `core/notifications/` | Toasts, histórico, não perturbe, silenciar por app |

## Sistema de arquivos

- **Metadados** (`VNode`: id, tipo, nome, pai, modo, dono, grupo, tamanho, datas, mime) ficam todos em memória para listar e buscar rápido, e são gravados no IndexedDB (store `nodes`).
- **Conteúdo** é carregado sob demanda: OPFS quando o navegador suporta `createWritable`, senão store `data` do IndexedDB. Arquivos < 1 MB ficam em cache.
- Toda operação recebe `Credentials` (usuário + grupos). A checagem segue o Linux: busca exige `x` em cada diretório do caminho; criar/remover exige `w`+`x` no diretório pai; sticky bit restringe remoção; só o dono muda permissões; só root muda o dono.
- Limites: 256 MB por arquivo; nomes até 255 caracteres; sem `/` ou NUL.
- Lixeira no padrão freedesktop: `~/.local/share/Trash/{files,info}`.

## Shell (lvsh)

1. `parser.ts` gera tokens preservando o tipo de aspas de cada pedaço e monta `lista → pipeline → comando`.
2. `shell.ts` expande no momento da execução (variáveis, `~`, globs só em trechos sem aspas), aplica aliases, abre redirecionamentos (o arquivo é truncado antes, como no bash), executa pipelines passando o texto de saída como entrada do próximo.
3. Cada comando vira um processo virtual (aparece no `ps`), com `AbortController` para Ctrl+C e `kill`.
4. Comandos têm `source`: `vos` (implementado pelo sistema), `browser` (usa API real do navegador) ou `gui` (abre app). `UNAVAILABLE` lista programas Linux que não existem aqui e explica o motivo.
5. `/bin/<cmd>` são arquivos `#!lvsh-builtin cmd` — por isso `ls /bin`, `which` e `/bin/echo` funcionam.

## LVP — formato do pacote (`.lvp`)

```json
{
  "lvp": 1,
  "name": "meu-app",
  "version": "1.0.0",
  "displayName": "Meu App",
  "description": "…",
  "author": "…", "license": "MIT", "icon": "🚀", "category": "Utilitários",
  "permissions": ["storage", "notifications"],
  "dependencies": { "lvp-runtime": "^1.0.0" },
  "entry": "index.html",
  "window": { "width": 480, "height": 360 },
  "files": { "index.html": "<button onclick=\"lvos.notify('oi')\">Oi</button>" },
  "sha256": "<sha256 de JSON.stringify(entradas de files ordenadas por nome)>"
}
```

Permissões: `notifications`, `storage`, `fs:home:read`, `fs:home:write`, `clipboard`. API dentro do app: `lvos.notify`, `lvos.storage.get/set`, `lvos.fs.list/read/write/writeDataUrl`, `lvos.clipboard.write`, `lvos.info`.

Segurança: manifesto validado campo a campo; hash conferido ao baixar, ao instalar e a cada abertura; iframe sem `allow-same-origin` (origem opaca: sem cookies, sem localStorage, sem acesso ao DOM do sistema); CSP `default-src 'none'` dentro do app (sem rede); cada chamada da ponte é checada contra as permissões e os caminhos são presos à pasta pessoal; instalar exige administrador e confirmação explícita.

## Backend

- `node:http` + `ws` (sem framework, para ficar leve), PostgreSQL via `pg`.
- **Auth:** senha com scrypt (N=2^15); token de sessão aleatório de 256 bits — no banco só o SHA-256 dele; cookie `HttpOnly`, `SameSite=Lax` (ou `None; Secure` com `COOKIE_SECURE=true`).
- **CSRF:** escrita exige `X-CSRF-Token` igual ao token da sessão **e** Origin na lista permitida.
- **Outros:** CORS por lista, cabeçalhos de segurança, limite de taxa (login/registro e geral), limite de corpo, cota por usuário, validação de caminho (sem `..`), conferência de SHA-256 no upload.
- **Sincronização:** tabela `files` com *tombstones* (`deleted = true`) para propagar exclusões; cliente guarda o último estado sincronizado em `~/.config/lvos/sync-state.json`; conflito = vence o mais recente (mtime); WebSocket avisa os outros aparelhos do mesmo usuário (o aparelho que fez a mudança não recebe eco, via `X-Client-Id`).

## Testes

| Suíte | Ferramenta | Cobertura |
|---|---|---|
| `tests/unit/*.test.ts` | node:test | VFS, caminhos, permissões, lixeira, persistência, usuários, sessões, bloqueio por tentativas, configurações, processos, notificações, parser, ~40 comandos, pipes/redirecionamento, sudo, jobs, Tab, histórico, LVP (dependências, integridade, upgrade, repositórios, .lvp local), window manager, calculadora |
| `tests/e2e/run.mjs` | Playwright | Assistente → desktop → terminal → janelas (arrastar, maximizar) → arquivos → editor → lixeira → pacote em sandbox → Central de Apps → tema → 12 apps abrindo → notificações → Alt+\` → bloqueio → recarregar a página (persistência) → celular |
| `server/tests/server.test.ts` | node:test + PostgreSQL real | Registro/login, hash, CSRF, arquivos, isolamento entre usuários, tombstones, cota, settings, WebSocket, rate limit |
| `tests/e2e/sync.mjs` | Playwright + backend | Dois aparelhos: upload, download inicial, edição em tempo real, exclusão |
