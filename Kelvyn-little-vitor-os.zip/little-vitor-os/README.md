# Little Vitor OS

> *A complete virtual operating environment in your browser.*

Um sistema operacional web inspirado em distribuições Linux: área de trabalho com janelas de verdade, sistema de arquivos persistente, terminal com shell próprio (`lvsh`), 16 aplicativos, usuários com senha, permissões estilo Unix, gerenciador de pacotes (**LVP**) e backend opcional com sincronização em nuvem.

---

## Rodando o frontend (o sistema em si)

Requisitos: **Node.js 20+**.

```bash
npm install          # instala dependências e copia o worker do pdf.js para public/
npm run dev          # abre em http://localhost:5173
```

Na primeira visita aparece o **assistente de configuração** (idioma, conta de administrador, tema, armazenamento). Depois disso, cada visita mostra a tela de login.

| Comando | O que faz |
|---|---|
| `npm run dev` | servidor de desenvolvimento (Vite) |
| `npm run build` | checagem de tipos + build de produção em `dist/` |
| `npm run preview` | serve o `dist/` |
| `npm test` | testes unitários (node:test) — 48 testes |
| `npm run test:e2e` | build + teste ponta a ponta no Chromium (Playwright) — 24 passos |
| `npm run typecheck` | TypeScript estrito |

> Para os testes E2E: `npx playwright install chromium` uma vez (ou defina `CHROME_PATH` com o caminho do seu Chrome).

## Rodando o backend (opcional — Fase 7)

Sem backend tudo funciona localmente. O backend adiciona **contas na nuvem e sincronização da pasta pessoal** entre navegadores/computadores.

```bash
docker compose up -d                 # sobe um PostgreSQL 16 (usuário/senha: lvos/lvos)
cd server
npm install
cp .env.example .env                 # ajuste se precisar
npm run dev                          # http://localhost:4000 (cria as tabelas sozinho)
```

Sem Docker? Instale o PostgreSQL, crie o usuário/banco `lvos` e ajuste `DATABASE_URL`.

Depois, no Little Vitor OS: **Configurações › Sincronização** → endereço `http://localhost:4000` → ligar → *Criar conta no servidor*.

Testes do backend (usam um banco de teste **real**; as tabelas são recriadas):

```bash
cd server
TEST_DATABASE_URL=postgres://lvos:lvos@localhost:5432/lvos_test npm test
```

Teste de sincronização entre dois "aparelhos" (com o backend rodando e `ALLOWED_ORIGINS=http://127.0.0.1:5180`):

```bash
npm run build && npm run test:sync
```

---

## O que tem dentro

**Área de trabalho** — barra superior (menu, relógio + calendário, rede, bateria, notificações, configurações rápidas), dock com indicador de apps abertos, ícones na área de trabalho, menus de contexto, papel de parede (6 prontos ou imagem sua), arrastar arquivos do computador para importar.

**Gerenciador de janelas** — abrir, fechar, minimizar, maximizar, restaurar, arrastar, redimensionar pelas 8 bordas, encaixar arrastando para a lateral/topo, lado a lado, Alt+Tab, foco e animações. No celular, cada app abre em tela cheia.

**Sistema de arquivos virtual** — árvore FHS (`/bin`, `/etc`, `/home`, `/proc`, `/tmp`…), persistente em IndexedDB (+ OPFS quando disponível), permissões rwx dono/grupo/outros com setuid/setgid/sticky (o `/tmp` é `1777` de verdade), lixeira com restauração, arquivos virtuais (`/proc/uptime`, `/dev/null`, `/dev/random`).

**Terminal (lvsh)** — 80 comandos, pipes, redirecionamento (`>`, `>>`, `<`, `2>`, `2>&1`, `&>`), `&&`, `||`, `;`, jobs em segundo plano (`&`, `jobs`, `fg`, `kill %1`), variáveis, `~`, globs `* ? [ ]`, aliases, histórico (↑ ↓ `!!`), Tab, scripts executáveis (`chmod +x` + `./script.sh`), `sudo` com senha, abas múltiplas, `top` em tela cheia.

**Aplicativos** — Arquivos, Terminal, Editor de Texto, Calculadora, Calendário (com lembretes), Relógio (mundial, cronômetro, timer), Monitor do Sistema, Configurações, Imagens, Leitor de PDF, Música, Vídeos, Navegador, Notas (Markdown), Gerenciador de Tarefas, Arquivos Compactados (.zip) e a **Central de Apps**.

**LVP** — `lvp install/remove/update/upgrade/search/list/info/verify/log/autoremove/repository`, dependências com versões (`^`, `~`, `>=`), verificação SHA-256, repositórios remotos (HTTPS), pacotes locais `.lvp`, log em `/var/log/lvp.log`. Apps instalados rodam em **iframe sandbox** sem acesso à página e só usam o que o manifesto declara. O repositório `core` traz 7 apps: Lembretes, Pomodoro, Snake, Paint, JSON Tools, Markdown Viewer e Conversor.

## Atalhos

| Atalho | Ação |
|---|---|
| Super (ou Alt+F1) | Menu de aplicativos |
| Super+E / Ctrl+Alt+E | Arquivos |
| Super+T / Ctrl+Alt+T | Terminal |
| Super+L / Ctrl+Alt+L | Bloquear |
| Super+D / Ctrl+Alt+D | Mostrar área de trabalho |
| Alt+Tab / Alt+\` | Alternar janelas |
| Super+← → ↑ ↓ | Encaixar / maximizar / minimizar |
| Ctrl+Alt+W | Fechar janela |
| Ctrl+Alt+Del / Ctrl+Alt+End | Painel do sistema |

O Windows e o macOS capturam alguns atalhos (Alt+Tab, Ctrl+Alt+Del) antes do navegador — por isso cada um tem uma alternativa.

## Limitações (sendo honesto)

- **Não há Linux real.** Os comandos são implementados pelo próprio sistema em TypeScript; `which`, `type` e `man` dizem isso. Programas como `python`, `gcc`, `git`, `ssh` respondem "indisponível" com o motivo, em vez de fingir que rodaram. Um Linux em WebAssembly (v86, container2wasm) é o próximo passo do [ROADMAP](ROADMAP.md).
- **Rede:** navegadores não enviam ICMP nem abrem sockets. `ping` mede latência com requisição HTTP real; `curl`/`wget` fazem requisições reais, mas sujeitas a CORS; `ip` mostra interfaces **virtuais** (e diz isso); `netstat` explica por que não existe.
- **Métricas:** o Monitor marca o que é **real** (atraso do event loop, FPS, heap JS no Chromium, cota de armazenamento) e o que é **virtual** (processos, janelas, arquivos). %CPU por processo não é mensurável no navegador e não é exibido.
- **Navegador:** muitos sites (Google, YouTube, bancos) proíbem ser exibidos dentro de outra página; há um botão para abri-los no navegador real.
- **Bateria:** real no Chromium (Battery API); nos outros navegadores o ícone fica esmaecido e marcado como simulado.
- **Idioma:** a interface está em português; "English" altera só formatos nesta versão.
- **Dados:** ficam no navegador. Limpar os dados do site apaga o sistema (a sincronização com o backend serve de cópia).

## Estrutura

```
src/
  kernel/        núcleo: barramento de eventos, store, boot (kernel.ts)
  core/
    vfs/         sistema de arquivos virtual + permissões + backends (memória, IndexedDB/OPFS)
    shell/       parser, executor (shell.ts) e comandos (commands/*)
    users/       contas, sessões, hash de senha (PBKDF2)
    process/     tabela de processos virtuais e sinais
    packages/    LVP: manifesto, repositório embutido, ponte do sandbox
    settings/    configurações (arquivos JSON no VFS)
    notifications/  network/  sync/
  wm/            gerenciador de janelas (lógica pura + componentes React)
  desktop/       barra superior, dock, menu, painéis, atalhos
  boot/          tela de boot, assistente, login e bloqueio
  apps/          os 17 aplicativos
  ui/            ícones, componentes, tema, helpers
server/          backend Node.js + PostgreSQL + WebSocket
tests/           unit (node:test) e e2e (Playwright)
```

Detalhes em [ARCHITECTURE.md](ARCHITECTURE.md). O que falta em [ROADMAP.md](ROADMAP.md).
