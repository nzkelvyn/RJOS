# Roadmap

Status das 8 fases do prompt mestre.

| Fase | Conteúdo | Status |
|---|---|---|
| 1 — Fundação | Estrutura, desktop, boot, window manager, dock, menu | ✅ feito e testado (E2E) |
| 2 — Arquivos | VFS, gerenciador de arquivos, IndexedDB/OPFS, importar/exportar, lixeira | ✅ feito e testado |
| 3 — Terminal | Shell, interpretador, 80 comandos, histórico, integração com VFS | ✅ feito e testado |
| 4 — Aplicativos | Editor, calculadora, calendário, relógio, monitor, visualizadores, players, navegador, notas, zip | ✅ feito (todos abrem no E2E; principais com teste de uso) |
| 5 — Sistema | Usuários, permissões, configurações, notificações, processos | ✅ feito e testado |
| 6 — Pacotes | LVP, repositórios, instalar/remover/atualizar | ✅ feito e testado |
| 7 — Integração | Backend, nuvem, autenticação, sincronização | ✅ feito e testado com PostgreSQL real |
| 8 — Finalização | Testes, segurança, otimização, documentação, deploy | 🟡 testes/segurança/docs feitos; deploy é seu (ver abaixo) |

## Próximos passos sugeridos

1. **Linux real em WebAssembly** — integrar v86 ou container2wasm como um "modo Linux" separado no terminal (marcado como tal). Custo: dezenas de MB de download, por isso deve ser opcional e baixado sob demanda.
2. **Tradução completa (i18n)** — extrair os textos para arquivos `pt-BR.json`/`en-US.json`.
3. **Sincronização de configurações** — a API `/api/settings` já existe; falta ligar no cliente.
4. **Resolução de conflitos melhor** — hoje vence o mais recente; dá para guardar a versão perdedora como `arquivo (conflito).txt`.
5. **Editor com destaque de sintaxe** — CodeMirror 6 é leve e modular.
6. **Deploy** — frontend é estático (`npm run build` → qualquer hospedagem estática: GitHub Pages, Netlify, Cloudflare Pages). Backend precisa de Node + PostgreSQL (Render, Railway, Fly.io ou uma VPS). Em produção: HTTPS, `COOKIE_SECURE=true` e `ALLOWED_ORIGINS` com o domínio do frontend.
7. **Mais pacotes LVP** e um repositório público (um `index.json` num GitHub Pages já serve).
8. **Multi-idioma de teclado / layouts** no terminal e acessibilidade com leitor de tela (já há `aria-*` básicos).
