// Offline build used where Vite is not installable: esbuild (same bundler Vite uses)
// + Tailwind v4 compiler API. Produces dist/ equivalent to `vite build`.
// Usage: node scripts/build-sandbox.mjs [--minify]
import { build, transform } from 'esbuild';
import { compile } from 'tailwindcss';
import { readFile, writeFile, mkdir, readdir, rm } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const out = path.join(root, 'dist');
const require = createRequire(import.meta.url);
const minify = process.argv.includes('--minify');

await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });

// 1) JS bundle with code splitting (lazy apps become separate chunks)
const result = await build({
  entryPoints: [path.join(root, 'src/main.tsx')],
  bundle: true,
  splitting: true,
  format: 'esm',
  target: 'es2022',
  outdir: out,
  entryNames: 'main',
  chunkNames: 'chunks/[name]-[hash]',
  jsx: 'automatic',
  minify,
  charset: 'ascii', // escape control/non-ASCII chars (e.g. ANSI ESC) so files are plain text
  sourcemap: false,
  metafile: true,
  loader: { '.css': 'empty' },
  define: { 'process.env.NODE_ENV': minify ? '"production"' : '"development"' },
  logLevel: 'warning',
});

// 2) Tailwind: collect candidate class names from the sources
async function walk(dir) {
  const files = [];
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) files.push(...(await walk(p)));
    else if (/\.(tsx?|html)$/.test(e.name)) files.push(p);
  }
  return files;
}
const candidates = new Set();
for (const f of [...(await walk(path.join(root, 'src'))), path.join(root, 'index.html')]) {
  const text = await readFile(f, 'utf8');
  for (const m of text.matchAll(/[^\s"'`{}<>]+/g)) candidates.add(m[0]);
}
const twDir = path.dirname(require.resolve('tailwindcss/package.json'));
const cssSrc = await readFile(path.join(root, 'src/styles.css'), 'utf8');
const compiler = await compile(cssSrc, {
  base: path.join(root, 'src'),
  async loadStylesheet(id, base) {
    const file = id === 'tailwindcss' ? path.join(twDir, 'index.css') : id.startsWith('tailwindcss/') ? path.join(twDir, id.slice('tailwindcss/'.length)) : path.resolve(base, id);
    return { content: await readFile(file, 'utf8'), base: path.dirname(file), path: file };
  },
});
await writeFile(path.join(out, 'styles.css'), compiler.build([...candidates]));

// 3) pdf.js worker, served next to index.html
const worker = await readFile(require.resolve('pdfjs-dist/build/pdf.worker.min.mjs'), 'utf8');
await writeFile(path.join(out, 'pdf.worker.min.mjs'), (await transform(worker, { charset: 'ascii', format: 'esm', minifyWhitespace: true })).code);

// 4) index.html
const html = (await readFile(path.join(root, 'index.html'), 'utf8'))
  .replace('<script type="module" src="/src/main.tsx"></script>', '<link rel="stylesheet" href="styles.css" />\n    <script type="module" src="main.js"></script>');
await writeFile(path.join(out, 'index.html'), html);

const outputs = Object.entries(result.metafile.outputs).map(([f, o]) => [path.relative(out, f), o.bytes]);
const total = outputs.reduce((a, [, b]) => a + b, 0);
console.log(`dist: ${outputs.length} JS files, ${(total / 1024).toFixed(0)} KB JS, css ${(compiler.build([...candidates]).length / 1024).toFixed(0)} KB`);
