// Copies the pdf.js worker to public/ so Vite serves it next to index.html.
// Runs automatically after `npm install` (postinstall).
import { copyFile, mkdir } from 'node:fs/promises';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
await mkdir(new URL('../public/', import.meta.url), { recursive: true });
await copyFile(require.resolve('pdfjs-dist/build/pdf.worker.min.mjs'), new URL('../public/pdf.worker.min.mjs', import.meta.url));
console.log('pdf.worker.min.mjs copiado para public/');
