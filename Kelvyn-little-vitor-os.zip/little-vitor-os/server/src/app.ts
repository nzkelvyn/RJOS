import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { WebSocketServer, type WebSocket } from 'ws';
import type { Db } from './db.ts';
import { RateLimiter, cleanPath, hashPassword, parseCookies, randomToken, safeEqual, sha256, verifyPassword } from './security.ts';

export interface Config {
  port: number;
  /** origins allowed to call the API with credentials (CORS) and open WebSockets */
  allowedOrigins: string[];
  /** Secure cookies (required when serving over HTTPS / cross-site) */
  cookieSecure: boolean;
  sessionTtlHours: number;
  maxFileBytes: number;
  maxUserBytes: number;
  /** login/register attempts allowed per IP per minute */
  authRatePerMinute: number;
}

export const DEFAULT_CONFIG: Config = {
  port: 4000,
  allowedOrigins: ['http://localhost:5173', 'http://127.0.0.1:5173'],
  cookieSecure: false,
  sessionTtlHours: 24 * 7,
  maxFileBytes: 25 * 1024 * 1024,
  maxUserBytes: 500 * 1024 * 1024,
  authRatePerMinute: 10,
};

const COOKIE = 'lvos_sid';
const USERNAME_RE = /^[a-z_][a-z0-9_-]{0,31}$/;

interface Session {
  userId: number;
  username: string;
  csrf: string;
  tokenHash: string;
}

class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

type Handler = (req: IncomingMessage, res: ServerResponse, ctx: { url: URL; session: Session | null; ip: string }) => Promise<void>;

export function createApp(db: Db, partial: Partial<Config> = {}): { server: Server; config: Config } {
  const config = { ...DEFAULT_CONFIG, ...partial };
  const authLimiter = new RateLimiter(config.authRatePerMinute, 60_000);
  const apiLimiter = new RateLimiter(600, 60_000);
  const sockets = new Map<number, Set<{ ws: WebSocket; client: string }>>();

  // ------------------------------------------------------------ helpers
  const send = (res: ServerResponse, status: number, body: unknown, headers: Record<string, string> = {}) => {
    const data = Buffer.from(JSON.stringify(body));
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': data.length, ...headers });
    res.end(data);
  };

  const readBody = (req: IncomingMessage, limit: number): Promise<Buffer> =>
    new Promise((resolve, reject) => {
      const chunks: Buffer[] = [];
      let size = 0;
      req.on('data', (c: Buffer) => {
        size += c.length;
        if (size > limit) {
          reject(new HttpError(413, 'corpo da requisição grande demais'));
          req.destroy();
          return;
        }
        chunks.push(c);
      });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });

  const readJson = async <T>(req: IncomingMessage): Promise<T> => {
    if (!(req.headers['content-type'] ?? '').includes('application/json')) throw new HttpError(415, 'esperado application/json');
    try {
      return JSON.parse((await readBody(req, 1024 * 1024)).toString('utf8')) as T;
    } catch (err) {
      if (err instanceof HttpError) throw err;
      throw new HttpError(400, 'JSON inválido');
    }
  };

  const cookie = (value: string, maxAgeSec: number) =>
    `${COOKIE}=${value}; Path=/; HttpOnly; Max-Age=${maxAgeSec}; SameSite=${config.cookieSecure ? 'None; Secure' : 'Lax'}`;

  const audit = (userId: number | null, action: string, ip: string) =>
    db.query('INSERT INTO audit_log (user_id, action, ip) VALUES ($1, $2, $3)', [userId, action, ip]).catch(() => undefined);

  async function loadSession(req: IncomingMessage): Promise<Session | null> {
    const token = parseCookies(req.headers.cookie)[COOKIE];
    if (!token || token.length > 100) return null;
    const tokenHash = sha256(token);
    const r = await db.query<{ user_id: number; username: string; csrf: string }>(
      'SELECT s.user_id, u.username, s.csrf FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = $1 AND s.expires_at > now()',
      [tokenHash],
    );
    const row = r.rows[0];
    return row ? { userId: row.user_id, username: row.username, csrf: row.csrf, tokenHash } : null;
  }

  async function createSession(userId: number, userAgent: string | undefined) {
    const token = randomToken();
    const csrf = randomToken(24);
    await db.query(
      `INSERT INTO sessions (token_hash, user_id, csrf, user_agent, expires_at) VALUES ($1, $2, $3, $4, now() + ($5 || ' hours')::interval)`,
      [sha256(token), userId, csrf, (userAgent ?? '').slice(0, 300), String(config.sessionTtlHours)],
    );
    // opportunistic cleanup of expired sessions
    void db.query('DELETE FROM sessions WHERE expires_at < now()').catch(() => undefined);
    return { token, csrf };
  }

  function broadcast(userId: number, msg: unknown, exceptClient?: string) {
    for (const s of sockets.get(userId) ?? []) {
      if (s.client !== exceptClient && s.ws.readyState === 1) s.ws.send(JSON.stringify(msg));
    }
  }

  const requireUser = (s: Session | null): Session => {
    if (!s) throw new HttpError(401, 'não autenticado');
    return s;
  };

  // ------------------------------------------------------------ routes
  const routes: Record<string, Handler> = {
    'GET /api/health': async (_req, res) => {
      await db.query('SELECT 1');
      send(res, 200, { ok: true, time: Date.now() });
    },

    'POST /api/auth/register': async (req, res, { ip }) => {
      if (!authLimiter.allow('auth:' + ip)) throw new HttpError(429, 'muitas tentativas; aguarde um minuto');
      const { username, password } = await readJson<{ username?: string; password?: string }>(req);
      const name = String(username ?? '').trim().toLowerCase();
      if (!USERNAME_RE.test(name)) throw new HttpError(400, 'nome de usuário inválido');
      if (typeof password !== 'string' || password.length < 8 || password.length > 200) throw new HttpError(400, 'a senha precisa ter de 8 a 200 caracteres');
      const exists = await db.query('SELECT 1 FROM users WHERE username = $1', [name]);
      if (exists.rowCount) throw new HttpError(409, 'usuário já existe');
      const r = await db.query<{ id: number }>('INSERT INTO users (username, password_hash) VALUES ($1, $2) RETURNING id', [name, await hashPassword(password)]);
      const { token, csrf } = await createSession(r.rows[0].id, req.headers['user-agent']);
      void audit(r.rows[0].id, 'register', ip);
      send(res, 201, { username: name, csrf }, { 'Set-Cookie': cookie(token, config.sessionTtlHours * 3600) });
    },

    'POST /api/auth/login': async (req, res, { ip }) => {
      if (!authLimiter.allow('auth:' + ip)) throw new HttpError(429, 'muitas tentativas; aguarde um minuto');
      const { username, password } = await readJson<{ username?: string; password?: string }>(req);
      const r = await db.query<{ id: number; password_hash: string }>('SELECT id, password_hash FROM users WHERE username = $1', [String(username ?? '').toLowerCase()]);
      const user = r.rows[0];
      // always run a hash to avoid leaking which usernames exist through timing
      const ok = await verifyPassword(String(password ?? ''), user?.password_hash ?? 'scrypt$32768$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=');
      if (!user || !ok) {
        void audit(user?.id ?? null, 'login-failed', ip);
        throw new HttpError(401, 'usuário ou senha incorretos');
      }
      const { token, csrf } = await createSession(user.id, req.headers['user-agent']);
      void audit(user.id, 'login', ip);
      send(res, 200, { username: String(username).toLowerCase(), csrf }, { 'Set-Cookie': cookie(token, config.sessionTtlHours * 3600) });
    },

    'POST /api/auth/logout': async (_req, res, { session }) => {
      if (session) await db.query('DELETE FROM sessions WHERE token_hash = $1', [session.tokenHash]);
      send(res, 200, { ok: true }, { 'Set-Cookie': cookie('', 0) });
    },

    'GET /api/auth/me': async (_req, res, { session }) => {
      const s = requireUser(session);
      send(res, 200, { username: s.username, csrf: s.csrf });
    },

    'GET /api/files': async (_req, res, { session, url }) => {
      const s = requireUser(session);
      const since = Number(url.searchParams.get('since') ?? 0);
      const r = await db.query<{ path: string; type: string; mode: number; mtime: number; size: number; sha256: string | null; deleted: boolean }>(
        'SELECT path, type, mode, mtime, size, sha256, deleted FROM files WHERE user_id = $1 AND extract(epoch from updated_at) * 1000 >= $2 ORDER BY path',
        [s.userId, since],
      );
      send(res, 200, r.rows.map((f) => ({ ...f, mtime: Number(f.mtime), size: Number(f.size) })));
    },

    'GET /api/files/content': async (_req, res, { session, url }) => {
      const s = requireUser(session);
      const path = cleanPath(url.searchParams.get('path'));
      if (!path) throw new HttpError(400, 'caminho inválido');
      const r = await db.query<{ content: Buffer | Uint8Array | null; type: string }>('SELECT content, type FROM files WHERE user_id = $1 AND path = $2 AND NOT deleted', [s.userId, path]);
      const row = r.rows[0];
      if (!row) throw new HttpError(404, 'arquivo não encontrado');
      if (row.type !== 'file') throw new HttpError(400, 'é um diretório');
      const data = row.content ? Buffer.from(row.content) : Buffer.alloc(0);
      res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': data.length, 'Cache-Control': 'no-store' });
      res.end(data);
    },

    'PUT /api/files/content': async (req, res, { session, url }) => {
      const s = requireUser(session);
      const path = cleanPath(url.searchParams.get('path'));
      if (!path) throw new HttpError(400, 'caminho inválido');
      const type = req.headers['x-type'] === 'dir' ? 'dir' : 'file';
      const mtime = Number(req.headers['x-mtime'] ?? Date.now());
      const mode = Number(req.headers['x-mode'] ?? (type === 'dir' ? 0o755 : 0o644)) & 0o777;
      if (!Number.isFinite(mtime) || mtime < 0) throw new HttpError(400, 'X-Mtime inválido');
      const body = await readBody(req, config.maxFileBytes);
      if (type === 'dir' && body.length) throw new HttpError(400, 'diretório não tem conteúdo');
      const digest = type === 'file' ? sha256(body) : null;
      const claimed = req.headers['x-sha256'];
      if (type === 'file' && typeof claimed === 'string' && claimed && claimed !== digest) throw new HttpError(422, 'sha256 não confere com o conteúdo enviado');
      const used = await db.query<{ total: number }>('SELECT COALESCE(SUM(size), 0)::bigint AS total FROM files WHERE user_id = $1 AND path <> $2 AND NOT deleted', [s.userId, path]);
      if (Number(used.rows[0].total) + body.length > config.maxUserBytes) throw new HttpError(507, 'cota de armazenamento do usuário excedida');
      await db.query(
        `INSERT INTO files (user_id, path, type, mode, mtime, size, sha256, content, deleted, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, false, now())
         ON CONFLICT (user_id, path) DO UPDATE SET type = EXCLUDED.type, mode = EXCLUDED.mode, mtime = EXCLUDED.mtime,
           size = EXCLUDED.size, sha256 = EXCLUDED.sha256, content = EXCLUDED.content, deleted = false, updated_at = now()`,
        [s.userId, path, type, mode, mtime, body.length, digest, type === 'file' ? body : null],
      );
      broadcast(s.userId, { type: 'file-changed', path, deleted: false }, String(req.headers['x-client-id'] ?? ''));
      send(res, 200, { path, size: body.length, sha256: digest });
    },

    'DELETE /api/files': async (req, res, { session, url }) => {
      const s = requireUser(session);
      const path = cleanPath(url.searchParams.get('path'));
      if (!path) throw new HttpError(400, 'caminho inválido');
      // tombstones (deleted = true) let other devices learn about the deletion
      const like = path.replace(/[\\%_]/g, (c) => '\\' + c) + '/%';
      const r = await db.query(
        `UPDATE files SET deleted = true, content = NULL, size = 0, updated_at = now(), mtime = $4
         WHERE user_id = $1 AND (path = $2 OR path LIKE $3) AND NOT deleted`,
        [s.userId, path, like, Date.now()],
      );
      broadcast(s.userId, { type: 'file-changed', path, deleted: true }, String(req.headers['x-client-id'] ?? ''));
      send(res, 200, { deleted: r.rowCount });
    },

    'GET /api/settings': async (_req, res, { session }) => {
      const s = requireUser(session);
      const r = await db.query<{ data: unknown }>('SELECT data FROM user_settings WHERE user_id = $1', [s.userId]);
      send(res, 200, r.rows[0]?.data ?? {});
    },

    'PUT /api/settings': async (req, res, { session }) => {
      const s = requireUser(session);
      const data = await readJson<Record<string, unknown>>(req);
      if (!data || typeof data !== 'object' || Array.isArray(data)) throw new HttpError(400, 'esperado um objeto JSON');
      await db.query(
        `INSERT INTO user_settings (user_id, data, updated_at) VALUES ($1, $2::text::jsonb, now())
         ON CONFLICT (user_id) DO UPDATE SET data = EXCLUDED.data, updated_at = now()`,
        [s.userId, JSON.stringify(data)],
      );
      broadcast(s.userId, { type: 'settings-changed' }, String(req.headers['x-client-id'] ?? ''));
      send(res, 200, { ok: true });
    },
  };

  // ------------------------------------------------------------ server
  const server = createServer(async (req, res) => {
    const origin = req.headers.origin;
    const ip = (req.socket.remoteAddress ?? '?').replace(/^::ffff:/, '');
    // security headers on every response
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'");
    res.setHeader('Cross-Origin-Resource-Policy', 'same-site');
    if (origin && config.allowedOrigins.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      res.setHeader('Vary', 'Origin');
    }
    if (req.method === 'OPTIONS') {
      if (!origin || !config.allowedOrigins.includes(origin)) return void res.writeHead(403).end();
      res.writeHead(204, {
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE',
        'Access-Control-Allow-Headers': 'Content-Type, X-CSRF-Token, X-Mtime, X-Mode, X-Type, X-Sha256, X-Client-Id',
        'Access-Control-Max-Age': '600',
      });
      return void res.end();
    }
    try {
      if (!apiLimiter.allow(ip)) throw new HttpError(429, 'muitas requisições');
      const url = new URL(req.url ?? '/', 'http://localhost');
      const handler = routes[`${req.method} ${url.pathname}`];
      if (!handler) throw new HttpError(404, 'rota não encontrada');
      const unsafe = req.method !== 'GET' && req.method !== 'HEAD';
      // CSRF (1): a cross-site request from an unknown origin is refused outright
      if (unsafe && origin && !config.allowedOrigins.includes(origin)) throw new HttpError(403, 'origem não permitida');
      const session = await loadSession(req);
      // CSRF (2): authenticated writes must echo the per-session CSRF token
      const isAuthRoute = url.pathname === '/api/auth/login' || url.pathname === '/api/auth/register';
      if (unsafe && session && !isAuthRoute) {
        const token = req.headers['x-csrf-token'];
        if (typeof token !== 'string' || !safeEqual(token, session.csrf)) throw new HttpError(403, 'token CSRF inválido');
      }
      await handler(req, res, { url, session, ip });
    } catch (err) {
      if (err instanceof HttpError) return send(res, err.status, { error: err.message });
      console.error('[server] erro interno', err);
      send(res, 500, { error: 'erro interno do servidor' });
    }
  });

  // ------------------------------------------------------------ websocket
  const wss = new WebSocketServer({ noServer: true, maxPayload: 4096 });
  server.on('upgrade', async (req, socket, head) => {
    try {
      const url = new URL(req.url ?? '/', 'http://localhost');
      const origin = req.headers.origin;
      if (url.pathname !== '/ws' || (origin && !config.allowedOrigins.includes(origin))) throw new Error('forbidden');
      const session = await loadSession(req);
      if (!session) throw new Error('unauthorized');
      wss.handleUpgrade(req, socket, head, (ws) => {
        const client = (url.searchParams.get('client') ?? '').slice(0, 64);
        const entry = { ws, client };
        let set = sockets.get(session.userId);
        if (!set) sockets.set(session.userId, (set = new Set()));
        set.add(entry);
        ws.send(JSON.stringify({ type: 'hello', username: session.username }));
        ws.on('message', (raw) => {
          // only a tiny ping protocol is accepted from clients
          if (String(raw) === 'ping') ws.send(JSON.stringify({ type: 'pong', time: Date.now() }));
        });
        ws.on('close', () => set!.delete(entry));
      });
    } catch {
      socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
      socket.destroy();
    }
  });
  server.on('close', () => wss.close());

  return { server, config };
}
