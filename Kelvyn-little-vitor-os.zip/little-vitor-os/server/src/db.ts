import { readFile } from 'node:fs/promises';

/** Minimal database interface (implemented with `pg`; tests may inject another driver). */
export interface Db {
  query<T = Record<string, unknown>>(text: string, params?: unknown[]): Promise<{ rows: T[]; rowCount: number }>;
  close(): Promise<void>;
}

export async function createPgDb(url: string): Promise<Db> {
  const { default: pg } = await import('pg');
  // BIGINT (int8) → number: mtimes/sizes fit safely below 2^53
  pg.types.setTypeParser(20, (v: string) => Number(v));
  const pool = new pg.Pool({ connectionString: url, max: 10 });
  return {
    async query<T>(text: string, params: unknown[] = []) {
      const r = await pool.query(text, params as unknown[]);
      return { rows: r.rows as T[], rowCount: r.rowCount ?? 0 };
    },
    close: () => pool.end(),
  };
}

export async function migrate(db: Db): Promise<void> {
  const sql = await readFile(new URL('./schema.sql', import.meta.url), 'utf8');
  // split on ";" at end of line (the schema has no functions/procedures)
  for (const stmt of sql.split(/;\s*\n/).map((s) => s.replace(/--.*$/gm, '').trim()).filter(Boolean)) {
    await db.query(stmt);
  }
}
