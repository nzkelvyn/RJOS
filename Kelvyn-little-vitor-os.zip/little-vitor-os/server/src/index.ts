import { createApp, DEFAULT_CONFIG } from './app.ts';
import { createPgDb, migrate } from './db.ts';

const env = process.env;
const databaseUrl = env.DATABASE_URL ?? 'postgres://lvos:lvos@localhost:5432/lvos';

const db = await createPgDb(databaseUrl);
await migrate(db);

const { server, config } = createApp(db, {
  port: Number(env.PORT ?? DEFAULT_CONFIG.port),
  allowedOrigins: env.ALLOWED_ORIGINS ? env.ALLOWED_ORIGINS.split(',').map((s) => s.trim()).filter(Boolean) : DEFAULT_CONFIG.allowedOrigins,
  cookieSecure: env.COOKIE_SECURE === 'true',
  sessionTtlHours: Number(env.SESSION_TTL_HOURS ?? DEFAULT_CONFIG.sessionTtlHours),
});

server.listen(config.port, () => {
  console.log(`Little Vitor OS server ouvindo em http://localhost:${config.port}`);
  console.log(`Origens permitidas: ${config.allowedOrigins.join(', ')}`);
});

const shutdown = async () => {
  server.close();
  await db.close();
  process.exit(0);
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
