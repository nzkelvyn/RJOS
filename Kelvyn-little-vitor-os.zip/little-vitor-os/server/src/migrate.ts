import { createPgDb, migrate } from './db.ts';

const db = await createPgDb(process.env.DATABASE_URL ?? 'postgres://lvos:lvos@localhost:5432/lvos');
await migrate(db);
console.log('Migração concluída.');
await db.close();
