-- Little Vitor OS — schema (idempotent; run by `npm run migrate` or on startup)

CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE CHECK (username ~ '^[a-z_][a-z0-9_-]{0,31}$'),
  password_hash TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Session tokens are never stored: only their SHA-256.
CREATE TABLE IF NOT EXISTS sessions (
  token_hash  TEXT PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf        TEXT NOT NULL,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at  TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions(user_id);
CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at);

-- One row per file/dir of the user's home (path relative to home, e.g. "/Documents/a.txt").
CREATE TABLE IF NOT EXISTS files (
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  path       TEXT NOT NULL CHECK (path LIKE '/%' AND length(path) <= 4096),
  type       TEXT NOT NULL CHECK (type IN ('file', 'dir')),
  mode       INTEGER NOT NULL DEFAULT 420,
  mtime      BIGINT NOT NULL,
  size       BIGINT NOT NULL DEFAULT 0,
  sha256     TEXT,
  content    BYTEA,
  deleted    BOOLEAN NOT NULL DEFAULT false,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, path)
);

CREATE TABLE IF NOT EXISTS user_settings (
  user_id    INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  data       JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_log (
  id       BIGSERIAL PRIMARY KEY,
  user_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action   TEXT NOT NULL,
  ip       TEXT,
  at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
