/**
 * Integration tests against a REAL PostgreSQL database.
 *   TEST_DATABASE_URL=postgres://user:pass@localhost:5432/lvos_test npm test
 * (the tests drop and recreate their tables). Runs on Node (pg driver) or Bun (Bun.SQL).
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import WebSocket from 'ws';
import { createApp } from '../src/app.ts';
import { createPgDb, migrate, type Db } from '../src/db.ts';

const URL_ = process.env.TEST_DATABASE_URL;
const skip = !URL_ ? 'defina TEST_DATABASE_URL para rodar os testes de integração' : false;

async function connect(url: string): Promise<Db> {
  const bun = (globalThis as { Bun?: { SQL: new (u: string) => { unsafe: (q: string, p?: unknown[]) => Promise<unknown[] & { count: number }>; close: () => Promise<void> } } }).Bun;
  if (bun) {
    const sql = new bun.SQL(url);
    return {
      async query<T>(text: string, params: unknown[] = []) {
        const rows = await sql.unsafe(text, params);
        return { rows: [...rows] as T[], rowCount: rows.count ?? rows.length };
      },
      close: () => sql.close(),
    };
  }
  return createPgDb(url);
}

let db: Db;
let base = '';
let close: () => void = () => {};
const ORIGIN = 'http://localhost:5173';

before(async () => {
  if (skip) return;
  db = await connect(URL_!);
  for (const t of ['audit_log', 'user_settings', 'files', 'sessions', 'users']) await db.query(`DROP TABLE IF EXISTS ${t} CASCADE`);
  await migrate(db);
  const { server } = createApp(db, { allowedOrigins: [ORIGIN], maxUserBytes: 1024 * 1024, authRatePerMinute: 40 });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  close = () => server.close();
});

after(async () => {
  if (skip) return;
  close();
  await db.close();
});

/** Tiny cookie-aware client. */
function client() {
  let cookie = '';
  let csrf = '';
  const call = async (method: string, path: string, opts: { json?: unknown; body?: Uint8Array; headers?: Record<string, string>; noCsrf?: boolean; origin?: string } = {}) => {
    const headers: Record<string, string> = { Origin: opts.origin ?? ORIGIN, ...(opts.headers ?? {}) };
    if (cookie) headers.Cookie = cookie;
    if (csrf && !opts.noCsrf && method !== 'GET') headers['X-CSRF-Token'] = csrf;
    let body: BodyInit | undefined;
    if (opts.json !== undefined) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(opts.json);
    } else if (opts.body) body = opts.body as BodyInit;
    const res = await fetch(base + path, { method, headers, body });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const type = res.headers.get('content-type') ?? '';
    const data = type.includes('json') ? await res.json() : new Uint8Array(await res.arrayBuffer());
    if (data && typeof data === 'object' && 'csrf' in data) csrf = (data as { csrf: string }).csrf;
    return { status: res.status, data: data as any, headers: res.headers };
  };
  return { call, get cookie() { return cookie; } };
}

test('health check and security headers', { skip }, async () => {
  const c = client();
  const r = await c.call('GET', '/api/health');
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.equal(r.headers.get('access-control-allow-origin'), ORIGIN);
});

test('register, login, me, logout — passwords hashed with scrypt', { skip }, async () => {
  const c = client();
  assert.equal((await c.call('POST', '/api/auth/register', { json: { username: 'Bad Name', password: '12345678' } })).status, 400);
  assert.equal((await c.call('POST', '/api/auth/register', { json: { username: 'vitor', password: 'curta' } })).status, 400);
  const reg = await c.call('POST', '/api/auth/register', { json: { username: 'vitor', password: 'senha-forte-1' } });
  assert.equal(reg.status, 201);
  assert.match(c.cookie, /^lvos_sid=/);
  assert.equal((await c.call('POST', '/api/auth/register', { json: { username: 'vitor', password: 'senha-forte-1' } })).status, 409);
  const stored = await db.query<{ password_hash: string }>("SELECT password_hash FROM users WHERE username = 'vitor'");
  assert.match(stored.rows[0].password_hash, /^scrypt\$/);
  assert.ok(!stored.rows[0].password_hash.includes('senha-forte-1'));
  const sess = await db.query<{ token_hash: string }>('SELECT token_hash FROM sessions');
  assert.ok(!sess.rows.some((s) => c.cookie.includes(s.token_hash)), 'raw token never stored');
  assert.equal((await c.call('GET', '/api/auth/me')).data.username, 'vitor');
  assert.equal((await c.call('POST', '/api/auth/logout')).status, 200);
  assert.equal((await c.call('GET', '/api/auth/me')).status, 401);
  const bad = await c.call('POST', '/api/auth/login', { json: { username: 'vitor', password: 'errada' } });
  assert.equal(bad.status, 401);
  const ok = await c.call('POST', '/api/auth/login', { json: { username: 'vitor', password: 'senha-forte-1' } });
  assert.equal(ok.status, 200);
  assert.equal((await c.call('GET', '/api/auth/me')).status, 200);
});

test('CSRF: writes need the session token and an allowed origin', { skip }, async () => {
  const c = client();
  await c.call('POST', '/api/auth/register', { json: { username: 'csrf_user', password: 'senha-forte-1' } });
  const noToken = await c.call('PUT', '/api/files/content?path=/a.txt', { body: new TextEncoder().encode('x'), noCsrf: true });
  assert.equal(noToken.status, 403);
  const evil = await c.call('PUT', '/api/files/content?path=/a.txt', { body: new TextEncoder().encode('x'), origin: 'https://evil.example' });
  assert.equal(evil.status, 403);
  const good = await c.call('PUT', '/api/files/content?path=/a.txt', { body: new TextEncoder().encode('x') });
  assert.equal(good.status, 200);
});

test('files: upload, list, download, path validation, integrity, delete with tombstones, quota', { skip }, async () => {
  const c = client();
  await c.call('POST', '/api/auth/register', { json: { username: 'files_user', password: 'senha-forte-1' } });
  const content = new TextEncoder().encode('olá, sincronização!');
  const up = await c.call('PUT', '/api/files/content?path=/Documents/nota.txt', { body: content, headers: { 'X-Mtime': '1700000000000', 'X-Mode': '420' } });
  assert.equal(up.status, 200);
  await c.call('PUT', '/api/files/content?path=/Documents', { headers: { 'X-Type': 'dir', 'X-Mtime': '1700000000000' } });
  const list = await c.call('GET', '/api/files');
  assert.deepEqual(list.data.map((f: { path: string }) => f.path), ['/Documents', '/Documents/nota.txt']);
  assert.equal(list.data[1].mtime, 1700000000000);
  const down = await c.call('GET', '/api/files/content?path=/Documents/nota.txt');
  assert.equal(new TextDecoder().decode(down.data), 'olá, sincronização!');
  assert.equal((await c.call('PUT', '/api/files/content?path=/../etc/passwd', { body: content })).status, 400);
  assert.equal((await c.call('PUT', '/api/files/content?path=relativo', { body: content })).status, 400);
  assert.equal((await c.call('PUT', '/api/files/content?path=/x.txt', { body: content, headers: { 'X-Sha256': 'deadbeef' } })).status, 422);
  // other users cannot see these files
  const other = client();
  await other.call('POST', '/api/auth/register', { json: { username: 'outro', password: 'senha-forte-1' } });
  assert.equal((await other.call('GET', '/api/files')).data.length, 0);
  assert.equal((await other.call('GET', '/api/files/content?path=/Documents/nota.txt')).status, 404);
  // delete folder → tombstones for the folder and its children
  assert.equal((await c.call('DELETE', '/api/files?path=/Documents')).data.deleted, 2);
  const after = await c.call('GET', '/api/files');
  assert.ok(after.data.every((f: { deleted: boolean }) => f.deleted));
  assert.equal((await c.call('GET', '/api/files/content?path=/Documents/nota.txt')).status, 404);
  // quota (1 MB in this test config)
  assert.equal((await c.call('PUT', '/api/files/content?path=/big.bin', { body: new Uint8Array(1024 * 1024 + 10) })).status, 507);
});

test('settings round-trip', { skip }, async () => {
  const c = client();
  await c.call('POST', '/api/auth/register', { json: { username: 'settings_user', password: 'senha-forte-1' } });
  assert.deepEqual((await c.call('GET', '/api/settings')).data, {});
  await c.call('PUT', '/api/settings', { json: { theme: 'light', accent: '#10b981' } });
  assert.deepEqual((await c.call('GET', '/api/settings')).data, { theme: 'light', accent: '#10b981' });
  assert.equal((await c.call('PUT', '/api/settings', { json: [1, 2] })).status, 400);
});

test('websocket: rejects anonymous, pushes changes to other devices of the same user', { skip }, async () => {
  const wsUrl = base.replace('http', 'ws') + '/ws';
  await assert.rejects(
    new Promise((resolve, reject) => {
      const ws = new WebSocket(wsUrl, { headers: { Origin: ORIGIN } });
      ws.on('open', resolve);
      ws.on('error', reject);
    }),
  );
  const c = client();
  await c.call('POST', '/api/auth/register', { json: { username: 'ws_user', password: 'senha-forte-1' } });
  const ws = new WebSocket(wsUrl + '?client=device-B', { headers: { Origin: ORIGIN, Cookie: c.cookie } });
  const messages: { type: string; path?: string }[] = [];
  await new Promise<void>((resolve, reject) => {
    ws.on('message', (m) => {
      messages.push(JSON.parse(String(m)));
      if (messages.length === 1) resolve();
    });
    ws.on('error', reject);
  });
  assert.equal(messages[0].type, 'hello');
  // upload from "device A" → device B is notified; an upload tagged as B is not echoed to B
  await c.call('PUT', '/api/files/content?path=/ws.txt', { body: new TextEncoder().encode('1'), headers: { 'X-Client-Id': 'device-A' } });
  await c.call('PUT', '/api/files/content?path=/self.txt', { body: new TextEncoder().encode('1'), headers: { 'X-Client-Id': 'device-B' } });
  await new Promise((r) => setTimeout(r, 300));
  const changed = messages.filter((m) => m.type === 'file-changed').map((m) => m.path);
  assert.deepEqual(changed, ['/ws.txt']);
  ws.close();
});

test('rate limiting on auth endpoints', { skip }, async () => {
  const c = client();
  let last = 0;
  for (let i = 0; i < 45; i++) last = (await c.call('POST', '/api/auth/login', { json: { username: 'ninguem', password: 'x' } })).status;
  assert.equal(last, 429);
});
