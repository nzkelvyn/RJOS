import { useCallback, useEffect, useMemo, useState } from 'react';
import type { Kernel } from './kernel/kernel';
import { BootScreen } from './boot/BootScreen';
import { SetupWizard } from './boot/SetupWizard';
import { LockScreen, LoginScreen } from './boot/LoginScreen';
import { Desktop } from './desktop/Desktop';
import { Session } from './desktop/session';
import { SessionContext } from './desktop/sessionContext';
import { KernelContext, useStore } from './ui/hooks';
import { cachedTheme, useApplyTheme } from './ui/theme';
import { DEFAULT_USER_SETTINGS } from './core/settings/settings';
import { startSync, stopSync } from './core/sync/syncClient';

type Phase = 'boot' | 'setup' | 'login' | 'desktop';
const SESSION_KEY = 'lvos:session';

function readSessionUser(): string | null {
  try {
    return sessionStorage.getItem(SESSION_KEY);
  } catch {
    return null;
  }
}

function writeSessionUser(u: string | null): void {
  try {
    if (u) sessionStorage.setItem(SESSION_KEY, u);
    else sessionStorage.removeItem(SESSION_KEY);
  } catch {
    /* ignore */
  }
}

export function App({ kernel }: { kernel: Kernel }) {
  const [phase, setPhase] = useState<Phase>('boot');
  const [bootStep, setBootStep] = useState(0);
  const [bootError, setBootError] = useState<string | null>(null);
  const [sessionKey, setSessionKey] = useState(0);
  const userSettings = useStore(kernel.settings.user);
  const sessionState = useStore(kernel.users.state);
  const loggedIn = phase === 'desktop' && !!sessionState.user;

  // theme: user's settings when logged in; cached theme on boot/login screens
  const cached = useMemo(cachedTheme, []);
  useApplyTheme(loggedIn || phase === 'setup' ? userSettings : { ...DEFAULT_USER_SETTINGS, ...cached });

  useEffect(() => {
    let cancelled = false;
    const started = performance.now();
    kernel
      .boot((_, i) => !cancelled && setBootStep(i))
      .then(async () => {
        // keep the boot screen visible briefly so the animation is readable
        const minBoot = 900 - (performance.now() - started);
        if (minBoot > 0) await new Promise((r) => setTimeout(r, minBoot));
        if (cancelled) return;
        setBootStep(99);
        if (!kernel.settings.system.get().setupDone) {
          kernel.settings.user.set({ ...kernel.settings.user.get(), theme: cached.theme, accent: cached.accent });
          setPhase('setup');
          return;
        }
        const remembered = readSessionUser();
        if (remembered && (await kernel.users.resume(remembered))) {
          await kernel.startSession();
          setPhase('desktop');
          return;
        }
        setPhase('login');
      })
      .catch((err: Error) => {
        console.error(err);
        setBootError(err.message || String(err));
      });
    return () => {
      cancelled = true;
    };
  }, [kernel, cached]);

  const session = useMemo(() => (phase === 'desktop' ? new Session(kernel) : null), [kernel, phase, sessionKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const enterDesktop = useCallback(async () => {
    await kernel.startSession();
    writeSessionUser(kernel.users.current?.username ?? null);
    setSessionKey((k) => k + 1);
    setPhase('desktop');
  }, [kernel]);

  const logout = useCallback(async () => {
    session?.wm.windows.forEach((w) => w.pid && kernel.procs.exit(w.pid));
    session?.wm.closeAll();
    stopSync();
    await kernel.endSession();
    writeSessionUser(null);
    setPhase('login');
  }, [kernel, session]);

  // optional cloud sync (Phase 7) — only when the user enabled it
  useEffect(() => {
    if (!loggedIn || !userSettings.syncEnabled || !userSettings.syncServer) return;
    startSync(kernel, userSettings.syncServer);
    return () => stopSync();
  }, [kernel, loggedIn, userSettings.syncEnabled, userSettings.syncServer]);

  // flush settings when the tab is hidden/closed
  useEffect(() => {
    const flush = () => void kernel.settings.flush();
    window.addEventListener('pagehide', flush);
    document.addEventListener('visibilitychange', flush);
    return () => {
      window.removeEventListener('pagehide', flush);
      document.removeEventListener('visibilitychange', flush);
    };
  }, [kernel]);

  if (bootError || phase === 'boot') return <BootScreen step={bootStep} error={bootError} verbose={kernel.freshInstall || bootStep > 2} />;

  return (
    <KernelContext.Provider value={kernel}>
      {phase === 'setup' && <SetupWizard kernel={kernel} onDone={() => void enterDesktop()} />}
      {phase === 'login' && <LoginScreen kernel={kernel} onLogin={() => void enterDesktop()} />}
      {phase === 'desktop' && session && sessionState.user && (
        <SessionContext.Provider value={session}>
          <Desktop key={sessionKey} onLogout={() => void logout()} locked={!!sessionState.session?.locked} />
          {sessionState.session?.locked && <LockScreen kernel={kernel} onUnlock={() => undefined} onSwitchUser={() => void logout()} />}
        </SessionContext.Provider>
      )}
    </KernelContext.Provider>
  );
}
