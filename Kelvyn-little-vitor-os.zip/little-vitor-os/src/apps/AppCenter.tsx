import { useEffect, useMemo, useState } from 'react';
import type { AppProps } from './registry';
import { useKernel, useStore } from '../ui/hooks';
import { Icon } from '../ui/icons';
import { Badge, Card, Empty, Spinner, cx, formatDate } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { PERMISSIONS, type PackageManifest } from '../core/packages/manifest';
import type { InstallPlan, Repository } from '../core/packages/lvp';
import { importFiles, pickFiles } from '../ui/blob';

type Tab = 'explore' | 'installed' | 'updates' | 'repos' | 'log';

export default function AppCenter({ args }: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const installed = useStore(kernel.lvp.installed);
  const [tab, setTab] = useState<Tab>('explore');
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [detail, setDetail] = useState<string | null>(null);
  const [, setTick] = useState(0);
  const isAdmin = kernel.users.isAdmin();
  const available = useMemo(() => kernel.lvp.available(), [kernel, installed]); // eslint-disable-line react-hooks/exhaustive-deps
  const upgradable = kernel.lvp.upgradable();

  const notify = (title: string, body: string, ok: boolean) => kernel.notifications.push({ app: 'appcenter', appName: 'Central de Apps', title, body, level: ok ? 'success' : 'error' });

  const confirmPlan = (plan: InstallPlan) =>
    session.confirm(
      'Autorizar instalação',
      'Os pacotes abaixo serão instalados. Apps rodam isolados e só acessam o que está listado.',
      {
        confirmLabel: 'Instalar',
        details: plan.steps.flatMap((s) => [
          `${s.manifest.icon} ${s.manifest.displayName} (${s.manifest.name}) ${s.upgradeFrom ? s.upgradeFrom + ' → ' : ''}${s.manifest.version}${s.auto ? ' — dependência' : ''}`,
          ...s.manifest.permissions.map((p) => `      ↳ ${PERMISSIONS[p]}`),
        ]),
      },
    );

  const install = async (names: string[], local?: PackageManifest) => {
    setBusy(names.join(','));
    try {
      const plan = await kernel.lvp.install(names, { confirm: confirmPlan, local });
      if (plan.steps.length) setTab('installed');
    } catch (err) {
      if (!/cancelada/.test((err as Error).message)) notify('Falha na instalação', (err as Error).message, false);
    } finally {
      setBusy(null);
    }
  };

  const remove = async (name: string) => {
    const deps = kernel.lvp.dependents(name);
    if (!(await session.confirm(`Remover ${name}?`, deps.length ? `Atenção: ${deps.join(', ')} depende(m) deste pacote.` : undefined, { confirmLabel: 'Remover', danger: true }))) return;
    setBusy(name);
    try {
      session.wm.windows.filter((w) => w.appId === 'pkg:' + name).forEach((w) => session.closeWindow(w.id));
      await kernel.lvp.remove(name, { force: deps.length > 0 });
      const orphans = kernel.lvp.orphans();
      if (orphans.length && (await session.confirm('Remover dependências não usadas?', orphans.join(', '), { confirmLabel: 'Remover' }))) await kernel.lvp.autoremove();
      notify(`${name} removido`, 'O pacote foi desinstalado.', true);
    } catch (err) {
      notify('Falha ao remover', (err as Error).message, false);
    } finally {
      setBusy(null);
    }
  };

  const installLocal = async (path: string) => {
    try {
      const m = await kernel.lvp.readLocal(path);
      await install([m.name], m);
    } catch (err) {
      notify('Pacote local inválido', (err as Error).message, false);
    }
  };

  useEffect(() => {
    if (args.install) void installLocal(args.install);
  }, [args.install, args._t]); // eslint-disable-line react-hooks/exhaustive-deps

  const query = q.trim().toLowerCase();
  const shown = available.filter(({ manifest: m }) => m.entry && (!query || `${m.name} ${m.displayName} ${m.description} ${m.category}`.toLowerCase().includes(query)));
  const detailPkg = detail ? available.find((a) => a.manifest.name === detail) : null;

  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 flex-wrap items-center gap-1 border-b border-line bg-surface-2 px-3 py-2">
        {([['explore', 'Explorar', 'store'], ['installed', `Instalados (${installed.length})`, 'package'], ['updates', `Atualizações${upgradable.length ? ` (${upgradable.length})` : ''}`, 'refresh'], ['repos', 'Repositórios', 'link'], ['log', 'Log', 'history']] as [Tab, string, string][]).map(([id, label, icon]) => (
          <button key={id} className={cx('flex h-8 items-center gap-1.5 rounded-lg px-3 text-[0.88rem]', tab === id ? 'bg-accent text-accent-fg' : 'hover:bg-hover')} onClick={() => { setTab(id); setDetail(null); }}>
            <Icon name={icon} size={15} />{label}
          </button>
        ))}
        {tab === 'explore' && <input className="field ml-auto h-8 w-52" placeholder="Buscar pacotes" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar pacotes" />}
      </div>
      {!isAdmin && <div className="border-b border-line bg-warning/15 px-4 py-2 text-[0.85rem]">Você não é administrador: pode ver os pacotes, mas só administradores (grupo sudo) instalam ou removem.</div>}
      <div className="min-h-0 flex-1 overflow-auto p-4">
        {tab === 'explore' && !detailPkg && (
          <>
            <div className="mb-4 flex items-center justify-between rounded-2xl p-5 text-white" style={{ background: 'linear-gradient(120deg, var(--accent), #0ea5e9)' }}>
              <div>
                <div className="text-[1.3rem] font-semibold">LVP — Little Vitor Package Manager</div>
                <div className="text-[0.9rem] opacity-90">Apps verificados por SHA-256, isolados em sandbox. Também pelo terminal: <code className="rounded bg-black/20 px-1">sudo lvp install nome</code></div>
              </div>
              <button className="btn shrink-0" disabled={!isAdmin} onClick={async () => {
                const files = await pickFiles('.lvp,application/json', false);
                if (!files?.length) return;
                const home = kernel.users.current?.home ?? '/';
                const r = await importFiles(kernel, files, `${home}/Downloads`);
                if (r.imported[0]) await installLocal(r.imported[0]);
              }}><Icon name="upload" size={15} />Instalar arquivo .lvp</button>
            </div>
            {!shown.length && <Empty icon="search" title="Nenhum pacote encontrado" />}
            <div className="grid grid-cols-[repeat(auto-fill,minmax(250px,1fr))] gap-3">
              {shown.map(({ manifest: m, repository }) => {
                const inst = installed.find((p) => p.name === m.name);
                return (
                  <div key={m.name} className="flex flex-col gap-2 rounded-xl border border-line bg-surface-2 p-3" data-testid={`pkg-${m.name}`}>
                    <button className="flex items-start gap-3 text-left" onClick={() => setDetail(m.name)}>
                      <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-surface-3 text-[1.7rem]">{m.icon}</div>
                      <div className="min-w-0">
                        <div className="font-medium">{m.displayName}</div>
                        <div className="text-[0.78rem] text-muted">{m.category} · {m.version} · {repository}</div>
                      </div>
                    </button>
                    <div className="line-clamp-2 min-h-[2.5em] text-[0.84rem] text-muted">{m.description}</div>
                    <div className="mt-auto flex items-center gap-2">
                      {inst ? (
                        <>
                          <button className="btn btn-primary flex-1" onClick={() => session.launch('pkg:' + m.name)}>Abrir</button>
                          <button className="btn" disabled={!isAdmin || !!busy} onClick={() => void remove(m.name)}>Remover</button>
                        </>
                      ) : (
                        <button className="btn btn-primary flex-1" disabled={!isAdmin || !!busy} onClick={() => void install([m.name])} data-testid={`install-${m.name}`}>
                          {busy === m.name ? <Spinner size={15} /> : <><Icon name="download" size={15} />Instalar</>}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
        {tab === 'explore' && detailPkg && (
          <div className="max-w-2xl">
            <button className="btn btn-ghost mb-3" onClick={() => setDetail(null)}><Icon name="arrow-left" size={15} />Voltar</button>
            <div className="mb-4 flex items-center gap-4">
              <div className="grid h-16 w-16 place-items-center rounded-2xl bg-surface-3 text-[2.2rem]">{detailPkg.manifest.icon}</div>
              <div>
                <div className="text-[1.3rem] font-semibold">{detailPkg.manifest.displayName}</div>
                <div className="text-muted">{detailPkg.manifest.author} · licença {detailPkg.manifest.license}</div>
              </div>
            </div>
            <p className="mb-4">{detailPkg.manifest.description}</p>
            <Card className="py-2 text-[0.88rem]">
              {[
                ['Pacote', detailPkg.manifest.name],
                ['Versão', detailPkg.manifest.version],
                ['Repositório', detailPkg.repository],
                ['Dependências', Object.entries(detailPkg.manifest.dependencies).map(([k, v]) => `${k} ${v}`).join(', ') || 'nenhuma'],
                ['Permissões', detailPkg.manifest.permissions.map((p) => PERMISSIONS[p]).join(' · ') || 'nenhuma'],
                ['SHA-256', detailPkg.manifest.sha256],
              ].map(([k, v]) => (
                <div key={k} className="flex gap-3 border-b border-line py-1.5 last:border-0"><span className="w-28 shrink-0 text-muted">{k}</span><span className="selectable min-w-0 break-all">{v}</span></div>
              ))}
            </Card>
          </div>
        )}
        {tab === 'installed' && (
          installed.length ? (
            <Card className="py-1">
              {installed.map((p) => (
                <div key={p.name} className="flex items-center gap-3 border-b border-line py-2.5 last:border-0">
                  <div className="grid h-10 w-10 place-items-center rounded-lg bg-surface-3 text-[1.4rem]">{p.icon}</div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">{p.displayName} {p.auto && <Badge>dependência</Badge>} {!p.entry && <Badge>biblioteca</Badge>}</div>
                    <div className="text-[0.78rem] text-muted">{p.name} {p.version} · {p.repository} · instalado {formatDate(p.installedAt)}</div>
                  </div>
                  <button className="btn" onClick={async () => notify(`Verificação de ${p.name}`, (await kernel.lvp.verify(p.name)) ? 'Integridade OK: os arquivos conferem com o SHA-256 registrado.' : 'FALHOU: os arquivos foram alterados.', true)}>Verificar</button>
                  {p.entry && <button className="btn" onClick={() => session.launch('pkg:' + p.name)}>Abrir</button>}
                  <button className="btn" disabled={!isAdmin || !!busy} onClick={() => void remove(p.name)}>Remover</button>
                </div>
              ))}
            </Card>
          ) : (
            <Empty icon="package" title="Nenhum pacote instalado">Explore o repositório e instale seu primeiro app.</Empty>
          )
        )}
        {tab === 'updates' && (
          <div>
            <div className="mb-3 flex gap-2">
              <button className="btn" disabled={!!busy} onClick={async () => {
                setBusy('update');
                const r = await kernel.lvp.update();
                setBusy(null);
                setTick((t) => t + 1);
                notify('Repositórios atualizados', r.map((x) => (x.error ? `${x.repo}: erro — ${x.error}` : `${x.repo}: ${x.packages} pacotes`)).join('\n'), !r.some((x) => x.error));
              }}><Icon name="refresh" size={15} />Procurar atualizações</button>
              {upgradable.length > 0 && <button className="btn btn-primary" disabled={!isAdmin || !!busy} onClick={() => void install(upgradable.map((u) => u.name))}>Atualizar tudo</button>}
            </div>
            {!upgradable.length ? <Empty icon="check-circle" title="Tudo atualizado" /> : (
              <Card className="py-1">
                {upgradable.map((u) => (
                  <div key={u.name} className="flex items-center justify-between border-b border-line py-2 last:border-0"><span>{u.name}</span><span className="text-muted">{u.from} → {u.to}</span></div>
                ))}
              </Card>
            )}
          </div>
        )}
        {tab === 'repos' && <Repos isAdmin={isAdmin} />}
        {tab === 'log' && <LogView />}
      </div>
    </div>
  );
}

function Repos({ isAdmin }: { isAdmin: boolean }) {
  const kernel = useKernel();
  const session = useSession();
  const [repos, setRepos] = useState<Repository[]>([]);
  const refresh = () => kernel.lvp.repositories().then(setRepos);
  useEffect(() => void refresh(), []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="max-w-2xl space-y-3">
      <Card className="py-1">
        {repos.map((r) => (
          <div key={r.name} className="flex items-center gap-3 border-b border-line py-2.5 last:border-0">
            <Icon name="link" size={16} className="text-muted" />
            <div className="min-w-0 flex-1"><div>{r.name}</div><div className="truncate text-[0.78rem] text-muted">{r.url === 'builtin' ? 'embutido no sistema' : r.url}</div></div>
            {r.name !== 'core' && <button className="btn btn-ghost" disabled={!isAdmin} onClick={async () => { await kernel.lvp.removeRepository(r.name); await refresh(); }}>Remover</button>}
          </div>
        ))}
      </Card>
      <button className="btn" disabled={!isAdmin} onClick={async () => {
        const name = await session.prompt('Nome do repositório', 'meu-repo');
        if (!name) return;
        const url = await session.prompt('URL do índice (https)', 'https://exemplo.com/lvp/index.json');
        if (!url) return;
        try {
          await kernel.lvp.addRepository(name, url);
          await kernel.lvp.update();
          await refresh();
        } catch (err) {
          await session.alert('Não foi possível adicionar', (err as Error).message);
        }
      }}><Icon name="plus" size={15} />Adicionar repositório</button>
      <p className="text-[0.82rem] text-muted">Um repositório é um arquivo JSON <code>{'{ "packages": [manifesto, …] }'}</code> servido por HTTPS com CORS liberado. Cada manifesto é validado e tem o SHA-256 conferido; pacotes adulterados são ignorados.</p>
    </div>
  );
}

function LogView() {
  const kernel = useKernel();
  const [lines, setLines] = useState<string[] | null>(null);
  useEffect(() => void kernel.lvp.logLines(300).then(setLines), [kernel]);
  if (!lines) return <Spinner />;
  return <pre className="selectable overflow-auto rounded-xl bg-surface-2 p-3 font-mono text-[0.78rem]">{lines.length ? lines.join('\n') : 'Log vazio.'}</pre>;
}
