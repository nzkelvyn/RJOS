import { useEffect, useState } from 'react';
import type { AppProps } from './registry';
import { useKernel } from '../ui/hooks';
import { Icon } from '../ui/icons';
import { Empty, Spinner, ToolButton, Toolbar } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { basename, dirname } from '../core/vfs/path';
import { formatBytes } from '../core/shell/args';
import { extractZip, listZip, zipPaths, type ZipEntry } from './zip';

export default function ArchiveManager({ windowId, args }: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const [path, setPath] = useState<string | null>(args.path ?? null);
  const [entries, setEntries] = useState<ZipEntry[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    if (args.path) setPath(args.path);
  }, [args.path, args._t]);

  useEffect(() => {
    if (!path) return;
    session.wm.setTitle(windowId, `${basename(path)} — Arquivos Compactados`);
    setEntries(null);
    setError(null);
    setSelected([]);
    kernel.vfs.readFile(path).then(listZip).then(setEntries).catch((e: Error) => setError(`Não é um .zip válido: ${e.message}`));
  }, [kernel, path, session, windowId]);

  const extract = async (only?: string[]) => {
    if (!path) return;
    const dest = await session.prompt('Extrair para a pasta', `${dirname(path)}/${basename(path).replace(/\.zip$/i, '')}`, { confirmLabel: 'Extrair' });
    if (!dest) return;
    setBusy(true);
    try {
      const n = await extractZip(kernel, await kernel.vfs.readFile(path), dest, only);
      setMsg(`${n} arquivo(s) extraído(s) em ${dest}`);
      kernel.notifications.push({ app: 'archive', appName: 'Arquivos Compactados', title: 'Extração concluída', body: `${n} arquivo(s) em ${dest}`, level: 'success' });
    } catch (e) {
      setMsg(`Erro: ${(e as Error).message}`);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (args.extract && entries) void extract();
  }, [entries]); // eslint-disable-line react-hooks/exhaustive-deps

  const create = async () => {
    const home = kernel.users.current?.home ?? '/';
    const src = await session.prompt('Pasta ou arquivo para compactar', `${home}/Documents`, { confirmLabel: 'Continuar' });
    if (!src) return;
    if (!kernel.vfs.exists(src)) return session.alert('Não encontrado', src);
    const out = await session.prompt('Salvar .zip em', `${dirname(src)}/${basename(src)}.zip`, { confirmLabel: 'Compactar' });
    if (!out) return;
    setBusy(true);
    try {
      await kernel.vfs.writeFile(kernel.vfs.uniquePath(out), await zipPaths(kernel, [src]));
      setPath(out);
    } catch (e) {
      setMsg(`Erro: ${(e as Error).message}`);
    } finally {
      setBusy(false);
    }
  };

  const total = entries?.reduce((a, e) => a + e.size, 0) ?? 0;
  return (
    <div className="flex h-full flex-col">
      <Toolbar>
        <ToolButton icon="folder-open" label="Abrir .zip" onClick={async () => { const p = await session.prompt('Abrir arquivo .zip', `${kernel.users.current?.home ?? ''}/`); if (p) setPath(p); }} />
        <button className="btn h-8" onClick={() => void create()} disabled={busy}><Icon name="archive" size={15} />Novo .zip</button>
        <button className="btn btn-primary h-8" disabled={!entries || busy} onClick={() => void extract()}><Icon name="download" size={15} />Extrair tudo</button>
        <button className="btn h-8" disabled={!selected.length || busy} onClick={() => void extract(selected)}>Extrair selecionados ({selected.length})</button>
        {busy && <Spinner size={18} />}
      </Toolbar>
      {msg && <div className="border-b border-line px-3 py-1.5 text-[0.85rem]">{msg}</div>}
      <div className="min-h-0 flex-1 overflow-auto">
        {!path ? <Empty icon="archive" title="Nenhum arquivo aberto">Abra um .zip pelo gerenciador de arquivos ou crie um novo.</Empty>
          : error ? <Empty icon="alert" title="Erro">{error}</Empty>
          : !entries ? <div className="grid h-full place-items-center"><Spinner /></div>
          : (
            <table className="w-full text-[0.86rem]">
              <thead className="sticky top-0 bg-surface text-left text-muted"><tr><th className="w-8" /><th className="px-2 py-1.5 font-medium">Nome</th><th className="px-2 py-1.5 font-medium">Tamanho</th><th className="px-2 py-1.5 font-medium">Data</th></tr></thead>
              <tbody>
                {entries.map((e) => (
                  <tr key={e.name} className="border-t border-line hover:bg-hover">
                    <td className="px-2"><input type="checkbox" checked={selected.includes(e.name)} onChange={(ev) => setSelected((s) => (ev.target.checked ? [...s, e.name] : s.filter((x) => x !== e.name)))} aria-label={`Selecionar ${e.name}`} /></td>
                    <td className="flex items-center gap-2 px-2 py-1.5" style={{ paddingLeft: 8 + e.name.split('/').length * 10 - 10 }}><Icon name={e.dir ? 'folder' : 'file'} size={15} className="text-muted" />{basename(e.name)}</td>
                    <td className="px-2 py-1.5 text-muted">{e.dir ? '—' : formatBytes(e.size)}</td>
                    <td className="px-2 py-1.5 text-muted">{e.date.toLocaleDateString('pt-BR')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
      </div>
      {entries && <footer className="border-t border-line px-3 py-1.5 text-[0.78rem] text-muted">{entries.length} entradas · {formatBytes(total)} descompactado · extração protegida contra caminhos maliciosos e zip-bomb</footer>}
    </div>
  );
}
