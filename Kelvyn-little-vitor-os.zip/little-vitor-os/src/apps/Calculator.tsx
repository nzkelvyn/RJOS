import { useEffect, useState } from 'react';
import type { AppProps } from './registry';
import { cx } from '../ui/components';
import { evaluate } from './calculatorLogic';

function fmt(n: number): string {
  if (!Number.isFinite(n)) return n > 0 ? '∞' : n < 0 ? '-∞' : 'Erro';
  return String(+n.toPrecision(12)).replace('.', ',');
}

export default function Calculator(_: AppProps) {
  const [expr, setExpr] = useState('');
  const [result, setResult] = useState<string>('0');
  const [history, setHistory] = useState<string[]>([]);
  const [sci, setSci] = useState(false);
  const [deg, setDeg] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!expr) return setResult('0');
    try {
      setResult(fmt(evaluate(expr.replace(/,/g, '.'), deg)));
      setError(false);
    } catch {
      /* keep previous preview while typing */
    }
  }, [expr, deg]);

  const press = (k: string) => {
    if (k === 'C') {
      setExpr('');
      setError(false);
      return;
    }
    if (k === '⌫') return setExpr((e) => e.slice(0, -1));
    if (k === '=') {
      try {
        const v = fmt(evaluate(expr.replace(/,/g, '.'), deg));
        setHistory((h) => [`${expr} = ${v}`, ...h].slice(0, 20));
        setExpr(v === 'Erro' ? '' : v.replace(',', '.'));
        setResult(v);
        setError(false);
      } catch {
        setError(true);
        setResult('Erro');
      }
      return;
    }
    setExpr((e) => e + k);
  };

  const keys = ['C', '(', ')', '÷', '7', '8', '9', '×', '4', '5', '6', '-', '1', '2', '3', '+', '0', '.', '⌫', '='];
  const sciKeys = ['sin(', 'cos(', 'tan(', '^', 'sqrt(', 'ln(', 'log(', '!', 'π', 'e', '%', 'abs('];

  return (
    <div
      className="flex h-full flex-col bg-surface p-3 outline-none"
      tabIndex={0}
      onKeyDown={(e) => {
        const map: Record<string, string> = { Enter: '=', '=': '=', Backspace: '⌫', Escape: 'C', '*': '×', '/': '÷' };
        const k = map[e.key] ?? (/^[\d+\-().^%!,]$/.test(e.key) ? e.key.replace(',', '.') : null);
        if (k) {
          e.preventDefault();
          press(k);
        }
      }}
    >
      <div className="mb-2 flex items-center gap-2 text-[0.8rem]">
        <button className={cx('rounded-md px-2 py-0.5', sci ? 'bg-accent text-accent-fg' : 'bg-surface-3')} onClick={() => setSci((s) => !s)}>Científica</button>
        {sci && <button className="rounded-md bg-surface-3 px-2 py-0.5" onClick={() => setDeg((d) => !d)}>{deg ? 'GRAUS' : 'RAD'}</button>}
      </div>
      <div className="mb-3 rounded-xl bg-surface-2 p-3 text-right">
        <div className="selectable min-h-5 truncate font-mono text-[0.9rem] text-muted" data-testid="calc-expr">{expr.replace(/\./g, ',') || ' '}</div>
        <div className={cx('selectable truncate text-[2.1rem] font-light tabular-nums', error && 'text-danger')} data-testid="calc-result">{result}</div>
      </div>
      {sci && (
        <div className="mb-1.5 grid grid-cols-4 gap-1.5">
          {sciKeys.map((k) => <button key={k} className="btn h-8 text-[0.85rem]" onClick={() => press(k)}>{k.replace('(', '')}</button>)}
        </div>
      )}
      <div className="grid flex-1 grid-cols-4 gap-1.5">
        {keys.map((k) => (
          <button key={k} className={cx('btn h-auto min-h-10 text-[1.15rem]', k === '=' && 'btn-primary', '÷×-+'.includes(k) && 'text-accent')} onClick={() => press(k)} aria-label={k === '⌫' ? 'Apagar' : k}>{k === '.' ? ',' : k}</button>
        ))}
      </div>
      {history.length > 0 && (
        <div className="mt-2 max-h-20 overflow-auto text-right font-mono text-[0.78rem] text-muted">
          {history.map((h, i) => <div key={i} className="cursor-default hover:text-fg" onClick={() => setExpr(h.split(' = ')[1].replace(',', '.'))}>{h.replace(/\./g, ',')}</div>)}
        </div>
      )}
    </div>
  );
}
