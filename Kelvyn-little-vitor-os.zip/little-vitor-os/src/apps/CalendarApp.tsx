import { useEffect, useState } from 'react';
import type { AppProps } from './registry';
import { useKernel } from '../ui/hooks';
import { Icon } from '../ui/icons';
import { Toggle, cx } from '../ui/components';
import { loadEvents, saveEvents, dateKey, type CalendarEvent } from './calendarStore';
import { uid } from '../core/vfs/vfs';

const COLORS = ['#7c6cff', '#ef4444', '#10b981', '#f59e0b', '#0ea5e9', '#ec4899'];
const WEEK = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

export default function CalendarApp(_: AppProps) {
  const kernel = useKernel();
  const today = new Date();
  const [cursor, setCursor] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [selected, setSelected] = useState(dateKey(today));
  const [editing, setEditing] = useState<CalendarEvent | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadEvents(kernel).then(setEvents).catch((e: Error) => setError(e.message));
  }, [kernel]);

  const persist = async (next: CalendarEvent[]) => {
    setEvents(next);
    try {
      await saveEvents(kernel, next);
    } catch (e) {
      setError((e as Error).message);
    }
  };

  const first = cursor.getDay();
  const days = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
  const cells = Array.from({ length: Math.ceil((first + days) / 7) * 7 }, (_, i) => {
    const d = i - first + 1;
    return d >= 1 && d <= days ? new Date(cursor.getFullYear(), cursor.getMonth(), d) : null;
  });
  const dayEvents = (k: string) => events.filter((e) => e.date === k).sort((a, b) => a.time.localeCompare(b.time));

  const newEvent = (date = selected) => setEditing({ id: uid(), title: '', date, time: '09:00', color: COLORS[0], notes: '', reminder: true });

  return (
    <div className="flex h-full max-md:flex-col">
      <div className="flex min-w-0 flex-1 flex-col p-4">
        <div className="mb-3 flex items-center gap-2">
          <h2 className="flex-1 text-[1.3rem] font-semibold capitalize">{cursor.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</h2>
          <button className="btn" onClick={() => { setCursor(new Date(today.getFullYear(), today.getMonth(), 1)); setSelected(dateKey(today)); }}>Hoje</button>
          <button className="btn btn-icon" aria-label="Mês anterior" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}><Icon name="chevron-left" size={16} /></button>
          <button className="btn btn-icon" aria-label="Próximo mês" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}><Icon name="chevron-right" size={16} /></button>
          <button className="btn btn-primary" onClick={() => newEvent()}><Icon name="plus" size={15} />Evento</button>
        </div>
        <div className="grid grid-cols-7 text-center text-[0.78rem] text-muted">{WEEK.map((w) => <div key={w} className="py-1">{w}</div>)}</div>
        <div className="grid min-h-0 flex-1 auto-rows-fr grid-cols-7 gap-px overflow-hidden rounded-xl border border-line bg-line">
          {cells.map((d, i) => {
            if (!d) return <div key={i} className="bg-surface-2" />;
            const k = dateKey(d);
            const isToday = k === dateKey(today);
            const evs = dayEvents(k);
            return (
              <button key={i} className={cx('flex min-h-14 flex-col items-stretch gap-0.5 bg-surface p-1 text-left', selected === k && 'ring-2 ring-inset ring-accent')} onClick={() => setSelected(k)} onDoubleClick={() => newEvent(k)}>
                <span className={cx('grid h-6 w-6 place-items-center rounded-full text-[0.82rem]', isToday && 'bg-accent text-accent-fg')}>{d.getDate()}</span>
                {evs.slice(0, 3).map((e) => <span key={e.id} className="truncate rounded px-1 text-[0.7rem] text-white" style={{ background: e.color }}>{e.time} {e.title}</span>)}
                {evs.length > 3 && <span className="text-[0.7rem] text-muted">+{evs.length - 3}</span>}
              </button>
            );
          })}
        </div>
        {error && <div className="mt-2 text-[0.85rem]" style={{ color: 'var(--danger)' }}>{error}</div>}
      </div>
      <aside className="w-72 shrink-0 overflow-auto border-l border-line bg-surface-2 p-4 max-md:w-full max-md:border-l-0 max-md:border-t">
        {editing ? (
          <form className="space-y-3" onSubmit={(e) => {
            e.preventDefault();
            if (!editing.title.trim()) return setError('Dê um título ao evento.');
            setError(null);
            const exists = events.some((x) => x.id === editing.id);
            void persist(exists ? events.map((x) => (x.id === editing.id ? { ...editing, notified: false } : x)) : [...events, editing]);
            setSelected(editing.date);
            setEditing(null);
          }}>
            <div className="font-semibold">{events.some((x) => x.id === editing.id) ? 'Editar evento' : 'Novo evento'}</div>
            <input autoFocus className="field w-full" placeholder="Título" value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} />
            <div className="flex gap-2">
              <input type="date" className="field flex-1" value={editing.date} onChange={(e) => setEditing({ ...editing, date: e.target.value })} required />
              <input type="time" className="field w-28" value={editing.time} onChange={(e) => setEditing({ ...editing, time: e.target.value })} />
            </div>
            <div className="flex gap-1.5">{COLORS.map((c) => <button type="button" key={c} aria-label={`Cor ${c}`} className="h-6 w-6 rounded-full" style={{ background: c, outline: editing.color === c ? '2px solid var(--fg)' : 'none', outlineOffset: 2 }} onClick={() => setEditing({ ...editing, color: c })} />)}</div>
            <textarea className="field h-24 w-full" placeholder="Notas" value={editing.notes} onChange={(e) => setEditing({ ...editing, notes: e.target.value })} />
            <label className="flex items-center justify-between text-[0.88rem]">Lembrete (notificação) <Toggle checked={editing.reminder} onChange={(reminder) => setEditing({ ...editing, reminder })} /></label>
            <div className="flex gap-2">
              <button className="btn btn-primary flex-1" type="submit">Salvar</button>
              <button className="btn" type="button" onClick={() => setEditing(null)}>Cancelar</button>
            </div>
            {events.some((x) => x.id === editing.id) && (
              <button className="btn btn-ghost w-full" type="button" style={{ color: 'var(--danger)' }} onClick={() => { void persist(events.filter((x) => x.id !== editing.id)); setEditing(null); }}>Excluir evento</button>
            )}
          </form>
        ) : (
          <>
            <div className="mb-2 font-semibold capitalize">{new Date(selected + 'T12:00').toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
            {!dayEvents(selected).length && <p className="text-[0.88rem] text-muted">Nenhum evento. Clique duas vezes em um dia para criar.</p>}
            {dayEvents(selected).map((e) => (
              <button key={e.id} className="mb-2 w-full rounded-lg border-l-4 bg-surface p-2 text-left hover:bg-hover" style={{ borderColor: e.color }} onClick={() => setEditing(e)}>
                <div className="font-medium">{e.title}</div>
                <div className="text-[0.8rem] text-muted">{e.time || 'Dia inteiro'}{e.reminder ? ' · 🔔' : ''}</div>
                {e.notes && <div className="mt-1 whitespace-pre-wrap text-[0.82rem] text-muted">{e.notes}</div>}
              </button>
            ))}
            <p className="mt-4 text-[0.76rem] text-muted">Eventos ficam em ~/.local/share/lvos/calendar.json</p>
          </>
        )}
      </aside>
    </div>
  );
}
