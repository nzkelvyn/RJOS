import { useEffect, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { useKernel, useNow } from '../ui/hooks';
import { cx } from '../ui/components';

const ZONES = [
  ['America/Sao_Paulo', 'São Paulo'], ['America/Manaus', 'Manaus'], ['America/New_York', 'Nova York'], ['Europe/Lisbon', 'Lisboa'],
  ['Europe/London', 'Londres'], ['Europe/Berlin', 'Berlim'], ['Asia/Tokyo', 'Tóquio'], ['Australia/Sydney', 'Sydney'],
];

function pad(n: number) {
  return String(n).padStart(2, '0');
}

function fmtMs(ms: number) {
  const t = Math.max(0, ms);
  const h = Math.floor(t / 3600000);
  const m = Math.floor((t % 3600000) / 60000);
  const s = Math.floor((t % 60000) / 1000);
  const cs = Math.floor((t % 1000) / 10);
  return `${h ? pad(h) + ':' : ''}${pad(m)}:${pad(s)},${pad(cs)}`;
}

export default function ClockApp(_: AppProps) {
  const kernel = useKernel();
  const [tab, setTab] = useState<'world' | 'stopwatch' | 'timer'>('world');
  const now = useNow(tab === 'world' ? 1000 : 50);

  // stopwatch
  const [swStart, setSwStart] = useState<number | null>(null);
  const [swAcc, setSwAcc] = useState(0);
  const [laps, setLaps] = useState<number[]>([]);
  const swValue = swAcc + (swStart ? Date.now() - swStart : 0);

  // timer
  const [minutes, setMinutes] = useState(5);
  const [seconds, setSeconds] = useState(0);
  const [timerEnd, setTimerEnd] = useState<number | null>(null);
  const [timerLeft, setTimerLeft] = useState<number | null>(null);
  const firedRef = useRef(false);
  const left = timerEnd ? timerEnd - Date.now() : timerLeft;

  useEffect(() => {
    if (!timerEnd) return;
    firedRef.current = false;
    const t = setInterval(() => {
      if (Date.now() >= timerEnd && !firedRef.current) {
        firedRef.current = true;
        setTimerEnd(null);
        setTimerLeft(null);
        kernel.notifications.push({ app: 'clock', appName: 'Relógio', title: 'O timer terminou ⏰', body: `${minutes} min ${seconds} s`, level: 'info' });
        try {
          const ctx = new AudioContext();
          const osc = ctx.createOscillator();
          osc.frequency.value = 880;
          osc.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.6);
        } catch {
          /* audio not allowed */
        }
      }
    }, 200);
    return () => clearInterval(t);
  }, [timerEnd, kernel, minutes, seconds]);

  const angle = (v: number, max: number) => (v / max) * 360;
  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 justify-center gap-1 border-b border-line bg-surface-2 p-2">
        {([['world', 'Relógio mundial'], ['stopwatch', 'Cronômetro'], ['timer', 'Timer']] as const).map(([id, l]) => (
          <button key={id} className={cx('h-8 rounded-lg px-3 text-[0.88rem]', tab === id ? 'bg-accent text-accent-fg' : 'hover:bg-hover')} onClick={() => setTab(id)}>{l}</button>
        ))}
      </div>
      <div className="min-h-0 flex-1 overflow-auto p-4">
        {tab === 'world' && (
          <div className="flex flex-col items-center gap-4">
            <svg width="150" height="150" viewBox="-50 -50 100 100" aria-label="Relógio analógico">
              <circle r="47" fill="var(--surface-2)" stroke="var(--line)" strokeWidth="2" />
              {Array.from({ length: 12 }, (_, i) => <line key={i} y1="-42" y2="-38" stroke="var(--muted)" strokeWidth="2" transform={`rotate(${i * 30})`} />)}
              <line y2="-24" stroke="var(--fg)" strokeWidth="3.5" strokeLinecap="round" transform={`rotate(${angle((now.getHours() % 12) + now.getMinutes() / 60, 12)})`} />
              <line y2="-34" stroke="var(--fg)" strokeWidth="2.5" strokeLinecap="round" transform={`rotate(${angle(now.getMinutes() + now.getSeconds() / 60, 60)})`} />
              <line y2="-38" stroke="var(--accent)" strokeWidth="1.2" strokeLinecap="round" transform={`rotate(${angle(now.getSeconds(), 60)})`} />
              <circle r="2.5" fill="var(--accent)" />
            </svg>
            <div className="w-full max-w-sm">
              {ZONES.map(([tz, name]) => (
                <div key={tz} className="flex items-center justify-between border-b border-line py-2 text-[0.92rem]">
                  <span>{name}</span>
                  <span className="tabular-nums">{now.toLocaleTimeString('pt-BR', { timeZone: tz, hour: '2-digit', minute: '2-digit' })} <span className="text-[0.78rem] text-muted">{now.toLocaleDateString('pt-BR', { timeZone: tz, weekday: 'short' })}</span></span>
                </div>
              ))}
            </div>
          </div>
        )}
        {tab === 'stopwatch' && (
          <div className="flex flex-col items-center gap-4 pt-4">
            <div className="text-[3rem] font-light tabular-nums">{fmtMs(swValue)}</div>
            <div className="flex gap-2">
              <button className="btn btn-primary w-28" onClick={() => {
                if (swStart) {
                  setSwAcc(swAcc + Date.now() - swStart);
                  setSwStart(null);
                } else setSwStart(Date.now());
              }}>{swStart ? 'Pausar' : 'Iniciar'}</button>
              <button className="btn w-28" onClick={() => (swStart ? setLaps([swValue, ...laps]) : (setSwAcc(0), setLaps([])))}>{swStart ? 'Volta' : 'Zerar'}</button>
            </div>
            <div className="w-full max-w-xs">{laps.map((l, i) => <div key={i} className="flex justify-between border-b border-line py-1 text-[0.88rem] tabular-nums"><span className="text-muted">Volta {laps.length - i}</span><span>{fmtMs(l)}</span></div>)}</div>
          </div>
        )}
        {tab === 'timer' && (
          <div className="flex flex-col items-center gap-4 pt-4">
            {left !== null ? (
              <div className="text-[3rem] font-light tabular-nums">{fmtMs(left).slice(0, -3)}</div>
            ) : (
              <div className="flex items-center gap-2 text-[1.5rem]">
                <input type="number" min={0} max={999} className="field h-14 w-24 text-center text-[1.5rem]" value={minutes} onChange={(e) => setMinutes(Math.max(0, Number(e.target.value)))} aria-label="Minutos" />:
                <input type="number" min={0} max={59} className="field h-14 w-24 text-center text-[1.5rem]" value={seconds} onChange={(e) => setSeconds(Math.min(59, Math.max(0, Number(e.target.value))))} aria-label="Segundos" />
              </div>
            )}
            <div className="flex gap-2">
              {timerEnd ? (
                <button className="btn w-28" onClick={() => { setTimerLeft(timerEnd - Date.now()); setTimerEnd(null); }}>Pausar</button>
              ) : (
                <button className="btn btn-primary w-28" disabled={left === null && minutes * 60 + seconds === 0} onClick={() => setTimerEnd(Date.now() + (left ?? (minutes * 60 + seconds) * 1000))}>{left !== null ? 'Continuar' : 'Iniciar'}</button>
              )}
              <button className="btn w-28" onClick={() => { setTimerEnd(null); setTimerLeft(null); }}>Cancelar</button>
            </div>
            <div className="flex gap-1.5">{[1, 3, 5, 10, 25].map((m) => <button key={m} className="btn h-7 text-[0.8rem]" disabled={left !== null} onClick={() => { setMinutes(m); setSeconds(0); }}>{m} min</button>)}</div>
          </div>
        )}
      </div>
    </div>
  );
}
