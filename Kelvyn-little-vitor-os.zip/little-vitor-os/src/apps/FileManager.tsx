import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { useFsVersion, useKernel, useStore } from '../ui/hooks';
import { Icon } from '../ui/icons';
import { Empty, ToolButton, Toolbar, cx, formatDate, useContextMenu, type MenuItem } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { fileIcon } from '../desktop/DesktopArea';
import { basename, dirname, join } from '../core/vfs/path';
import { formatMode } from '../core/vfs/permissions';
import { kindOf } from '../core/vfs/mime';
import { formatBytes } from '../core/shell/args';
import type { DirEntry, TrashEntry } from '../core/vfs/types';
import { downloadFile, importFiles, pickFiles, useFileUrl } from '../ui/blob';
import { APPS } from './registry';
import { zipPaths } from './zip';

type SortKey = 'name' | 'size' | 'mtime' | 'type';

export default function FileManager({ windowId, args }: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const home = kernel.users.current?.home ?? '/';
  const clipboard = useStore(session.clipboard);
  const [path, setPath] = useState(args.path && kernel.vfs.isDir(args.path) ? args.path : home);
  const [trashView, setTrashView] = useState(args.view === 'trash');
  const [history, setHistory] = useState<{ stack: string[]; idx: number }>({ stack: [path], idx: 0 });
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const [sort, setSort] = useState<{ key: SortKey; asc: boolean }>({ key: 'name', asc: true });
  const [hidden, setHidden] = useState(false);
  const [selection, setSelection] = useState<string[]>([]);
  const [anchor, setAnchor] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [editingPath, setEditingPath] = useState(false);
  const [pathInput, setPathInput] = useState(path);
  const [error, setError] = useState<string | null>(null);
  const [props, setProps] = useState<string | null>(null);
  const [trash, setTrash] = useState<TrashEntry[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const menu = useContextMenu();
  const version = useFsVersion(trashView ? kernel.vfs.trashDir(kernel.users.current?.username ?? 'root') : path);
  const rootRef = useRef<HTMLDivElement>(null);

  // external navigation requests (e.g. "open" of another folder in this singleton)
  useEffect(() => {
    if (args.path && kernel.vfs.isDir(args.path)) navigate(args.path);
    if (args.view === 'trash') setTrashView(true);
  }, [args._t]); // eslint-disable-line react-hooks/exhaustive-deps

  const navigate = useCallback((p: string, push = true) => {
    setTrashView(false);
    setPath(p);
    setSelection([]);
    setQuery('');
    setError(null);
    if (push) setHistory((h) => ({ stack: [...h.stack.slice(0, h.idx + 1), p], idx: h.idx + 1 }));
  }, []);

  useEffect(() => {
    session.wm.setTitle(windowId, trashView ? 'Lixeira' : path === home ? 'Pasta pessoal' : basename(path));
    setPathInput(path);
  }, [session, windowId, path, trashView, home]);

  const entries: DirEntry[] = useMemo(() => {
    if (trashView) return [];
    try {
      let list = query.trim()
        ? kernel.vfs.find(path, (e) => e.name.toLowerCase().includes(query.trim().toLowerCase()), undefined, 500)
        : kernel.vfs.readdir(path);
      if (!hidden) list = list.filter((e) => !e.name.startsWith('.'));
      const dir = (e: DirEntry) => (e.node.type === 'dir' ? 0 : 1);
      const cmp = {
        name: (a: DirEntry, b: DirEntry) => a.name.localeCompare(b.name, 'pt-BR', { numeric: true }),
        size: (a: DirEntry, b: DirEntry) => a.node.size - b.node.size,
        mtime: (a: DirEntry, b: DirEntry) => a.node.mtime - b.node.mtime,
        type: (a: DirEntry, b: DirEntry) => (a.node.mime ?? '').localeCompare(b.node.mime ?? '') || a.name.localeCompare(b.name),
      }[sort.key];
      return [...list].sort((a, b) => dir(a) - dir(b) || (sort.asc ? cmp(a, b) : cmp(b, a)));
    } catch (err) {
      setTimeout(() => setError((err as Error).message), 0);
      return [];
    }
  }, [kernel, path, hidden, sort, query, version, trashView]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (trashView) kernel.vfs.listTrash().then(setTrash).catch(() => setTrash([]));
  }, [kernel, trashView, version]);

  const notifyErr = (title: string, err: unknown) => kernel.notifications.push({ app: 'files', appName: 'Arquivos', title, body: (err as Error).message, level: 'error' });

  // ------------------------------------------------------------ actions
  const open = (e: DirEntry) => (e.node.type === 'dir' ? navigate(e.path) : session.openPath(e.path));

  const newItem = async (type: 'file' | 'dir') => {
    const name = await session.prompt(type === 'dir' ? 'Nova pasta' : 'Novo arquivo', type === 'dir' ? 'Nova pasta' : 'novo.txt', { confirmLabel: 'Criar' });
    if (!name) return;
    try {
      const target = kernel.vfs.uniquePath(join(path, name));
      if (type === 'dir') await kernel.vfs.mkdir(target);
      else await kernel.vfs.writeFile(target, '');
      setSelection([target]);
    } catch (err) {
      notifyErr('Não foi possível criar', err);
    }
  };

  const rename = async (p: string) => {
    const name = await session.prompt('Renomear', basename(p), { confirmLabel: 'Renomear' });
    if (!name || name === basename(p)) return;
    try {
      const dest = join(dirname(p), name);
      if (kernel.vfs.exists(dest)) throw new Error(`Já existe um item chamado "${name}".`);
      await kernel.vfs.move(p, dest);
      setSelection([dest]);
    } catch (err) {
      notifyErr('Erro ao renomear', err);
    }
  };

  const toTrash = async (paths: string[]) => {
    for (const p of paths) await kernel.vfs.moveToTrash(p).catch((err) => notifyErr(`Erro ao mover ${basename(p)} para a lixeira`, err));
    setSelection([]);
  };

  const deleteForever = async (paths: string[]) => {
    if (!(await session.confirm(`Excluir permanentemente ${paths.length === 1 ? `"${basename(paths[0])}"` : `${paths.length} itens`}?`, 'Esta ação não pode ser desfeita.', { confirmLabel: 'Excluir', danger: true }))) return;
    for (const p of paths) await kernel.vfs.rm(p, { recursive: true }).catch((err) => notifyErr('Erro ao excluir', err));
    setSelection([]);
  };

  const copy = (paths: string[], mode: 'copy' | 'cut') => paths.length && session.clipboard.set({ paths, mode });

  const paste = async () => {
    const cb = session.clipboard.get();
    if (!cb) return;
    const done: string[] = [];
    for (const src of cb.paths) {
      try {
        if (!kernel.vfs.exists(src)) continue;
        const target = kernel.vfs.uniquePath(join(path, basename(src)));
        if (cb.mode === 'cut') {
          if (dirname(src) === path) continue;
          done.push(await kernel.vfs.move(src, target));
        } else done.push(await kernel.vfs.copy(src, target, { recursive: true }));
      } catch (err) {
        notifyErr(`Erro ao colar ${basename(src)}`, err);
      }
    }
    if (cb.mode === 'cut') session.clipboard.set(null);
    setSelection(done);
  };

  const importHere = async (files: FileList | File[] | null) => {
    if (!files?.length) return;
    try {
      const r = await importFiles(kernel, files, path);
      if (r.imported.length) kernel.notifications.push({ app: 'files', appName: 'Arquivos', title: `${r.imported.length} arquivo(s) importado(s)`, body: path, level: 'success' });
      if (r.rejected.length) kernel.notifications.push({ app: 'files', appName: 'Arquivos', title: 'Não importados', body: r.rejected.join('\n'), level: 'warning' });
      setSelection(r.imported);
    } catch (err) {
      notifyErr('Erro ao importar', err);
    }
  };

  const compress = async (paths: string[]) => {
    const name = await session.prompt('Compactar como', paths.length === 1 ? basename(paths[0]) + '.zip' : 'arquivos.zip', { confirmLabel: 'Compactar' });
    if (!name) return;
    try {
      const out = kernel.vfs.uniquePath(join(path, name.endsWith('.zip') ? name : name + '.zip'));
      await kernel.vfs.writeFile(out, await zipPaths(kernel, paths));
      setSelection([out]);
    } catch (err) {
      notifyErr('Erro ao compactar', err);
    }
  };

  const select = (e: React.MouseEvent, p: string) => {
    if (e.shiftKey && anchor) {
      const names = entries.map((x) => x.path);
      const [a, b] = [names.indexOf(anchor), names.indexOf(p)].sort((x, y) => x - y);
      setSelection(names.slice(a, b + 1));
    } else if (e.ctrlKey || e.metaKey) {
      setSelection((s) => (s.includes(p) ? s.filter((x) => x !== p) : [...s, p]));
      setAnchor(p);
    } else {
      setSelection([p]);
      setAnchor(p);
    }
  };

  const itemMenu = (e: React.MouseEvent, entry: DirEntry) => {
    const sel = selection.includes(entry.path) ? selection : [entry.path];
    if (!selection.includes(entry.path)) setSelection([entry.path]);
    const kind = entry.node.type === 'dir' ? null : kindOf(entry.name, entry.node.mime);
    const openWith: MenuItem[] = kind
      ? APPS.filter((a) => a.opens?.includes(kind) || a.id === 'editor').map((a) => ({ label: `Abrir com ${a.name}`, icon: a.icon, onClick: () => session.openPath(entry.path, a.id) }))
      : [];
    menu.open(e, [
      { label: 'Abrir', icon: 'folder-open', onClick: () => open(entry) },
      ...openWith,
      ...(entry.node.type === 'dir' ? [{ label: 'Abrir terminal aqui', icon: 'terminal', onClick: () => session.launch('terminal', { cwd: entry.path }) } as MenuItem] : []),
      { separator: true },
      { label: 'Recortar', icon: 'scissors', shortcut: 'Ctrl+X', onClick: () => copy(sel, 'cut') },
      { label: 'Copiar', icon: 'copy', shortcut: 'Ctrl+C', onClick: () => copy(sel, 'copy') },
      { label: 'Renomear…', icon: 'edit', shortcut: 'F2', disabled: sel.length !== 1, onClick: () => void rename(entry.path) },
      { label: 'Compactar em .zip…', icon: 'archive', onClick: () => void compress(sel) },
      ...(kind === 'archive' ? [{ label: 'Extrair aqui', icon: 'archive', onClick: () => session.launch('archive', { path: entry.path, extract: '1' }) } as MenuItem] : []),
      { label: 'Exportar para o computador', icon: 'download', disabled: entry.node.type === 'dir', onClick: () => void downloadFile(kernel, entry.path).catch((err) => notifyErr('Erro ao exportar', err)) },
      ...(kind === 'image' ? [{ label: 'Usar como papel de parede', icon: 'image', onClick: () => kernel.settings.update({ wallpaper: entry.path }) } as MenuItem] : []),
      { separator: true },
      { label: 'Mover para a lixeira', icon: 'trash', shortcut: 'Del', onClick: () => void toTrash(sel) },
      { label: 'Excluir permanentemente', icon: 'x-circle', danger: true, shortcut: 'Shift+Del', onClick: () => void deleteForever(sel) },
      { separator: true },
      { label: 'Propriedades', icon: 'info', onClick: () => setProps(entry.path) },
    ]);
  };

  const bgMenu = (e: React.MouseEvent) => {
    if (trashView) return e.preventDefault();
    setSelection([]);
    menu.open(e, [
      { label: 'Nova pasta', icon: 'folder', shortcut: 'Ctrl+Shift+N', onClick: () => void newItem('dir') },
      { label: 'Novo arquivo', icon: 'file-text', onClick: () => void newItem('file') },
      { label: 'Colar', icon: 'clipboard', shortcut: 'Ctrl+V', disabled: !clipboard, onClick: () => void paste() },
      { label: 'Importar arquivos do computador…', icon: 'upload', onClick: () => void pickFiles().then(importHere) },
      { separator: true },
      { label: 'Abrir terminal aqui', icon: 'terminal', onClick: () => session.launch('terminal', { cwd: path }) },
      { label: hidden ? 'Ocultar arquivos ocultos' : 'Mostrar arquivos ocultos', icon: 'eye', shortcut: 'Ctrl+H', onClick: () => setHidden((h) => !h) },
      { label: 'Propriedades da pasta', icon: 'info', onClick: () => setProps(path) },
    ]);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if ((e.target as HTMLElement).tagName === 'INPUT') return;
    const ctrl = e.ctrlKey || e.metaKey;
    const key = e.key.toLowerCase();
    const sel = selection;
    const handled = () => e.preventDefault();
    if (ctrl && key === 'a') { handled(); setSelection(entries.map((x) => x.path)); }
    else if (ctrl && key === 'c') { handled(); copy(sel, 'copy'); }
    else if (ctrl && key === 'x') { handled(); copy(sel, 'cut'); }
    else if (ctrl && key === 'v') { handled(); void paste(); }
    else if (ctrl && key === 'h') { handled(); setHidden((h) => !h); }
    else if (ctrl && e.shiftKey && key === 'n') { handled(); void newItem('dir'); }
    else if (key === 'delete' && sel.length) { handled(); void (e.shiftKey ? deleteForever(sel) : toTrash(sel)); }
    else if (key === 'f2' && sel.length === 1) { handled(); void rename(sel[0]); }
    else if (key === 'enter' && sel.length === 1) {
      handled();
      const en = entries.find((x) => x.path === sel[0]);
      if (en) open(en);
    } else if (key === 'backspace' || (e.altKey && key === 'arrowup')) { handled(); if (path !== '/') navigate(dirname(path)); }
  };

  const places = [
    { label: 'Pasta pessoal', icon: 'home', path: home },
    { label: 'Área de Trabalho', icon: 'monitor', path: `${home}/Desktop` },
    { label: 'Documentos', icon: 'file-text', path: `${home}/Documents` },
    { label: 'Downloads', icon: 'download', path: `${home}/Downloads` },
    { label: 'Músicas', icon: 'music', path: `${home}/Music` },
    { label: 'Imagens', icon: 'image', path: `${home}/Pictures` },
    { label: 'Vídeos', icon: 'video', path: `${home}/Videos` },
    { label: 'Projetos', icon: 'folder', path: `${home}/Projects` },
    { label: 'Sistema de arquivos', icon: 'hard-drive', path: '/' },
  ].filter((p) => kernel.vfs.exists(p.path));

  const crumbs = path === '/' ? ['/'] : ['/', ...path.split('/').filter(Boolean)];
  const totalSel = selection.reduce((acc, p) => acc + (kernel.vfs.exists(p) ? kernel.vfs.stat(p).size : 0), 0);

  return (
    <div ref={rootRef} className="flex h-full flex-col outline-none" tabIndex={0} onKeyDown={onKeyDown}>
      <Toolbar>
        <ToolButton icon="chevron-left" label="Voltar" disabled={history.idx === 0} onClick={() => { const idx = history.idx - 1; setHistory({ ...history, idx }); navigate(history.stack[idx], false); }} />
        <ToolButton icon="chevron-right" label="Avançar" disabled={history.idx >= history.stack.length - 1} onClick={() => { const idx = history.idx + 1; setHistory({ ...history, idx }); navigate(history.stack[idx], false); }} />
        <ToolButton icon="arrow-up" label="Pasta acima" disabled={path === '/' || trashView} onClick={() => navigate(dirname(path))} />
        {editingPath ? (
          <form className="flex-1" onSubmit={(e) => {
            e.preventDefault();
            const target = pathInput.startsWith('~') ? home + pathInput.slice(1) : pathInput;
            if (kernel.vfs.isDir(target)) navigate(target);
            else setError(`Pasta não encontrada: ${pathInput}`);
            setEditingPath(false);
          }}>
            <input autoFocus className="field h-8 w-full font-mono text-[0.85rem]" value={pathInput} onChange={(e) => setPathInput(e.target.value)} onBlur={() => setEditingPath(false)} aria-label="Caminho" />
          </form>
        ) : (
          <div className="flex h-8 min-w-0 flex-1 items-center overflow-x-auto rounded-lg border border-line bg-surface px-1" onDoubleClick={() => setEditingPath(true)} title="Clique duplo para digitar o caminho">
            {trashView ? (
              <span className="px-2 text-[0.88rem]">Lixeira</span>
            ) : (
              crumbs.map((c, i) => {
                const target = i === 0 ? '/' : '/' + crumbs.slice(1, i + 1).join('/');
                return (
                  <span key={target} className="flex shrink-0 items-center">
                    {i > 1 && <Icon name="chevron-right" size={13} className="text-muted" />}
                    <button className="rounded px-1.5 py-0.5 text-[0.86rem] hover:bg-hover" onClick={() => navigate(target)}>
                      {i === 0 ? <Icon name="hard-drive" size={14} /> : c}
                    </button>
                  </span>
                );
              })
            )}
          </div>
        )}
        {!trashView && (
          <div className="relative hidden sm:block">
            <Icon name="search" size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted" />
            <input className="field h-8 w-44 pl-8 text-[0.86rem]" placeholder="Buscar nesta pasta" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Buscar arquivos" />
          </div>
        )}
        <ToolButton icon={view === 'grid' ? 'list' : 'grid'} label={view === 'grid' ? 'Ver em lista' : 'Ver em grade'} onClick={() => setView((v) => (v === 'grid' ? 'list' : 'grid'))} />
        <ToolButton icon="more" label="Mais opções" onClick={() => {
          const r = rootRef.current?.getBoundingClientRect();
          menu.open({ clientX: (r?.right ?? 300) - 220, clientY: (r?.top ?? 0) + 44, preventDefault() {} }, [
            { label: 'Nova pasta', icon: 'folder', onClick: () => void newItem('dir') },
            { label: 'Novo arquivo', icon: 'file-text', onClick: () => void newItem('file') },
            { label: 'Importar do computador…', icon: 'upload', onClick: () => void pickFiles().then(importHere) },
            { separator: true },
            ...(['name', 'size', 'mtime', 'type'] as SortKey[]).map((k) => ({
              label: `Ordenar por ${{ name: 'nome', size: 'tamanho', mtime: 'data', type: 'tipo' }[k]}${sort.key === k ? (sort.asc ? ' ↑' : ' ↓') : ''}`,
              icon: 'list',
              onClick: () => setSort((s) => ({ key: k, asc: s.key === k ? !s.asc : true })),
            })),
            { separator: true },
            { label: hidden ? 'Ocultar arquivos ocultos' : 'Mostrar arquivos ocultos', icon: 'eye', onClick: () => setHidden((h) => !h) },
          ]);
        }} />
      </Toolbar>
      <div className="flex min-h-0 flex-1">
        <aside className="hidden w-48 shrink-0 overflow-auto border-r border-line bg-surface-2 p-2 md:block">
          {places.map((p) => (
            <button key={p.path} className="list-row w-full text-left text-[0.88rem]" data-selected={!trashView && path === p.path} onClick={() => navigate(p.path)}>
              <Icon name={p.icon} size={16} className="text-muted" />
              <span className="truncate">{p.label}</span>
            </button>
          ))}
          <div className="my-2 h-px bg-line" />
          <button className="list-row w-full text-left text-[0.88rem]" data-selected={trashView} onClick={() => { setTrashView(true); setSelection([]); }}>
            <Icon name="trash" size={16} className="text-muted" />
            <span>Lixeira</span>
          </button>
        </aside>
        <main
          className={cx('relative min-w-0 flex-1 overflow-auto', dragOver && 'ring-2 ring-inset ring-accent')}
          onClick={(e) => e.target === e.currentTarget && setSelection([])}
          onContextMenu={bgMenu}
          onDragOver={(e) => {
            if (!trashView && e.dataTransfer.types.includes('Files')) {
              e.preventDefault();
              setDragOver(true);
            }
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            void importHere(e.dataTransfer.files);
          }}
          data-testid="file-list"
        >
          {trashView ? (
            <TrashView items={trash} onRestore={async (id) => { await kernel.vfs.restoreFromTrash(id).catch((err) => notifyErr('Erro ao restaurar', err)); setTrash(await kernel.vfs.listTrash()); }} onDelete={async (id) => { await kernel.vfs.deleteFromTrash(id); setTrash(await kernel.vfs.listTrash()); }} onEmpty={async () => {
              if (await session.confirm('Esvaziar a lixeira?', `${trash.length} item(ns) serão excluídos permanentemente.`, { confirmLabel: 'Esvaziar', danger: true })) {
                await kernel.vfs.emptyTrash();
                setTrash([]);
              }
            }} />
          ) : error ? (
            <Empty icon="lock" title="Não foi possível abrir a pasta">{error}</Empty>
          ) : !entries.length ? (
            <Empty icon={query ? 'search' : 'folder-open'} title={query ? 'Nada encontrado' : 'Pasta vazia'}>
              {query ? `Nenhum item com “${query}”.` : 'Arraste arquivos do seu computador para cá ou use o botão direito para criar.'}
            </Empty>
          ) : view === 'grid' ? (
            <div className="grid grid-cols-[repeat(auto-fill,minmax(98px,1fr))] gap-1 p-2" onClick={(e) => e.target === e.currentTarget && setSelection([])}>
              {entries.map((e) => (
                <FileTile key={e.path} entry={e} selected={selection.includes(e.path)} cut={clipboard?.mode === 'cut' && clipboard.paths.includes(e.path)} onClick={(ev) => select(ev, e.path)} onOpen={() => open(e)} onMenu={(ev) => itemMenu(ev, e)} showPath={!!query} />
              ))}
            </div>
          ) : (
            <table className="w-full text-[0.86rem]">
              <thead className="sticky top-0 bg-surface text-left text-muted">
                <tr>
                  {(['name', 'size', 'mtime', 'type'] as SortKey[]).map((k) => (
                    <th key={k} className="cursor-default px-3 py-1.5 font-medium" onClick={() => setSort((s) => ({ key: k, asc: s.key === k ? !s.asc : true }))}>
                      {{ name: 'Nome', size: 'Tamanho', mtime: 'Modificado', type: 'Tipo' }[k]} {sort.key === k ? (sort.asc ? '↑' : '↓') : ''}
                    </th>
                  ))}
                  <th className="px-3 py-1.5 font-medium">Permissões</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((e) => {
                  const fi = fileIcon(e);
                  return (
                    <tr key={e.path} className={cx(selection.includes(e.path) ? 'bg-accent/20' : 'hover:bg-hover')} onClick={(ev) => select(ev, e.path)} onDoubleClick={() => open(e)} onContextMenu={(ev) => itemMenu(ev, e)} style={{ opacity: clipboard?.mode === 'cut' && clipboard.paths.includes(e.path) ? 0.5 : 1 }}>
                      <td className="flex items-center gap-2 px-3 py-1.5"><Icon name={fi.icon} size={17} style={{ color: fi.color }} /><span className="truncate">{query ? e.path.slice(path.length + 1) : e.name}</span></td>
                      <td className="px-3 py-1.5 text-muted tabular-nums">{e.node.type === 'dir' ? '—' : formatBytes(e.node.size)}</td>
                      <td className="px-3 py-1.5 text-muted">{formatDate(e.node.mtime)}</td>
                      <td className="px-3 py-1.5 text-muted">{e.node.type === 'dir' ? 'pasta' : e.node.mime}</td>
                      <td className="px-3 py-1.5 font-mono text-[0.78rem] text-muted">{formatMode(e.node)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </main>
      </div>
      <footer className="flex h-7 shrink-0 items-center gap-3 border-t border-line bg-surface-2 px-3 text-[0.78rem] text-muted">
        <span>{trashView ? `${trash.length} item(ns) na lixeira` : `${entries.length} item(ns)`}</span>
        {selection.length > 0 && <span>{selection.length} selecionado(s) · {formatBytes(totalSel)}</span>}
        {clipboard && <span className="ml-auto">{clipboard.paths.length} item(ns) na área de transferência ({clipboard.mode === 'cut' ? 'recortar' : 'copiar'})</span>}
      </footer>
      {props && <PropertiesDialog path={props} onClose={() => setProps(null)} />}
      {menu.element}
    </div>
  );
}

function FileTile({ entry, selected, cut, onClick, onOpen, onMenu, showPath }: { entry: DirEntry; selected: boolean; cut: boolean; onClick: (e: React.MouseEvent) => void; onOpen: () => void; onMenu: (e: React.MouseEvent) => void; showPath: boolean }) {
  const kernel = useKernel();
  const fi = fileIcon(entry);
  const isImage = entry.node.type === 'file' && kindOf(entry.name, entry.node.mime) === 'image' && entry.node.size < 8 * 1024 * 1024;
  const thumb = useFileUrl(kernel, isImage ? entry.path : null, entry.node.mtime);
  return (
    <button
      className={cx('flex flex-col items-center gap-1 rounded-lg p-2 text-center', selected ? 'bg-accent/25' : 'hover:bg-hover')}
      style={{ opacity: cut ? 0.5 : 1 }}
      onClick={onClick}
      onDoubleClick={onOpen}
      onContextMenu={onMenu}
      title={entry.path}
      data-testid={`file-${entry.name}`}
    >
      <div className="grid h-14 w-14 place-items-center">
        {thumb.url ? <img src={thumb.url} alt="" className="max-h-14 max-w-14 rounded object-cover shadow" draggable={false} /> : <Icon name={fi.icon} size={46} strokeWidth={1.2} style={{ color: fi.color }} />}
      </div>
      <span className="line-clamp-2 w-full break-all text-[0.8rem] leading-tight">{showPath ? entry.path.split('/').slice(-2).join('/') : entry.name}</span>
    </button>
  );
}

function TrashView({ items, onRestore, onDelete, onEmpty }: { items: TrashEntry[]; onRestore: (id: string) => void; onDelete: (id: string) => void; onEmpty: () => void }) {
  if (!items.length) return <Empty icon="trash" title="A lixeira está vazia">Itens apagados pelo gerenciador de arquivos ou pelo comando “trash” aparecem aqui.</Empty>;
  return (
    <div className="p-2">
      <div className="mb-2 flex justify-end">
        <button className="btn btn-danger" onClick={onEmpty}><Icon name="trash" size={15} />Esvaziar lixeira</button>
      </div>
      {items.map((i) => (
        <div key={i.id} className="list-row">
          <Icon name={i.type === 'dir' ? 'folder' : 'file'} size={18} className="text-muted" />
          <div className="min-w-0 flex-1">
            <div className="truncate text-[0.9rem]">{i.name}</div>
            <div className="truncate text-[0.76rem] text-muted">{i.originalPath} · apagado em {formatDate(i.deletedAt)} · {formatBytes(i.size)}</div>
          </div>
          <button className="btn" onClick={() => onRestore(i.id)}><Icon name="rotate" size={14} />Restaurar</button>
          <button className="btn btn-ghost btn-icon" aria-label="Excluir permanentemente" title="Excluir permanentemente" onClick={() => onDelete(i.id)}><Icon name="x" size={15} /></button>
        </div>
      ))}
    </div>
  );
}

function PropertiesDialog({ path, onClose }: { path: string; onClose: () => void }) {
  const kernel = useKernel();
  const node = kernel.vfs.exists(path) ? kernel.vfs.stat(path) : null;
  const [mode, setMode] = useState(node?.mode ?? 0);
  const [err, setErr] = useState<string | null>(null);
  if (!node) return null;
  const size = node.type === 'dir' ? kernel.vfs.du(path) : node.size;
  const me = kernel.users.current?.username;
  const canEdit = me === node.owner; // like chmod(1): only the owner (or root via sudo in the terminal)
  const bit = (b: number) => (
    <input type="checkbox" checked={(mode & b) !== 0} disabled={!canEdit} onChange={(e) => setMode((m) => (e.target.checked ? m | b : m & ~b))} />
  );
  const row = (k: string, v: React.ReactNode) => (
    <div className="flex gap-3 py-1 text-[0.88rem]"><span className="w-28 shrink-0 text-muted">{k}</span><span className="selectable min-w-0 break-all">{v}</span></div>
  );
  return (
    <div className="absolute inset-0 z-20 grid place-items-center bg-black/40" onClick={onClose}>
      <div className="pop-in w-[min(420px,94%)] rounded-xl border border-line bg-surface p-4 shadow-2xl" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="Propriedades">
        <div className="mb-3 flex items-center gap-2 font-semibold"><Icon name={node.type === 'dir' ? 'folder' : 'file'} size={20} />{basename(path) || '/'}</div>
        {row('Local', dirname(path))}
        {row('Tipo', node.type === 'dir' ? 'Pasta' : node.mime)}
        {row('Tamanho', `${formatBytes(size)} (${size.toLocaleString('pt-BR')} bytes)`)}
        {row('Criado', formatDate(node.ctime))}
        {row('Modificado', formatDate(node.mtime))}
        {row('Dono', `${node.owner} (grupo ${node.group})`)}
        <div className="mt-3 rounded-lg border border-line p-3">
          <div className="mb-2 flex items-center justify-between text-[0.85rem]"><span className="font-medium">Permissões</span><code className="text-muted">{formatMode({ type: node.type, mode })} ({(mode & 0o7777).toString(8)})</code></div>
          <table className="w-full text-center text-[0.84rem]">
            <thead><tr className="text-muted"><th /><th>Ler</th><th>Escrever</th><th>Executar</th></tr></thead>
            <tbody>
              {[['Dono', 6], ['Grupo', 3], ['Outros', 0]].map(([label, shift]) => (
                <tr key={label as string}><td className="text-left">{label}</td><td>{bit(4 << (shift as number))}</td><td>{bit(2 << (shift as number))}</td><td>{bit(1 << (shift as number))}</td></tr>
              ))}
            </tbody>
          </table>
          {!canEdit && <div className="mt-2 text-[0.78rem] text-muted">Só o dono pode alterar (ou use "sudo chmod" no Terminal).</div>}
        </div>
        {err && <div className="mt-2 text-[0.85rem]" style={{ color: 'var(--danger)' }}>{err}</div>}
        <div className="mt-4 flex justify-end gap-2">
          <button className="btn" onClick={onClose}>Fechar</button>
          {canEdit && mode !== node.mode && (
            <button className="btn btn-primary" onClick={async () => {
              try {
                await kernel.vfs.chmod(path, mode);
                onClose();
              } catch (e) {
                setErr((e as Error).message);
              }
            }}>Aplicar</button>
          )}
        </div>
      </div>
    </div>
  );
}
