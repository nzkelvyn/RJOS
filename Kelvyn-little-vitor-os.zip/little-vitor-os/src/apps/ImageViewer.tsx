import { useEffect, useMemo, useState } from 'react';
import type { AppProps } from './registry';
import { useKernel } from '../ui/hooks';
import { Empty, Spinner, ToolButton, Toolbar } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { basename, dirname } from '../core/vfs/path';
import { kindOf } from '../core/vfs/mime';
import { downloadFile, useFileUrl } from '../ui/blob';

export default function ImageViewer({ windowId, args }: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const [path, setPath] = useState<string | null>(args.path ?? null);
  const [zoom, setZoom] = useState<number | 'fit'>('fit');
  const [rotation, setRotation] = useState(0);
  const [dims, setDims] = useState<{ w: number; h: number } | null>(null);
  const img = useFileUrl(kernel, path);

  useEffect(() => {
    if (args.path) setPath(args.path);
  }, [args.path, args._t]);
  useEffect(() => {
    session.wm.setTitle(windowId, path ? `${basename(path)} — Imagens` : 'Imagens');
    setZoom('fit');
    setRotation(0);
  }, [session, windowId, path]);

  const siblings = useMemo(() => {
    if (!path) return [];
    try {
      return kernel.vfs.readdir(dirname(path)).filter((e) => e.node.type === 'file' && kindOf(e.name, e.node.mime) === 'image').map((e) => e.path);
    } catch {
      return [];
    }
  }, [kernel, path]);
  const idx = path ? siblings.indexOf(path) : -1;
  const go = (d: number) => siblings.length && setPath(siblings[(idx + d + siblings.length) % siblings.length]);

  const choose = async () => {
    const home = kernel.users.current?.home ?? '/';
    const p = await session.prompt('Abrir imagem', `${home}/Pictures/`);
    if (p) setPath(p);
  };

  return (
    <div
      className="flex h-full flex-col outline-none"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'ArrowRight') go(1);
        if (e.key === 'ArrowLeft') go(-1);
        if (e.key === '+' || e.key === '=') setZoom((z) => Math.min(8, (z === 'fit' ? 1 : z) * 1.25));
        if (e.key === '-') setZoom((z) => Math.max(0.1, (z === 'fit' ? 1 : z) / 1.25));
        if (e.key === '0') setZoom('fit');
        if (e.key.toLowerCase() === 'r') setRotation((r) => r + 90);
      }}
    >
      <Toolbar>
        <ToolButton icon="folder-open" label="Abrir" onClick={() => void choose()} />
        <ToolButton icon="chevron-left" label="Anterior (←)" onClick={() => go(-1)} disabled={siblings.length < 2} />
        <ToolButton icon="chevron-right" label="Próxima (→)" onClick={() => go(1)} disabled={siblings.length < 2} />
        <div className="mx-1 h-5 w-px bg-line" />
        <ToolButton icon="zoom_out" label="Diminuir (-)" onClick={() => setZoom((z) => Math.max(0.1, (z === 'fit' ? 1 : z) / 1.25))} />
        <button className="btn btn-ghost h-8 w-16 text-[0.82rem]" onClick={() => setZoom((z) => (z === 'fit' ? 1 : 'fit'))}>{zoom === 'fit' ? 'Ajustar' : `${Math.round(zoom * 100)}%`}</button>
        <ToolButton icon="zoom_in" label="Aumentar (+)" onClick={() => setZoom((z) => Math.min(8, (z === 'fit' ? 1 : z) * 1.25))} />
        <ToolButton icon="rotate" label="Girar (R)" onClick={() => setRotation((r) => r + 90)} />
        <div className="mx-1 h-5 w-px bg-line" />
        <ToolButton icon="image" label="Usar como papel de parede" disabled={!path} onClick={() => path && kernel.settings.update({ wallpaper: path })} />
        <ToolButton icon="download" label="Exportar" disabled={!path} onClick={() => path && void downloadFile(kernel, path)} />
        {dims && <span className="ml-auto text-[0.8rem] text-muted">{dims.w} × {dims.h} px {siblings.length > 1 ? `· ${idx + 1}/${siblings.length}` : ''}</span>}
      </Toolbar>
      <div className="relative min-h-0 flex-1 overflow-auto" style={{ background: 'repeating-conic-gradient(var(--surface-2) 0 25%, var(--surface-3) 0 50%) 0 0 / 20px 20px' }}>
        {!path ? <Empty icon="image" title="Nenhuma imagem aberta">Abra uma imagem pelo gerenciador de arquivos ou pelo botão Abrir.</Empty>
          : img.error ? <Empty icon="alert" title="Não foi possível abrir">{img.error}</Empty>
          : !img.url ? <div className="grid h-full place-items-center"><Spinner /></div>
          : (
            <div className="grid min-h-full min-w-full place-items-center p-4">
              <img
                src={img.url}
                alt={basename(path)}
                onLoad={(e) => setDims({ w: e.currentTarget.naturalWidth, h: e.currentTarget.naturalHeight })}
                onError={() => setDims(null)}
                draggable={false}
                style={{
                  transform: `rotate(${rotation}deg)`,
                  maxWidth: zoom === 'fit' ? '100%' : 'none',
                  maxHeight: zoom === 'fit' ? 'calc(100% - 0px)' : 'none',
                  width: zoom === 'fit' || !dims ? undefined : dims.w * zoom,
                  transition: 'transform .2s',
                }}
                className={zoom === 'fit' ? 'max-h-[calc(100vh-200px)] object-contain' : ''}
              />
            </div>
          )}
      </div>
    </div>
  );
}
