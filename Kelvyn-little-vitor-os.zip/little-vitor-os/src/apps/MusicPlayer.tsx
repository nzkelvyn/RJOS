import { useEffect, useMemo, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { useFsVersion, useKernel } from '../ui/hooks';
import { Icon } from '../ui/icons';
import { Empty, cx } from '../ui/components';
import { kindOf } from '../core/vfs/mime';
import { basename } from '../core/vfs/path';
import { importFiles, pickFiles, useFileUrl } from '../ui/blob';
import { volumeStore } from '../desktop/Panels';

function time(s: number) {
  if (!Number.isFinite(s)) return '0:00';
  return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
}

export default function MusicPlayer({ args }: AppProps) {
  const kernel = useKernel();
  const home = kernel.users.current?.home ?? '/';
  const v = useFsVersion(`${home}/Music`);
  const library = useMemo(() => kernel.vfs.find(home, (e) => e.node.type === 'file' && kindOf(e.name, e.node.mime) === 'audio').map((e) => e.path), [kernel, home, v]);
  const [current, setCurrent] = useState<string | null>(args.path ?? null);
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState(0);
  const [dur, setDur] = useState(0);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const audio = useRef<HTMLAudioElement>(null);
  const src = useFileUrl(kernel, current);
  const queue = current && !library.includes(current) ? [current, ...library] : library;

  useEffect(() => {
    if (args.path) setCurrent(args.path);
  }, [args.path, args._t]);

  useEffect(() => {
    const apply = () => audio.current && (audio.current.volume = volumeStore.value);
    apply();
    volumeStore.listeners.add(apply);
    return () => void volumeStore.listeners.delete(apply);
  }, []);

  useEffect(() => {
    if (src.url && audio.current) {
      audio.current.src = src.url;
      audio.current.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    }
  }, [src.url]);

  const next = (d = 1) => {
    if (!queue.length) return;
    const idx = current ? queue.indexOf(current) : -1;
    const n = shuffle ? Math.floor(Math.random() * queue.length) : (idx + d + queue.length) % queue.length;
    setCurrent(queue[n]);
  };

  // media keys / lock-screen controls (real browser API)
  useEffect(() => {
    if (!('mediaSession' in navigator) || !current) return;
    navigator.mediaSession.metadata = new MediaMetadata({ title: basename(current), artist: 'Little Vitor OS' });
    navigator.mediaSession.setActionHandler('nexttrack', () => next(1));
    navigator.mediaSession.setActionHandler('previoustrack', () => next(-1));
  });

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-col items-center gap-3 border-b border-line p-5" style={{ background: 'linear-gradient(160deg, color-mix(in oklab, var(--accent) 35%, var(--surface)), var(--surface))' }}>
        <div className="grid h-28 w-28 place-items-center rounded-2xl bg-black/20 shadow-lg"><Icon name="music" size={52} strokeWidth={1.3} className={cx(playing && 'animate-pulse')} /></div>
        <div className="max-w-full truncate text-center font-semibold" data-testid="music-title">{current ? basename(current) : 'Nada tocando'}</div>
        <div className="flex w-full max-w-sm items-center gap-2 text-[0.76rem] tabular-nums text-muted">
          <span>{time(pos)}</span>
          <input type="range" min={0} max={dur || 0} step={0.1} value={pos} onChange={(e) => { if (audio.current) audio.current.currentTime = Number(e.target.value); }} className="flex-1 accent-[var(--accent)]" aria-label="Posição" />
          <span>{time(dur)}</span>
        </div>
        <div className="flex items-center gap-2">
          <button className={cx('btn btn-ghost btn-icon', shuffle && 'text-accent')} aria-label="Aleatório" onClick={() => setShuffle((s) => !s)}><Icon name="sparkle" size={17} /></button>
          <button className="btn btn-ghost btn-icon" aria-label="Anterior" onClick={() => next(-1)}><Icon name="skip-back" size={18} /></button>
          <button className="btn btn-primary h-12 w-12 rounded-full" aria-label={playing ? 'Pausar' : 'Tocar'} disabled={!current} onClick={() => (playing ? audio.current?.pause() : audio.current?.play())}><Icon name={playing ? 'pause' : 'play'} size={20} /></button>
          <button className="btn btn-ghost btn-icon" aria-label="Próxima" onClick={() => next(1)}><Icon name="skip-forward" size={18} /></button>
          <button className={cx('btn btn-ghost btn-icon', repeat && 'text-accent')} aria-label="Repetir" onClick={() => setRepeat((r) => !r)}><Icon name="refresh" size={17} /></button>
        </div>
        {(error || src.error) && <div className="text-[0.82rem]" style={{ color: 'var(--danger)' }}>{error ?? src.error}</div>}
      </div>
      <div className="flex items-center justify-between px-4 py-2">
        <span className="text-[0.82rem] font-semibold uppercase tracking-wider text-muted">Biblioteca ({library.length})</span>
        <button className="btn h-7 text-[0.8rem]" onClick={async () => {
          const files = await pickFiles('audio/*');
          if (!files) return;
          await kernel.vfs.mkdir(`${home}/Music`, { parents: true });
          const r = await importFiles(kernel, files, `${home}/Music`);
          if (r.imported[0]) setCurrent(r.imported[0]);
        }}><Icon name="upload" size={14} />Importar músicas</button>
      </div>
      <div className="min-h-0 flex-1 overflow-auto px-2 pb-2">
        {!queue.length ? <Empty icon="music" title="Nenhuma música">Importe arquivos MP3, OGG, WAV ou M4A — eles vão para ~/Music.</Empty> : queue.map((p) => (
          <button key={p} className="list-row w-full text-left text-[0.88rem]" data-selected={p === current} onDoubleClick={() => setCurrent(p)} onClick={() => setCurrent(p)}>
            <Icon name={p === current && playing ? 'volume' : 'music'} size={15} className="text-muted" />
            <span className="truncate">{basename(p)}</span>
            <span className="ml-auto truncate text-[0.75rem] text-muted">{p.slice(home.length + 1, p.lastIndexOf('/')) || '~'}</span>
          </button>
        ))}
      </div>
      <audio
        ref={audio}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onTimeUpdate={(e) => setPos(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => { setDur(e.currentTarget.duration); setError(null); }}
        onEnded={() => (repeat && audio.current ? (audio.current.currentTime = 0, void audio.current.play()) : next(1))}
        onError={() => current && setError('O navegador não conseguiu tocar este arquivo (formato não suportado?).')}
      />
    </div>
  );
}
