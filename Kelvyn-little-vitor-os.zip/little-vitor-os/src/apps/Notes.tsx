import { useEffect, useMemo, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { useFsVersion, useKernel } from '../ui/hooks';
import { Icon } from '../ui/icons';
import { Empty, Segmented, cx, formatDate } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { basename } from '../core/vfs/path';
import { renderMarkdown } from '../ui/markdown';

export default function Notes({ args }: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const dir = `${kernel.users.current?.home ?? '/root'}/Documents/Notas`;
  const v = useFsVersion(dir);
  const [current, setCurrent] = useState<string | null>(args.path ?? null);
  const [text, setText] = useState('');
  const [mode, setMode] = useState<'edit' | 'split' | 'preview'>('split');
  const [q, setQ] = useState('');
  const [saveState, setSaveState] = useState<'saved' | 'saving' | 'error'>('saved');
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const loadedPath = useRef<string | null>(null);

  useEffect(() => {
    void kernel.vfs.mkdir(dir, { parents: true }).then(async () => {
      if (!kernel.vfs.readdir(dir).length) {
        await kernel.vfs.writeFile(`${dir}/Bem-vindo.md`, '# Bem-vindo às Notas\n\nAs notas são arquivos **Markdown** salvos em `~/Documents/Notas`.\n\n- [x] Criar a primeira nota\n- [ ] Experimentar o modo dividido\n\n> Dica: Ctrl+N cria uma nota nova.\n');
      }
    }).catch(() => undefined);
  }, [kernel, dir]);

  const notes = useMemo(() => {
    try {
      return kernel.vfs.readdir(dir).filter((e) => e.node.type === 'file' && e.name.endsWith('.md')).sort((a, b) => b.node.mtime - a.node.mtime);
    } catch {
      return [];
    }
  }, [kernel, dir, v]);

  useEffect(() => {
    if (!current && notes[0]) setCurrent(notes[0].path);
  }, [current, notes]);

  useEffect(() => {
    if (args.path) setCurrent(args.path);
  }, [args.path, args._t]);

  useEffect(() => {
    if (!current || loadedPath.current === current) return;
    loadedPath.current = current;
    kernel.vfs.readText(current).then(setText).catch(() => setText(''));
  }, [kernel, current]);

  const onChange = (t: string) => {
    setText(t);
    setSaveState('saving');
    if (timer.current) clearTimeout(timer.current);
    const p = current;
    timer.current = setTimeout(() => {
      if (!p) return;
      kernel.vfs.writeFile(p, t).then(() => setSaveState('saved')).catch(() => setSaveState('error'));
    }, 500);
  };

  const create = async () => {
    const name = await session.prompt('Nova nota', 'Nova nota', { confirmLabel: 'Criar' });
    if (!name) return;
    const p = kernel.vfs.uniquePath(`${dir}/${name.replace(/[/\0]/g, '-')}.md`);
    await kernel.vfs.writeFile(p, `# ${name}\n\n`);
    loadedPath.current = null;
    setCurrent(p);
  };

  const filtered = notes.filter((n) => !q || n.name.toLowerCase().includes(q.toLowerCase()));
  const html = useMemo(() => renderMarkdown(text), [text]);

  return (
    <div className="flex h-full" onKeyDown={(e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') { e.preventDefault(); void create(); } }}>
      <aside className="flex w-56 shrink-0 flex-col border-r border-line bg-surface-2 max-sm:w-40">
        <div className="flex gap-1 p-2">
          <input className="field h-8 min-w-0 flex-1 text-[0.85rem]" placeholder="Buscar" value={q} onChange={(e) => setQ(e.target.value)} />
          <button className="btn btn-primary btn-icon" aria-label="Nova nota (Ctrl+N)" title="Nova nota (Ctrl+N)" onClick={() => void create()}><Icon name="plus" size={16} /></button>
        </div>
        <div className="min-h-0 flex-1 overflow-auto px-1 pb-2">
          {filtered.map((n) => (
            <button key={n.path} className={cx('mb-0.5 w-full rounded-lg px-2.5 py-2 text-left', n.path === current ? 'bg-accent/20' : 'hover:bg-hover')} onClick={() => { loadedPath.current = null; setCurrent(n.path); }}>
              <div className="truncate text-[0.88rem] font-medium">{n.name.replace(/\.md$/, '')}</div>
              <div className="text-[0.72rem] text-muted">{formatDate(n.node.mtime)}</div>
            </button>
          ))}
        </div>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        {!current ? <Empty icon="note" title="Nenhuma nota" /> : (
          <>
            <div className="flex h-11 shrink-0 items-center gap-2 border-b border-line px-3">
              <div className="min-w-0 flex-1 truncate font-medium">{basename(current).replace(/\.md$/, '')}</div>
              <span className="text-[0.75rem] text-muted">{saveState === 'saving' ? 'salvando…' : saveState === 'error' ? 'erro ao salvar!' : 'salvo'}</span>
              <Segmented value={mode} onChange={setMode} options={[{ value: 'edit', label: 'Editar' }, { value: 'split', label: 'Dividir' }, { value: 'preview', label: 'Ver' }]} />
              <button className="btn btn-ghost btn-icon" aria-label="Excluir nota" title="Mover para a lixeira" onClick={async () => {
                if (!(await session.confirm('Mover nota para a lixeira?', basename(current), { confirmLabel: 'Mover', danger: true }))) return;
                await kernel.vfs.moveToTrash(current);
                loadedPath.current = null;
                setCurrent(null);
                setText('');
              }}><Icon name="trash" size={16} /></button>
            </div>
            <div className="flex min-h-0 flex-1">
              {mode !== 'preview' && (
                <textarea className="selectable min-w-0 flex-1 resize-none bg-surface p-4 font-mono text-[13px] leading-relaxed outline-none" value={text} onChange={(e) => onChange(e.target.value)} spellCheck={false} aria-label="Texto da nota" />
              )}
              {mode !== 'edit' && (
                <div className={cx('prose-lv selectable min-w-0 flex-1 overflow-auto p-5', mode === 'split' && 'border-l border-line')} dangerouslySetInnerHTML={{ __html: html }} />
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
