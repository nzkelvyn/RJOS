import { useEffect, useMemo, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { useKernel, useStore } from '../ui/hooks';
import { useSession } from '../desktop/sessionContext';
import { Empty, Spinner } from '../ui/components';
import { BRIDGE_SCRIPT } from '../core/packages/bridge';
import type { Permission } from '../core/packages/manifest';
import { isInside, normalize, resolve } from '../core/vfs/path';

const CSP = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; media-src data: blob:; font-src data:";

/**
 * Runs an installed LVP app inside a sandboxed iframe:
 * - sandbox="allow-scripts" WITHOUT allow-same-origin → opaque origin, no access to this page
 * - CSP blocks all network requests from the app
 * - the only way to reach the OS is the postMessage bridge, checked against the manifest permissions
 */
export default function PackageAppHost({ windowId }: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const win = useStore(session.wm.state).windows.find((w) => w.id === windowId);
  const name = win?.appId.replace(/^pkg:/, '') ?? '';
  const pkg = useStore(kernel.lvp.installed).find((p) => p.name === name);
  const [doc, setDoc] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const frame = useRef<HTMLIFrameElement>(null);
  const settings = useStore(kernel.settings.user);

  useEffect(() => {
    if (!pkg?.entry) return;
    let alive = true;
    (async () => {
      try {
        if (!(await kernel.lvp.verify(pkg.name))) throw new Error('Os arquivos deste pacote foram alterados depois da instalação (sha256 não confere). Reinstale pela Central de Apps.');
        const files = await kernel.lvp.readFiles(pkg.name);
        let libs = '';
        for (const dep of Object.keys(pkg.dependencies)) {
          const depPkg = kernel.lvp.getInstalled(dep);
          if (!depPkg) throw new Error(`Dependência ausente: ${dep}`);
          const depFiles = await kernel.lvp.readFiles(dep);
          for (const [f, content] of Object.entries(depFiles)) {
            if (f.endsWith('.css')) libs += `<style>${content.replace(/<\/style/gi, '<\\/style')}</style>`;
            if (f.endsWith('.js')) libs += `<script>${content.replace(/<\/script/gi, '<\\/script')}</script>`;
          }
        }
        const scheme = document.documentElement.dataset.theme === 'light' ? 'light' : 'dark';
        const html = `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${CSP}"><meta name="color-scheme" content="${scheme}"><style>:root{color-scheme:${scheme}}</style>${libs}<script>${BRIDGE_SCRIPT}</script></head><body>${files[pkg.entry!] ?? ''}</body></html>`;
        if (alive) setDoc(html);
      } catch (err) {
        if (alive) setError((err as Error).message);
      }
    })();
    return () => {
      alive = false;
    };
  }, [kernel, pkg, settings.theme]);

  const perms = useMemo(() => new Set<Permission>(pkg?.permissions ?? []), [pkg]);

  useEffect(() => {
    if (!pkg) return;
    const home = kernel.users.current?.home ?? '/nonexistent';
    const dataDir = `${home}/.local/share/lvp/${pkg.name}`;
    const need = (p: Permission) => {
      if (!perms.has(p)) throw new Error(`permissão "${p}" não declarada no manifesto`);
    };
    const homePath = (raw: string) => {
      const p = normalize(resolve(home, raw.replace(/^~(?=\/|$)/, home), home));
      if (!isInside(p, home)) throw new Error('acesso negado: fora da pasta pessoal');
      return p;
    };
    const handlers: Record<string, (...a: unknown[]) => Promise<unknown>> = {
      notify: async (title, body) => {
        need('notifications');
        kernel.notifications.push({ app: 'pkg:' + pkg.name, appName: pkg.displayName, title: String(title).slice(0, 120), body: String(body ?? '').slice(0, 500), level: 'info' });
      },
      'storage.get': async (key) => {
        need('storage');
        const f = `${dataDir}/storage.json`;
        if (!kernel.vfs.exists(f)) return null;
        const data = JSON.parse(await kernel.vfs.readText(f));
        return data[String(key)] ?? null;
      },
      'storage.set': async (key, value) => {
        need('storage');
        await kernel.vfs.mkdir(dataDir, { parents: true });
        const f = `${dataDir}/storage.json`;
        const data = kernel.vfs.exists(f) ? JSON.parse(await kernel.vfs.readText(f)) : {};
        data[String(key)] = value;
        const json = JSON.stringify(data);
        if (json.length > 1024 * 1024) throw new Error('limite de 1 MB de armazenamento do app');
        await kernel.vfs.writeFile(f, json);
      },
      'fs.list': async (raw) => {
        if (!perms.has('fs:home:read') && !perms.has('fs:home:write')) need('fs:home:read');
        return kernel.vfs.readdir(homePath(String(raw))).map((e) => ({ name: e.name, path: e.path, type: e.node.type, size: e.node.size }));
      },
      'fs.read': async (raw) => {
        need('fs:home:read');
        const p = homePath(String(raw));
        if (kernel.vfs.stat(p).size > 2 * 1024 * 1024) throw new Error('arquivo maior que 2 MB');
        return kernel.vfs.readText(p);
      },
      'fs.write': async (raw, text) => {
        need('fs:home:write');
        const p = homePath(String(raw));
        await kernel.vfs.writeFile(p, String(text));
        return p;
      },
      'fs.writeDataUrl': async (raw, dataUrl) => {
        need('fs:home:write');
        const m = /^data:([\w/+.-]+);base64,(.*)$/s.exec(String(dataUrl));
        if (!m) throw new Error('data URL inválida');
        const bin = atob(m[2]);
        if (bin.length > 20 * 1024 * 1024) throw new Error('arquivo maior que 20 MB');
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        const p = homePath(String(raw));
        await kernel.vfs.mkdir(p.slice(0, p.lastIndexOf('/')), { parents: true });
        await kernel.vfs.writeFile(kernel.vfs.uniquePath(p), bytes);
        return p;
      },
      'clipboard.write': async (text) => {
        need('clipboard');
        await navigator.clipboard.writeText(String(text).slice(0, 1_000_000));
      },
      info: async () => ({ user: kernel.users.current?.username, theme: document.documentElement.dataset.theme, package: pkg.name, version: pkg.version }),
    };
    const onMessage = async (ev: MessageEvent) => {
      if (ev.source !== frame.current?.contentWindow) return; // only our iframe
      const d = ev.data as { __lvos?: string; id?: number; method?: string; args?: unknown[] };
      if (!d || d.__lvos !== 'req' || typeof d.id !== 'number' || typeof d.method !== 'string') return;
      const reply = (msg: Record<string, unknown>) => frame.current?.contentWindow?.postMessage({ __lvos: 'res', id: d.id, ...msg }, '*');
      const fn = handlers[d.method];
      if (!fn) return reply({ ok: false, error: `método desconhecido: ${d.method}` });
      try {
        reply({ ok: true, result: await fn(...(Array.isArray(d.args) ? d.args.slice(0, 4) : [])) });
      } catch (err) {
        reply({ ok: false, error: (err as Error).message });
      }
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [kernel, pkg, perms]);

  if (!pkg) return <Empty icon="package" title="Pacote não instalado">Este app foi removido.</Empty>;
  if (error) return <Empty icon="shield" title="Não foi possível abrir">{error}</Empty>;
  if (!doc) return <div className="grid h-full place-items-center text-muted"><Spinner /></div>;
  return <iframe ref={frame} title={pkg.displayName} srcDoc={doc} sandbox="allow-scripts" className="h-full w-full border-0 bg-surface" data-testid="package-frame" />;
}
