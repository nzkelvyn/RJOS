import { useEffect, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { useKernel } from '../ui/hooks';
import { Empty, Spinner, ToolButton, Toolbar } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { basename } from '../core/vfs/path';
import { downloadFile } from '../ui/blob';
import * as pdfjs from 'pdfjs-dist';

// The worker is served next to index.html (public/pdf.worker.min.mjs, copied from pdfjs-dist).
pdfjs.GlobalWorkerOptions.workerSrc = new URL('pdf.worker.min.mjs', document.baseURI).href;

type PDFDoc = Awaited<ReturnType<typeof pdfjs.getDocument>['promise']>;

export default function PdfViewer({ windowId, args }: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const [path, setPath] = useState<string | null>(args.path ?? null);
  const [doc, setDoc] = useState<PDFDoc | null>(null);
  const [page, setPage] = useState(1);
  const [scale, setScale] = useState(1.2);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (args.path) setPath(args.path);
  }, [args.path, args._t]);

  useEffect(() => {
    if (!path) return;
    let cancelled = false;
    let task: ReturnType<typeof pdfjs.getDocument> | null = null;
    setLoading(true);
    setError(null);
    session.wm.setTitle(windowId, `${basename(path)} — PDF`);
    (async () => {
      try {
        const data = await kernel.vfs.readFile(path);
        // pdf.js transfers the buffer to the worker, so pass a copy
        task = pdfjs.getDocument({ data: data.slice() });
        const loaded = await task.promise;
        if (cancelled) return;
        setDoc(loaded);
        setPage(1);
      } catch (err) {
        if (!cancelled) setError((err as Error).message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
      void task?.destroy();
    };
  }, [kernel, path, session, windowId]);

  useEffect(() => {
    if (!doc || !canvasRef.current) return;
    let task: { cancel: () => void; promise: Promise<void> } | null = null;
    let cancelled = false;
    (async () => {
      const p = await doc.getPage(page);
      if (cancelled) return;
      const dpr = window.devicePixelRatio || 1;
      const viewport = p.getViewport({ scale: scale * dpr });
      const canvas = canvasRef.current!;
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      canvas.style.width = `${viewport.width / dpr}px`;
      canvas.style.height = `${viewport.height / dpr}px`;
      task = p.render({ canvas, viewport });
      await task.promise.catch(() => undefined);
    })();
    return () => {
      cancelled = true;
      task?.cancel();
    };
  }, [doc, page, scale]);

  const pages = doc?.numPages ?? 0;
  return (
    <div
      className="flex h-full flex-col outline-none"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'ArrowRight' || e.key === 'PageDown') setPage((p) => Math.min(pages, p + 1));
        if (e.key === 'ArrowLeft' || e.key === 'PageUp') setPage((p) => Math.max(1, p - 1));
        if (e.key === '+' || e.key === '=') setScale((s) => Math.min(4, s + 0.2));
        if (e.key === '-') setScale((s) => Math.max(0.4, s - 0.2));
      }}
    >
      <Toolbar>
        <ToolButton icon="folder-open" label="Abrir" onClick={async () => {
          const p = await session.prompt('Abrir PDF', `${kernel.users.current?.home ?? ''}/Documents/`);
          if (p) setPath(p);
        }} />
        <ToolButton icon="chevron-left" label="Página anterior" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} />
        <span className="flex items-center gap-1 text-[0.85rem]">
          <input className="field h-7 w-12 text-center" value={page} onChange={(e) => { const n = Number(e.target.value); if (n >= 1 && n <= pages) setPage(n); }} aria-label="Página" /> / {pages || '–'}
        </span>
        <ToolButton icon="chevron-right" label="Próxima página" disabled={page >= pages} onClick={() => setPage((p) => p + 1)} />
        <div className="mx-1 h-5 w-px bg-line" />
        <ToolButton icon="zoom_out" label="Diminuir" onClick={() => setScale((s) => Math.max(0.4, s - 0.2))} />
        <span className="w-12 text-center text-[0.82rem]">{Math.round(scale * 100)}%</span>
        <ToolButton icon="zoom_in" label="Aumentar" onClick={() => setScale((s) => Math.min(4, s + 0.2))} />
        <ToolButton icon="download" label="Exportar" disabled={!path} onClick={() => path && void downloadFile(kernel, path)} />
      </Toolbar>
      <div className="min-h-0 flex-1 overflow-auto bg-surface-3 p-4">
        {!path ? <Empty icon="pdf" title="Nenhum PDF aberto">Abra um arquivo .pdf pelo gerenciador de arquivos.</Empty>
          : error ? <Empty icon="alert" title="Não foi possível abrir o PDF">{error}</Empty>
          : loading ? <div className="grid h-full place-items-center"><Spinner /></div>
          : <canvas ref={canvasRef} className="mx-auto block bg-white shadow-lg" data-testid="pdf-canvas" />}
      </div>
    </div>
  );
}
