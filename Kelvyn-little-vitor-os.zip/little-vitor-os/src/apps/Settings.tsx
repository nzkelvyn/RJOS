import { useEffect, useState } from 'react';
import type { AppProps } from './registry';
import { APPS } from './registry';
import { useKernel, useStore } from '../ui/hooks';
import { AppIcon, Icon } from '../ui/icons';
import { Badge, Card, Segmented, SettingRow, Toggle, cx, formatDate } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { WALLPAPERS } from '../desktop/wallpapers';
import { SHORTCUTS } from '../desktop/shortcuts';
import { ACCENTS, type Language, type ThemeMode } from '../core/settings/settings';
import type { UserAccount } from '../core/users/userManager';
import { PERMISSIONS } from '../core/packages/manifest';
import { formatBytes, formatDuration } from '../core/shell/args';
import { KERNEL_RELEASE, OS_NAME, OS_VERSION, memoryInfo } from '../kernel/info';
import { pickFiles, importFiles } from '../ui/blob';
import { syncEngine, syncStatus, startSync, stopSync } from '../core/sync/syncClient';
import { useAllApps } from '../desktop/Panels';

const PAGES = [
  { id: 'appearance', label: 'Aparência', icon: 'palette' },
  { id: 'desktop', label: 'Área de trabalho e Dock', icon: 'monitor' },
  { id: 'users', label: 'Usuários', icon: 'users' },
  { id: 'system', label: 'Sistema', icon: 'cpu' },
  { id: 'storage', label: 'Armazenamento', icon: 'hard-drive' },
  { id: 'network', label: 'Rede', icon: 'wifi' },
  { id: 'notifications', label: 'Notificações', icon: 'bell' },
  { id: 'privacy', label: 'Privacidade e segurança', icon: 'shield' },
  { id: 'accessibility', label: 'Acessibilidade', icon: 'accessibility' },
  { id: 'sync', label: 'Sincronização', icon: 'cloud' },
  { id: 'keyboard', label: 'Atalhos de teclado', icon: 'keyboard' },
  { id: 'about', label: 'Sobre', icon: 'info' },
] as const;
type PageId = (typeof PAGES)[number]['id'];

export default function Settings({ args }: AppProps) {
  const [page, setPage] = useState<PageId>((args.page as PageId) ?? 'appearance');
  useEffect(() => {
    if (args.page) setPage(args.page as PageId);
  }, [args.page, args._t]);
  return (
    <div className="flex h-full max-md:flex-col">
      <nav className="w-56 shrink-0 overflow-auto border-r border-line bg-surface-2 p-2 max-md:flex max-md:w-full max-md:gap-1 max-md:border-b max-md:border-r-0">
        {PAGES.map((p) => (
          <button key={p.id} className="list-row w-full text-left text-[0.9rem] max-md:w-auto max-md:shrink-0" data-selected={page === p.id} onClick={() => setPage(p.id)} data-testid={`settings-${p.id}`}>
            <Icon name={p.icon} size={17} className="text-muted" />
            <span className="whitespace-nowrap">{p.label}</span>
          </button>
        ))}
      </nav>
      <main className="min-w-0 flex-1 overflow-auto p-6">
        <h1 className="mb-4 text-[1.35rem] font-semibold">{PAGES.find((p) => p.id === page)?.label}</h1>
        {page === 'appearance' && <Appearance />}
        {page === 'desktop' && <DesktopPage />}
        {page === 'users' && <Users />}
        {page === 'system' && <SystemPage />}
        {page === 'storage' && <Storage />}
        {page === 'network' && <Network />}
        {page === 'notifications' && <NotificationsPage />}
        {page === 'privacy' && <Privacy />}
        {page === 'accessibility' && <Accessibility />}
        {page === 'sync' && <SyncPage />}
        {page === 'keyboard' && <Keyboard />}
        {page === 'about' && <About />}
      </main>
    </div>
  );
}

function useSettings() {
  const kernel = useKernel();
  const s = useStore(kernel.settings.user);
  return { s, set: kernel.settings.update.bind(kernel.settings), kernel };
}

function Appearance() {
  const { s, set, kernel } = useSettings();
  const home = kernel.users.current?.home ?? '/';
  return (
    <div className="space-y-5">
      <Card>
        <SettingRow title="Tema" desc="Automático segue o tema do seu computador.">
          <Segmented<ThemeMode> value={s.theme} onChange={(theme) => set({ theme })} options={[{ value: 'light', label: 'Claro', icon: 'sun' }, { value: 'dark', label: 'Escuro', icon: 'moon' }, { value: 'auto', label: 'Auto', icon: 'monitor' }]} />
        </SettingRow>
        <SettingRow title="Cor de destaque">
          <div className="flex flex-wrap gap-1.5">
            {ACCENTS.map((c) => (
              <button key={c} aria-label={`Cor ${c}`} className="h-7 w-7 rounded-full" style={{ background: c, outline: s.accent === c ? '2px solid var(--fg)' : 'none', outlineOffset: 2 }} onClick={() => set({ accent: c })} />
            ))}
            <label className="relative h-7 w-7 overflow-hidden rounded-full border border-line" title="Cor personalizada" style={{ background: 'conic-gradient(red,yellow,lime,cyan,blue,magenta,red)' }}>
              <input type="color" value={s.accent} onChange={(e) => set({ accent: e.target.value })} className="absolute inset-0 opacity-0" aria-label="Cor personalizada" />
            </label>
          </div>
        </SettingRow>
        <SettingRow title="Transparência" desc="Efeito de vidro na barra superior, dock e menus.">
          <Toggle checked={s.transparency} onChange={(transparency) => set({ transparency })} label="Transparência" />
        </SettingRow>
        <SettingRow title="Animações">
          <Toggle checked={s.animations} onChange={(animations) => set({ animations })} label="Animações" />
        </SettingRow>
      </Card>
      <div>
        <h2 className="mb-2 font-medium">Papel de parede</h2>
        <div className="grid grid-cols-[repeat(auto-fill,minmax(140px,1fr))] gap-3">
          {WALLPAPERS.map((w) => (
            <button key={w.id} onClick={() => set({ wallpaper: w.id })} className={cx('overflow-hidden rounded-xl border-2 text-left', s.wallpaper === w.id ? 'border-accent' : 'border-transparent')}>
              <div className="h-20" style={{ background: w.css }} />
              <div className="bg-surface-2 px-2 py-1 text-[0.82rem]">{w.name}</div>
            </button>
          ))}
          <button
            onClick={async () => {
              const files = await pickFiles('image/*', false);
              if (!files?.length) return;
              await kernel.vfs.mkdir(`${home}/Pictures`, { parents: true });
              const r = await importFiles(kernel, files, `${home}/Pictures`);
              if (r.imported[0]) set({ wallpaper: r.imported[0] });
            }}
            className={cx('grid h-[104px] place-items-center rounded-xl border-2 border-dashed text-[0.85rem] text-muted', !WALLPAPERS.some((w) => w.id === s.wallpaper) ? 'border-accent' : 'border-line')}
          >
            <span className="flex flex-col items-center gap-1"><Icon name="upload" size={20} />Imagem do computador</span>
          </button>
        </div>
        {!WALLPAPERS.some((w) => w.id === s.wallpaper) && <p className="mt-2 text-[0.82rem] text-muted">Atual: {s.wallpaper}</p>}
      </div>
    </div>
  );
}

function DesktopPage() {
  const { s, set } = useSettings();
  const apps = useAllApps();
  return (
    <div className="space-y-5">
      <Card>
        <SettingRow title="Ícones na área de trabalho">
          <Toggle checked={s.desktopIcons} onChange={(desktopIcons) => set({ desktopIcons })} label="Ícones" />
        </SettingRow>
        <SettingRow title="Tamanho dos ícones">
          <Segmented value={s.iconSize} onChange={(iconSize) => set({ iconSize })} options={[{ value: 'small', label: 'Pequeno' }, { value: 'medium', label: 'Médio' }, { value: 'large', label: 'Grande' }]} />
        </SettingRow>
        <SettingRow title="Posição do dock">
          <Segmented value={s.dockPosition} onChange={(dockPosition) => set({ dockPosition })} options={[{ value: 'bottom', label: 'Embaixo' }, { value: 'left', label: 'Esquerda' }]} />
        </SettingRow>
        <SettingRow title="Janelas sobre o dock" desc="Quando ligado, janelas maximizadas ocupam também a área do dock.">
          <Toggle checked={s.dockAutoHide} onChange={(dockAutoHide) => set({ dockAutoHide })} label="Janelas sobre o dock" />
        </SettingRow>
        <SettingRow title="Relógio 24 horas">
          <Toggle checked={s.clock24h} onChange={(clock24h) => set({ clock24h })} label="24 horas" />
        </SettingRow>
        <SettingRow title="Mostrar segundos">
          <Toggle checked={s.showSeconds} onChange={(showSeconds) => set({ showSeconds })} label="Segundos" />
        </SettingRow>
      </Card>
      <div>
        <h2 className="mb-2 font-medium">Aplicativos fixados no dock</h2>
        <Card className="py-2">
          {apps.map((a) => (
            <div key={a.id} className="flex items-center gap-3 py-1.5">
              <AppIcon icon={a.icon} color={a.color} emoji={a.emoji} size={26} />
              <span className="flex-1 text-[0.9rem]">{a.name}</span>
              <Toggle checked={s.dockApps.includes(a.id)} onChange={(on) => set({ dockApps: on ? [...s.dockApps, a.id] : s.dockApps.filter((x) => x !== a.id) })} label={`Fixar ${a.name}`} />
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

function Users() {
  const kernel = useKernel();
  const session = useSession();
  const me = kernel.users.current!;
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);
  const isAdmin = kernel.users.isAdmin();
  const refresh = () => kernel.users.humans().then(setUsers);
  useEffect(() => {
    void refresh();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const run = async (fn: () => Promise<unknown>, ok: string) => {
    try {
      await fn();
      setMsg({ text: ok, ok: true });
      await refresh();
    } catch (err) {
      setMsg({ text: (err as Error).message, ok: false });
    }
  };
  const create = async () => {
    const username = await session.prompt('Nome de usuário do novo usuário', '', { confirmLabel: 'Continuar', message: 'Letras minúsculas, números, _ ou -' });
    if (!username) return;
    const fullName = (await session.prompt('Nome completo', username)) ?? username;
    const password = await session.prompt('Senha inicial', '', { secret: true, confirmLabel: 'Criar' });
    if (!password) return;
    const admin = await session.confirm('Tornar administrador?', 'Administradores podem instalar pacotes e usar sudo.', { confirmLabel: 'Sim, administrador' });
    await run(() => kernel.users.create({ username, password, fullName, admin }), `Usuário ${username} criado.`);
  };
  return (
    <div className="space-y-4">
      {msg && <div className="rounded-lg px-3 py-2 text-[0.88rem]" style={{ background: msg.ok ? 'color-mix(in oklab,var(--success) 20%,transparent)' : 'color-mix(in oklab,var(--danger) 20%,transparent)' }}>{msg.text}</div>}
      <Card>
        <SettingRow title="Seu avatar" desc="Um emoji ou até 2 letras.">
          <div className="grid h-9 w-9 place-items-center rounded-full bg-accent text-[1.1rem] text-accent-fg">{me.avatar}</div>
          <button className="btn" onClick={async () => { const a = await session.prompt('Novo avatar', me.avatar); if (a) await run(() => kernel.users.update(me.username, { avatar: a }), 'Avatar atualizado.'); }}>Alterar</button>
        </SettingRow>
        <SettingRow title="Nome" desc={me.fullName}>
          <button className="btn" onClick={async () => { const n = await session.prompt('Nome completo', me.fullName); if (n) await run(() => kernel.users.update(me.username, { fullName: n }), 'Nome atualizado.'); }}>Alterar</button>
        </SettingRow>
        <SettingRow title="Senha">
          <button className="btn" onClick={async () => {
            const old = await session.prompt('Senha atual', '', { secret: true });
            if (old === null) return;
            const a = await session.prompt('Nova senha', '', { secret: true });
            if (!a) return;
            const b = await session.prompt('Confirme a nova senha', '', { secret: true });
            if (a !== b) return setMsg({ text: 'As senhas não coincidem.', ok: false });
            await run(() => kernel.users.changePassword(me.username, old, a), 'Senha alterada.');
          }}>Alterar senha</button>
        </SettingRow>
        <SettingRow title="Sessão">
          <button className="btn" onClick={() => kernel.users.lock()}><Icon name="lock" size={15} />Bloquear</button>
          <button className="btn" onClick={() => session.panel.set('system')}><Icon name="log-out" size={15} />Sair…</button>
        </SettingRow>
      </Card>
      <div className="flex items-center justify-between">
        <h2 className="font-medium">Contas neste computador</h2>
        <button className="btn btn-primary" disabled={!isAdmin} onClick={() => void create()} title={isAdmin ? '' : 'Somente administradores'}><Icon name="plus" size={15} />Adicionar usuário</button>
      </div>
      <Card className="py-1">
        {users.map((u) => (
          <div key={u.username} className="flex items-center gap-3 border-b border-line py-2.5 last:border-0">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-surface-3 text-[1.1rem]">{u.avatar}</div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 text-[0.92rem]">{u.fullName} {u.username === me.username && <Badge tone="accent">você</Badge>} {u.groups.includes('sudo') && <Badge tone="warn">admin</Badge>}</div>
              <div className="text-[0.78rem] text-muted">{u.username} · uid {u.uid} · {u.home}</div>
            </div>
            {isAdmin && u.username !== me.username && (
              <>
                <button className="btn" onClick={() => void run(() => kernel.users.update(u.username, { admin: !u.groups.includes('sudo') }), 'Permissões atualizadas.')}>{u.groups.includes('sudo') ? 'Remover admin' : 'Tornar admin'}</button>
                <button className="btn btn-ghost" onClick={async () => {
                  const p = await session.prompt(`Nova senha para ${u.username}`, '', { secret: true });
                  if (p) await run(() => kernel.users.changePassword(u.username, null, p), 'Senha redefinida.');
                }}>Redefinir senha</button>
                <button className="btn btn-ghost" style={{ color: 'var(--danger)' }} onClick={async () => {
                  if (await session.confirm(`Remover ${u.username}?`, `A pasta ${u.home} também será apagada.`, { confirmLabel: 'Remover', danger: true })) await run(() => kernel.users.remove(u.username), 'Usuário removido.');
                }}>Remover</button>
              </>
            )}
          </div>
        ))}
      </Card>
      {!isAdmin && <p className="text-[0.82rem] text-muted">Apenas administradores (grupo sudo) podem criar ou gerenciar outros usuários.</p>}
    </div>
  );
}

function SystemPage() {
  const { s, set, kernel } = useSettings();
  const session = useSession();
  const sys = useStore(kernel.settings.system);
  const isAdmin = kernel.users.isAdmin();
  const apps = useAllApps();
  const kinds: [string, string][] = [['text', 'Texto'], ['image', 'Imagens'], ['pdf', 'PDF'], ['audio', 'Áudio'], ['video', 'Vídeo'], ['archive', 'Zip']];
  return (
    <div className="space-y-5">
      <Card>
        <SettingRow title="Nome do computador" desc={sys.hostname}>
          <button className="btn" disabled={!isAdmin} onClick={async () => {
            const h = await session.prompt('Nome do computador', sys.hostname);
            if (!h) return;
            if (!/^[a-zA-Z0-9-]{1,63}$/.test(h)) return session.alert('Nome inválido', 'Use apenas letras, números e hífen.');
            await kernel.settings.saveSystem({ hostname: h });
            await kernel.vfs.writeFile('/etc/hostname', h + '\n', {}, { username: 'root', groups: ['root'] });
          }}>Alterar</button>
        </SettingRow>
        <SettingRow title="Idioma e formatos" desc="Esta versão tem a interface em português.">
          <select className="field" value={sys.language} disabled={!isAdmin} onChange={(e) => void kernel.settings.saveSystem({ language: e.target.value as Language })}>
            <option value="pt-BR">Português (Brasil)</option>
            <option value="en-US">English (US)</option>
          </select>
        </SettingRow>
        <SettingRow title="Data e hora" desc={`Fuso: ${sys.timezone} — vem do relógio do seu computador (o navegador não permite alterá-lo).`}>
          <span className="tabular-nums text-muted">{new Date().toLocaleString('pt-BR')}</span>
        </SettingRow>
      </Card>
      <div>
        <h2 className="mb-2 font-medium">Aplicativos padrão</h2>
        <Card>
          {kinds.map(([k, label]) => (
            <SettingRow key={k} title={label}>
              <select className="field" value={s.defaultApps[k] ?? ''} onChange={(e) => set({ defaultApps: { ...s.defaultApps, [k]: e.target.value } })}>
                {APPS.filter((a) => a.opens?.includes(k as never) || a.id === 'editor').map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
              </select>
            </SettingRow>
          ))}
        </Card>
      </div>
      <div>
        <h2 className="mb-2 font-medium">Inicialização</h2>
        <p className="mb-2 text-[0.85rem] text-muted">Apps abertos automaticamente quando você entra.</p>
        <Card className="py-2">
          {apps.filter((a) => !a.hidden).map((a) => (
            <div key={a.id} className="flex items-center gap-3 py-1.5">
              <AppIcon icon={a.icon} color={a.color} emoji={a.emoji} size={24} />
              <span className="flex-1 text-[0.9rem]">{a.name}</span>
              <Toggle checked={s.autostart.includes(a.id)} onChange={(on) => set({ autostart: on ? [...s.autostart, a.id] : s.autostart.filter((x) => x !== a.id) })} label={`Iniciar ${a.name}`} />
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

function Storage() {
  const kernel = useKernel();
  const [est, setEst] = useState<{ usage: number | null; quota: number | null }>({ usage: null, quota: null });
  const [persisted, setPersisted] = useState<boolean | null>(null);
  const stats = kernel.vfs.stats();
  const home = kernel.users.current?.home ?? '/';
  useEffect(() => {
    void kernel.vfs.estimate().then(setEst);
    navigator.storage?.persisted?.().then(setPersisted).catch(() => setPersisted(null));
  }, [kernel]);
  const pct = est.usage !== null && est.quota ? Math.min(100, (est.usage / est.quota) * 100) : null;
  const folders = ['Desktop', 'Documents', 'Downloads', 'Music', 'Pictures', 'Videos', 'Projects'].filter((f) => kernel.vfs.exists(`${home}/${f}`)).map((f) => ({ f, size: kernel.vfs.du(`${home}/${f}`) }));
  const max = Math.max(1, ...folders.map((x) => x.size));
  return (
    <div className="space-y-5">
      <Card className="py-4">
        <div className="mb-2 flex justify-between text-[0.9rem]"><span>Espaço usado pelo site</span><span className="text-muted">{est.usage !== null ? formatBytes(est.usage) : '?'} de {est.quota ? formatBytes(est.quota) : '?'}</span></div>
        <div className="progress" style={{ background: 'var(--surface-3)' }}><div style={{ width: `${pct ?? 0}%` }} /></div>
        <p className="mt-2 text-[0.8rem] text-muted">Valores reais do navegador (navigator.storage.estimate). Incluem cache e metadados.</p>
      </Card>
      <Card>
        <SettingRow title="Mecanismo de armazenamento"><code className="text-muted">{kernel.vfs.backendKind}</code></SettingRow>
        <SettingRow title="Arquivos no sistema virtual"><span className="text-muted">{stats.files} arquivos · {stats.dirs} pastas · {formatBytes(stats.bytes)}</span></SettingRow>
        <SettingRow title="Armazenamento persistente" desc="Impede o navegador de apagar os dados quando o disco enche.">
          {persisted ? <Badge tone="ok">concedido</Badge> : <button className="btn" onClick={async () => setPersisted((await navigator.storage?.persist?.()) ?? false)}>{persisted === false ? 'Pedir ao navegador' : 'Indisponível'}</button>}
        </SettingRow>
      </Card>
      <div>
        <h2 className="mb-2 font-medium">Sua pasta pessoal</h2>
        <Card className="py-3">
          {folders.map(({ f, size }) => (
            <div key={f} className="mb-2 last:mb-0">
              <div className="flex justify-between text-[0.85rem]"><span>{f}</span><span className="text-muted">{formatBytes(size)}</span></div>
              <div className="mt-1 h-1.5 rounded-full bg-surface-3"><div className="h-full rounded-full bg-accent" style={{ width: `${(size / max) * 100}%` }} /></div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

function Network() {
  const kernel = useKernel();
  const net = useStore(kernel.net.info);
  const [ping, setPing] = useState<string | null>(null);
  return (
    <div className="space-y-5">
      <Card>
        <SettingRow title="Conexão (real)" desc="Estado informado pelo navegador (navigator.onLine).">
          <Badge tone={net.online ? 'ok' : 'danger'}>{net.online ? 'Online' : 'Offline'}</Badge>
        </SettingRow>
        <SettingRow title="Tipo de conexão" desc="Network Information API — só existe em navegadores Chromium.">
          <span className="text-muted">{net.effectiveType ?? 'não informado'}</span>
        </SettingRow>
        <SettingRow title="Velocidade estimada"><span className="text-muted">{net.downlinkMbps !== null ? `${net.downlinkMbps} Mbps` : 'não informada'}</span></SettingRow>
        <SettingRow title="Latência estimada"><span className="text-muted">{net.rttMs !== null ? `${net.rttMs} ms` : 'não informada'}</span></SettingRow>
        <SettingRow title="Economia de dados"><span className="text-muted">{net.saveData === null ? 'não informada' : net.saveData ? 'ativada' : 'desativada'}</span></SettingRow>
        <SettingRow title="Teste de latência HTTP" desc={ping ?? 'Faz uma requisição real e mede o tempo de resposta.'}>
          <button className="btn" onClick={async () => {
            setPing('Medindo…');
            const r = await kernel.net.httpPing('https://www.google.com/generate_204');
            setPing(r.ok ? `Resposta em ${r.ms.toFixed(0)} ms` : `Falhou: ${r.error}`);
          }}>Testar</button>
        </SettingRow>
      </Card>
      <div>
        <h2 className="mb-2 font-medium">Interfaces virtuais</h2>
        <Card className="py-2">
          {kernel.net.interfaces().map((i) => (
            <div key={i.name} className="flex items-center gap-3 py-1.5 text-[0.88rem]">
              <code className="w-10">{i.name}</code>
              <span className="flex-1 text-muted">{i.ipv4} · {i.mac}</span>
              <Badge tone={i.state === 'UP' ? 'ok' : 'neutral'}>{i.state}</Badge>
              <Badge>simulada</Badge>
            </div>
          ))}
        </Card>
        <p className="mt-2 text-[0.8rem] text-muted">Navegadores não dão acesso às placas de rede reais, nem a IP, Wi-Fi ou portas. Estas interfaces existem só dentro do Little Vitor OS.</p>
      </div>
    </div>
  );
}

function NotificationsPage() {
  const { s, set, kernel } = useSettings();
  const apps = useAllApps();
  return (
    <div className="space-y-5">
      <Card>
        <SettingRow title="Não perturbe" desc="Notificações vão direto para a central, sem aparecer na tela. Mensagens do sistema ainda aparecem.">
          <Toggle checked={s.notificationsDnd} onChange={(v) => { set({ notificationsDnd: v }); kernel.notifications.setDnd(v); }} label="Não perturbe" />
        </SettingRow>
        <SettingRow title="Enviar notificação de teste">
          <button className="btn" onClick={() => kernel.notifications.push({ app: 'settings', appName: 'Configurações', title: 'Notificação de teste', body: 'Está funcionando 🎉', level: 'success' })}>Enviar</button>
        </SettingRow>
      </Card>
      <div>
        <h2 className="mb-2 font-medium">Por aplicativo</h2>
        <Card className="py-2">
          {apps.map((a) => (
            <div key={a.id} className="flex items-center gap-3 py-1.5">
              <AppIcon icon={a.icon} color={a.color} emoji={a.emoji} size={24} />
              <span className="flex-1 text-[0.9rem]">{a.name}</span>
              <Toggle checked={!s.mutedApps.includes(a.id)} onChange={(on) => { const mutedApps = on ? s.mutedApps.filter((x) => x !== a.id) : [...s.mutedApps, a.id]; set({ mutedApps }); kernel.notifications.setMuted(mutedApps); }} label={`Notificações de ${a.name}`} />
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

function Privacy() {
  const { s, set, kernel } = useSettings();
  const session = useSession();
  const st = useStore(kernel.users.state);
  const installed = useStore(kernel.lvp.installed);
  const home = kernel.users.current?.home ?? '/';
  return (
    <div className="space-y-5">
      <Card>
        <SettingRow title="Bloqueio automático" desc="Bloqueia a tela após inatividade.">
          <select className="field" value={s.lockAfterMinutes} onChange={(e) => set({ lockAfterMinutes: Number(e.target.value) })}>
            {[0, 1, 5, 10, 15, 30, 60].map((m) => <option key={m} value={m}>{m === 0 ? 'Nunca' : `${m} min`}</option>)}
          </select>
        </SettingRow>
        <SettingRow title="Bloquear agora" desc="Atalho: Super+L ou Ctrl+Alt+L"><button className="btn" onClick={() => kernel.users.lock()}><Icon name="lock" size={15} />Bloquear</button></SettingRow>
        <SettingRow title="Sessão atual" desc={st.session ? `${st.session.username} · iniciada em ${formatDate(st.session.startedAt)}` : ''}>
          <Badge tone="ok">ativa</Badge>
        </SettingRow>
      </Card>
      <Card>
        <SettingRow title="Salvar histórico do terminal" desc="~/.lvsh_history">
          <Toggle checked={s.terminalHistory} onChange={(terminalHistory) => set({ terminalHistory })} label="Histórico do terminal" />
        </SettingRow>
        <SettingRow title="Apagar histórico do terminal">
          <button className="btn" onClick={async () => {
            const p = `${home}/.lvsh_history`;
            if (kernel.vfs.exists(p)) await kernel.vfs.writeFile(p, '');
            kernel.notifications.push({ app: 'settings', appName: 'Configurações', title: 'Histórico apagado', level: 'success' });
          }}>Apagar</button>
        </SettingRow>
        <SettingRow title="Acesso a arquivos do computador" desc="O sistema só lê arquivos que você escolhe (importar/arrastar). Nada é lido do seu disco sem sua ação.">
          <Badge tone="ok">protegido</Badge>
        </SettingRow>
      </Card>
      <div>
        <h2 className="mb-2 font-medium">Permissões dos pacotes instalados</h2>
        <Card className="py-2">
          {!installed.filter((p) => p.entry).length && <div className="py-2 text-[0.88rem] text-muted">Nenhum app de pacote instalado.</div>}
          {installed.filter((p) => p.entry).map((p) => (
            <div key={p.name} className="border-b border-line py-2 last:border-0">
              <div className="text-[0.9rem]">{p.icon} {p.displayName} <span className="text-muted">({p.name} {p.version})</span></div>
              <div className="text-[0.8rem] text-muted">{p.permissions.length ? p.permissions.map((x) => PERMISSIONS[x]).join(' · ') : 'Nenhuma permissão'}</div>
            </div>
          ))}
        </Card>
      </div>
      <div>
        <h2 className="mb-2 font-medium" style={{ color: 'var(--danger)' }}>Zona de perigo</h2>
        <Card>
          <SettingRow title="Restaurar padrão de fábrica" desc="Apaga TODOS os usuários, arquivos e configurações deste navegador.">
            <button className="btn btn-danger" disabled={!kernel.users.isAdmin()} onClick={async () => {
              if (!(await session.confirm('Apagar tudo?', 'Todos os arquivos, usuários e configurações do Little Vitor OS neste navegador serão apagados. Não dá para desfazer.', { confirmLabel: 'Apagar tudo', danger: true }))) return;
              const pw = await session.prompt('Confirme com sua senha', '', { secret: true });
              if (!pw || !(await kernel.users.verify(kernel.users.current!.username, pw).catch(() => false))) return session.alert('Senha incorreta', 'Nada foi apagado.');
              await kernel.factoryReset();
              location.reload();
            }}>Restaurar</button>
          </SettingRow>
        </Card>
      </div>
    </div>
  );
}

function Accessibility() {
  const { s, set } = useSettings();
  return (
    <Card>
      <SettingRow title="Tamanho do texto" desc={`${Math.round(s.fontScale * 100)}%`}>
        <input type="range" min={0.85} max={1.4} step={0.05} value={s.fontScale} onChange={(e) => set({ fontScale: Number(e.target.value) })} aria-label="Tamanho do texto" className="accent-[var(--accent)]" />
      </SettingRow>
      <SettingRow title="Alto contraste"><Toggle checked={s.highContrast} onChange={(highContrast) => set({ highContrast })} label="Alto contraste" /></SettingRow>
      <SettingRow title="Reduzir movimento" desc="Desliga animações de janelas e menus."><Toggle checked={s.reduceMotion} onChange={(reduceMotion) => set({ reduceMotion })} label="Reduzir movimento" /></SettingRow>
      <SettingRow title="Navegação por teclado" desc="Tab percorre os controles; Enter ativa; Esc fecha menus. Veja Atalhos de teclado."><Badge tone="ok">ativa</Badge></SettingRow>
    </Card>
  );
}

function SyncPage() {
  const { s, set } = useSettings();
  const kernel = useKernel();
  const status = useStore(syncStatus);
  const [server, setServer] = useState(s.syncServer || 'http://localhost:4000');
  const [user, setUser] = useState(kernel.users.current?.username ?? '');
  const [pw, setPw] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const engine = syncEngine();
  const LABEL: Record<string, string> = { off: 'Desligada', disconnected: 'Servidor indisponível', 'needs-login': 'Precisa entrar', syncing: 'Sincronizando…', idle: 'Sincronizada', error: 'Erro' };
  return (
    <div className="space-y-5">
      <p className="text-[0.88rem] text-muted">Sincroniza sua pasta pessoal com o servidor do Little Vitor OS (pasta <code>server/</code> do projeto: Node.js + PostgreSQL). Assim seus arquivos aparecem em outros navegadores e computadores. Sem servidor, tudo continua funcionando localmente.</p>
      <Card>
        <SettingRow title="Endereço do servidor" desc="Ex.: http://localhost:4000">
          <input className="field w-60" value={server} onChange={(e) => setServer(e.target.value)} disabled={s.syncEnabled} />
        </SettingRow>
        <SettingRow title="Sincronização" desc={`${LABEL[status.phase]}${status.message ? ' — ' + status.message : ''}`}>
          <Toggle checked={s.syncEnabled} onChange={(on) => {
            setErr(null);
            if (on && !/^https?:\/\//.test(server)) return setErr('Use um endereço começando com http:// ou https://');
            set({ syncEnabled: on, syncServer: server });
            if (on) startSync(kernel, server);
            else stopSync();
          }} label="Sincronização" />
        </SettingRow>
        {s.syncEnabled && (
          <>
            <SettingRow title="Conta no servidor" desc={status.account ?? 'não conectada'}>
              {status.account ? <button className="btn" onClick={() => void engine?.logout()}>Sair</button> : null}
            </SettingRow>
            <SettingRow title="Tempo real (WebSocket)"><Badge tone={status.realtime ? 'ok' : 'neutral'}>{status.realtime ? 'conectado' : 'desconectado'}</Badge></SettingRow>
            <SettingRow title="Última sincronização" desc={`${status.uploaded} enviados · ${status.downloaded} recebidos`}>
              <span className="text-muted">{status.lastSync ? formatDate(status.lastSync) : '—'}</span>
              <button className="btn" disabled={!status.account} onClick={() => void engine?.fullSync().catch((e: Error) => setErr(e.message))}>Sincronizar agora</button>
            </SettingRow>
          </>
        )}
      </Card>
      {s.syncEnabled && status.phase === 'needs-login' && (
        <Card className="py-4">
          <div className="mb-3 font-medium">Entrar no servidor</div>
          <div className="grid gap-2 sm:grid-cols-2">
            <input className="field" placeholder="usuário" value={user} onChange={(e) => setUser(e.target.value)} />
            <input className="field" type="password" placeholder="senha (mín. 8)" value={pw} onChange={(e) => setPw(e.target.value)} />
          </div>
          <div className="mt-3 flex gap-2">
            <button className="btn btn-primary" onClick={() => engine?.login(user, pw).catch((e: Error) => setErr(e.message))}>Entrar</button>
            <button className="btn" onClick={() => engine?.login(user, pw, true).catch((e: Error) => setErr(e.message))}>Criar conta no servidor</button>
          </div>
        </Card>
      )}
      {err && <div className="text-[0.88rem]" style={{ color: 'var(--danger)' }}>{err}</div>}
    </div>
  );
}

function Keyboard() {
  return (
    <Card className="py-2">
      {SHORTCUTS.map(([k, d]) => (
        <div key={k} className="flex items-center justify-between gap-4 border-b border-line py-2.5 last:border-0">
          <span className="text-[0.9rem]">{d}</span>
          <span className="kbd whitespace-nowrap">{k}</span>
        </div>
      ))}
      <p className="py-2 text-[0.8rem] text-muted">Alguns atalhos (como Alt+Tab e Ctrl+Alt+Del no Windows) são capturados pelo seu sistema antes de chegar ao navegador — por isso cada um tem uma alternativa.</p>
    </Card>
  );
}

function About() {
  const kernel = useKernel();
  const sys = useStore(kernel.settings.system);
  const mem = memoryInfo();
  const ua = navigator.userAgent;
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-4">
        <div className="boot-logo" style={{ width: 64, height: 64, borderRadius: 18 }}><span className="text-[1.4rem] font-black text-white">LV</span></div>
        <div>
          <div className="text-[1.3rem] font-semibold">{OS_NAME}</div>
          <div className="text-muted">Versão {OS_VERSION} · kernel {KERNEL_RELEASE}</div>
        </div>
      </div>
      <Card>
        <SettingRow title="Computador"><span className="text-muted">{sys.hostname}</span></SettingRow>
        <SettingRow title="Instalado em"><span className="text-muted">{sys.installedAt ? formatDate(sys.installedAt) : '—'}</span></SettingRow>
        <SettingRow title="Ativo há"><span className="text-muted">{formatDuration(kernel.procs.uptimeMs())}</span></SettingRow>
        <SettingRow title="Processador (real)"><span className="text-muted">{navigator.hardwareConcurrency ?? '?'} núcleos lógicos</span></SettingRow>
        <SettingRow title="Memória (real)"><span className="text-muted">{mem ? `heap JS ${formatBytes(mem.used)} / ${formatBytes(mem.limit)}` : 'não exposta por este navegador'}</span></SettingRow>
        <SettingRow title="Pacotes LVP"><span className="text-muted">{kernel.lvp.installed.get().length}</span></SettingRow>
        <SettingRow title="Navegador"><span className="max-w-[340px] truncate text-[0.8rem] text-muted" title={ua}>{ua}</span></SettingRow>
      </Card>
      <p className="text-[0.82rem] text-muted">O Little Vitor OS é um ambiente operacional que roda dentro do navegador. Os comandos do terminal e os processos são implementados pelo próprio sistema — nenhum binário Linux real é executado.</p>
    </div>
  );
}
