import { useEffect, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { useInterval, useKernel, useStore } from '../ui/hooks';
import { Badge, Card, cx } from '../ui/components';
import { memoryInfo } from '../kernel/info';
import { formatBytes, formatDuration } from '../core/shell/args';
import { useSession } from '../desktop/sessionContext';
import type { LoggedEvent } from '../kernel/events';

interface Sample {
  lag: number;
  heap: number | null;
  procs: number;
  fps: number;
}

function Spark({ data, max, color, label }: { data: number[]; max: number; color: string; label: string }) {
  const w = 300;
  const h = 70;
  const pts = data.map((v, i) => `${(i / Math.max(1, data.length - 1)) * w},${h - (Math.min(v, max) / max) * (h - 4) - 2}`).join(' ');
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-[70px] w-full" preserveAspectRatio="none" role="img" aria-label={label}>
      <polyline points={`0,${h} ${pts} ${w},${h}`} fill={color} opacity="0.15" />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

export default function SystemMonitor(_: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const procs = useStore(kernel.procs.table);
  const wm = useStore(session.wm.state);
  const [tab, setTab] = useState<'resources' | 'processes' | 'events'>('resources');
  const [samples, setSamples] = useState<Sample[]>([]);
  const [events, setEvents] = useState<LoggedEvent[]>([]);
  const [storage, setStorage] = useState<{ usage: number | null; quota: number | null }>({ usage: null, quota: null });
  const frames = useRef(0);

  // count animation frames: a real measure of UI smoothness
  useEffect(() => {
    let id = 0;
    const loop = () => {
      frames.current++;
      id = requestAnimationFrame(loop);
    };
    id = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(id);
  }, []);

  useInterval(() => {
    const start = performance.now();
    setTimeout(() => {
      const lag = performance.now() - start;
      const mem = memoryInfo();
      const fps = frames.current;
      frames.current = 0;
      setSamples((s) => [...s.slice(-59), { lag, heap: mem?.used ?? null, procs: kernel.procs.list().length, fps }]);
      setEvents(kernel.events.recent(80));
    }, 0);
  }, 1000);

  useEffect(() => {
    void kernel.vfs.estimate().then(setStorage);
  }, [kernel, samples.length % 10 === 0]); // eslint-disable-line react-hooks/exhaustive-deps

  const last = samples[samples.length - 1];
  const mem = memoryInfo();
  const vfsStats = kernel.vfs.stats();
  const tile = (title: string, value: string, sub: string, real: boolean, chart?: React.ReactNode) => (
    <Card className="py-3">
      <div className="flex items-center justify-between text-[0.82rem] text-muted">{title}<Badge tone={real ? 'ok' : 'neutral'}>{real ? 'real' : 'virtual'}</Badge></div>
      <div className="mt-1 text-[1.5rem] font-semibold tabular-nums">{value}</div>
      <div className="text-[0.78rem] text-muted">{sub}</div>
      {chart}
    </Card>
  );

  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 gap-1 border-b border-line bg-surface-2 px-3 py-2">
        {([['resources', 'Recursos'], ['processes', `Processos (${procs.length})`], ['events', 'Eventos']] as const).map(([id, l]) => (
          <button key={id} className={cx('h-8 rounded-lg px-3 text-[0.88rem]', tab === id ? 'bg-accent text-accent-fg' : 'hover:bg-hover')} onClick={() => setTab(id)}>{l}</button>
        ))}
      </div>
      <div className="min-h-0 flex-1 overflow-auto p-4">
        {tab === 'resources' && (
          <div className="grid gap-3 md:grid-cols-2">
            {tile('Atraso do event loop', last ? `${last.lag.toFixed(1)} ms` : '…', 'Quanto a aba demora para responder (CPU ocupada = valor alto)', true, <Spark data={samples.map((s) => s.lag)} max={Math.max(20, ...samples.map((s) => s.lag))} color="var(--accent)" label="Atraso do event loop" />)}
            {tile('Quadros por segundo', last ? `${last.fps} fps` : '…', 'Fluidez da interface medida por requestAnimationFrame', true, <Spark data={samples.map((s) => s.fps)} max={Math.max(60, ...samples.map((s) => s.fps))} color="#22c55e" label="FPS" />)}
            {mem
              ? tile('Memória (heap JavaScript)', formatBytes(mem.used), `de ${formatBytes(mem.limit)} — medido pelo navegador`, true, <Spark data={samples.map((s) => s.heap ?? 0)} max={mem.limit} color="#f59e0b" label="Memória" />)
              : tile('Memória', 'indisponível', 'Este navegador não expõe medição de memória (só Chromium tem)', true)}
            {tile('Armazenamento', storage.usage !== null ? formatBytes(storage.usage) : '…', storage.quota ? `de ${formatBytes(storage.quota)} de cota do navegador` : 'cota não informada', true, (
              <div className="progress mt-3" style={{ background: 'var(--surface-3)' }}><div style={{ width: `${storage.usage && storage.quota ? Math.max(1, (storage.usage / storage.quota) * 100) : 0}%` }} /></div>
            ))}
            {tile('Processos virtuais', String(procs.length), `${procs.filter((p) => p.kind === 'app').length} apps · ${procs.filter((p) => p.kind === 'system').length} serviços · ${procs.filter((p) => p.kind === 'command').length} comandos`, false, <Spark data={samples.map((s) => s.procs)} max={Math.max(10, ...samples.map((s) => s.procs))} color="#0ea5e9" label="Processos" />)}
            {tile('Janelas abertas', String(wm.windows.length), `${wm.windows.filter((w) => w.minimized).length} minimizada(s)`, false)}
            {tile('Sistema de arquivos virtual', `${vfsStats.files} arquivos`, `${vfsStats.dirs} pastas · ${formatBytes(vfsStats.bytes)} · ${kernel.vfs.backendKind}`, false)}
            {tile('Tempo de atividade', formatDuration(kernel.procs.uptimeMs()), `Núcleos lógicos (real): ${navigator.hardwareConcurrency ?? '?'}`, true)}
            <p className="text-[0.8rem] text-muted md:col-span-2">“real” = medido pelo navegador agora. “virtual” = contadores do próprio Little Vitor OS. Uso de CPU por processo não é mensurável no navegador, por isso não é exibido.</p>
          </div>
        )}
        {tab === 'processes' && (
          <table className="w-full text-[0.85rem]">
            <thead className="text-left text-muted"><tr>{['PID', 'Nome', 'Usuário', 'Tipo', 'Estado', 'Iniciado', 'Tempo'].map((h) => <th key={h} className="px-2 py-1 font-medium">{h}</th>)}</tr></thead>
            <tbody>
              {procs.map((p) => (
                <tr key={p.pid} className="border-t border-line">
                  <td className="px-2 py-1 tabular-nums">{p.pid}</td>
                  <td className="px-2 py-1">{p.name}</td>
                  <td className="px-2 py-1 text-muted">{p.user}</td>
                  <td className="px-2 py-1 text-muted">{p.kind}</td>
                  <td className="px-2 py-1">{p.state}</td>
                  <td className="px-2 py-1 text-muted">{new Date(p.startedAt).toLocaleTimeString('pt-BR')}</td>
                  <td className="px-2 py-1 text-muted">{p.cpuTimeMs === null ? '—' : `${(p.cpuTimeMs / 1000).toFixed(2)} s`}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {tab === 'events' && (
          <div className="font-mono text-[0.8rem]">
            {events.map((e, i) => (
              <div key={i} className="flex gap-3 border-b border-line py-1">
                <span className="shrink-0 text-muted">{new Date(e.at).toLocaleTimeString('pt-BR')}</span>
                <span className="w-24 shrink-0 text-accent">{e.type}</span>
                <span className="selectable min-w-0 break-all">{e.summary}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
