import { useState } from 'react';
import type { AppProps } from './registry';
import { useKernel, useNow, useStore } from '../ui/hooks';
import { AppIcon, Icon } from '../ui/icons';
import { Badge, Empty, cx } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { formatDuration } from '../core/shell/args';

export default function TaskManager(_: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const procs = useStore(kernel.procs.table);
  const wm = useStore(session.wm.state);
  const [tab, setTab] = useState<'apps' | 'all'>('apps');
  const [selected, setSelected] = useState<number | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  useNow(2000);
  const me = kernel.users.current?.username ?? '';
  const list = tab === 'apps' ? procs.filter((p) => p.kind === 'app') : procs;
  const sel = procs.find((p) => p.pid === selected);

  const signal = (sig: 'SIGTERM' | 'SIGKILL' | 'SIGSTOP' | 'SIGCONT') => {
    if (!sel) return;
    const err = kernel.procs.kill(sel.pid, sig, me);
    setMsg(err ?? `${sig} enviado para ${sel.name} (pid ${sel.pid})`);
    if (!err && (sig === 'SIGTERM' || sig === 'SIGKILL')) setSelected(null);
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 items-center gap-1 border-b border-line bg-surface-2 px-3 py-2">
        {([['apps', 'Aplicativos'], ['all', 'Todos os processos']] as const).map(([id, l]) => (
          <button key={id} className={cx('h-8 rounded-lg px-3 text-[0.88rem]', tab === id ? 'bg-accent text-accent-fg' : 'hover:bg-hover')} onClick={() => setTab(id)}>{l}</button>
        ))}
        <div className="ml-auto flex gap-1">
          <button className="btn" disabled={!sel || sel.state === 'stopped'} onClick={() => signal('SIGSTOP')} title="Pausar (SIGSTOP)">Pausar</button>
          <button className="btn" disabled={!sel || sel.state !== 'stopped'} onClick={() => signal('SIGCONT')} title="Continuar (SIGCONT)">Continuar</button>
          <button className="btn btn-danger" disabled={!sel} onClick={() => signal('SIGTERM')} data-testid="end-task">Encerrar</button>
          <button className="btn" disabled={!sel} onClick={() => signal('SIGKILL')} title="Forçar (SIGKILL)">Forçar</button>
        </div>
      </div>
      {msg && <div className="border-b border-line px-3 py-1.5 text-[0.84rem] text-muted">{msg}</div>}
      <div className="min-h-0 flex-1 overflow-auto">
        {!list.length ? <Empty icon="tasks" title="Nenhum aplicativo aberto" /> : (
          <table className="w-full text-[0.86rem]">
            <thead className="sticky top-0 bg-surface text-left text-muted"><tr>{['Nome', 'PID', 'Usuário', 'Estado', 'Ativo há'].map((h) => <th key={h} className="px-3 py-1.5 font-medium">{h}</th>)}</tr></thead>
            <tbody>
              {list.map((p) => {
                const win = p.windowId ? wm.windows.find((w) => w.id === p.windowId) : undefined;
                return (
                  <tr key={p.pid} className={cx('cursor-default', selected === p.pid ? 'bg-accent/20' : 'hover:bg-hover')} onClick={() => setSelected(p.pid)} onDoubleClick={() => win && session.wm.focus(win.id)}>
                    <td className="flex items-center gap-2 px-3 py-1.5">
                      {win ? <AppIcon icon={win.icon} color={win.color} emoji={win.emoji} size={20} /> : <Icon name={p.kind === 'system' ? 'cpu' : 'terminal'} size={16} className="text-muted" />}
                      <span className="truncate">{win?.title ?? p.command}</span>
                      {p.kind === 'system' && <Badge>sistema</Badge>}
                    </td>
                    <td className="px-3 py-1.5 tabular-nums text-muted">{p.pid}</td>
                    <td className="px-3 py-1.5 text-muted">{p.user}</td>
                    <td className="px-3 py-1.5">{p.state === 'running' ? 'executando' : p.state === 'stopped' ? 'pausado' : 'dormindo'}</td>
                    <td className="px-3 py-1.5 text-muted">{formatDuration(Date.now() - p.startedAt)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
      <div className="border-t border-line px-3 py-1.5 text-[0.76rem] text-muted">Processos virtuais do Little Vitor OS. Serviços do sistema são protegidos; você só pode encerrar processos seus.</div>
    </div>
  );
}
