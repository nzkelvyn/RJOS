import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { Shell } from '../core/shell/shell';
import type { ShellHost } from '../core/shell/types';
import { useKernel, useStore } from '../ui/hooks';
import { Icon } from '../ui/icons';
import { cx, useContextMenu } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { Screen, styleCss, type Line } from './terminal/ansi';
import { OS_NAME } from '../kernel/info';

interface TabState {
  id: number;
  title: string;
}

export default function Terminal({ windowId, args }: AppProps) {
  const session = useSession();
  const [tabs, setTabs] = useState<TabState[]>([{ id: 1, title: 'Terminal' }]);
  const [active, setActive] = useState(1);
  const nextId = useRef(2);

  const addTab = useCallback(() => {
    const id = nextId.current++;
    setTabs((t) => [...t, { id, title: 'Terminal' }]);
    setActive(id);
  }, []);
  const closeTab = useCallback(
    (id: number) => {
      setTabs((t) => {
        const rest = t.filter((x) => x.id !== id);
        if (!rest.length) {
          session.closeWindow(windowId);
          return t;
        }
        setActive((a) => (a === id ? rest[rest.length - 1].id : a));
        return rest;
      });
    },
    [session, windowId],
  );

  const activeTitle = tabs.find((t) => t.id === active)?.title ?? 'Terminal';
  useEffect(() => session.wm.setTitle(windowId, activeTitle), [session, windowId, activeTitle]);

  return (
    <div
      className="term flex h-full flex-col"
      onKeyDown={(e) => {
        if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 't') {
          e.preventDefault();
          addTab();
        }
        if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'w') {
          e.preventDefault();
          closeTab(active);
        }
      }}
    >
        <div className="flex h-8 shrink-0 items-center gap-1 border-b border-white/10 bg-black/25 px-1.5 font-sans text-[0.8rem]" role="tablist">
          {tabs.map((t) => (
            <div
              key={t.id}
              role="tab"
              aria-selected={t.id === active}
              className={cx('group flex h-6 max-w-44 items-center gap-1.5 rounded-md pl-2.5 pr-1', t.id === active ? 'bg-white/12 text-white' : 'text-white/60 hover:bg-white/6')}
              onClick={() => setActive(t.id)}
            >
              <span className="truncate">{t.title}</span>
              <button className="grid h-4 w-4 place-items-center rounded opacity-60 hover:bg-white/20 hover:opacity-100" aria-label="Fechar aba" onClick={(e) => { e.stopPropagation(); closeTab(t.id); }}>
                <Icon name="x" size={11} />
              </button>
            </div>
          ))}
          <button className="grid h-6 w-6 place-items-center rounded-md text-white/70 hover:bg-white/10" aria-label="Nova aba (Ctrl+Shift+T)" title="Nova aba (Ctrl+Shift+T)" onClick={addTab}>
            <Icon name="plus" size={14} />
          </button>
        </div>
      <div className="relative min-h-0 flex-1">
        {tabs.map((t, idx) => (
          <TerminalTab
            key={t.id}
            visible={t.id === active}
            cwd={idx === 0 ? args.cwd : undefined}
            onTitle={(title) => setTabs((list) => list.map((x) => (x.id === t.id ? { ...x, title } : x)))}
            onExit={() => closeTab(t.id)}
          />
        ))}
      </div>
    </div>
  );
}

function TerminalTab({ visible, cwd, onTitle, onExit }: { visible: boolean; cwd?: string; onTitle: (t: string) => void; onExit: () => void }) {
  const kernel = useKernel();
  const session = useSession();
  const settings = useStore(kernel.settings.user);
  const screen = useMemo(() => new Screen(), []);
  const [, force] = useState(0);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [prompt, setPrompt] = useState<{ q: string; secret: boolean } | null>(null);
  const [fullscreen, setFullscreen] = useState<string | null>(null);
  const [histIdx, setHistIdx] = useState<number | null>(null);
  const draft = useRef('');
  const promptResolve = useRef<((v: string | null) => void) | null>(null);
  const keyWaiters = useRef<((k: string) => void)[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const menu = useContextMenu();
  const exitRef = useRef(onExit);
  exitRef.current = onExit;

  const render = useCallback(() => force((x) => x + 1), []);
  const write = useCallback(
    (t: string) => {
      screen.write(t);
      render();
    },
    [screen, render],
  );

  const shell = useMemo(() => {
    const host: ShellHost = {
      clear: () => {
        screen.clear();
        render();
      },
      exit: () => setTimeout(() => exitRef.current(), 0),
      prompt: (q, secret = false) =>
        new Promise((resolve) => {
          promptResolve.current = resolve;
          setPrompt({ q, secret });
          setInput('');
        }),
      openPath: (p) => session.openPath(p),
      openApp: (id, a) => session.launch(id, a ?? {}),
      setFullscreen: (t) => setFullscreen(t),
      readKey: (signal) =>
        new Promise((resolve, reject) => {
          keyWaiters.current.push(resolve);
          signal.addEventListener('abort', () => reject(new Error('aborted')), { once: true });
        }),
      columns: () => {
        const w = scrollRef.current?.clientWidth ?? 640;
        return Math.max(20, Math.floor((w - 24) / 8.1));
      },
    };
    return new Shell(kernel, host, { write });
  }, [kernel, session, screen, render, write]);

  // process for the shell itself (shows in ps / Task Manager)
  useEffect(() => {
    const proc = kernel.procs.spawn({ ppid: 1, name: 'lvsh', command: '-lvsh', user: shell.user.username, kind: 'app' }, () => exitRef.current());
    let alive = true;
    (async () => {
      if (cwd && kernel.vfs.isDir(cwd)) shell.cd(cwd, { write });
      await shell.init();
      if (!alive) return;
      const motd = kernel.vfs.exists('/etc/motd') ? await kernel.vfs.readText('/etc/motd').catch(() => '') : '';
      write(`\x1b[1m${OS_NAME}\x1b[0m — lvsh\n${motd}\n`);
      render();
    })();
    return () => {
      alive = false;
      kernel.procs.exit(proc.pid);
    };
  }, [kernel, shell, cwd, write, render]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  });

  useEffect(() => {
    if (visible && !fullscreen) inputRef.current?.focus();
  }, [visible, busy, prompt, fullscreen]);

  const cwdTitle = () => {
    const home = shell.home;
    const d = shell.cwd === home ? '~' : shell.cwd.startsWith(home + '/') ? '~' + shell.cwd.slice(home.length) : shell.cwd;
    return `${shell.user.username}@${shell.env.get('HOSTNAME')}: ${d}`;
  };

  const submit = async () => {
    if (prompt) {
      const r = promptResolve.current;
      promptResolve.current = null;
      write(prompt.q + (prompt.secret ? '' : input) + '\n');
      setPrompt(null);
      setInput('');
      r?.(input);
      return;
    }
    const line = input;
    write(shell.prompt() + line + '\n');
    setInput('');
    setHistIdx(null);
    if (!line.trim()) return;
    setBusy(true);
    onTitle(line.trim().split(/\s+/)[0]);
    try {
      await shell.run(line);
    } catch (err) {
      write(`\x1b[31mlvsh: erro interno: ${(err as Error).message}\x1b[0m\n`);
    }
    for (const n of shell.takeNotices()) write(n + '\n');
    setBusy(false);
    onTitle(cwdTitle());
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const ctrl = e.ctrlKey && !e.altKey && !e.metaKey;
    if (ctrl && e.key.toLowerCase() === 'c' && !e.shiftKey) {
      e.preventDefault();
      if (prompt) {
        write(prompt.q + '^C\n');
        promptResolve.current?.(null);
        promptResolve.current = null;
        setPrompt(null);
      } else if (busy) shell.interrupt();
      else {
        write(shell.prompt() + input + '^C\n');
        setInput('');
      }
      return;
    }
    if (busy && !prompt) return;
    if (ctrl && e.key.toLowerCase() === 'l') {
      e.preventDefault();
      screen.clear();
      render();
      return;
    }
    if (ctrl && e.key.toLowerCase() === 'd' && !input) {
      e.preventDefault();
      onExit();
      return;
    }
    if (ctrl && e.key.toLowerCase() === 'u') {
      e.preventDefault();
      setInput('');
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      void submit();
      return;
    }
    if (prompt) return;
    if (e.key === 'Tab') {
      e.preventDefault();
      const r = shell.complete(input);
      if (r.options.length) write(shell.prompt() + input + '\n' + r.options.join('  ') + '\n');
      setInput(r.replacement);
      return;
    }
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault();
      const h = shell.history;
      if (!h.length) return;
      let idx = histIdx;
      if (e.key === 'ArrowUp') {
        if (idx === null) {
          draft.current = input;
          idx = h.length - 1;
        } else idx = Math.max(0, idx - 1);
      } else {
        if (idx === null) return;
        idx = idx + 1;
        if (idx >= h.length) {
          setHistIdx(null);
          setInput(draft.current);
          return;
        }
      }
      setHistIdx(idx);
      setInput(h[idx]);
    }
  };

  // keys for full-screen programs (top)
  useEffect(() => {
    if (!fullscreen || !visible) return;
    const fn = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key.toLowerCase() === 'c') {
        e.preventDefault();
        shell.interrupt();
        return;
      }
      const w = keyWaiters.current.shift();
      if (w) {
        e.preventDefault();
        w(e.key);
      }
    };
    window.addEventListener('keydown', fn);
    return () => window.removeEventListener('keydown', fn);
  }, [fullscreen, visible, shell]);

  const promptText = prompt ? prompt.q : busy ? '' : shell.prompt();
  const promptScreen = useMemo(() => {
    const s = new Screen();
    s.write(promptText);
    return s.lines[0] ?? [];
  }, [promptText]);

  const copySelection = () => {
    const sel = window.getSelection()?.toString() ?? '';
    if (sel) void navigator.clipboard?.writeText(sel).catch(() => undefined);
  };
  const paste = async () => {
    try {
      const t = await navigator.clipboard.readText();
      setInput((v) => v + t.replace(/\n/g, ' '));
      inputRef.current?.focus();
    } catch {
      kernel.notifications.push({ app: 'terminal', appName: 'Terminal', title: 'Colar bloqueado', body: 'O navegador não liberou a área de transferência. Use Ctrl+Shift+V.', level: 'warning' });
    }
  };

  return (
    <div
      className="absolute inset-0 flex flex-col"
      style={{ display: visible ? 'flex' : 'none' }}
      onMouseUp={() => {
        if (!window.getSelection()?.toString()) inputRef.current?.focus();
      }}
      onContextMenu={(e) =>
        menu.open(e, [
          { label: 'Copiar', icon: 'copy', shortcut: 'Ctrl+Shift+C', onClick: copySelection },
          { label: 'Colar', icon: 'clipboard', shortcut: 'Ctrl+Shift+V', onClick: () => void paste() },
          { separator: true },
          { label: 'Limpar tela', icon: 'refresh', shortcut: 'Ctrl+L', onClick: () => { screen.clear(); render(); } },
        ])
      }
      onKeyDown={(e) => {
        if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'c') {
          e.preventDefault();
          copySelection();
        }
      }}
    >
      <div ref={scrollRef} className="selectable min-h-0 flex-1 overflow-auto whitespace-pre-wrap break-all px-3 py-2" data-testid="terminal-output">
        {screen.lines.map((line, i) => (
          <TermLine key={i} line={line} />
        ))}
        {!fullscreen && (
          <div className="flex items-baseline">
            <span className="shrink-0">
              <TermLine line={promptScreen} inline />
            </span>
            <input
              ref={inputRef}
              className="min-w-0 flex-1 bg-transparent font-mono text-inherit outline-none"
              style={{ caretColor: '#d7dae4', fontSize: 'inherit', display: busy && !prompt ? 'none' : undefined }}
              type={prompt?.secret ? 'password' : 'text'}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKeyDown}
              spellCheck={false}
              autoCapitalize="off"
              autoComplete="off"
              autoCorrect="off"
              aria-label="Entrada do terminal"
              data-testid="terminal-input"
            />
            {busy && !prompt && <span className="term-cursor" data-blink={settings.animations}>&nbsp;</span>}
          </div>
        )}
      </div>
      {fullscreen !== null && (
        <div className="absolute inset-0 overflow-auto whitespace-pre px-3 py-2" style={{ background: 'var(--term-bg)' }} data-testid="terminal-fullscreen">
          {(() => {
            const s = new Screen();
            s.write(fullscreen);
            return s.lines.map((l, i) => <TermLine key={i} line={l} />);
          })()}
        </div>
      )}
      {menu.element}
    </div>
  );
}

function TermLine({ line, inline }: { line: Line; inline?: boolean }) {
  const content = line.map((s, i) => (
    <span key={i} style={styleCss(s.style)}>
      {s.text}
    </span>
  ));
  if (inline) return <>{content}</>;
  return <div className="min-h-[1.45em]">{content}</div>;
}
