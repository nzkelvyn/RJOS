import { useCallback, useEffect, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { useKernel } from '../ui/hooks';
import { ToolButton, Toolbar } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { basename, dirname, extname } from '../core/vfs/path';
import { downloadBlob } from '../ui/blob';
import { Icon } from '../ui/icons';

export default function TextEditor({ windowId, args }: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const [path, setPath] = useState<string | null>(args.path ?? null);
  const [text, setText] = useState('');
  const [saved, setSaved] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [readOnly, setReadOnly] = useState(false);
  const [wrap, setWrap] = useState(true);
  const [find, setFind] = useState<{ open: boolean; q: string; replace: string }>({ open: false, q: '', replace: '' });
  const [cursor, setCursor] = useState({ line: 1, col: 1 });
  const ref = useRef<HTMLTextAreaElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);
  const dirty = text !== saved;

  const load = useCallback(
    async (p: string) => {
      try {
        const st = kernel.vfs.stat(p);
        if (st.size > 5 * 1024 * 1024) throw new Error('Arquivo grande demais para o editor (limite de 5 MB).');
        const content = await kernel.vfs.readText(p);
        setText(content);
        setSaved(content);
        setPath(p);
        setReadOnly(!kernel.vfs.canAccess(p, 'w'));
        setError(null);
      } catch (err) {
        setError((err as Error).message);
      }
    },
    [kernel],
  );

  useEffect(() => {
    if (args.path) void load(args.path);
  }, [args.path, args._t, load]);

  useEffect(() => {
    session.wm.setTitle(windowId, `${dirty ? '● ' : ''}${path ? basename(path) : 'Sem título'}${readOnly ? ' (somente leitura)' : ''} — Editor`);
  }, [session, windowId, path, dirty, readOnly]);

  const saveAs = async () => {
    const home = kernel.users.current?.home ?? '/';
    const suggestion = path ?? `${home}/Documents/sem-titulo.txt`;
    const target = await session.prompt('Salvar como', suggestion, { confirmLabel: 'Salvar', message: 'Caminho completo do arquivo:' });
    if (!target) return false;
    const abs = target.startsWith('~') ? home + target.slice(1) : target;
    if (kernel.vfs.exists(abs) && abs !== path && !(await session.confirm('Substituir arquivo?', `${abs} já existe.`, { confirmLabel: 'Substituir', danger: true }))) return false;
    return write(abs);
  };

  const write = async (p: string) => {
    try {
      if (!kernel.vfs.exists(dirname(p))) throw new Error(`A pasta ${dirname(p)} não existe.`);
      await kernel.vfs.writeFile(p, text);
      setSaved(text);
      setPath(p);
      setReadOnly(false);
      setError(null);
      return true;
    } catch (err) {
      setError((err as Error).message);
      return false;
    }
  };

  const save = () => (path && !readOnly ? write(path) : saveAs());

  const open = async () => {
    if (dirty && !(await session.confirm('Descartar alterações?', 'O arquivo atual tem alterações não salvas.', { confirmLabel: 'Descartar', danger: true }))) return;
    const home = kernel.users.current?.home ?? '/';
    const p = await session.prompt('Abrir arquivo', path ? dirname(path) + '/' : home + '/', { confirmLabel: 'Abrir' });
    if (p) void load(p.startsWith('~') ? home + p.slice(1) : p);
  };

  const newDoc = async () => {
    if (dirty && !(await session.confirm('Descartar alterações?', undefined, { confirmLabel: 'Descartar', danger: true }))) return;
    setText('');
    setSaved('');
    setPath(null);
    setReadOnly(false);
  };

  const findNext = () => {
    const ta = ref.current;
    if (!ta || !find.q) return;
    const from = ta.selectionEnd;
    let idx = text.toLowerCase().indexOf(find.q.toLowerCase(), from);
    if (idx === -1) idx = text.toLowerCase().indexOf(find.q.toLowerCase());
    if (idx === -1) return setError(`“${find.q}” não encontrado.`);
    setError(null);
    ta.focus();
    ta.setSelectionRange(idx, idx + find.q.length);
  };

  const replaceAll = () => {
    if (!find.q) return;
    const re = new RegExp(find.q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    const count = (text.match(re) ?? []).length;
    setText(text.replace(re, find.replace));
    setError(`${count} ocorrência(s) substituída(s).`);
  };

  const lines = text.split('\n').length;
  const updateCursor = () => {
    const ta = ref.current;
    if (!ta) return;
    const before = text.slice(0, ta.selectionStart);
    const ls = before.split('\n');
    setCursor({ line: ls.length, col: ls[ls.length - 1].length + 1 });
  };

  return (
    <div
      className="flex h-full flex-col"
      onKeyDown={(e) => {
        const ctrl = e.ctrlKey || e.metaKey;
        const k = e.key.toLowerCase();
        if (ctrl && k === 's') {
          e.preventDefault();
          void (e.shiftKey ? saveAs() : save());
        } else if (ctrl && k === 'o') {
          e.preventDefault();
          void open();
        } else if (ctrl && (k === 'f' || k === 'h')) {
          e.preventDefault();
          setFind((f) => ({ ...f, open: true }));
        } else if (e.key === 'Escape' && find.open) setFind((f) => ({ ...f, open: false }));
      }}
    >
      <Toolbar>
        <ToolButton icon="file" label="Novo" onClick={() => void newDoc()} />
        <ToolButton icon="folder-open" label="Abrir (Ctrl+O)" onClick={() => void open()} />
        <ToolButton icon="save" label="Salvar (Ctrl+S)" onClick={() => void save()} disabled={!dirty && !!path} />
        <button className="btn btn-ghost h-8 text-[0.85rem]" onClick={() => void saveAs()}>Salvar como…</button>
        <div className="mx-1 h-5 w-px bg-line" />
        <ToolButton icon="search" label="Localizar e substituir (Ctrl+F)" active={find.open} onClick={() => setFind((f) => ({ ...f, open: !f.open }))} />
        <ToolButton icon="menu" label={wrap ? 'Desativar quebra de linha' : 'Ativar quebra de linha'} active={wrap} onClick={() => setWrap((w) => !w)} />
        <ToolButton icon="download" label="Exportar para o computador" onClick={() => downloadBlob(new Blob([text], { type: 'text/plain' }), path ? basename(path) : 'sem-titulo.txt')} />
        {path && extname(path) === '.md' && <ToolButton icon="eye" label="Abrir nas Notas (pré-visualização)" onClick={() => session.launch('notes', { path })} />}
      </Toolbar>
      {find.open && (
        <div className="flex flex-wrap items-center gap-2 border-b border-line bg-surface-2 px-2 py-1.5">
          <input autoFocus className="field h-8 w-44" placeholder="Localizar" value={find.q} onChange={(e) => setFind({ ...find, q: e.target.value })} onKeyDown={(e) => e.key === 'Enter' && findNext()} />
          <button className="btn h-8" onClick={findNext}>Próximo</button>
          <input className="field h-8 w-44" placeholder="Substituir por" value={find.replace} onChange={(e) => setFind({ ...find, replace: e.target.value })} />
          <button className="btn h-8" onClick={replaceAll} disabled={readOnly}>Substituir tudo</button>
          <button className="win-btn ml-auto" aria-label="Fechar busca" onClick={() => setFind({ ...find, open: false })}><Icon name="x" size={14} /></button>
        </div>
      )}
      {error && <div className="border-b border-line bg-warning/15 px-3 py-1.5 text-[0.85rem]" role="status">{error}</div>}
      <div className="flex min-h-0 flex-1 font-mono text-[13px] leading-[1.55]">
        <div ref={gutterRef} className="w-12 shrink-0 select-none overflow-hidden border-r border-line bg-surface-2 py-2 pr-2 text-right text-muted" aria-hidden="true">
          {!wrap && Array.from({ length: lines }, (_, i) => <div key={i}>{i + 1}</div>)}
        </div>
        <textarea
          ref={ref}
          className="selectable min-w-0 flex-1 resize-none bg-surface p-2 text-fg outline-none"
          style={{ whiteSpace: wrap ? 'pre-wrap' : 'pre', overflowWrap: wrap ? 'anywhere' : 'normal', tabSize: 4 }}
          value={text}
          readOnly={readOnly}
          spellCheck={false}
          onChange={(e) => setText(e.target.value)}
          onScroll={(e) => {
            if (gutterRef.current) gutterRef.current.scrollTop = e.currentTarget.scrollTop;
          }}
          onKeyUp={updateCursor}
          onClick={updateCursor}
          onKeyDown={(e) => {
            if (e.key === 'Tab' && !readOnly) {
              e.preventDefault();
              const ta = e.currentTarget;
              const s = ta.selectionStart;
              const next = text.slice(0, s) + '    ' + text.slice(ta.selectionEnd);
              setText(next);
              requestAnimationFrame(() => ta.setSelectionRange(s + 4, s + 4));
            }
          }}
          aria-label="Conteúdo do arquivo"
          data-testid="editor-textarea"
        />
      </div>
      <footer className="flex h-7 shrink-0 items-center gap-4 border-t border-line bg-surface-2 px-3 text-[0.78rem] text-muted">
        <span className="truncate">{path ?? 'Arquivo novo (não salvo)'}</span>
        <span className="ml-auto">Ln {cursor.line}, Col {cursor.col}</span>
        <span>{lines} linhas · {text.length} caracteres</span>
        <span>UTF-8</span>
      </footer>
    </div>
  );
}
