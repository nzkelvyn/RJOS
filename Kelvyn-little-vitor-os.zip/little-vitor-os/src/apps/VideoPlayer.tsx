import { useEffect, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { useKernel } from '../ui/hooks';
import { Empty, Spinner, ToolButton, Toolbar } from '../ui/components';
import { useSession } from '../desktop/sessionContext';
import { basename } from '../core/vfs/path';
import { importFiles, pickFiles, useFileUrl } from '../ui/blob';
import { volumeStore } from '../desktop/Panels';

export default function VideoPlayer({ windowId, args }: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const [path, setPath] = useState<string | null>(args.path ?? null);
  const [error, setError] = useState<string | null>(null);
  const [rate, setRate] = useState(1);
  const video = useRef<HTMLVideoElement>(null);
  const src = useFileUrl(kernel, path);

  useEffect(() => {
    if (args.path) setPath(args.path);
  }, [args.path, args._t]);
  useEffect(() => {
    session.wm.setTitle(windowId, path ? `${basename(path)} — Vídeos` : 'Vídeos');
    setError(null);
  }, [session, windowId, path]);
  useEffect(() => {
    const apply = () => video.current && (video.current.volume = volumeStore.value);
    apply();
    volumeStore.listeners.add(apply);
    return () => void volumeStore.listeners.delete(apply);
  }, [src.url]);
  useEffect(() => {
    if (video.current) video.current.playbackRate = rate;
  }, [rate]);

  return (
    <div className="flex h-full flex-col">
      <Toolbar>
        <ToolButton icon="folder-open" label="Abrir do sistema" onClick={async () => {
          const p = await session.prompt('Abrir vídeo', `${kernel.users.current?.home ?? ''}/Videos/`);
          if (p) setPath(p);
        }} />
        <ToolButton icon="upload" label="Importar do computador" onClick={async () => {
          const files = await pickFiles('video/*', false);
          if (!files) return;
          const dir = `${kernel.users.current?.home ?? ''}/Videos`;
          await kernel.vfs.mkdir(dir, { parents: true });
          const r = await importFiles(kernel, files, dir);
          if (r.imported[0]) setPath(r.imported[0]);
        }} />
        <select className="field ml-auto h-8" value={rate} onChange={(e) => setRate(Number(e.target.value))} aria-label="Velocidade">
          {[0.5, 0.75, 1, 1.25, 1.5, 2].map((r) => <option key={r} value={r}>{r}×</option>)}
        </select>
        <ToolButton icon="monitor" label="Tela cheia" disabled={!src.url} onClick={() => void video.current?.requestFullscreen?.()} />
      </Toolbar>
      <div className="grid min-h-0 flex-1 place-items-center bg-black">
        {!path ? <Empty icon="video" title="Nenhum vídeo aberto">Abra um MP4 ou WebM pelo gerenciador de arquivos ou importe do computador.</Empty>
          : src.error || error ? <Empty icon="alert" title="Não foi possível reproduzir">{src.error ?? error}</Empty>
          : !src.url ? <Spinner />
          : <video ref={video} src={src.url} controls autoPlay className="max-h-full max-w-full" onError={() => setError('Formato não suportado por este navegador.')} />}
      </div>
    </div>
  );
}
