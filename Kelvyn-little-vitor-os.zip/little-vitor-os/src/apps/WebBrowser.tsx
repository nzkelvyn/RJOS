import { useEffect, useRef, useState } from 'react';
import type { AppProps } from './registry';
import { useKernel } from '../ui/hooks';
import { Icon } from '../ui/icons';
import { ToolButton, cx } from '../ui/components';
import { useSession } from '../desktop/sessionContext';

interface Tab {
  id: number;
  url: string;
  history: string[];
  idx: number;
  srcdoc?: string;
  reloadKey: number;
}

interface Bookmark {
  title: string;
  url: string;
}

const HOME = 'lvos://inicio';
const DEFAULT_BOOKMARKS: Bookmark[] = [
  { title: 'Wikipédia', url: 'https://pt.wikipedia.org' },
  { title: 'OpenStreetMap', url: 'https://www.openstreetmap.org/export/embed.html' },
  { title: 'MDN Web Docs', url: 'https://developer.mozilla.org' },
  { title: 'Example.com', url: 'https://example.com' },
];

function normalizeInput(raw: string): string {
  const t = raw.trim();
  if (!t) return HOME;
  if (t.startsWith('lvos://') || t.startsWith('/') || t.startsWith('file://')) return t;
  if (/^https?:\/\//i.test(t)) return t;
  if (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(t)) return 'https://' + t;
  return 'https://duckduckgo.com/html/?q=' + encodeURIComponent(t);
}

export default function WebBrowser({ windowId, args }: AppProps) {
  const kernel = useKernel();
  const session = useSession();
  const seq = useRef(1);
  const [tabs, setTabs] = useState<Tab[]>([{ id: 0, url: args.url ?? HOME, history: [args.url ?? HOME], idx: 0, reloadKey: 0 }]);
  const [active, setActive] = useState(0);
  const tab = tabs.find((t) => t.id === active) ?? tabs[0];
  const [address, setAddress] = useState(tab.url);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(DEFAULT_BOOKMARKS);
  const bmPath = `${kernel.users.current?.home ?? '/root'}/.config/lvos/bookmarks.json`;

  useEffect(() => {
    if (!kernel.vfs.exists(bmPath)) return;
    kernel.vfs.readText(bmPath).then((t) => {
      const v = JSON.parse(t);
      if (Array.isArray(v)) setBookmarks(v.filter((b) => b && typeof b.url === 'string' && typeof b.title === 'string'));
    }).catch(() => undefined);
  }, [kernel, bmPath]);

  const saveBookmarks = async (list: Bookmark[]) => {
    setBookmarks(list);
    await kernel.vfs.mkdir(bmPath.slice(0, bmPath.lastIndexOf('/')), { parents: true });
    await kernel.vfs.writeFile(bmPath, JSON.stringify(list, null, 2));
  };

  useEffect(() => {
    setAddress(tab.url === HOME ? '' : tab.url);
    session.wm.setTitle(windowId, tab.url === HOME ? 'Nova aba — Navegador' : `${hostOf(tab.url)} — Navegador`);
  }, [tab.url, active, session, windowId]);

  const update = (patch: Partial<Tab>) => setTabs((ts) => ts.map((t) => (t.id === tab.id ? { ...t, ...patch } : t)));

  const go = async (raw: string) => {
    const url = normalizeInput(raw);
    try {
      if (url.startsWith(location.origin)) throw new Error('Por segurança, o Little Vitor OS não pode ser aberto dentro dele mesmo.');
    } catch (err) {
      return void kernel.notifications.push({ app: 'browser', appName: 'Navegador', title: 'Endereço bloqueado', body: (err as Error).message, level: 'warning' });
    }
    let srcdoc: string | undefined;
    if (url.startsWith('/') || url.startsWith('file://')) {
      const p = url.replace(/^file:\/\//, '');
      try {
        srcdoc = await kernel.vfs.readText(p);
      } catch (err) {
        srcdoc = `<p style="font-family:sans-serif">Não foi possível abrir ${p}: ${(err as Error).message}</p>`;
      }
    }
    const history = [...tab.history.slice(0, tab.idx + 1), url];
    update({ url, history, idx: history.length - 1, srcdoc });
  };

  const nav = (d: number) => {
    const idx = tab.idx + d;
    if (idx < 0 || idx >= tab.history.length) return;
    update({ idx, url: tab.history[idx], srcdoc: undefined });
    if (tab.history[idx].startsWith('/')) void go(tab.history[idx]);
  };

  const isBookmarked = bookmarks.some((b) => b.url === tab.url);

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-9 shrink-0 items-end gap-1 bg-surface-2 px-2 pt-1.5">
        {tabs.map((t) => (
          <div key={t.id} className={cx('group flex h-full max-w-48 min-w-0 items-center gap-1.5 rounded-t-lg px-3 text-[0.8rem]', t.id === active ? 'bg-surface' : 'hover:bg-hover')} onClick={() => setActive(t.id)}>
            <Icon name="globe" size={13} className="shrink-0 text-muted" />
            <span className="truncate">{t.url === HOME ? 'Nova aba' : hostOf(t.url)}</span>
            {tabs.length > 1 && (
              <button className="ml-auto grid h-4 w-4 shrink-0 place-items-center rounded opacity-50 hover:bg-hover hover:opacity-100" aria-label="Fechar aba" onClick={(e) => {
                e.stopPropagation();
                const rest = tabs.filter((x) => x.id !== t.id);
                setTabs(rest);
                if (active === t.id) setActive(rest[rest.length - 1].id);
              }}><Icon name="x" size={11} /></button>
            )}
          </div>
        ))}
        <button className="mb-1 grid h-6 w-6 place-items-center rounded-md hover:bg-hover" aria-label="Nova aba" onClick={() => {
          const id = seq.current++;
          setTabs((ts) => [...ts, { id, url: HOME, history: [HOME], idx: 0, reloadKey: 0 }]);
          setActive(id);
        }}><Icon name="plus" size={14} /></button>
      </div>
      <div className="flex h-11 shrink-0 items-center gap-1 border-b border-line px-2">
        <ToolButton icon="arrow-left" label="Voltar" disabled={tab.idx === 0} onClick={() => nav(-1)} />
        <ToolButton icon="arrow-right" label="Avançar" disabled={tab.idx >= tab.history.length - 1} onClick={() => nav(1)} />
        <ToolButton icon="refresh" label="Recarregar" onClick={() => update({ reloadKey: tab.reloadKey + 1 })} />
        <ToolButton icon="home" label="Início" onClick={() => void go(HOME)} />
        <form className="flex-1" onSubmit={(e) => { e.preventDefault(); void go(address); }}>
          <input className="field h-8 w-full rounded-full px-4 text-[0.88rem]" placeholder="Pesquisar ou digitar endereço" value={address} onChange={(e) => setAddress(e.target.value)} onFocus={(e) => e.target.select()} aria-label="Endereço" data-testid="browser-address" />
        </form>
        <ToolButton icon="star" label={isBookmarked ? 'Remover favorito' : 'Adicionar aos favoritos'} active={isBookmarked} disabled={tab.url === HOME} onClick={() => void saveBookmarks(isBookmarked ? bookmarks.filter((b) => b.url !== tab.url) : [...bookmarks, { title: hostOf(tab.url), url: tab.url }])} />
        <ToolButton icon="external-link" label="Abrir no navegador real" disabled={tab.url === HOME || !!tab.srcdoc} onClick={() => window.open(tab.url, '_blank', 'noopener,noreferrer')} />
      </div>
      <div className="relative min-h-0 flex-1 bg-white">
        {tab.url === HOME ? (
          <div className="h-full overflow-auto bg-surface p-8">
            <div className="mx-auto max-w-2xl">
              <h1 className="mb-6 text-center text-[1.6rem] font-semibold">Navegador</h1>
              <form onSubmit={(e) => { e.preventDefault(); void go(address); }}>
                <input autoFocus className="field mb-6 h-11 w-full rounded-full px-5" placeholder="Pesquisar no DuckDuckGo ou digitar um endereço" value={address} onChange={(e) => setAddress(e.target.value)} />
              </form>
              <div className="grid grid-cols-[repeat(auto-fill,minmax(150px,1fr))] gap-2">
                {bookmarks.map((b) => (
                  <button key={b.url} className="flex items-center gap-2 rounded-xl border border-line bg-surface-2 p-3 text-left text-[0.88rem] hover:bg-hover" onClick={() => void go(b.url)}>
                    <Icon name="star" size={15} className="text-accent" /><span className="truncate">{b.title}</span>
                  </button>
                ))}
              </div>
              <div className="mt-8 rounded-xl border border-line bg-surface-2 p-4 text-[0.85rem] text-muted">
                <b className="text-fg">Por que alguns sites aparecem em branco?</b> Muitos sites (Google, YouTube, bancos, redes sociais) proíbem ser exibidos dentro de outra página (cabeçalhos X-Frame-Options / CSP). É uma proteção deles, não um erro. Use o botão <Icon name="external-link" size={13} className="inline" /> para abrir no seu navegador de verdade. Também é possível abrir arquivos HTML do sistema digitando o caminho, ex.: <code>/home/usuario/Documents/pagina.html</code>.
              </div>
            </div>
          </div>
        ) : tab.srcdoc !== undefined ? (
          <iframe key={tab.reloadKey} title="Página local" srcDoc={tab.srcdoc} sandbox="allow-scripts" className="h-full w-full border-0" />
        ) : (
          <iframe
            key={`${tab.url}-${tab.reloadKey}`}
            title={tab.url}
            src={tab.url}
            sandbox="allow-scripts allow-forms allow-popups allow-same-origin allow-popups-to-escape-sandbox"
            referrerPolicy="no-referrer"
            className="h-full w-full border-0"
            data-testid="browser-frame"
          />
        )}
      </div>
    </div>
  );
}

function hostOf(url: string): string {
  if (url.startsWith('/')) return url.slice(url.lastIndexOf('/') + 1);
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}
