/**
 * Safe expression evaluator (shunting-yard) — never uses eval().
 * Supports + - × ÷ ^ %, parentheses, unary minus, functions and constants.
 */
const FUNCS: Record<string, (x: number) => number> = {
  sin: Math.sin, cos: Math.cos, tan: Math.tan, sqrt: Math.sqrt, ln: Math.log, log: Math.log10, abs: Math.abs,
};

export function evaluate(expr: string, degrees = false): number {
  const src = expr.replace(/×/g, '*').replace(/÷/g, '/').replace(/π/g, 'pi').replace(/\s+/g, '');
  const tokens = src.match(/\d*\.?\d+(e[+-]?\d+)?|[a-z]+|[-+*/^%()!]/gi);
  if (!tokens || tokens.join('') !== src) throw new Error('Expressão inválida');
  const out: (number | string)[] = [];
  const ops: string[] = [];
  const prec: Record<string, number> = { '+': 1, '-': 1, '*': 2, '/': 2, '%': 2, '^': 3, neg: 4 };
  let prevIsValue = false;
  for (const t of tokens) {
    if (/^[\d.]/.test(t)) {
      out.push(parseFloat(t));
      prevIsValue = true;
    } else if (t === 'pi' || t === 'e') {
      out.push(t === 'pi' ? Math.PI : Math.E);
      prevIsValue = true;
    } else if (FUNCS[t]) {
      ops.push(t);
      prevIsValue = false;
    } else if (t === '(') {
      ops.push(t);
      prevIsValue = false;
    } else if (t === ')') {
      while (ops.length && ops[ops.length - 1] !== '(') out.push(ops.pop()!);
      if (!ops.length) throw new Error('Parênteses desbalanceados');
      ops.pop();
      if (ops.length && FUNCS[ops[ops.length - 1]]) out.push(ops.pop()!);
      prevIsValue = true;
    } else if (t === '!') {
      out.push('!');
    } else {
      const op = t === '-' && !prevIsValue ? 'neg' : t;
      if (op === '+' && !prevIsValue) continue;
      while (ops.length) {
        const top = ops[ops.length - 1];
        if (top === '(' || FUNCS[top]) break;
        if (prec[top] > prec[op] || (prec[top] === prec[op] && op !== '^' && op !== 'neg')) out.push(ops.pop()!);
        else break;
      }
      ops.push(op);
      prevIsValue = false;
    }
  }
  while (ops.length) {
    const op = ops.pop()!;
    if (op === '(') throw new Error('Parênteses desbalanceados');
    out.push(op);
  }
  const st: number[] = [];
  for (const t of out) {
    if (typeof t === 'number') st.push(t);
    else if (FUNCS[t]) {
      const x = st.pop();
      if (x === undefined) throw new Error('Expressão inválida');
      const arg = degrees && ['sin', 'cos', 'tan'].includes(t) ? (x * Math.PI) / 180 : x;
      st.push(FUNCS[t](arg));
    } else if (t === 'neg') st.push(-(st.pop() ?? NaN));
    else if (t === '!') {
      const n = st.pop() ?? NaN;
      if (n < 0 || n > 170 || !Number.isInteger(n)) throw new Error('Fatorial só de inteiros 0–170');
      let f = 1;
      for (let i = 2; i <= n; i++) f *= i;
      st.push(f);
    } else {
      const b = st.pop();
      const a = st.pop();
      if (a === undefined || b === undefined) throw new Error('Expressão inválida');
      st.push(t === '+' ? a + b : t === '-' ? a - b : t === '*' ? a * b : t === '/' ? a / b : t === '%' ? a % b : a ** b);
    }
  }
  if (st.length !== 1 || Number.isNaN(st[0])) throw new Error('Expressão inválida');
  return st[0];
}
