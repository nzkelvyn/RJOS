import type { Kernel } from '../kernel/kernel';

export interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM or ''
  color: string;
  notes: string;
  reminder: boolean;
  notified?: boolean;
}

export function calendarPath(kernel: Kernel): string {
  return `${kernel.users.current?.home ?? '/root'}/.local/share/lvos/calendar.json`;
}

export async function loadEvents(kernel: Kernel): Promise<CalendarEvent[]> {
  const p = calendarPath(kernel);
  if (!kernel.vfs.exists(p)) return [];
  try {
    const data = JSON.parse(await kernel.vfs.readText(p));
    return Array.isArray(data) ? data.filter((e) => e && typeof e.title === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(e.date)) : [];
  } catch {
    return [];
  }
}

export async function saveEvents(kernel: Kernel, events: CalendarEvent[]): Promise<void> {
  const p = calendarPath(kernel);
  await kernel.vfs.mkdir(p.slice(0, p.lastIndexOf('/')), { parents: true });
  await kernel.vfs.writeFile(p, JSON.stringify(events, null, 2));
}

export function dateKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
