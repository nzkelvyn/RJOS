import { lazy, type ComponentType, type LazyExoticComponent } from 'react';
import type { InstalledPackage } from '../core/packages/manifest';
import type { FileKind } from '../core/vfs/mime';

export interface AppProps {
  windowId: string;
  args: Record<string, string>;
}

export interface AppDef {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  emoji?: string;
  category: 'Sistema' | 'Acessórios' | 'Multimídia' | 'Internet' | 'Escritório' | 'Pacotes';
  component: LazyExoticComponent<ComponentType<AppProps>> | ComponentType<AppProps>;
  size?: [number, number];
  minSize?: [number, number];
  singleton?: boolean;
  opens?: FileKind[];
  keywords?: string;
  /** hidden from launcher (opened programmatically) */
  hidden?: boolean;
}

const FileManager = lazy(() => import('./FileManager'));
const Terminal = lazy(() => import('./Terminal'));
const TextEditor = lazy(() => import('./TextEditor'));
const Calculator = lazy(() => import('./Calculator'));
const CalendarApp = lazy(() => import('./CalendarApp'));
const ClockApp = lazy(() => import('./ClockApp'));
const SystemMonitor = lazy(() => import('./SystemMonitor'));
const Settings = lazy(() => import('./Settings'));
const ImageViewer = lazy(() => import('./ImageViewer'));
const PdfViewer = lazy(() => import('./PdfViewer'));
const MusicPlayer = lazy(() => import('./MusicPlayer'));
const VideoPlayer = lazy(() => import('./VideoPlayer'));
const WebBrowser = lazy(() => import('./WebBrowser'));
const Notes = lazy(() => import('./Notes'));
const TaskManager = lazy(() => import('./TaskManager'));
const ArchiveManager = lazy(() => import('./ArchiveManager'));
const AppCenter = lazy(() => import('./AppCenter'));
const PackageAppHost = lazy(() => import('./PackageAppHost'));

export const APPS: AppDef[] = [
  { id: 'files', name: 'Arquivos', description: 'Gerenciador de arquivos', icon: 'folder', color: '#3b82f6', category: 'Sistema', component: FileManager, size: [860, 540], keywords: 'explorer pastas file manager' },
  { id: 'terminal', name: 'Terminal', description: 'Shell lvsh', icon: 'terminal', color: '#334155', category: 'Sistema', component: Terminal, size: [760, 460], keywords: 'console shell bash cmd' },
  { id: 'editor', name: 'Editor de Texto', description: 'Edite arquivos de texto e código', icon: 'edit', color: '#0ea5e9', category: 'Acessórios', component: TextEditor, size: [780, 540], opens: ['text'], keywords: 'text editor nano gedit código' },
  { id: 'calculator', name: 'Calculadora', description: 'Calculadora básica e científica', icon: 'calculator', color: '#f97316', category: 'Acessórios', component: Calculator, size: [340, 500], minSize: [300, 440], singleton: true },
  { id: 'calendar', name: 'Calendário', description: 'Agenda com eventos', icon: 'calendar', color: '#ef4444', category: 'Escritório', component: CalendarApp, size: [820, 560], singleton: true, keywords: 'agenda eventos' },
  { id: 'clock', name: 'Relógio', description: 'Relógio mundial, cronômetro e timer', icon: 'clock', color: '#8b5cf6', category: 'Acessórios', component: ClockApp, size: [460, 480], singleton: true, keywords: 'timer cronômetro alarme' },
  { id: 'monitor', name: 'Monitor do Sistema', description: 'Recursos e eventos em tempo real', icon: 'activity', color: '#10b981', category: 'Sistema', component: SystemMonitor, size: [820, 560], singleton: true, keywords: 'desempenho recursos memória cpu' },
  { id: 'settings', name: 'Configurações', description: 'Aparência, usuários, sistema', icon: 'settings', color: '#64748b', category: 'Sistema', component: Settings, size: [880, 600], singleton: true, keywords: 'preferências tema papel de parede usuários' },
  { id: 'images', name: 'Imagens', description: 'Visualizador de imagens', icon: 'image', color: '#ec4899', category: 'Multimídia', component: ImageViewer, size: [760, 560], opens: ['image'], keywords: 'fotos viewer' },
  { id: 'pdf', name: 'Leitor de PDF', description: 'Visualize documentos PDF', icon: 'pdf', color: '#dc2626', category: 'Escritório', component: PdfViewer, size: [760, 620], opens: ['pdf'], keywords: 'documento' },
  { id: 'music', name: 'Música', description: 'Player de áudio', icon: 'music', color: '#f43f5e', category: 'Multimídia', component: MusicPlayer, size: [520, 520], singleton: true, opens: ['audio'], keywords: 'mp3 áudio player' },
  { id: 'video', name: 'Vídeos', description: 'Player de vídeo', icon: 'video', color: '#7c3aed', category: 'Multimídia', component: VideoPlayer, size: [800, 520], opens: ['video'], keywords: 'mp4 filme player' },
  { id: 'browser', name: 'Navegador', description: 'Navegue na web', icon: 'globe', color: '#2563eb', category: 'Internet', component: WebBrowser, size: [980, 640], keywords: 'web internet browser' },
  { id: 'notes', name: 'Notas', description: 'Anotações rápidas em Markdown', icon: 'note', color: '#eab308', category: 'Escritório', component: Notes, size: [760, 520], singleton: true, keywords: 'anotações markdown' },
  { id: 'taskmanager', name: 'Gerenciador de Tarefas', description: 'Processos e aplicativos abertos', icon: 'tasks', color: '#0d9488', category: 'Sistema', component: TaskManager, size: [720, 480], singleton: true, keywords: 'processos kill encerrar' },
  { id: 'archive', name: 'Arquivos Compactados', description: 'Crie e extraia arquivos .zip', icon: 'archive', color: '#a16207', category: 'Acessórios', component: ArchiveManager, size: [720, 500], opens: ['archive'], keywords: 'zip compactar extrair' },
  { id: 'appcenter', name: 'Central de Apps', description: 'Instale apps com o LVP', icon: 'store', color: '#7c6cff', category: 'Sistema', component: AppCenter, size: [880, 600], singleton: true, keywords: 'lvp pacotes loja instalar' },
];

const byId = new Map(APPS.map((a) => [a.id, a]));

export function getApp(id: string): AppDef | undefined {
  return byId.get(id);
}

/** Builds an AppDef for an installed LVP package. */
export function packageApp(p: InstalledPackage): AppDef {
  return {
    id: 'pkg:' + p.name,
    name: p.displayName,
    description: p.description,
    icon: 'package',
    emoji: p.icon,
    color: '#475569',
    category: 'Pacotes',
    component: PackageAppHost,
    size: p.window ? [p.window.width, p.window.height] : [640, 480],
  };
}
