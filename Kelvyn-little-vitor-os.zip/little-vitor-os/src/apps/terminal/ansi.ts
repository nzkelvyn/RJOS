/**
 * Tiny ANSI renderer for the terminal: SGR colors/bold/dim/inverse,
 * clear screen (ESC[2J / ESC[H) and carriage handling.
 */
export interface Style {
  fg?: string;
  bg?: string;
  bold?: boolean;
  dim?: boolean;
  inverse?: boolean;
}

export interface Seg {
  text: string;
  style: Style;
}

export type Line = Seg[];

const PALETTE: Record<number, string> = {
  30: '#2e3240', 31: '#f7768e', 32: '#9ece6a', 33: '#e0af68', 34: '#7aa2f7', 35: '#bb9af7', 36: '#7dcfff', 37: '#c0caf5',
  90: '#6b7089', 91: '#ff8ea6', 92: '#b5e88a', 93: '#f5c97f', 94: '#8fb4ff', 95: '#cfb0ff', 96: '#9de2ff', 97: '#ffffff',
};
const BG: Record<number, string> = {
  40: '#2e3240', 41: '#f7768e', 42: '#9ece6a', 43: '#e0af68', 44: '#7aa2f7', 45: '#bb9af7', 46: '#7dcfff', 47: '#c0caf5',
};

export class Screen {
  lines: Line[] = [[]];
  private style: Style = {};
  readonly max: number;

  constructor(maxLines = 5000) {
    this.max = maxLines;
  }

  /** Returns true if the screen was cleared. */
  write(data: string): boolean {
    let cleared = false;
    let i = 0;
    let buf = '';
    const flush = () => {
      if (!buf) return;
      const parts = buf.split('\n');
      parts.forEach((p, idx) => {
        if (idx > 0) this.lines.push([]);
        if (p) this.push(p.replace(/\r/g, ''));
      });
      buf = '';
    };
    while (i < data.length) {
      const c = data[i];
      if (c === '\x1b' && data[i + 1] === '[') {
        flush();
        const m = /^\x1b\[([0-9;?]*)([A-Za-z])/.exec(data.slice(i));
        if (!m) {
          i++;
          continue;
        }
        i += m[0].length;
        if (m[2] === 'm') this.sgr(m[1]);
        else if (m[2] === 'J' && (m[1] === '2' || m[1] === '3')) {
          this.lines = [[]];
          cleared = true;
        }
        continue;
      }
      buf += c;
      i++;
    }
    flush();
    if (this.lines.length > this.max) this.lines.splice(0, this.lines.length - this.max);
    return cleared;
  }

  private push(text: string) {
    const line = this.lines[this.lines.length - 1];
    const last = line[line.length - 1];
    if (last && sameStyle(last.style, this.style)) last.text += text;
    else line.push({ text, style: { ...this.style } });
  }

  private sgr(params: string) {
    const codes = params === '' ? [0] : params.split(';').map(Number);
    for (const n of codes) {
      if (n === 0) this.style = {};
      else if (n === 1) this.style.bold = true;
      else if (n === 2) this.style.dim = true;
      else if (n === 7) this.style.inverse = true;
      else if (n === 22) this.style.bold = this.style.dim = false;
      else if (n === 27) this.style.inverse = false;
      else if (n === 39) delete this.style.fg;
      else if (n === 49) delete this.style.bg;
      else if (PALETTE[n]) this.style.fg = PALETTE[n];
      else if (BG[n]) this.style.bg = BG[n];
    }
  }

  clear() {
    this.lines = [[]];
    this.style = {};
  }

  /** Plain text (used by copy). */
  text(): string {
    return this.lines.map((l) => l.map((s) => s.text).join('')).join('\n');
  }
}

function sameStyle(a: Style, b: Style) {
  return a.fg === b.fg && a.bg === b.bg && !!a.bold === !!b.bold && !!a.dim === !!b.dim && !!a.inverse === !!b.inverse;
}

export function styleCss(s: Style): Record<string, string | number> | undefined {
  if (!s.fg && !s.bg && !s.bold && !s.dim && !s.inverse) return undefined;
  const css: Record<string, string | number> = {};
  let fg = s.fg;
  let bg = s.bg;
  if (s.inverse) {
    [fg, bg] = [bg ?? 'var(--term-bg)', fg ?? '#d7dae4'];
  }
  if (fg) css.color = fg;
  if (bg) css.background = bg;
  if (s.bold) css.fontWeight = 700;
  if (s.dim) css.opacity = 0.6;
  return css;
}
