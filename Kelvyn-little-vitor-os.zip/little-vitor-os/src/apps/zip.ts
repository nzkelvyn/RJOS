import JSZip from 'jszip';
import type { Kernel } from '../kernel/kernel';
import { basename, join, normalize } from '../core/vfs/path';

export interface ZipEntry {
  name: string;
  dir: boolean;
  size: number;
  date: Date;
}

const MAX_TOTAL = 500 * 1024 * 1024; // zip-bomb guard
const MAX_ENTRIES = 20000;

/** Builds a .zip from VFS paths (folders are added recursively). */
export async function zipPaths(kernel: Kernel, paths: string[]): Promise<Uint8Array> {
  const zip = new JSZip();
  const add = async (path: string, prefix: string) => {
    const node = kernel.vfs.stat(path);
    if (node.type === 'dir') {
      zip.folder(prefix);
      for (const e of kernel.vfs.readdir(path)) await add(e.path, `${prefix}/${e.name}`);
    } else {
      zip.file(prefix, await kernel.vfs.readFile(path), { date: new Date(node.mtime) });
    }
  };
  for (const p of paths) await add(p, basename(p));
  return zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 6 } });
}

export async function listZip(data: Uint8Array): Promise<ZipEntry[]> {
  const zip = await JSZip.loadAsync(data);
  const out: ZipEntry[] = [];
  zip.forEach((relPath, file) => {
    const size = (file as unknown as { _data?: { uncompressedSize?: number } })._data?.uncompressedSize ?? 0;
    out.push({ name: relPath.replace(/\/$/, ''), dir: file.dir, size, date: file.date });
  });
  return out.sort((a, b) => a.name.localeCompare(b.name));
}

/**
 * Extracts into `dest`, validating every entry: no absolute paths, no "..",
 * entry count and total size limits (protects against zip-slip and zip bombs).
 */
export async function extractZip(kernel: Kernel, data: Uint8Array, dest: string, only?: string[]): Promise<number> {
  const zip = await JSZip.loadAsync(data);
  const files = Object.values(zip.files);
  if (files.length > MAX_ENTRIES) throw new Error(`arquivo com entradas demais (${files.length})`);
  let total = 0;
  let count = 0;
  for (const f of files) {
    const clean = normalize(f.name);
    if (f.name.startsWith('/') || clean.startsWith('..') || clean.includes('/../') || f.name.includes('\0')) {
      throw new Error(`entrada insegura recusada: ${f.name}`);
    }
    if (only && !only.some((o) => clean === o || clean.startsWith(o + '/'))) continue;
    const target = join(dest, clean);
    if (f.dir) {
      await kernel.vfs.mkdir(target, { parents: true });
      continue;
    }
    const content = await f.async('uint8array');
    total += content.byteLength;
    if (total > MAX_TOTAL) throw new Error('conteúdo descompactado passa de 500 MB — extração interrompida');
    await kernel.vfs.mkdir(target.slice(0, target.lastIndexOf('/')) || '/', { parents: true });
    await kernel.vfs.writeFile(target, content);
    count++;
  }
  return count;
}
