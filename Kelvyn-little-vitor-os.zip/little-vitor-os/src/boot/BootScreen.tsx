import { BOOT_STEPS } from '../kernel/kernel';
import { OS_NAME, OS_VERSION } from '../kernel/info';

export function Logo({ size = 92 }: { size?: number }) {
  return (
    <div className="boot-logo" style={{ width: size, height: size, borderRadius: size * 0.28 }}>
      <svg width={size * 0.56} height={size * 0.56} viewBox="0 0 48 48" aria-hidden="true">
        <path d="M10 8v30h14" fill="none" stroke="#fff" strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M24 12l7 24 7-24" fill="none" stroke="#fff" strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round" opacity=".92" />
      </svg>
    </div>
  );
}

export function BootScreen({ step, error, verbose }: { step: number; error: string | null; verbose: boolean }) {
  const pct = Math.round(((step + 1) / BOOT_STEPS.length) * 100);
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center gap-7 bg-[#07080d] text-white" data-testid="boot-screen">
      <Logo />
      <div className="text-center">
        <div className="text-[1.6rem] font-semibold tracking-tight">{OS_NAME}</div>
        <div className="text-[0.85rem] text-white/50">versão {OS_VERSION}</div>
      </div>
      <div className="w-[min(320px,80vw)]">
        <div className="progress" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
          <div style={{ width: `${pct}%` }} />
        </div>
        <div className="mt-2 h-5 text-center text-[0.82rem] text-white/60">{error ? '' : BOOT_STEPS[Math.max(0, step)]?.label}…</div>
      </div>
      {verbose && (
        <div className="absolute bottom-4 left-4 right-4 max-h-[30vh] overflow-hidden font-mono text-[0.75rem] leading-relaxed text-white/45">
          {BOOT_STEPS.slice(0, step + 1).map((s, i) => (
            <div key={s.id}>
              [ <span className={i < step || pct === 100 ? 'text-emerald-400' : 'text-sky-400'}>{i < step || pct === 100 ? ' OK ' : ' .. '}</span> ] {s.label}
            </div>
          ))}
        </div>
      )}
      {error && (
        <div className="max-w-md rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-center text-[0.9rem]">
          <div className="mb-1 font-semibold text-red-300">Falha ao iniciar</div>
          <div className="selectable text-white/70">{error}</div>
          <button className="btn mt-3" onClick={() => location.reload()}>Tentar novamente</button>
        </div>
      )}
    </div>
  );
}
