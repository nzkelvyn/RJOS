import { useEffect, useRef, useState } from 'react';
import type { Kernel } from '../kernel/kernel';
import type { UserAccount } from '../core/users/userManager';
import { Icon } from '../ui/icons';
import { Spinner, cx } from '../ui/components';
import { useNow } from '../ui/hooks';
import { wallpaperCss } from '../desktop/wallpapers';

function Clock() {
  const now = useNow(1000);
  return (
    <div className="text-center text-white [text-shadow:0_2px_20px_rgba(0,0,0,.4)]">
      <div className="text-[4.5rem] font-light leading-none tabular-nums">{now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
      <div className="mt-2 text-[1.1rem] capitalize opacity-85">{now.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
    </div>
  );
}

function PasswordForm({ onSubmit, label, autoFocus = true }: { onSubmit: (pw: string) => Promise<string | null>; label: string; autoFocus?: boolean }) {
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [shake, setShake] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (autoFocus) ref.current?.focus();
  }, [autoFocus]);
  return (
    <form
      className="w-[min(300px,80vw)]"
      onSubmit={async (e) => {
        e.preventDefault();
        if (!pw || busy) return;
        setBusy(true);
        const err = await onSubmit(pw);
        setBusy(false);
        if (err) {
          setError(err);
          setPw('');
          setShake(true);
          setTimeout(() => setShake(false), 400);
          ref.current?.focus();
        }
      }}
    >
      <div className={cx('flex items-center rounded-full border border-white/25 bg-white/15 pl-4 backdrop-blur-md', shake && 'animate-[pulse_.4s]')}>
        <input
          ref={ref}
          type={show ? 'text' : 'password'}
          placeholder={label}
          value={pw}
          onChange={(e) => setPw(e.target.value)}
          className="h-11 flex-1 bg-transparent text-white outline-none placeholder:text-white/60"
          aria-label={label}
          autoComplete="current-password"
          data-testid="login-password"
        />
        <button type="button" className="grid h-9 w-9 place-items-center text-white/70" onClick={() => setShow((s) => !s)} aria-label={show ? 'Ocultar senha' : 'Mostrar senha'}>
          <Icon name={show ? 'eye-off' : 'eye'} size={17} />
        </button>
        <button type="submit" className="mr-1 grid h-9 w-9 place-items-center rounded-full bg-white/90 text-black" aria-label="Entrar" data-testid="login-submit">
          {busy ? <Spinner size={16} /> : <Icon name="arrow-right" size={17} />}
        </button>
      </div>
      <div className="mt-2 h-5 text-center text-[0.85rem] text-red-200" role="alert">{error}</div>
    </form>
  );
}

function Backdrop({ wallpaper }: { wallpaper: string }) {
  return <div className="absolute inset-0 scale-105 blur-md" style={{ background: wallpaperCss(wallpaper) ?? wallpaperCss('aurora')! }} />;
}

export function LoginScreen({ kernel, onLogin, initialUser }: { kernel: Kernel; onLogin: () => void; initialUser?: string }) {
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [selected, setSelected] = useState<string | null>(initialUser ?? null);
  useEffect(() => {
    kernel.users.humans().then((list) => {
      setUsers(list);
      if (!selected && list.length === 1) setSelected(list[0].username);
    });
  }, [kernel, selected]);
  const user = users.find((u) => u.username === selected);
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center gap-10 overflow-hidden" data-testid="login-screen">
      <Backdrop wallpaper="aurora" />
      <div className="relative"><Clock /></div>
      <div className="relative flex flex-col items-center gap-4">
        {user ? (
          <>
            <div className="grid h-24 w-24 place-items-center rounded-full border-2 border-white/40 bg-white/15 text-[2.6rem] backdrop-blur-md">{user.avatar}</div>
            <div className="text-[1.3rem] font-medium text-white">{user.fullName}</div>
            <PasswordForm
              label="Senha"
              onSubmit={async (pw) => {
                try {
                  await kernel.users.login(user.username, pw);
                  onLogin();
                  return null;
                } catch (err) {
                  return (err as Error).message;
                }
              }}
            />
            {users.length > 1 && <button className="text-[0.85rem] text-white/70 hover:text-white" onClick={() => setSelected(null)}>Outro usuário</button>}
          </>
        ) : (
          <div className="flex flex-wrap justify-center gap-4">
            {users.map((u) => (
              <button key={u.username} className="flex w-28 flex-col items-center gap-2 rounded-2xl p-3 text-white hover:bg-white/10" onClick={() => setSelected(u.username)} data-testid={`login-user-${u.username}`}>
                <div className="grid h-20 w-20 place-items-center rounded-full border-2 border-white/40 bg-white/15 text-[2.2rem] backdrop-blur-md">{u.avatar}</div>
                <span className="truncate">{u.fullName}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function LockScreen({ kernel, onUnlock, onSwitchUser }: { kernel: Kernel; onUnlock: () => void; onSwitchUser: () => void }) {
  const user = kernel.users.current;
  const [showForm, setShowForm] = useState(false);
  const wallpaper = kernel.settings.user.get().wallpaper;
  useEffect(() => {
    const key = () => setShowForm(true);
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);
  return (
    <div className="fixed inset-0 z-[9999] flex flex-col items-center justify-center gap-10 overflow-hidden fade-in" onClick={() => setShowForm(true)} data-testid="lock-screen">
      <Backdrop wallpaper={wallpaper} />
      <div className="absolute inset-0 bg-black/30" />
      <div className="relative"><Clock /></div>
      <div className="relative flex min-h-48 flex-col items-center gap-3">
        {showForm ? (
          <>
            <div className="grid h-20 w-20 place-items-center rounded-full border-2 border-white/40 bg-white/15 text-[2.2rem] backdrop-blur-md">{user?.avatar}</div>
            <div className="text-[1.15rem] text-white">{user?.fullName}</div>
            <PasswordForm
              label="Senha para desbloquear"
              onSubmit={async (pw) => {
                try {
                  if (await kernel.users.unlock(pw)) {
                    onUnlock();
                    return null;
                  }
                  return 'Senha incorreta.';
                } catch (err) {
                  return (err as Error).message;
                }
              }}
            />
            <button className="text-[0.85rem] text-white/70 hover:text-white" onClick={(e) => { e.stopPropagation(); onSwitchUser(); }}>Encerrar sessão / trocar usuário</button>
          </>
        ) : (
          <div className="flex items-center gap-2 text-white/80"><Icon name="lock" size={16} /> Clique ou pressione uma tecla para desbloquear</div>
        )}
      </div>
    </div>
  );
}
