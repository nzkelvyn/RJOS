import { useState } from 'react';
import type { Kernel } from '../kernel/kernel';
import { ACCENTS, type Language, type ThemeMode } from '../core/settings/settings';
import { formatBytes } from '../core/shell/args';
import { Icon } from '../ui/icons';
import { Segmented, Spinner, cx } from '../ui/components';
import { useStore } from '../ui/hooks';
import { Logo } from './BootScreen';
import { OS_NAME } from '../kernel/info';

const STEPS = ['Boas-vindas', 'Idioma', 'Conta', 'Aparência', 'Armazenamento', 'Pronto'];
const AVATARS = ['🦊', '🐼', '🐧', '🚀', '🎮', '🤖', '🌵', '⚡', '🎧', '🐱'];

export function SetupWizard({ kernel, onDone }: { kernel: Kernel; onDone: () => void }) {
  const [step, setStep] = useState(0);
  const [language, setLanguage] = useState<Language>('pt-BR');
  const [fullName, setFullName] = useState('Vitor');
  const [username, setUsername] = useState('vitor');
  const [touchedUser, setTouchedUser] = useState(false);
  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const [avatar, setAvatar] = useState(AVATARS[0]);
  const [hostname, setHostname] = useState('littlevitor');
  const settings = useStore(kernel.settings.user);
  const [storage, setStorage] = useState<{ usage: number | null; quota: number | null; persisted: boolean | null } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const userError =
    !/^[a-z_][a-z0-9_-]{0,31}$/.test(username) ? 'Use letras minúsculas, números, _ ou - (começando por letra).'
    : password.length < 4 ? 'A senha precisa ter pelo menos 4 caracteres.'
    : password !== password2 ? 'As senhas não coincidem.'
    : !/^[a-zA-Z0-9-]{1,63}$/.test(hostname) ? 'Nome do computador: só letras, números e hífen.'
    : null;

  const go = async (n: number) => {
    setError(null);
    if (n === 4 && !storage) {
      const est = await kernel.vfs.estimate();
      let persisted: boolean | null = null;
      try {
        persisted = (await navigator.storage?.persisted?.()) ?? null;
      } catch {
        persisted = null;
      }
      setStorage({ ...est, persisted });
    }
    setStep(n);
  };

  const finish = async () => {
    setBusy(true);
    setError(null);
    try {
      await kernel.users.create({ username, password, fullName, avatar, admin: true });
      await kernel.settings.saveSystem({ setupDone: true, language, hostname, installedAt: Date.now() });
      await kernel.vfs.writeFile('/etc/hostname', hostname + '\n', {}, { username: 'root', groups: ['root'] });
      // persist the appearance chosen in the wizard into the new user's settings
      const chosen = kernel.settings.user.get();
      await kernel.users.login(username, password);
      await kernel.startSession();
      kernel.settings.update({ theme: chosen.theme, accent: chosen.accent, wallpaper: chosen.wallpaper });
      await kernel.settings.flush();
      onDone();
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 grid place-items-center overflow-auto p-4" style={{ background: 'radial-gradient(900px 600px at 20% 20%, #5b47e055, transparent 60%), radial-gradient(800px 600px at 80% 80%, #0ea5e955, transparent 60%), var(--bg)' }} data-testid="setup">
      <div className="pop-in flex w-[min(760px,100%)] overflow-hidden rounded-2xl border border-line bg-surface shadow-2xl max-md:flex-col">
        <aside className="w-56 shrink-0 border-r border-line bg-surface-2 p-5 max-md:hidden">
          <div className="mb-6 flex items-center gap-2">
            <Logo size={34} />
            <span className="font-semibold">Configuração</span>
          </div>
          <ol className="space-y-1">
            {STEPS.map((s, i) => (
              <li key={s} className={cx('flex items-center gap-2 rounded-lg px-2 py-1.5 text-[0.9rem]', i === step ? 'bg-accent text-accent-fg' : i < step ? 'text-fg' : 'text-muted')}>
                <span className="grid h-5 w-5 place-items-center rounded-full border border-current text-[0.7rem]">{i < step ? <Icon name="check" size={12} /> : i + 1}</span>
                {s}
              </li>
            ))}
          </ol>
        </aside>
        <main className="flex min-h-[460px] flex-1 flex-col p-7">
          <div className="flex-1">
            {step === 0 && (
              <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
                <Logo size={80} />
                <h1 className="text-[1.7rem] font-semibold">Bem-vindo ao {OS_NAME}</h1>
                <p className="max-w-md text-muted">Um sistema operacional completo rodando no seu navegador: janelas, arquivos, terminal, aplicativos e pacotes. Vamos configurar em menos de um minuto.</p>
              </div>
            )}
            {step === 1 && (
              <div>
                <h2 className="mb-1 text-[1.3rem] font-semibold">Idioma</h2>
                <p className="mb-5 text-muted">Escolha o idioma do sistema.</p>
                {(
                  [
                    ['pt-BR', 'Português (Brasil)', 'Interface totalmente traduzida'],
                    ['en-US', 'English (US)', 'Formatos de data/número em inglês; a interface continua em português nesta versão'],
                  ] as [Language, string, string][]
                ).map(([code, name, desc]) => (
                  <button key={code} onClick={() => setLanguage(code)} className={cx('mb-2 flex w-full items-center gap-3 rounded-xl border p-3 text-left', language === code ? 'border-accent bg-accent/10' : 'border-line hover:bg-hover')}>
                    <Icon name="language" size={20} />
                    <span className="flex-1">
                      <span className="block font-medium">{name}</span>
                      <span className="block text-[0.82rem] text-muted">{desc}</span>
                    </span>
                    {language === code && <Icon name="check" size={18} />}
                  </button>
                ))}
              </div>
            )}
            {step === 2 && (
              <div>
                <h2 className="mb-1 text-[1.3rem] font-semibold">Criar sua conta</h2>
                <p className="mb-4 text-muted">Esta conta será administradora (pode instalar pacotes e usar sudo).</p>
                <div className="mb-3 flex flex-wrap gap-1.5">
                  {AVATARS.map((a) => (
                    <button key={a} onClick={() => setAvatar(a)} className={cx('grid h-10 w-10 place-items-center rounded-full text-[1.3rem]', avatar === a ? 'bg-accent' : 'bg-surface-3 hover:bg-hover')} aria-label={`Avatar ${a}`}>{a}</button>
                  ))}
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <label className="grid gap-1 text-[0.85rem]">Nome completo
                    <input className="field" value={fullName} onChange={(e) => {
                      setFullName(e.target.value);
                      if (!touchedUser) setUsername(e.target.value.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '').slice(0, 32) || 'usuario');
                    }} data-testid="setup-fullname" />
                  </label>
                  <label className="grid gap-1 text-[0.85rem]">Nome de usuário
                    <input className="field font-mono" value={username} onChange={(e) => { setTouchedUser(true); setUsername(e.target.value); }} data-testid="setup-username" />
                  </label>
                  <label className="grid gap-1 text-[0.85rem]">Senha
                    <input className="field" type="password" value={password} onChange={(e) => setPassword(e.target.value)} data-testid="setup-password" autoComplete="new-password" />
                  </label>
                  <label className="grid gap-1 text-[0.85rem]">Confirmar senha
                    <input className="field" type="password" value={password2} onChange={(e) => setPassword2(e.target.value)} data-testid="setup-password2" autoComplete="new-password" />
                  </label>
                  <label className="grid gap-1 text-[0.85rem] sm:col-span-2">Nome do computador
                    <input className="field font-mono" value={hostname} onChange={(e) => setHostname(e.target.value)} />
                  </label>
                </div>
                <p className="mt-3 text-[0.8rem] text-muted"><Icon name="shield" size={13} className="mr-1 inline" />A senha é guardada só como hash PBKDF2-SHA256 (nunca em texto puro).</p>
                {userError && (password || password2) && <p className="mt-2 text-[0.85rem]" style={{ color: 'var(--danger)' }}>{userError}</p>}
              </div>
            )}
            {step === 3 && (
              <div>
                <h2 className="mb-1 text-[1.3rem] font-semibold">Aparência</h2>
                <p className="mb-5 text-muted">Você pode mudar isso depois em Configurações.</p>
                <div className="mb-5">
                  <div className="mb-2 text-[0.85rem] text-muted">Tema</div>
                  <Segmented<ThemeMode>
                    value={settings.theme}
                    onChange={(theme) => kernel.settings.user.set({ ...settings, theme })}
                    options={[{ value: 'light', label: 'Claro', icon: 'sun' }, { value: 'dark', label: 'Escuro', icon: 'moon' }, { value: 'auto', label: 'Automático', icon: 'monitor' }]}
                  />
                </div>
                <div className="mb-2 text-[0.85rem] text-muted">Cor de destaque</div>
                <div className="flex gap-2">
                  {ACCENTS.map((c) => (
                    <button key={c} aria-label={`Cor ${c}`} onClick={() => kernel.settings.user.set({ ...settings, accent: c })} className="grid h-9 w-9 place-items-center rounded-full" style={{ background: c, outline: settings.accent === c ? '3px solid var(--fg)' : 'none', outlineOffset: 2 }}>
                      {settings.accent === c && <Icon name="check" size={16} style={{ color: '#fff' }} />}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {step === 4 && (
              <div>
                <h2 className="mb-1 text-[1.3rem] font-semibold">Armazenamento</h2>
                <p className="mb-4 text-muted">Seus arquivos ficam guardados no próprio navegador, neste computador.</p>
                <div className="space-y-2 rounded-xl border border-line bg-surface-2 p-4 text-[0.9rem]">
                  <div className="flex justify-between"><span className="text-muted">Mecanismo</span><span className="font-mono">{kernel.vfs.backendKind}</span></div>
                  <div className="flex justify-between"><span className="text-muted">Cota disponível (informada pelo navegador)</span><span>{storage?.quota ? formatBytes(storage.quota) : 'não informada'}</span></div>
                  <div className="flex justify-between"><span className="text-muted">Armazenamento persistente</span><span>{storage?.persisted === null ? 'não suportado' : storage?.persisted ? 'concedido' : 'não concedido'}</span></div>
                </div>
                <ul className="mt-4 space-y-1.5 text-[0.85rem] text-muted">
                  <li>• Limpar os dados do site no navegador apaga o sistema inteiro.</li>
                  <li>• “Persistente” pede ao navegador para não apagar os dados quando o disco enche.</li>
                  <li>• Sincronização com servidor pode ser ligada depois em Configurações › Sincronização.</li>
                </ul>
                {storage?.persisted === false && (
                  <button className="btn mt-4" onClick={async () => {
                    const ok = await navigator.storage?.persist?.().catch(() => false);
                    setStorage((s) => (s ? { ...s, persisted: !!ok } : s));
                  }}>Pedir armazenamento persistente</button>
                )}
              </div>
            )}
            {step === 5 && (
              <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
                <div className="grid h-16 w-16 place-items-center rounded-full bg-accent/20 text-[2rem]">{avatar}</div>
                <h2 className="text-[1.4rem] font-semibold">Tudo pronto, {fullName.split(' ')[0] || username}!</h2>
                <p className="max-w-sm text-muted">Clique em “Começar” para criar sua conta e entrar na área de trabalho.</p>
                {error && <p style={{ color: 'var(--danger)' }}>{error}</p>}
              </div>
            )}
          </div>
          <div className="mt-6 flex items-center justify-between">
            <button className="btn btn-ghost" disabled={step === 0 || busy} onClick={() => go(step - 1)}>Voltar</button>
            <div className="text-[0.8rem] text-muted md:hidden">{step + 1} / {STEPS.length}</div>
            {step < 5 ? (
              <button className="btn btn-primary" disabled={step === 2 && !!userError} onClick={() => go(step + 1)} data-testid="setup-next">Continuar</button>
            ) : (
              <button className="btn btn-primary" disabled={busy} onClick={finish} data-testid="setup-finish">{busy ? <Spinner size={16} /> : 'Começar'}</button>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
