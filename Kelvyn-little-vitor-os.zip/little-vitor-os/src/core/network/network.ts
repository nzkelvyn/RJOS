import { EventBus } from '../../kernel/events';
import { Store } from '../../kernel/store';

export interface NetworkInfo {
  online: boolean;
  /** From the Network Information API — only Chromium browsers expose it. */
  effectiveType: string | null;
  downlinkMbps: number | null;
  rttMs: number | null;
  saveData: boolean | null;
}

export interface VirtualInterface {
  name: string;
  ipv4: string;
  mac: string;
  state: 'UP' | 'DOWN';
  /** All interfaces are virtual: browsers do not expose real network interfaces. */
  simulated: true;
}

interface NavigatorConnection {
  effectiveType?: string;
  downlink?: number;
  rtt?: number;
  saveData?: boolean;
  addEventListener?: (type: string, fn: () => void) => void;
}

export class NetworkManager {
  readonly info = new Store<NetworkInfo>(readInfo());

  constructor(private events: EventBus) {
    if (typeof window === 'undefined') return;
    const refresh = () => {
      this.info.set(readInfo());
      this.events.emit('net:status', { online: this.info.get().online });
    };
    window.addEventListener('online', refresh);
    window.addEventListener('offline', refresh);
    connection()?.addEventListener?.('change', refresh);
  }

  interfaces(): VirtualInterface[] {
    const online = this.info.get().online;
    return [
      { name: 'lo', ipv4: '127.0.0.1/8', mac: '00:00:00:00:00:00', state: 'UP', simulated: true },
      { name: 'lv0', ipv4: '10.0.2.15/24', mac: '52:54:00:4c:56:01', state: online ? 'UP' : 'DOWN', simulated: true },
    ];
  }

  /**
   * HTTP "ping": measures real round-trip time of a HEAD/GET request with fetch().
   * Browsers cannot send ICMP packets, so this is NOT an ICMP echo.
   */
  async httpPing(target: string, timeoutMs = 5000): Promise<{ ok: boolean; ms: number; status?: number; error?: string }> {
    const url = toUrl(target);
    const started = performance.now();
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      // no-cors gives an opaque response but still measures a real network round-trip
      const res = await fetch(url, { method: 'HEAD', mode: 'no-cors', cache: 'no-store', signal: ctrl.signal });
      return { ok: true, ms: performance.now() - started, status: res.status || undefined };
    } catch (err) {
      return { ok: false, ms: performance.now() - started, error: ctrl.signal.aborted ? 'tempo esgotado' : String((err as Error).message) };
    } finally {
      clearTimeout(timer);
    }
  }

  /** Real HTTP request (subject to the browser's CORS rules). */
  async fetchText(target: string, init: RequestInit = {}, maxBytes = 2_000_000) {
    const res = await fetch(toUrl(target), { ...init, cache: 'no-store' });
    const buf = new Uint8Array(await res.arrayBuffer());
    return {
      status: res.status,
      statusText: res.statusText,
      headers: [...res.headers.entries()],
      body: buf.slice(0, maxBytes),
      truncated: buf.byteLength > maxBytes,
    };
  }
}

function connection(): NavigatorConnection | undefined {
  if (typeof navigator === 'undefined') return undefined;
  return (navigator as unknown as { connection?: NavigatorConnection }).connection;
}

function readInfo(): NetworkInfo {
  const c = connection();
  return {
    online: typeof navigator === 'undefined' ? true : navigator.onLine,
    effectiveType: c?.effectiveType ?? null,
    downlinkMbps: c?.downlink ?? null,
    rttMs: c?.rtt ?? null,
    saveData: c?.saveData ?? null,
  };
}

export function toUrl(target: string): string {
  if (/^https?:\/\//i.test(target)) return target;
  return 'https://' + target;
}
