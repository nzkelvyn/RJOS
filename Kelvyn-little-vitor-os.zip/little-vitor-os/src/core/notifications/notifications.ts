import { EventBus } from '../../kernel/events';
import { Store } from '../../kernel/store';

export type NotificationLevel = 'info' | 'success' | 'warning' | 'error';

export interface OSNotification {
  id: string;
  app: string;
  appName: string;
  title: string;
  body?: string;
  level: NotificationLevel;
  at: number;
  read: boolean;
  /** system messages ignore DND and app muting */
  system?: boolean;
  action?: { label: string; run: () => void };
}

export interface NotificationState {
  items: OSNotification[];
  /** notifications currently shown as toasts */
  toasts: string[];
  dnd: boolean;
  muted: string[];
}

const MAX_HISTORY = 100;
const TOAST_MS = 5000;

export class NotificationService {
  readonly state = new Store<NotificationState>({ items: [], toasts: [], dnd: false, muted: [] });
  private seq = 0;

  constructor(private events: EventBus) {}

  push(n: Omit<OSNotification, 'id' | 'at' | 'read'>): OSNotification {
    const item: OSNotification = {
      ...n,
      title: n.title.slice(0, 120),
      body: n.body?.slice(0, 500),
      id: `n${++this.seq}-${Date.now()}`,
      at: Date.now(),
      read: false,
    };
    const s = this.state.get();
    const silenced = !item.system && (s.dnd || s.muted.includes(item.app));
    this.state.set({
      ...s,
      items: [item, ...s.items].slice(0, MAX_HISTORY),
      toasts: silenced ? s.toasts : [...s.toasts, item.id].slice(-4),
    });
    if (!silenced) setTimeout(() => this.hideToast(item.id), item.level === 'error' ? TOAST_MS * 2 : TOAST_MS);
    this.events.emit('notify', { id: item.id });
    return item;
  }

  system(title: string, body?: string, level: NotificationLevel = 'info') {
    return this.push({ app: 'system', appName: 'Sistema', title, body, level, system: true });
  }

  hideToast(id: string): void {
    const s = this.state.get();
    if (s.toasts.includes(id)) this.state.set({ ...s, toasts: s.toasts.filter((t) => t !== id) });
  }

  markAllRead(): void {
    const s = this.state.get();
    this.state.set({ ...s, items: s.items.map((i) => ({ ...i, read: true })) });
  }

  dismiss(id: string): void {
    const s = this.state.get();
    this.state.set({ ...s, items: s.items.filter((i) => i.id !== id), toasts: s.toasts.filter((t) => t !== id) });
  }

  clear(): void {
    this.state.set({ ...this.state.get(), items: [], toasts: [] });
  }

  setDnd(dnd: boolean): void {
    this.state.set({ ...this.state.get(), dnd });
  }

  setMuted(muted: string[]): void {
    this.state.set({ ...this.state.get(), muted });
  }

  unreadCount(): number {
    return this.state.get().items.filter((i) => !i.read).length;
  }
}
