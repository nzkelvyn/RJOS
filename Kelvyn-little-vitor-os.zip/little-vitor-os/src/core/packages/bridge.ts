/**
 * Script injected into every LVP app iframe. The iframe is sandboxed WITHOUT
 * allow-same-origin, so the app has an opaque origin: no cookies, no
 * localStorage, no access to the host DOM. Its only channel to the OS is this
 * postMessage bridge, and every call is checked against the manifest
 * permissions on the host side.
 */
export const BRIDGE_SCRIPT = `
(function(){
  var seq = 0, pending = {};
  window.addEventListener('message', function(ev){
    var d = ev.data;
    if (!d || d.__lvos !== 'res' || !pending[d.id]) return;
    var p = pending[d.id]; delete pending[d.id];
    d.ok ? p.resolve(d.result) : p.reject(new Error(d.error));
  });
  function call(method, args){
    return new Promise(function(resolve, reject){
      var id = ++seq; pending[id] = {resolve: resolve, reject: reject};
      parent.postMessage({__lvos: 'req', id: id, method: method, args: args || []}, '*');
    });
  }
  window.lvos = {
    notify: function(title, body){ return call('notify', [String(title), body == null ? '' : String(body)]); },
    storage: {
      get: function(key){ return call('storage.get', [String(key)]); },
      set: function(key, value){ return call('storage.set', [String(key), value]); }
    },
    fs: {
      list: function(path){ return call('fs.list', [String(path)]); },
      read: function(path){ return call('fs.read', [String(path)]); },
      write: function(path, text){ return call('fs.write', [String(path), String(text)]); },
      writeDataUrl: function(path, dataUrl){ return call('fs.writeDataUrl', [String(path), String(dataUrl)]); }
    },
    clipboard: { write: function(text){ return call('clipboard.write', [String(text)]); } },
    info: function(){ return call('info', []); }
  };
})();
`;
