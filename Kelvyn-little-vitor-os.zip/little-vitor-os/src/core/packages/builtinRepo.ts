import { computeHash, type PackageManifest } from './manifest';

/**
 * Packages of the built-in "core" repository. Each one is a real, working
 * mini-app (HTML + JS) that runs sandboxed through the LVP bridge.
 */
type Draft = Omit<PackageManifest, 'sha256' | 'lvp' | 'license' | 'author'> & { author?: string };

const RUNTIME_CSS = `
:root{color-scheme:light dark;--bg:#f6f7fb;--fg:#1b1d26;--muted:#6b7080;--card:#fff;--line:#e3e5ee;--accent:#7c6cff}
@media (prefers-color-scheme:dark){:root{--bg:#161821;--fg:#e8e9f0;--muted:#9aa0b4;--card:#1f2230;--line:#2c3042}}
*{box-sizing:border-box}html,body{margin:0;height:100%}
body{font:14px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:var(--bg);color:var(--fg)}
button,input,select,textarea{font:inherit;color:inherit}
button{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:6px 12px;cursor:pointer}
button:hover{border-color:var(--accent)}
button.primary{background:var(--accent);border-color:var(--accent);color:#fff}
input,select,textarea{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:6px 10px}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.muted{color:var(--muted)}
`;

const drafts: Draft[] = [
  {
    name: 'lvp-runtime',
    version: '1.0.0',
    displayName: 'LVP Runtime',
    description: 'Biblioteca base dos apps LVP: estilos compartilhados (tema claro/escuro).',
    icon: '🧩',
    category: 'Bibliotecas',
    permissions: [],
    dependencies: {},
    entry: null,
    files: { 'runtime.css': RUNTIME_CSS },
  },
  {
    name: 'sticky-notes',
    version: '1.0.0',
    displayName: 'Lembretes',
    description: 'Post-its coloridos que ficam salvos entre as sessões.',
    icon: '🗒️',
    category: 'Produtividade',
    permissions: ['storage'],
    dependencies: { 'lvp-runtime': '^1.0.0' },
    entry: 'index.html',
    window: { width: 560, height: 420 },
    files: {
      'index.html': `<div style="padding:12px" class="row"><button class="primary" id="add">+ Novo lembrete</button><span class="muted" id="count"></span></div>
<div id="wall" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;padding:0 12px 12px"></div>
<script>
var colors=['#fde68a','#bbf7d0','#bfdbfe','#fbcfe8','#ddd6fe'];var notes=[];
function save(){lvos.storage.set('notes',notes);document.getElementById('count').textContent=notes.length+' lembrete(s)'}
function render(){var w=document.getElementById('wall');w.innerHTML='';notes.forEach(function(n,i){
var d=document.createElement('div');d.style.cssText='background:'+n.c+';color:#222;border-radius:10px;padding:8px;min-height:120px;display:flex;flex-direction:column;box-shadow:0 2px 6px #0002';
var t=document.createElement('textarea');t.value=n.t;t.style.cssText='flex:1;background:transparent;border:0;color:#222;resize:none;outline:none';
t.oninput=function(){n.t=t.value;save()};var x=document.createElement('button');x.textContent='Apagar';x.style.cssText='align-self:flex-end;background:#0001;border:0;color:#222';
x.onclick=function(){notes.splice(i,1);save();render()};d.appendChild(t);d.appendChild(x);w.appendChild(d)});save()}
document.getElementById('add').onclick=function(){notes.push({t:'',c:colors[notes.length%colors.length]});render()};
lvos.storage.get('notes').then(function(v){notes=Array.isArray(v)?v:[];render()});
</script>`,
    },
  },
  {
    name: 'pomodoro',
    version: '1.1.0',
    displayName: 'Pomodoro',
    description: 'Cronômetro de foco 25/5 com notificação ao terminar cada ciclo.',
    icon: '🍅',
    category: 'Produtividade',
    permissions: ['notifications', 'storage'],
    dependencies: { 'lvp-runtime': '^1.0.0' },
    entry: 'index.html',
    window: { width: 340, height: 360 },
    files: {
      'index.html': `<div style="display:flex;flex-direction:column;align-items:center;gap:14px;padding:24px">
<div id="mode" class="muted">Foco</div><div id="time" style="font-size:56px;font-variant-numeric:tabular-nums">25:00</div>
<div class="row"><button class="primary" id="go">Iniciar</button><button id="reset">Zerar</button></div>
<div class="muted">Ciclos concluídos: <b id="done">0</b></div></div>
<script>
var FOCUS=25*60,BREAK=5*60,left=FOCUS,focus=true,timer=null,done=0;
function fmt(s){return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
function draw(){time.textContent=fmt(left);mode.textContent=focus?'Foco':'Pausa';go.textContent=timer?'Pausar':'Iniciar';document.getElementById('done').textContent=done}
function tick(){left--;if(left<=0){if(focus){done++;lvos.storage.set('done',done)}
lvos.notify(focus?'Hora da pausa!':'De volta ao foco',focus?'Você completou um ciclo de 25 minutos.':'Pausa encerrada.');focus=!focus;left=focus?FOCUS:BREAK}draw()}
go.onclick=function(){if(timer){clearInterval(timer);timer=null}else timer=setInterval(tick,1000);draw()};
reset.onclick=function(){clearInterval(timer);timer=null;focus=true;left=FOCUS;draw()};
lvos.storage.get('done').then(function(v){done=v||0;draw()});
</script>`,
    },
  },
  {
    name: 'snake',
    version: '1.0.0',
    displayName: 'Snake',
    description: 'O clássico jogo da cobrinha. Use as setas ou WASD. Recorde salvo.',
    icon: '🐍',
    category: 'Jogos',
    permissions: ['storage'],
    dependencies: { 'lvp-runtime': '^1.0.0' },
    entry: 'index.html',
    window: { width: 420, height: 500 },
    files: {
      'index.html': `<div style="display:flex;flex-direction:column;align-items:center;gap:8px;padding:12px">
<div class="row"><span>Pontos: <b id="s">0</b></span><span class="muted">Recorde: <b id="hi">0</b></span><button id="b">Novo jogo</button></div>
<canvas id="c" width="360" height="360" style="background:#111;border-radius:10px;max-width:100%"></canvas>
<div class="muted">Setas / WASD para mover · Espaço pausa</div></div>
<script>
var N=18,S=20,ctx=c.getContext('2d'),snake,dir,next,food,score,hi=0,loop=null,paused=false;
function place(){do{food={x:Math.floor(Math.random()*N),y:Math.floor(Math.random()*N)}}while(snake.some(function(p){return p.x===food.x&&p.y===food.y}))}
function start(){snake=[{x:8,y:9},{x:7,y:9},{x:6,y:9}];dir={x:1,y:0};next=dir;score=0;paused=false;place();clearInterval(loop);loop=setInterval(step,110);draw()}
function step(){if(paused)return;dir=next;var h={x:snake[0].x+dir.x,y:snake[0].y+dir.y};
if(h.x<0||h.y<0||h.x>=N||h.y>=N||snake.some(function(p){return p.x===h.x&&p.y===h.y})){clearInterval(loop);loop=null;
if(score>hi){hi=score;lvos.storage.set('hi',hi)}draw(true);return}
snake.unshift(h);if(h.x===food.x&&h.y===food.y){score++;place()}else snake.pop();draw()}
function draw(over){ctx.fillStyle='#111';ctx.fillRect(0,0,360,360);ctx.fillStyle='#ef4444';ctx.fillRect(food.x*S+2,food.y*S+2,S-4,S-4);
snake.forEach(function(p,i){ctx.fillStyle=i?'#22c55e':'#86efac';ctx.fillRect(p.x*S+1,p.y*S+1,S-2,S-2)});
s.textContent=score;document.getElementById('hi').textContent=hi;
if(over){ctx.fillStyle='#000a';ctx.fillRect(0,0,360,360);ctx.fillStyle='#fff';ctx.font='24px sans-serif';ctx.textAlign='center';ctx.fillText('Fim de jogo',180,170);ctx.font='14px sans-serif';ctx.fillText('Clique em Novo jogo',180,200)}}
document.addEventListener('keydown',function(e){var k=e.key.toLowerCase(),m={arrowup:[0,-1],w:[0,-1],arrowdown:[0,1],s:[0,1],arrowleft:[-1,0],a:[-1,0],arrowright:[1,0],d:[1,0]}[k];
if(k===' '){paused=!paused;e.preventDefault();return}if(!m)return;e.preventDefault();if(m[0]===-dir.x&&m[1]===-dir.y)return;next={x:m[0],y:m[1]}});
b.onclick=start;lvos.storage.get('hi').then(function(v){hi=v||0;start()});
</script>`,
    },
  },
  {
    name: 'paint',
    version: '1.0.0',
    displayName: 'Paint',
    description: 'Desenho livre com pincel e cores. Salva PNG em ~/Pictures.',
    icon: '🎨',
    category: 'Gráficos',
    permissions: ['fs:home:write', 'notifications'],
    dependencies: { 'lvp-runtime': '^1.0.0' },
    entry: 'index.html',
    window: { width: 720, height: 540 },
    files: {
      'index.html': `<div class="row" style="padding:8px;border-bottom:1px solid var(--line)">
<input type="color" id="col" value="#7c6cff"><label>Tamanho <input type="range" id="sz" min="1" max="40" value="6"></label>
<button id="er">Borracha</button><button id="clr">Limpar</button><button class="primary" id="sv">Salvar PNG</button><span id="msg" class="muted"></span></div>
<canvas id="cv" style="display:block;width:100%;height:calc(100% - 52px);background:#fff;cursor:crosshair;touch-action:none"></canvas>
<script>
var ctx=cv.getContext('2d'),drawing=false,erase=false,last=null;
function fit(){var d=ctx.getImageData(0,0,cv.width||1,cv.height||1);cv.width=cv.clientWidth;cv.height=cv.clientHeight;ctx.fillStyle='#fff';ctx.fillRect(0,0,cv.width,cv.height);ctx.putImageData(d,0,0)}
window.addEventListener('resize',fit);setTimeout(fit,0);
function pos(e){var r=cv.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}}
cv.onpointerdown=function(e){drawing=true;last=pos(e);cv.setPointerCapture(e.pointerId)};
cv.onpointerup=function(){drawing=false};
cv.onpointermove=function(e){if(!drawing)return;var p=pos(e);ctx.strokeStyle=erase?'#fff':col.value;ctx.lineWidth=sz.value;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(p.x,p.y);ctx.stroke();last=p};
er.onclick=function(){erase=!erase;er.textContent=erase?'Pincel':'Borracha'};
clr.onclick=function(){ctx.fillStyle='#fff';ctx.fillRect(0,0,cv.width,cv.height)};
sv.onclick=function(){var name='Pictures/desenho-'+new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')+'.png';
lvos.fs.writeDataUrl(name,cv.toDataURL('image/png')).then(function(p){msg.textContent='Salvo em '+p;lvos.notify('Desenho salvo',p)}).catch(function(e){msg.textContent=e.message})};
</script>`,
    },
  },
  {
    name: 'json-tools',
    version: '1.0.0',
    displayName: 'JSON Tools',
    description: 'Valida, formata e minifica JSON, mostrando a linha do erro.',
    icon: '🧾',
    category: 'Desenvolvimento',
    permissions: ['clipboard'],
    dependencies: { 'lvp-runtime': '^1.0.0' },
    entry: 'index.html',
    window: { width: 640, height: 480 },
    files: {
      'index.html': `<div style="display:flex;flex-direction:column;height:100%;padding:10px;gap:8px">
<div class="row"><button class="primary" id="f">Formatar</button><button id="m">Minificar</button><button id="cp">Copiar</button><span id="st" class="muted"></span></div>
<textarea id="t" spellcheck="false" style="flex:1;font-family:ui-monospace,monospace;font-size:13px" placeholder='Cole seu JSON aqui, ex: {"ok": true}'></textarea></div>
<script>
function parse(){try{var v=JSON.parse(t.value);st.textContent='✓ JSON válido';st.style.color='#16a34a';return{v:v}}catch(e){
var m=/position (\\d+)/.exec(e.message),line='';if(m){line=' (linha '+t.value.slice(0,+m[1]).split('\\n').length+')'}
st.textContent='✗ '+e.message+line;st.style.color='#dc2626';return null}}
f.onclick=function(){var r=parse();if(r)t.value=JSON.stringify(r.v,null,2)};
m.onclick=function(){var r=parse();if(r)t.value=JSON.stringify(r.v)};
cp.onclick=function(){lvos.clipboard.write(t.value).then(function(){st.textContent='Copiado';st.style.color=''})};
t.oninput=function(){if(t.value.trim())parse();else st.textContent=''};
</script>`,
    },
  },
  {
    name: 'markdown-viewer',
    version: '1.0.0',
    displayName: 'Markdown Viewer',
    description: 'Abre arquivos .md da sua pasta pessoal e mostra formatados.',
    icon: '📘',
    category: 'Escritório',
    permissions: ['fs:home:read'],
    dependencies: { 'lvp-runtime': '^1.0.0' },
    entry: 'index.html',
    window: { width: 720, height: 520 },
    files: {
      'index.html': `<div style="display:flex;height:100%"><aside id="list" style="width:200px;border-right:1px solid var(--line);overflow:auto;padding:8px"></aside>
<main id="out" style="flex:1;overflow:auto;padding:16px 24px"><p class="muted">Escolha um arquivo .md à esquerda.</p></main></div>
<script>
function esc(s){return s.replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function inline(s){return esc(s).replace(/\`([^\`]+)\`/g,'<code>$1</code>').replace(/\\*\\*([^*]+)\\*\\*/g,'<b>$1</b>').replace(/\\*([^*]+)\\*/g,'<i>$1</i>')}
function md(src){var out=[],code=false,list=false;src.split('\\n').forEach(function(l){
if(l.startsWith('\`\`\`')){out.push(code?'</pre>':'<pre style="background:var(--card);padding:10px;border-radius:8px;overflow:auto">');code=!code;return}
if(code){out.push(esc(l));return}var h=/^(#{1,6})\\s+(.*)/.exec(l);
if(/^[-*]\\s+/.test(l)){if(!list){out.push('<ul>');list=true}out.push('<li>'+inline(l.replace(/^[-*]\\s+/,''))+'</li>');return}
if(list){out.push('</ul>');list=false}
if(h)out.push('<h'+h[1].length+'>'+inline(h[2])+'</h'+h[1].length+'>');else if(l.trim())out.push('<p>'+inline(l)+'</p>')});
if(list)out.push('</ul>');if(code)out.push('</pre>');return out.join('\\n')}
function walk(dir,depth){return lvos.fs.list(dir).then(function(items){var ps=[];items.forEach(function(it){
if(it.type==='dir'&&depth<3&&it.name[0]!=='.')ps.push(walk(it.path,depth+1));
else if(/\\.md$/i.test(it.name)){var b=document.createElement('button');b.textContent=it.name;b.title=it.path;b.style.cssText='display:block;width:100%;text-align:left;margin-bottom:4px';
b.onclick=function(){lvos.fs.read(it.path).then(function(t){out.innerHTML=md(t)})};list.appendChild(b)}});return Promise.all(ps)})}
walk('~',0).then(function(){if(!list.children.length)list.innerHTML='<p class="muted">Nenhum .md encontrado em ~</p>'}).catch(function(e){list.textContent=e.message});
</script>`,
    },
  },
  {
    name: 'unit-converter',
    version: '1.0.0',
    displayName: 'Conversor',
    description: 'Converte comprimento, massa, temperatura e dados (bytes).',
    icon: '📐',
    category: 'Utilitários',
    permissions: [],
    dependencies: { 'lvp-runtime': '^1.0.0' },
    entry: 'index.html',
    window: { width: 420, height: 300 },
    files: {
      'index.html': `<div style="padding:16px;display:flex;flex-direction:column;gap:12px">
<select id="cat"></select><div class="row"><input id="v" type="number" value="1" style="width:120px"><select id="from"></select><span>→</span><select id="to"></select></div>
<div id="r" style="font-size:24px"></div></div>
<script>
var U={'Comprimento':{m:1,km:1000,cm:.01,mm:.001,mi:1609.344,ft:.3048,in:.0254},'Massa':{kg:1,g:.001,t:1000,lb:.45359237,oz:.028349523},
'Dados':{B:1,KB:1024,MB:1048576,GB:1073741824,TB:1099511627776},'Temperatura':{'°C':0,'°F':0,K:0}};
function toC(v,u){return u==='°C'?v:u==='°F'?(v-32)*5/9:v-273.15}function fromC(v,u){return u==='°C'?v:u==='°F'?v*9/5+32:v+273.15}
function fill(){var units=Object.keys(U[cat.value]);[from,to].forEach(function(s,i){s.innerHTML=units.map(function(u){return'<option>'+u+'</option>'}).join('');s.selectedIndex=Math.min(i,units.length-1)});calc()}
function calc(){var x=parseFloat(v.value)||0,res;if(cat.value==='Temperatura')res=fromC(toC(x,from.value),to.value);else res=x*U[cat.value][from.value]/U[cat.value][to.value];
r.textContent=(+res.toPrecision(10))+' '+to.value}
cat.innerHTML=Object.keys(U).map(function(c){return'<option>'+c+'</option>'}).join('');cat.onchange=fill;[v,from,to].forEach(function(e){e.oninput=calc});fill();
</script>`,
    },
  },
];

let cache: PackageManifest[] | null = null;

export async function builtinPackages(): Promise<PackageManifest[]> {
  if (cache) return cache;
  cache = await Promise.all(
    drafts.map(async (d) => ({
      lvp: 1 as const,
      author: d.author ?? 'Little Vitor OS',
      license: 'MIT',
      ...d,
      sha256: await computeHash(d.files),
    })),
  );
  return cache;
}
