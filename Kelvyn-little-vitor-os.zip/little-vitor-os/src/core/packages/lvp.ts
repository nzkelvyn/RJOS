import { EventBus } from '../../kernel/events';
import { Store } from '../../kernel/store';
import type { VFS } from '../vfs/vfs';
import { ROOT_CREDS } from '../vfs/types';
import { builtinPackages } from './builtinRepo';
import {
  compareVersions,
  computeHash,
  satisfies,
  validateManifest,
  verifyIntegrity,
  type InstalledPackage,
  type PackageManifest,
} from './manifest';

export interface Repository {
  name: string;
  /** "builtin" or an https:// URL to an index.json */
  url: string;
  enabled: boolean;
}

export interface RepoIndex {
  name: string;
  updatedAt: number;
  packages: PackageManifest[];
}

export interface InstallPlan {
  /** packages to install, dependencies first */
  steps: { manifest: PackageManifest; repository: string; auto: boolean; upgradeFrom?: string }[];
}

const REPOS = '/etc/lvp/repositories.json';
const DB = '/var/lib/lvp/installed.json';
const INDEX_DIR = '/var/lib/lvp/index';
const SHARE = '/usr/share/lvp';
const LOG = '/var/log/lvp.log';

export class LvpError extends Error {}

/**
 * LVP — Little Vitor Package Manager.
 * Installs sandboxed web apps described by a validated manifest, tracking
 * versions, dependencies and integrity (SHA-256 of the package files).
 */
export class PackageManager {
  readonly installed = new Store<InstalledPackage[]>([]);
  private indexes = new Map<string, RepoIndex>();

  constructor(
    private vfs: VFS,
    private events: EventBus,
    private isAdmin: () => boolean,
    private fetcher: (url: string) => Promise<unknown> = defaultFetcher,
  ) {}

  // ------------------------------------------------------------ bootstrap

  async init(): Promise<void> {
    for (const d of ['/etc/lvp', INDEX_DIR, SHARE, '/var/log']) {
      await this.vfs.mkdir(d, { parents: true }, ROOT_CREDS);
    }
    if (!this.vfs.exists(REPOS)) {
      await this.saveRepos([{ name: 'core', url: 'builtin', enabled: true }]);
    }
    if (this.vfs.exists(DB)) {
      try {
        this.installed.set(JSON.parse(await this.vfs.readText(DB, ROOT_CREDS)));
      } catch {
        await this.log('ERRO banco de pacotes corrompido; recriando');
        this.installed.set([]);
      }
    }
    for (const repo of await this.repositories()) {
      const path = `${INDEX_DIR}/${repo.name}.json`;
      if (this.vfs.exists(path)) {
        try {
          this.indexes.set(repo.name, JSON.parse(await this.vfs.readText(path, ROOT_CREDS)));
        } catch {
          /* refreshed on next update */
        }
      }
    }
    if (!this.indexes.has('core')) await this.update();
  }

  // ------------------------------------------------------------ repositories

  async repositories(): Promise<Repository[]> {
    if (!this.vfs.exists(REPOS)) return [];
    return JSON.parse(await this.vfs.readText(REPOS, ROOT_CREDS));
  }

  private async saveRepos(repos: Repository[]) {
    await this.vfs.writeFile(REPOS, JSON.stringify(repos, null, 2), { mode: 0o644 }, ROOT_CREDS);
  }

  async addRepository(name: string, url: string): Promise<void> {
    this.requireAdmin();
    if (!/^[a-z0-9-]{2,30}$/.test(name)) throw new LvpError('nome de repositório inválido');
    if (!/^https:\/\//.test(url)) throw new LvpError('o repositório precisa usar https://');
    const repos = await this.repositories();
    if (repos.some((r) => r.name === name)) throw new LvpError(`repositório ${name} já existe`);
    await this.saveRepos([...repos, { name, url, enabled: true }]);
    await this.log(`repositório adicionado: ${name} ${url}`);
  }

  async removeRepository(name: string): Promise<void> {
    this.requireAdmin();
    if (name === 'core') throw new LvpError('o repositório core não pode ser removido');
    const repos = await this.repositories();
    if (!repos.some((r) => r.name === name)) throw new LvpError(`repositório ${name} não encontrado`);
    await this.saveRepos(repos.filter((r) => r.name !== name));
    this.indexes.delete(name);
    const path = `${INDEX_DIR}/${name}.json`;
    if (this.vfs.exists(path)) await this.vfs.unlink(path, ROOT_CREDS);
    await this.log(`repositório removido: ${name}`);
  }

  async setRepositoryEnabled(name: string, enabled: boolean): Promise<void> {
    this.requireAdmin();
    const repos = await this.repositories();
    await this.saveRepos(repos.map((r) => (r.name === name ? { ...r, enabled } : r)));
  }

  /** Refreshes every enabled repository index ("lvp update"). */
  async update(): Promise<{ repo: string; packages: number; error?: string }[]> {
    const results = [];
    for (const repo of await this.repositories()) {
      if (!repo.enabled) continue;
      try {
        const index = await this.fetchIndex(repo);
        this.indexes.set(repo.name, index);
        await this.vfs.writeFile(`${INDEX_DIR}/${repo.name}.json`, JSON.stringify(index), { mode: 0o644 }, ROOT_CREDS);
        results.push({ repo: repo.name, packages: index.packages.length });
      } catch (err) {
        results.push({ repo: repo.name, packages: 0, error: (err as Error).message });
        await this.log(`ERRO ao atualizar ${repo.name}: ${(err as Error).message}`);
      }
    }
    await this.log('índices atualizados');
    return results;
  }

  private async fetchIndex(repo: Repository): Promise<RepoIndex> {
    if (repo.url === 'builtin') {
      return { name: repo.name, updatedAt: Date.now(), packages: await builtinPackages() };
    }
    const raw = (await this.fetcher(repo.url)) as { packages?: unknown[] };
    if (!raw || !Array.isArray(raw.packages)) throw new LvpError('índice inválido (esperado {"packages": [...]})');
    const packages: PackageManifest[] = [];
    for (const p of raw.packages) {
      try {
        const m = validateManifest(p);
        if (await verifyIntegrity(m)) packages.push(m);
        else await this.log(`AVISO ${repo.name}/${m.name}: hash não confere, pacote ignorado`);
      } catch (err) {
        await this.log(`AVISO ${repo.name}: manifesto rejeitado (${(err as Error).message})`);
      }
    }
    return { name: repo.name, updatedAt: Date.now(), packages };
  }

  // ------------------------------------------------------------ queries

  available(): { manifest: PackageManifest; repository: string }[] {
    const out = new Map<string, { manifest: PackageManifest; repository: string }>();
    for (const [repo, index] of this.indexes) {
      for (const m of index.packages) {
        const prev = out.get(m.name);
        if (!prev || compareVersions(m.version, prev.manifest.version) > 0) out.set(m.name, { manifest: m, repository: repo });
      }
    }
    return [...out.values()].sort((a, b) => a.manifest.name.localeCompare(b.manifest.name));
  }

  search(query: string) {
    const q = query.toLowerCase();
    return this.available().filter(({ manifest: m }) =>
      [m.name, m.displayName, m.description, m.category].some((f) => f.toLowerCase().includes(q)),
    );
  }

  getInstalled(name: string): InstalledPackage | undefined {
    return this.installed.get().find((p) => p.name === name);
  }

  findAvailable(name: string) {
    return this.available().find((a) => a.manifest.name === name);
  }

  upgradable(): { name: string; from: string; to: string }[] {
    return this.installed
      .get()
      .map((p) => {
        const a = this.findAvailable(p.name);
        return a && compareVersions(a.manifest.version, p.version) > 0
          ? { name: p.name, from: p.version, to: a.manifest.version }
          : null;
      })
      .filter((x): x is { name: string; from: string; to: string } => !!x);
  }

  /** Packages that depend on `name`. */
  dependents(name: string): string[] {
    return this.installed.get().filter((p) => name in p.dependencies).map((p) => p.name);
  }

  // ------------------------------------------------------------ install

  /** Resolves the dependency graph (depth-first, dependencies first). */
  plan(names: string[], local?: PackageManifest): InstallPlan {
    const steps: InstallPlan['steps'] = [];
    const visiting = new Set<string>();
    const planned = new Set<string>();

    const visit = (name: string, range: string, auto: boolean, requiredBy?: string) => {
      if (planned.has(name)) return;
      if (visiting.has(name)) throw new LvpError(`dependência circular envolvendo ${name}`);
      const installed = this.getInstalled(name);
      if (installed && satisfies(installed.version, range) && auto) return;
      let manifest: PackageManifest;
      let repository: string;
      if (local && local.name === name) {
        manifest = local;
        repository = 'local';
      } else {
        const a = this.findAvailable(name);
        if (!a) throw new LvpError(`pacote não encontrado: ${name}${requiredBy ? ` (requerido por ${requiredBy})` : ''}`);
        manifest = a.manifest;
        repository = a.repository;
      }
      if (!satisfies(manifest.version, range)) {
        throw new LvpError(`${name} ${manifest.version} não satisfaz ${range}${requiredBy ? ` (requerido por ${requiredBy})` : ''}`);
      }
      if (installed && installed.version === manifest.version && !auto) {
        planned.add(name); // already installed at that version: nothing to do
        return;
      }
      visiting.add(name);
      for (const [dep, depRange] of Object.entries(manifest.dependencies)) visit(dep, depRange, true, name);
      visiting.delete(name);
      planned.add(name);
      steps.push({ manifest, repository, auto: installed ? installed.auto && auto : auto, upgradeFrom: installed?.version });
    };

    for (const n of names) visit(n, '*', false);
    return { steps };
  }

  async install(
    names: string[],
    opts: { confirm?: (plan: InstallPlan) => Promise<boolean>; local?: PackageManifest } = {},
  ): Promise<InstallPlan> {
    this.requireAdmin();
    const plan = this.plan(names, opts.local);
    if (!plan.steps.length) return plan;
    // Explicit authorization is mandatory before anything is written.
    if (!opts.confirm || !(await opts.confirm(plan))) throw new LvpError('instalação cancelada pelo usuário');
    for (const step of plan.steps) await this.installOne(step.manifest, step.repository, step.auto);
    return plan;
  }

  private async installOne(m: PackageManifest, repository: string, auto: boolean) {
    if (!(await verifyIntegrity(m))) {
      await this.log(`ERRO ${m.name}@${m.version}: verificação de integridade falhou`);
      throw new LvpError(`${m.name}: verificação de integridade falhou (sha256 não confere)`);
    }
    const dir = `${SHARE}/${m.name}`;
    if (this.vfs.exists(dir)) await this.vfs.rm(dir, { recursive: true }, ROOT_CREDS);
    await this.vfs.mkdir(dir, { parents: true }, ROOT_CREDS);
    for (const [file, content] of Object.entries(m.files)) {
      const target = `${dir}/${file}`;
      await this.vfs.mkdir(target.slice(0, target.lastIndexOf('/')), { parents: true }, ROOT_CREDS);
      await this.vfs.writeFile(target, content, { mode: 0o644 }, ROOT_CREDS);
    }
    const record: InstalledPackage = {
      name: m.name, version: m.version, displayName: m.displayName, icon: m.icon,
      description: m.description, category: m.category, entry: m.entry,
      permissions: m.permissions, dependencies: m.dependencies, repository,
      installedAt: Date.now(), sha256: m.sha256, window: m.window, auto,
    };
    const prev = this.getInstalled(m.name);
    await this.saveDb([...this.installed.get().filter((p) => p.name !== m.name), record]);
    await this.log(prev ? `atualizado ${m.name} ${prev.version} -> ${m.version}` : `instalado ${m.name}@${m.version} (${repository})`);
    this.events.emit('pkg:install', { name: m.name, version: m.version });
  }

  async upgrade(confirm?: (plan: InstallPlan) => Promise<boolean>): Promise<InstallPlan> {
    const names = this.upgradable().map((u) => u.name);
    if (!names.length) return { steps: [] };
    return this.install(names, { confirm });
  }

  async remove(name: string, opts: { force?: boolean } = {}): Promise<void> {
    this.requireAdmin();
    const pkg = this.getInstalled(name);
    if (!pkg) throw new LvpError(`pacote não instalado: ${name}`);
    const deps = this.dependents(name);
    if (deps.length && !opts.force) {
      throw new LvpError(`${name} é dependência de: ${deps.join(', ')} (use --force para remover mesmo assim)`);
    }
    const dir = `${SHARE}/${name}`;
    if (this.vfs.exists(dir)) await this.vfs.rm(dir, { recursive: true }, ROOT_CREDS);
    await this.saveDb(this.installed.get().filter((p) => p.name !== name));
    await this.log(`removido ${name}@${pkg.version}`);
    this.events.emit('pkg:remove', { name });
  }

  /** Auto-installed dependencies no longer required by anyone. */
  orphans(): string[] {
    return this.installed.get().filter((p) => p.auto && !this.dependents(p.name).length).map((p) => p.name);
  }

  async autoremove(): Promise<string[]> {
    const removed: string[] = [];
    let orphans = this.orphans();
    while (orphans.length) {
      for (const o of orphans) {
        await this.remove(o);
        removed.push(o);
      }
      orphans = this.orphans();
    }
    return removed;
  }

  /** Re-hashes installed files and compares with the recorded checksum. */
  async verify(name: string): Promise<boolean> {
    const pkg = this.getInstalled(name);
    if (!pkg) throw new LvpError(`pacote não instalado: ${name}`);
    const files = await this.readFiles(name);
    return (await computeHash(files)) === pkg.sha256;
  }

  async readFiles(name: string): Promise<Record<string, string>> {
    const dir = `${SHARE}/${name}`;
    const out: Record<string, string> = {};
    const entries = this.vfs.find(dir, (e) => e.node.type === 'file', ROOT_CREDS);
    for (const e of entries) out[e.path.slice(dir.length + 1)] = await this.vfs.readText(e.path, ROOT_CREDS);
    return out;
  }

  async readLocal(path: string): Promise<PackageManifest> {
    const text = await this.vfs.readText(path);
    let raw: unknown;
    try {
      raw = JSON.parse(text);
    } catch {
      throw new LvpError('arquivo .lvp não é JSON válido');
    }
    const m = validateManifest(raw);
    if (!(await verifyIntegrity(m))) throw new LvpError('integridade do pacote local falhou (sha256 não confere)');
    return m;
  }

  async logLines(limit = 200): Promise<string[]> {
    if (!this.vfs.exists(LOG)) return [];
    return (await this.vfs.readText(LOG, ROOT_CREDS)).trim().split('\n').slice(-limit);
  }

  // ------------------------------------------------------------ internals

  private requireAdmin() {
    if (!this.isAdmin()) throw new LvpError('permissão negada: é preciso ser administrador (grupo sudo)');
  }

  private async saveDb(list: InstalledPackage[]) {
    list.sort((a, b) => a.name.localeCompare(b.name));
    this.installed.set(list);
    await this.vfs.writeFile(DB, JSON.stringify(list, null, 2), { mode: 0o644 }, ROOT_CREDS);
  }

  private async log(line: string) {
    await this.vfs.writeFile(LOG, `${new Date().toISOString()} ${line}\n`, { append: true, mode: 0o644 }, ROOT_CREDS);
  }
}

async function defaultFetcher(url: string): Promise<unknown> {
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) throw new LvpError(`HTTP ${res.status} ao baixar ${url}`);
  return res.json();
}
