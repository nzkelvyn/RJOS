import { sha256Hex } from '../users/crypto';

/**
 * LVP package manifest (format version 1).
 *
 * A package is a single JSON document (.lvp file) containing its metadata and
 * all of its files. Apps are HTML/JS that run inside a sandboxed iframe with no
 * access to the host page; they talk to the OS only through the permission-
 * checked bridge (see apps/PackageAppHost.tsx).
 */
export const PERMISSIONS = {
  notifications: 'Mostrar notificações',
  'storage': 'Guardar dados próprios do app',
  'fs:home:read': 'Ler arquivos da sua pasta pessoal',
  'fs:home:write': 'Criar e alterar arquivos da sua pasta pessoal',
  clipboard: 'Copiar texto para a área de transferência',
} as const;
export type Permission = keyof typeof PERMISSIONS;

export interface PackageManifest {
  lvp: 1;
  name: string;
  version: string;
  displayName: string;
  description: string;
  author: string;
  license: string;
  icon: string; // emoji
  category: string;
  permissions: Permission[];
  dependencies: Record<string, string>;
  /** library packages have no entry and cannot be launched */
  entry: string | null;
  window?: { width: number; height: number };
  files: Record<string, string>;
  sha256: string;
}

export interface InstalledPackage {
  name: string;
  version: string;
  displayName: string;
  icon: string;
  description: string;
  category: string;
  entry: string | null;
  permissions: Permission[];
  dependencies: Record<string, string>;
  repository: string;
  installedAt: number;
  sha256: string;
  window?: { width: number; height: number };
  /** installed only to satisfy a dependency */
  auto: boolean;
}

const NAME_RE = /^[a-z0-9][a-z0-9-]{1,40}$/;
const VERSION_RE = /^\d+\.\d+\.\d+$/;
const MAX_PACKAGE_BYTES = 2 * 1024 * 1024;

export async function computeHash(files: Record<string, string>): Promise<string> {
  const canonical = JSON.stringify(Object.keys(files).sort().map((k) => [k, files[k]]));
  return sha256Hex(new TextEncoder().encode(canonical));
}

/** Validates an untrusted manifest. Throws with a readable message. */
export function validateManifest(raw: unknown): PackageManifest {
  if (!raw || typeof raw !== 'object') throw new Error('manifesto ausente ou não é um objeto JSON');
  const m = raw as Record<string, unknown>;
  const str = (k: string, max = 200) => {
    if (typeof m[k] !== 'string' || !(m[k] as string).trim()) throw new Error(`campo "${k}" obrigatório`);
    if ((m[k] as string).length > max) throw new Error(`campo "${k}" grande demais`);
    return m[k] as string;
  };
  if (m.lvp !== 1) throw new Error('versão de manifesto não suportada (esperado "lvp": 1)');
  const name = str('name', 41);
  if (!NAME_RE.test(name)) throw new Error('nome de pacote inválido (minúsculas, números e hífen)');
  const version = str('version', 20);
  if (!VERSION_RE.test(version)) throw new Error('versão inválida (use x.y.z)');
  const permissions = Array.isArray(m.permissions) ? (m.permissions as unknown[]) : [];
  for (const p of permissions) {
    if (typeof p !== 'string' || !(p in PERMISSIONS)) throw new Error(`permissão desconhecida: ${String(p)}`);
  }
  const deps = (m.dependencies ?? {}) as Record<string, unknown>;
  if (typeof deps !== 'object' || Array.isArray(deps)) throw new Error('"dependencies" deve ser um objeto');
  for (const [k, v] of Object.entries(deps)) {
    if (!NAME_RE.test(k) || typeof v !== 'string') throw new Error(`dependência inválida: ${k}`);
  }
  const files = m.files as Record<string, unknown>;
  if (!files || typeof files !== 'object') throw new Error('"files" obrigatório');
  let total = 0;
  for (const [k, v] of Object.entries(files)) {
    if (typeof v !== 'string') throw new Error(`arquivo ${k} deve ser texto`);
    if (!/^[\w.-]+(\/[\w.-]+)*$/.test(k) || k.includes('..')) throw new Error(`caminho de arquivo inválido: ${k}`);
    total += v.length;
  }
  if (total > MAX_PACKAGE_BYTES) throw new Error('pacote maior que o limite de 2 MB');
  const entry = m.entry === null || m.entry === undefined ? null : str('entry');
  if (entry && !(entry in files)) throw new Error(`entry "${entry}" não existe em files`);
  const win = m.window as { width?: unknown; height?: unknown } | undefined;
  return {
    lvp: 1,
    name,
    version,
    displayName: str('displayName', 60),
    description: str('description', 300),
    author: typeof m.author === 'string' ? m.author.slice(0, 80) : 'desconhecido',
    license: typeof m.license === 'string' ? m.license.slice(0, 40) : 'desconhecida',
    icon: typeof m.icon === 'string' ? [...m.icon].slice(0, 2).join('') : '📦',
    category: typeof m.category === 'string' ? m.category.slice(0, 30) : 'Outros',
    permissions: permissions as Permission[],
    dependencies: deps as Record<string, string>,
    entry,
    window:
      win && typeof win.width === 'number' && typeof win.height === 'number'
        ? { width: clamp(win.width, 240, 1600), height: clamp(win.height, 160, 1200) }
        : undefined,
    files: files as Record<string, string>,
    sha256: str('sha256', 64),
  };
}

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

export async function verifyIntegrity(m: PackageManifest): Promise<boolean> {
  return (await computeHash(m.files)) === m.sha256;
}

// ---------------------------------------------------------------- semver

export function compareVersions(a: string, b: string): number {
  const pa = a.split('.').map(Number);
  const pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if ((pa[i] ?? 0) !== (pb[i] ?? 0)) return (pa[i] ?? 0) - (pb[i] ?? 0);
  }
  return 0;
}

/** Supports: "*", "1.2.3", ">=1.2.3", "^1.2.3", "~1.2.3". */
export function satisfies(version: string, range: string): boolean {
  range = range.trim();
  if (range === '*' || range === '') return true;
  const m = /^(>=|\^|~)?(\d+\.\d+\.\d+)$/.exec(range);
  if (!m) return false;
  const [, op, base] = m;
  const cmp = compareVersions(version, base);
  const [maj, min] = base.split('.').map(Number);
  const [vmaj, vmin] = version.split('.').map(Number);
  if (!op) return cmp === 0;
  if (op === '>=') return cmp >= 0;
  if (op === '^') return cmp >= 0 && vmaj === maj;
  return cmp >= 0 && vmaj === maj && vmin === min; // ~
}
