import { EventBus } from '../../kernel/events';
import { Store } from '../../kernel/store';

export type ProcessState = 'running' | 'sleeping' | 'stopped';
export type ProcessKind = 'system' | 'app' | 'command' | 'worker';

export interface VProcess {
  pid: number;
  ppid: number;
  name: string;
  command: string;
  user: string;
  kind: ProcessKind;
  state: ProcessState;
  startedAt: number;
  /** window id when the process owns a window */
  windowId?: string;
  /** Busy time measured by the process itself (ms) — real for commands/workers, null when unknown. */
  cpuTimeMs: number | null;
}

type KillHandler = (signal: Signal) => void;
export type Signal = 'SIGTERM' | 'SIGKILL' | 'SIGINT' | 'SIGSTOP' | 'SIGCONT';

export const SIGNALS: Record<string, Signal> = {
  '15': 'SIGTERM', TERM: 'SIGTERM', SIGTERM: 'SIGTERM',
  '9': 'SIGKILL', KILL: 'SIGKILL', SIGKILL: 'SIGKILL',
  '2': 'SIGINT', INT: 'SIGINT', SIGINT: 'SIGINT',
  '19': 'SIGSTOP', STOP: 'SIGSTOP', SIGSTOP: 'SIGSTOP',
  '18': 'SIGCONT', CONT: 'SIGCONT', SIGCONT: 'SIGCONT',
};

/**
 * Process table of the virtual OS. These are *virtual* processes: every app
 * window, shell command and system service registers itself here so it can be
 * listed (ps/top/Task Manager) and signalled (kill). They all share the single
 * browser JS thread (or a Web Worker), not real OS processes.
 */
export class ProcessManager {
  readonly table = new Store<VProcess[]>([]);
  private nextPid = 1;
  private handlers = new Map<number, KillHandler>();
  readonly bootTime = Date.now();

  constructor(private events: EventBus) {}

  spawn(
    opts: Omit<VProcess, 'pid' | 'startedAt' | 'state' | 'cpuTimeMs'> & { cpuTimeMs?: number | null },
    onSignal?: KillHandler,
  ): VProcess {
    const proc: VProcess = {
      ...opts,
      pid: this.nextPid++,
      startedAt: Date.now(),
      state: 'running',
      cpuTimeMs: opts.cpuTimeMs ?? null,
    };
    if (onSignal) this.handlers.set(proc.pid, onSignal);
    this.table.set((t) => [...t, proc]);
    this.events.emit('proc:spawn', { pid: proc.pid, name: proc.name });
    return proc;
  }

  get(pid: number): VProcess | undefined {
    return this.table.get().find((p) => p.pid === pid);
  }

  list(): VProcess[] {
    return this.table.get();
  }

  update(pid: number, patch: Partial<Pick<VProcess, 'state' | 'cpuTimeMs' | 'name' | 'windowId'>>): void {
    this.table.set((t) => t.map((p) => (p.pid === pid ? { ...p, ...patch } : p)));
  }

  exit(pid: number, code = 0): void {
    const proc = this.get(pid);
    if (!proc) return;
    this.handlers.delete(pid);
    this.table.set((t) => t.filter((p) => p.pid !== pid));
    this.events.emit('proc:exit', { pid, name: proc.name, code });
  }

  /**
   * Sends a signal. Returns an error string on failure (like kill(1)).
   * Only root or the owning user may signal a process; system processes are protected.
   */
  kill(pid: number, signal: Signal, asUser: string): string | null {
    const proc = this.get(pid);
    if (!proc) return `kill: (${pid}) - Processo inexistente`;
    if (asUser !== 'root' && proc.user !== asUser) return `kill: (${pid}) - Operação não permitida`;
    if (proc.kind === 'system' && signal !== 'SIGCONT') return `kill: (${pid}) - Processo do sistema protegido`;
    const handler = this.handlers.get(pid);
    if (signal === 'SIGSTOP') {
      this.update(pid, { state: 'stopped' });
      handler?.(signal);
      return null;
    }
    if (signal === 'SIGCONT') {
      this.update(pid, { state: 'running' });
      handler?.(signal);
      return null;
    }
    handler?.(signal);
    // processes without a handler, or killed with SIGKILL, are removed immediately
    if (!handler || signal === 'SIGKILL') this.exit(pid, signal === 'SIGKILL' ? 137 : 143);
    return null;
  }

  uptimeMs(): number {
    return Date.now() - this.bootTime;
  }
}
