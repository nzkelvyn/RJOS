import { EventBus } from '../../kernel/events';
import { Store } from '../../kernel/store';
import type { VFS } from '../vfs/vfs';
import { ROOT_CREDS, type Credentials } from '../vfs/types';

export type ThemeMode = 'light' | 'dark' | 'auto';
export type Language = 'pt-BR' | 'en-US';

export interface UserSettings {
  theme: ThemeMode;
  accent: string;
  wallpaper: string; // preset id or VFS path to an image
  transparency: boolean;
  animations: boolean;
  iconSize: 'small' | 'medium' | 'large';
  dockPosition: 'bottom' | 'left';
  dockAutoHide: boolean;
  dockApps: string[];
  desktopIcons: boolean;
  clock24h: boolean;
  showSeconds: boolean;
  fontScale: number; // 1 = 100%
  highContrast: boolean;
  reduceMotion: boolean;
  lockAfterMinutes: number; // 0 = never
  defaultApps: Record<string, string>; // file kind -> app id
  notificationsDnd: boolean;
  mutedApps: string[];
  autostart: string[];
  terminalHistory: boolean;
  syncEnabled: boolean;
  syncServer: string;
}

export interface SystemSettings {
  setupDone: boolean;
  hostname: string;
  language: Language;
  timezone: string;
  storagePersistence: boolean;
  installedAt: number;
}

export const ACCENTS = ['#7c6cff', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#14b8a6'];

export const DEFAULT_USER_SETTINGS: UserSettings = {
  theme: 'dark',
  accent: ACCENTS[0],
  wallpaper: 'aurora',
  transparency: true,
  animations: true,
  iconSize: 'medium',
  dockPosition: 'bottom',
  dockAutoHide: false,
  dockApps: ['files', 'terminal', 'browser', 'editor', 'settings', 'appcenter'],
  desktopIcons: true,
  clock24h: true,
  showSeconds: false,
  fontScale: 1,
  highContrast: false,
  reduceMotion: false,
  lockAfterMinutes: 0,
  defaultApps: { text: 'editor', image: 'images', pdf: 'pdf', audio: 'music', video: 'video', archive: 'archive' },
  notificationsDnd: false,
  mutedApps: [],
  autostart: [],
  terminalHistory: true,
  syncEnabled: false,
  syncServer: '',
};

export const DEFAULT_SYSTEM_SETTINGS: SystemSettings = {
  setupDone: false,
  hostname: 'littlevitor',
  language: 'pt-BR',
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
  storagePersistence: true,
  installedAt: 0,
};

const SYSTEM_PATH = '/etc/lvos/system.json';
const userPath = (home: string) => `${home}/.config/lvos/settings.json`;

/**
 * Settings persisted as JSON files inside the VFS:
 *   /etc/lvos/system.json            system-wide (root owned)
 *   ~/.config/lvos/settings.json     per user
 * A tiny copy of the theme lives in localStorage so the boot screen can be
 * themed before the VFS is mounted.
 */
export class SettingsService {
  readonly user = new Store<UserSettings>({ ...DEFAULT_USER_SETTINGS });
  readonly system = new Store<SystemSettings>({ ...DEFAULT_SYSTEM_SETTINGS });
  private home: string | null = null;
  private creds: Credentials | null = null;
  private saveTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(
    private vfs: VFS,
    private events: EventBus,
  ) {}

  async loadSystem(): Promise<SystemSettings> {
    if (this.vfs.exists(SYSTEM_PATH)) {
      try {
        const parsed = JSON.parse(await this.vfs.readText(SYSTEM_PATH, ROOT_CREDS));
        this.system.set({ ...DEFAULT_SYSTEM_SETTINGS, ...sanitizeSystem(parsed) });
      } catch {
        this.events.emit('log', { level: 'warn', source: 'settings', message: 'system.json inválido; usando padrão' });
      }
    }
    return this.system.get();
  }

  async saveSystem(patch: Partial<SystemSettings>): Promise<void> {
    this.system.set({ ...this.system.get(), ...sanitizeSystem(patch) });
    await this.vfs.mkdir('/etc/lvos', { parents: true }, ROOT_CREDS);
    await this.vfs.writeFile(SYSTEM_PATH, JSON.stringify(this.system.get(), null, 2), { mode: 0o644 }, ROOT_CREDS);
    for (const key of Object.keys(patch)) this.events.emit('settings:change', { key: 'system.' + key });
  }

  async loadUser(home: string, creds: Credentials): Promise<UserSettings> {
    this.home = home;
    this.creds = creds;
    let settings = { ...DEFAULT_USER_SETTINGS };
    const path = userPath(home);
    if (this.vfs.exists(path)) {
      try {
        settings = { ...settings, ...sanitizeUser(JSON.parse(await this.vfs.readText(path, creds))) };
      } catch {
        this.events.emit('log', { level: 'warn', source: 'settings', message: 'settings.json inválido; usando padrão' });
      }
    }
    this.user.set(settings);
    this.cacheTheme();
    return settings;
  }

  /** Updates user settings in memory immediately and persists (debounced). */
  update(patch: Partial<UserSettings>): void {
    this.user.set({ ...this.user.get(), ...sanitizeUser(patch) });
    for (const key of Object.keys(patch)) this.events.emit('settings:change', { key });
    this.cacheTheme();
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => void this.flush(), 250);
  }

  async flush(): Promise<void> {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = null;
    if (!this.home || !this.creds) return;
    const path = userPath(this.home);
    await this.vfs.mkdir(path.slice(0, path.lastIndexOf('/')), { parents: true }, this.creds);
    await this.vfs.writeFile(path, JSON.stringify(this.user.get(), null, 2), {}, this.creds);
  }

  unloadUser(): void {
    this.home = null;
    this.creds = null;
    this.user.set({ ...DEFAULT_USER_SETTINGS, theme: this.user.get().theme, accent: this.user.get().accent });
  }

  private cacheTheme() {
    try {
      const { theme, accent } = this.user.get();
      localStorage.setItem('lvos:theme', JSON.stringify({ theme, accent }));
    } catch {
      /* localStorage unavailable (private mode / Node tests) */
    }
  }
}

// --- validation: settings files are user-editable, so never trust their shape.

function pick<T extends object>(src: unknown, defaults: T): Partial<T> {
  const out: Partial<T> = {};
  if (!src || typeof src !== 'object') return out;
  for (const key of Object.keys(defaults) as (keyof T)[]) {
    const value = (src as Record<string, unknown>)[key as string];
    if (value === undefined) continue;
    const def = defaults[key];
    if (Array.isArray(def) ? Array.isArray(value) : typeof value === typeof def) {
      out[key] = value as T[keyof T];
    }
  }
  return out;
}

export function sanitizeUser(src: unknown): Partial<UserSettings> {
  const out = pick(src, DEFAULT_USER_SETTINGS);
  if (out.theme && !['light', 'dark', 'auto'].includes(out.theme)) delete out.theme;
  if (out.accent && !/^#[0-9a-fA-F]{6}$/.test(out.accent)) delete out.accent;
  if (out.iconSize && !['small', 'medium', 'large'].includes(out.iconSize)) delete out.iconSize;
  if (out.dockPosition && !['bottom', 'left'].includes(out.dockPosition)) delete out.dockPosition;
  if (out.fontScale !== undefined) out.fontScale = Math.min(1.5, Math.max(0.8, out.fontScale));
  if (out.lockAfterMinutes !== undefined) out.lockAfterMinutes = Math.max(0, Math.min(240, Math.round(out.lockAfterMinutes)));
  if (out.dockApps) out.dockApps = out.dockApps.filter((x) => typeof x === 'string').slice(0, 20);
  if (out.syncServer !== undefined && out.syncServer && !/^https?:\/\//.test(out.syncServer)) delete out.syncServer;
  return out;
}

export function sanitizeSystem(src: unknown): Partial<SystemSettings> {
  const out = pick(src, DEFAULT_SYSTEM_SETTINGS);
  if (out.hostname !== undefined && !/^[a-zA-Z0-9-]{1,63}$/.test(out.hostname)) delete out.hostname;
  if (out.language && !['pt-BR', 'en-US'].includes(out.language)) delete out.language;
  return out;
}
