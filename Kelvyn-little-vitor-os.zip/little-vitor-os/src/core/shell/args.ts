/**
 * Small getopt-style parser.
 *   parseArgs(['-la', '-n', '5', 'file'], { bool: 'la', value: 'n' })
 *   -> { flags: Set{'l','a'}, values: { n: '5' }, rest: ['file'] }
 * Long options: --name, --name=value (value options must be listed in `long`).
 * "--" ends option parsing.
 */
export interface ParsedArgs {
  flags: Set<string>;
  values: Record<string, string>;
  rest: string[];
}

export class ArgError extends Error {}

export function parseArgs(
  args: string[],
  spec: { bool?: string; value?: string; long?: string[]; longValue?: string[] } = {},
): ParsedArgs {
  const bool = new Set((spec.bool ?? '').split(''));
  const value = new Set((spec.value ?? '').split(''));
  const long = new Set(spec.long ?? []);
  const longValue = new Set(spec.longValue ?? []);
  const flags = new Set<string>();
  const values: Record<string, string> = {};
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--') {
      rest.push(...args.slice(i + 1));
      break;
    }
    if (a.startsWith('--') && a.length > 2) {
      const [name, inline] = a.slice(2).split(/=(.*)/s, 2);
      if (longValue.has(name)) {
        const v = inline ?? args[++i];
        if (v === undefined) throw new ArgError(`a opção --${name} requer um argumento`);
        values[name] = v;
      } else if (long.has(name)) flags.add(name);
      else throw new ArgError(`opção não reconhecida '--${name}'`);
      continue;
    }
    if (a.startsWith('-') && a.length > 1 && !/^-\d+$/.test(a)) {
      for (let j = 1; j < a.length; j++) {
        const c = a[j];
        if (value.has(c)) {
          const v = a.slice(j + 1) || args[++i];
          if (v === undefined) throw new ArgError(`a opção requer um argumento -- '${c}'`);
          values[c] = v;
          break;
        }
        if (!bool.has(c)) throw new ArgError(`opção inválida -- '${c}'`);
        flags.add(c);
      }
      continue;
    }
    rest.push(a);
  }
  return { flags, values, rest };
}

export function humanSize(bytes: number, human = true): string {
  if (!human) return String(bytes);
  const units = ['B', 'K', 'M', 'G', 'T'];
  let v = bytes;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return i === 0 ? `${v}` : `${v < 10 ? v.toFixed(1) : Math.round(v)}${units[i]}`;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let v = bytes / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v < 10 ? 1 : 0)} ${units[i]}`;
}

export function formatDuration(ms: number): string {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const parts = [];
  if (d) parts.push(`${d} dia${d > 1 ? 's' : ''}`);
  if (h) parts.push(`${h}h`);
  parts.push(`${m}min`);
  if (!d && !h) parts.push(`${s % 60}s`);
  return parts.join(' ');
}

export function pad(s: string | number, n: number, right = false): string {
  const str = String(s);
  return right ? str.padStart(n) : str.padEnd(n);
}
