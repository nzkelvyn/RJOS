import { kindOf } from '../../vfs/mime';
import { parseArgs } from '../args';
import { ANSI, type CommandDef } from '../types';

const exportCmd: CommandDef = {
  name: 'export', summary: 'define variáveis de ambiente', usage: 'export NOME=valor...', source: 'vos',
  run(ctx) {
    if (!ctx.args.length || ctx.args[0] === '-p') {
      for (const [k, v] of [...ctx.shell.env].sort()) ctx.stdout.write(`declare -x ${k}="${v}"\n`);
      return 0;
    }
    for (const a of ctx.args) {
      const m = /^([A-Za-z_][A-Za-z0-9_]*)(?:=(.*))?$/s.exec(a);
      if (!m) {
        ctx.stderr.write(`export: '${a}': identificador inválido\n`);
        return 1;
      }
      if (m[2] !== undefined) ctx.shell.env.set(m[1], m[2]);
      else if (!ctx.shell.env.has(m[1])) ctx.shell.env.set(m[1], '');
    }
    return 0;
  },
};

const unset: CommandDef = {
  name: 'unset', summary: 'remove variáveis', usage: 'unset NOME...', source: 'vos',
  run(ctx) {
    for (const a of ctx.args) ctx.shell.env.delete(a);
    return 0;
  },
};

const env: CommandDef = {
  name: 'env', summary: 'mostra o ambiente', usage: 'env', source: 'vos',
  run(ctx) {
    for (const [k, v] of [...ctx.shell.env].filter(([k]) => !/^[0-9#@]$/.test(k)).sort()) ctx.stdout.write(`${k}=${v}\n`);
    return 0;
  },
};

const alias: CommandDef = {
  name: 'alias', summary: 'define atalhos de comandos', usage: "alias [nome='comando']", source: 'vos',
  run(ctx) {
    if (!ctx.args.length) {
      for (const [k, v] of [...ctx.shell.aliases].sort()) ctx.stdout.write(`alias ${k}='${v}'\n`);
      return 0;
    }
    for (const a of ctx.args) {
      const idx = a.indexOf('=');
      if (idx === -1) {
        const v = ctx.shell.aliases.get(a);
        if (v === undefined) {
          ctx.stderr.write(`alias: ${a}: não encontrado\n`);
          return 1;
        }
        ctx.stdout.write(`alias ${a}='${v}'\n`);
      } else ctx.shell.aliases.set(a.slice(0, idx), a.slice(idx + 1));
    }
    return 0;
  },
};

const unalias: CommandDef = {
  name: 'unalias', summary: 'remove atalhos', usage: 'unalias nome...', source: 'vos',
  run(ctx) {
    for (const a of ctx.args) ctx.shell.aliases.delete(a);
    return 0;
  },
};

const history: CommandDef = {
  name: 'history', summary: 'histórico de comandos', usage: 'history [-c] [N]', source: 'vos',
  async run(ctx) {
    if (ctx.args[0] === '-c') {
      await ctx.shell.clearHistory();
      return 0;
    }
    const n = ctx.args[0] ? Number(ctx.args[0]) : ctx.shell.history.length;
    const start = Math.max(0, ctx.shell.history.length - n);
    ctx.shell.history.slice(start).forEach((h, i) => ctx.stdout.write(`${String(start + i + 1).padStart(5)}  ${h}\n`));
    return 0;
  },
};

const clear: CommandDef = {
  name: 'clear', summary: 'limpa a tela', usage: 'clear', source: 'vos',
  run(ctx) {
    ctx.shell.host.clear();
    return 0;
  },
};

const exit: CommandDef = {
  name: 'exit', summary: 'fecha o terminal (aba)', usage: 'exit [código]', source: 'vos',
  run(ctx) {
    ctx.shell.host.exit();
    return Number(ctx.args[0] ?? 0);
  },
};

const logout: CommandDef = { ...exit, name: 'logout', summary: 'fecha o terminal (aba)' };

const sudo: CommandDef = {
  name: 'sudo', summary: 'executa um comando como root', usage: 'sudo comando [args...]', source: 'vos',
  async run(ctx) {
    if (!ctx.args.length) {
      ctx.stderr.write('uso: sudo comando [args...]\n');
      return 1;
    }
    if (!(await ctx.shell.authenticateSudo(ctx.stderr))) return 1;
    ctx.kernel.events.emit('log', { level: 'info', source: 'sudo', message: `${ctx.creds.username}: ${ctx.args.join(' ')}` });
    const controller = new AbortController();
    if (ctx.signal.aborted) controller.abort();
    ctx.signal.addEventListener('abort', () => controller.abort(), { once: true });
    return ctx.shell.dispatch(ctx.args, {
      creds: { username: 'root', groups: ['root'] },
      controller,
      stdin: ctx.stdin.isTTY ? null : ctx.stdin.read(),
      stdout: ctx.stdout,
      stderr: ctx.stderr,
      interactive: ctx.interactive,
    });
  },
};

const source: CommandDef = {
  name: 'source', summary: 'executa um script no shell atual', usage: 'source arquivo [args]', source: 'vos',
  async run(ctx) {
    if (!ctx.args[0]) {
      ctx.stderr.write('source: nome de arquivo requerido\n');
      return 2;
    }
    const path = ctx.shell.resolvePath(ctx.args[0]);
    const text = await ctx.kernel.vfs.readText(path, ctx.creds);
    return ctx.shell.runScript(text, [path, ...ctx.args.slice(1)], ctx.creds, { stdout: ctx.stdout, stderr: ctx.stderr });
  },
};

const sh: CommandDef = {
  name: 'sh', summary: 'executa um script lvsh', usage: 'sh arquivo [args] | sh -c "comandos"', source: 'vos',
  async run(ctx) {
    if (ctx.args[0] === '-c') return ctx.shell.execString(ctx.args.slice(1).join(' '), ctx.creds, { stdout: ctx.stdout, stderr: ctx.stderr });
    if (!ctx.args[0]) {
      ctx.stderr.write('sh: modo interativo aninhado não suportado; passe um arquivo ou -c\n');
      return 2;
    }
    const path = ctx.shell.resolvePath(ctx.args[0]);
    const text = await ctx.kernel.vfs.readText(path, ctx.creds);
    return ctx.shell.runScript(text, [path, ...ctx.args.slice(1)], ctx.creds, { stdout: ctx.stdout, stderr: ctx.stderr });
  },
};

const open: CommandDef = {
  name: 'open', summary: 'abre arquivo/pasta no app gráfico padrão', usage: 'open caminho | open -a app', source: 'gui',
  run(ctx) {
    const { values, rest } = parseArgs(ctx.args, { value: 'a' });
    if (values.a) {
      ctx.shell.host.openApp(values.a, rest[0] ? { path: ctx.shell.resolvePath(rest[0]) } : undefined);
      return 0;
    }
    if (!rest.length) {
      ctx.stderr.write(`uso: ${open.usage}\n`);
      return 1;
    }
    for (const r of rest) {
      const path = ctx.shell.resolvePath(r);
      if (!ctx.kernel.vfs.exists(path)) {
        ctx.stderr.write(`open: ${r}: Arquivo ou diretório inexistente\n`);
        return 1;
      }
      ctx.shell.host.openPath(path);
    }
    return 0;
  },
};

const nano: CommandDef = {
  name: 'nano', summary: 'edita um arquivo no Editor de Texto gráfico', usage: 'nano arquivo', source: 'gui',
  async run(ctx) {
    if (!ctx.args[0]) {
      ctx.shell.host.openApp('editor');
      return 0;
    }
    const path = ctx.shell.resolvePath(ctx.args[0]);
    if (!ctx.kernel.vfs.exists(path)) await ctx.kernel.vfs.writeFile(path, '', {}, ctx.creds);
    if (kindOf(path) !== 'text' && kindOf(path) !== 'binary') {
      ctx.stderr.write(`nano: ${ctx.args[0]} não é um arquivo de texto\n`);
      return 1;
    }
    ctx.shell.host.openApp('editor', { path });
    ctx.stdout.write(`${ANSI.dim}Aberto no Editor de Texto (o lvsh não tem editor em modo texto).${ANSI.reset}\n`);
    return 0;
  },
};

const passwd: CommandDef = {
  name: 'passwd', summary: 'altera a senha', usage: 'passwd', source: 'vos',
  async run(ctx) {
    const host = ctx.shell.host;
    const user = ctx.kernel.users.current;
    if (!user) return 1;
    const old = await host.prompt('Senha atual: ', true);
    if (old === null) return 1;
    const a = await host.prompt('Nova senha: ', true);
    if (a === null) return 1;
    const b = await host.prompt('Redigite a nova senha: ', true);
    if (a !== b) {
      ctx.stderr.write('passwd: as senhas não coincidem\n');
      return 1;
    }
    try {
      await ctx.kernel.users.changePassword(user.username, old, a);
      ctx.stdout.write('passwd: senha atualizada com sucesso\n');
      return 0;
    } catch (err) {
      ctx.stderr.write(`passwd: ${(err as Error).message}\n`);
      return 1;
    }
  },
};

const notifySend: CommandDef = {
  name: 'notify-send', summary: 'envia uma notificação para a área de trabalho', usage: 'notify-send título [corpo]', source: 'gui',
  run(ctx) {
    if (!ctx.args[0]) {
      ctx.stderr.write('notify-send: título obrigatório\n');
      return 1;
    }
    ctx.kernel.notifications.push({ app: 'terminal', appName: 'Terminal', title: ctx.args[0], body: ctx.args.slice(1).join(' ') || undefined, level: 'info' });
    return 0;
  },
};

const lock: CommandDef = {
  name: 'lock', summary: 'bloqueia a sessão', usage: 'lock', source: 'gui',
  run(ctx) {
    ctx.kernel.users.lock();
    return 0;
  },
};

const reboot: CommandDef = {
  name: 'reboot', summary: 'reinicia o Little Vitor OS (recarrega a página)', usage: 'reboot', source: 'gui',
  async run(ctx) {
    if (ctx.creds.username !== 'root') {
      ctx.stderr.write('reboot: é preciso ser root (use sudo reboot)\n');
      return 1;
    }
    await ctx.kernel.settings.flush();
    ctx.stdout.write('O sistema vai reiniciar agora...\n');
    setTimeout(() => globalThis.location?.reload(), 600);
    return 0;
  },
};

export const builtinCommands: CommandDef[] = [
  exportCmd, unset, env, alias, unalias, history, clear, exit, logout, sudo, source, { ...source, name: '.' }, sh, { ...sh, name: 'lvsh' },
  open, nano, passwd, notifySend, lock, reboot, { ...reboot, name: 'shutdown', summary: 'encerra (recarrega a página)' },
];
