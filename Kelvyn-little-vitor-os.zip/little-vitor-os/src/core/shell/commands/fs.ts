import { basename, dirname, join } from '../../vfs/path';
import { formatMode, parseChmod } from '../../vfs/permissions';
import type { DirEntry, VNode } from '../../vfs/types';
import { kindOf } from '../../vfs/mime';
import { humanSize, parseArgs } from '../args';
import { globToRegExp } from '../glob';
import { ANSI, type CommandContext, type CommandDef } from '../types';

const MONTHS = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];

function lsDate(ts: number): string {
  const d = new Date(ts);
  const recent = Date.now() - ts < 1000 * 60 * 60 * 24 * 180;
  const time = recent ? `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}` : ` ${d.getFullYear()}`;
  return `${MONTHS[d.getMonth()]} ${String(d.getDate()).padStart(2)} ${time}`;
}

function colorName(name: string, node: VNode, color: boolean, classify: boolean): string {
  const suffix = classify ? (node.type === 'dir' ? '/' : node.mode & 0o111 ? '*' : '') : '';
  if (!color) return name + suffix;
  if (node.type === 'dir') {
    if (node.mode & 0o1000 && node.mode & 0o002) return `\x1b[30;42m${name}${ANSI.reset}${suffix}`;
    return `${ANSI.bold}${ANSI.brightBlue}${name}${ANSI.reset}${suffix}`;
  }
  if (node.mode & 0o111) return `${ANSI.bold}${ANSI.brightGreen}${name}${ANSI.reset}${suffix}`;
  const kind = kindOf(name, node.mime);
  if (kind === 'image' || kind === 'video') return `${ANSI.magenta}${name}${ANSI.reset}${suffix}`;
  if (kind === 'archive') return `${ANSI.red}${name}${ANSI.reset}${suffix}`;
  if (kind === 'audio') return `${ANSI.cyan}${name}${ANSI.reset}${suffix}`;
  return name + suffix;
}

function columns(names: { plain: string; shown: string }[], width: number): string {
  if (!names.length) return '';
  const max = Math.max(...names.map((n) => n.plain.length)) + 2;
  const cols = Math.max(1, Math.floor(width / max));
  const rows = Math.ceil(names.length / cols);
  const lines: string[] = [];
  for (let r = 0; r < rows; r++) {
    let line = '';
    for (let c = 0; c < cols; c++) {
      const item = names[c * rows + r];
      if (!item) continue;
      line += item.shown + ' '.repeat(Math.max(1, max - item.plain.length));
    }
    lines.push(line.trimEnd());
  }
  return lines.join('\n') + '\n';
}

const ls: CommandDef = {
  name: 'ls',
  summary: 'lista o conteúdo de diretórios',
  usage: 'ls [-laAhRrtS1dF] [caminho...]',
  source: 'vos',
  manual: '-l formato longo  -a inclui ocultos  -A ocultos sem . e ..  -h tamanhos legíveis\n-R recursivo  -t ordena por data  -S ordena por tamanho  -r inverte  -1 um por linha\n-d lista o próprio diretório  -F indica tipo (/ diretório, * executável)',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'laAhRrtS1dF', long: ['color', 'all'] });
    if (flags.has('all')) flags.add('a');
    const vfs = ctx.kernel.vfs;
    const targets = rest.length ? rest : ['.'];
    let status = 0;
    const color = ctx.interactive;
    const sortEntries = (list: DirEntry[]) => {
      if (flags.has('t')) list.sort((a, b) => b.node.mtime - a.node.mtime);
      else if (flags.has('S')) list.sort((a, b) => b.node.size - a.node.size);
      if (flags.has('r')) list.reverse();
      return list;
    };
    const render = (list: DirEntry[]) => {
      if (flags.has('l')) {
        const sizeOf = (e: DirEntry) => (e.node.type === 'dir' ? 4096 : e.node.size);
        const sizes = list.map((e) => humanSize(sizeOf(e), flags.has('h')));
        const w = Math.max(1, ...sizes.map((s) => s.length));
        const ow = Math.max(1, ...list.map((e) => e.node.owner.length));
        const gw = Math.max(1, ...list.map((e) => e.node.group.length));
        if (!flags.has('d')) {
          const total = list.reduce((acc, e) => acc + Math.ceil(sizeOf(e) / 1024), 0);
          ctx.stdout.write(`total ${total}\n`);
        }
        for (let i = 0; i < list.length; i++) {
          const e = list[i];
          const links = e.node.type === 'dir' ? 2 : 1;
          ctx.stdout.write(
            `${formatMode(e.node)} ${links} ${e.node.owner.padEnd(ow)} ${e.node.group.padEnd(gw)} ${sizes[i].padStart(w)} ${lsDate(e.node.mtime)} ${colorName(e.name, e.node, color, flags.has('F'))}\n`,
          );
        }
      } else if (flags.has('1') || !ctx.interactive) {
        for (const e of list) ctx.stdout.write(colorName(e.name, e.node, color, flags.has('F')) + '\n');
      } else {
        ctx.stdout.write(columns(list.map((e) => ({ plain: e.name + (flags.has('F') && (e.node.type === 'dir' || e.node.mode & 0o111) ? '/' : ''), shown: colorName(e.name, e.node, color, flags.has('F')) })), ctx.shell.host.columns()));
      }
    };
    const listDir = (path: string, label: string | null) => {
      let entries = vfs.readdir(path, ctx.creds);
      if (!flags.has('a') && !flags.has('A')) entries = entries.filter((e) => !e.name.startsWith('.'));
      if (flags.has('a')) {
        const self = vfs.stat(path, ctx.creds);
        const parent = vfs.stat(dirname(path), ctx.creds);
        entries = [{ name: '.', path, node: self }, { name: '..', path: dirname(path), node: parent }, ...entries];
      }
      if (label !== null) ctx.stdout.write(`${label}:\n`);
      render(sortEntries(entries));
      if (flags.has('R')) {
        for (const e of entries) {
          if (e.node.type === 'dir' && e.name !== '.' && e.name !== '..') {
            ctx.stdout.write('\n');
            try {
              listDir(e.path, label === null ? e.path : join(label, e.name));
            } catch (err) {
              ctx.stderr.write(`ls: ${(err as Error).message}\n`);
              status = 2;
            }
          }
        }
      }
    };
    const files: DirEntry[] = [];
    const dirs: string[] = [];
    for (const t of targets) {
      const path = ctx.shell.resolvePath(t);
      try {
        const node = vfs.stat(path, ctx.creds);
        if (node.type === 'dir' && !flags.has('d')) dirs.push(t);
        else files.push({ name: t, path, node });
      } catch (err) {
        ctx.stderr.write(`ls: não foi possível acessar '${t}': ${(err as Error).message.split(': ').pop()}\n`);
        status = 2;
      }
    }
    if (files.length) render(sortEntries(files));
    dirs.forEach((d, i) => {
      if (files.length || i > 0) ctx.stdout.write('\n');
      try {
        listDir(ctx.shell.resolvePath(d), targets.length > 1 || flags.has('R') ? d : null);
      } catch (err) {
        ctx.stderr.write(`ls: não foi possível abrir o diretório '${d}': ${(err as Error).message.split(': ').pop()}\n`);
        status = 2;
      }
    });
    return status;
  },
};

const pwd: CommandDef = {
  name: 'pwd', summary: 'mostra o diretório atual', usage: 'pwd', source: 'vos',
  run(ctx) {
    ctx.stdout.write(ctx.shell.cwd + '\n');
    return 0;
  },
};

const cd: CommandDef = {
  name: 'cd', summary: 'muda o diretório atual', usage: 'cd [dir | - | ~]', source: 'vos',
  run(ctx) {
    if (ctx.args.length > 1) {
      ctx.stderr.write('cd: argumentos em excesso\n');
      return 1;
    }
    return ctx.shell.cd(ctx.args[0], ctx.stderr);
  },
};

async function eachPath(ctx: CommandContext, paths: string[], fn: (abs: string, raw: string) => Promise<void>): Promise<number> {
  let status = 0;
  for (const p of paths) {
    try {
      await fn(ctx.shell.resolvePath(p), p);
    } catch (err) {
      ctx.stderr.write(`${ctx.name}: ${shortErr(err, p)}\n`);
      status = 1;
    }
  }
  return status;
}

function shortErr(err: unknown, raw: string): string {
  const msg = (err as Error).message;
  const idx = msg.indexOf(': ');
  return idx >= 0 ? `'${raw}': ${msg.slice(idx + 2)}` : msg;
}

const mkdir: CommandDef = {
  name: 'mkdir', summary: 'cria diretórios', usage: 'mkdir [-p] [-m modo] dir...', source: 'vos',
  async run(ctx) {
    const { flags, values, rest } = parseArgs(ctx.args, { bool: 'pv', value: 'm' });
    if (!rest.length) {
      ctx.stderr.write('mkdir: falta operando\n');
      return 1;
    }
    const mode = values.m ? parseChmod(values.m, 0o755) ?? 0o755 : 0o755;
    return eachPath(ctx, rest, async (abs, raw) => {
      await ctx.kernel.vfs.mkdir(abs, { parents: flags.has('p'), mode }, ctx.creds);
      if (flags.has('v')) ctx.stdout.write(`mkdir: foi criado o diretório '${raw}'\n`);
    });
  },
};

const rmdir: CommandDef = {
  name: 'rmdir', summary: 'remove diretórios vazios', usage: 'rmdir dir...', source: 'vos',
  async run(ctx) {
    const { rest } = parseArgs(ctx.args, {});
    if (!rest.length) {
      ctx.stderr.write('rmdir: falta operando\n');
      return 1;
    }
    return eachPath(ctx, rest, (abs) => ctx.kernel.vfs.rmdir(abs, ctx.creds));
  },
};

const touch: CommandDef = {
  name: 'touch', summary: 'cria arquivos vazios ou atualiza a data', usage: 'touch arquivo...', source: 'vos',
  async run(ctx) {
    const { rest } = parseArgs(ctx.args, { bool: 'c' });
    if (!rest.length) {
      ctx.stderr.write('touch: falta operando de arquivo\n');
      return 1;
    }
    return eachPath(ctx, rest, (abs) => ctx.kernel.vfs.touch(abs, ctx.creds));
  },
};

const cp: CommandDef = {
  name: 'cp', summary: 'copia arquivos e diretórios', usage: 'cp [-r] [-v] origem... destino', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'rRvaf' });
    if (rest.length < 2) {
      ctx.stderr.write('cp: falta operando\n');
      return 1;
    }
    const dest = rest.pop()!;
    const destAbs = ctx.shell.resolvePath(dest);
    if (rest.length > 1 && !ctx.kernel.vfs.isDir(destAbs)) {
      ctx.stderr.write(`cp: o destino '${dest}' não é um diretório\n`);
      return 1;
    }
    const recursive = flags.has('r') || flags.has('R') || flags.has('a');
    return eachPath(ctx, rest, async (abs, raw) => {
      if (ctx.kernel.vfs.isDir(abs) && !recursive) throw new Error(`-r não especificado; omitindo diretório '${raw}'`);
      const out = await ctx.kernel.vfs.copy(abs, destAbs, { recursive }, ctx.creds);
      if (flags.has('v')) ctx.stdout.write(`'${raw}' -> '${out}'\n`);
    });
  },
};

const mv: CommandDef = {
  name: 'mv', summary: 'move ou renomeia arquivos', usage: 'mv [-v] origem... destino', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'vfi' });
    if (rest.length < 2) {
      ctx.stderr.write('mv: falta operando\n');
      return 1;
    }
    const dest = rest.pop()!;
    const destAbs = ctx.shell.resolvePath(dest);
    if (rest.length > 1 && !ctx.kernel.vfs.isDir(destAbs)) {
      ctx.stderr.write(`mv: o destino '${dest}' não é um diretório\n`);
      return 1;
    }
    return eachPath(ctx, rest, async (abs, raw) => {
      const out = await ctx.kernel.vfs.move(abs, destAbs, ctx.creds);
      if (flags.has('v')) ctx.stdout.write(`renomeado '${raw}' -> '${out}'\n`);
    });
  },
};

const rm: CommandDef = {
  name: 'rm', summary: 'remove arquivos (permanente; use "trash" para a lixeira)', usage: 'rm [-rfv] arquivo...', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'rRfvid' });
    if (!rest.length) {
      if (flags.has('f')) return 0;
      ctx.stderr.write('rm: falta operando\n');
      return 1;
    }
    const recursive = flags.has('r') || flags.has('R');
    let status = 0;
    for (const p of rest) {
      const abs = ctx.shell.resolvePath(p);
      if (abs === '/') {
        ctx.stderr.write("rm: é perigoso operar recursivamente em '/'\nrm: use --no-preserve-root para ignorar esta proteção (não suportado aqui)\n");
        status = 1;
        continue;
      }
      try {
        if (!ctx.kernel.vfs.exists(abs)) {
          if (!flags.has('f')) throw new Error(`não foi possível remover '${p}': Arquivo ou diretório inexistente`);
          continue;
        }
        if (ctx.kernel.vfs.isDir(abs) && !recursive) {
          if (flags.has('d')) await ctx.kernel.vfs.rmdir(abs, ctx.creds);
          else throw new Error(`não foi possível remover '${p}': É um diretório`);
        } else await ctx.kernel.vfs.rm(abs, { recursive }, ctx.creds);
        if (flags.has('v')) ctx.stdout.write(`removido '${p}'\n`);
      } catch (err) {
        ctx.stderr.write(`rm: ${(err as Error).message}\n`);
        status = 1;
      }
    }
    return status;
  },
};

const trash: CommandDef = {
  name: 'trash', summary: 'envia para a lixeira, lista ou restaura', usage: 'trash arquivo... | trash -l | trash -r ID | trash --empty', source: 'vos',
  async run(ctx) {
    const { flags, values, rest } = parseArgs(ctx.args, { bool: 'l', value: 'r', long: ['empty'] });
    const vfs = ctx.kernel.vfs;
    if (flags.has('l')) {
      const items = await vfs.listTrash(ctx.creds);
      if (!items.length) ctx.stdout.write('A lixeira está vazia.\n');
      for (const i of items) ctx.stdout.write(`${i.id.slice(0, 8)}  ${new Date(i.deletedAt).toLocaleString()}  ${i.originalPath}\n`);
      return 0;
    }
    if (values.r) {
      const items = await vfs.listTrash(ctx.creds);
      const item = items.find((i) => i.id.startsWith(values.r));
      if (!item) {
        ctx.stderr.write(`trash: item não encontrado: ${values.r}\n`);
        return 1;
      }
      ctx.stdout.write(`restaurado em ${await vfs.restoreFromTrash(item.id, ctx.creds)}\n`);
      return 0;
    }
    if (flags.has('empty')) {
      ctx.stdout.write(`${await vfs.emptyTrash(ctx.creds)} item(ns) removido(s) definitivamente.\n`);
      return 0;
    }
    if (!rest.length) {
      ctx.stderr.write(`uso: ${trash.usage}\n`);
      return 1;
    }
    return eachPath(ctx, rest, async (abs) => {
      await vfs.moveToTrash(abs, ctx.creds);
    });
  },
};

const cat: CommandDef = {
  name: 'cat', summary: 'concatena e mostra arquivos', usage: 'cat [-n] [arquivo...]', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'nAE' });
    let out = '';
    let status = 0;
    if (!rest.length || (rest.length === 1 && rest[0] === '-')) out = ctx.stdin.read();
    for (const p of rest) {
      if (p === '-') {
        out += ctx.stdin.read();
        continue;
      }
      try {
        out += await ctx.kernel.vfs.readText(ctx.shell.resolvePath(p), ctx.creds);
      } catch (err) {
        ctx.stderr.write(`cat: ${shortErr(err, p).replace(/'/g, '')}\n`);
        status = 1;
      }
    }
    if (flags.has('n')) {
      const lines = out.split('\n');
      if (lines[lines.length - 1] === '') lines.pop();
      out = lines.map((l, i) => `${String(i + 1).padStart(6)}\t${l}`).join('\n') + (lines.length ? '\n' : '');
    }
    ctx.stdout.write(out);
    return status;
  },
};

const find: CommandDef = {
  name: 'find', summary: 'procura arquivos', usage: 'find [caminho] [-name P] [-iname P] [-type f|d] [-maxdepth N] [-size +N[k|M]]', source: 'vos',
  async run(ctx) {
    const args = [...ctx.args];
    const start = args[0] && !args[0].startsWith('-') ? args.shift()! : '.';
    let name: RegExp | null = null;
    let type: string | null = null;
    let maxdepth = Infinity;
    let size: ((n: number) => boolean) | null = null;
    while (args.length) {
      const opt = args.shift()!;
      const val = args.shift();
      if (val === undefined) {
        ctx.stderr.write(`find: falta argumento para '${opt}'\n`);
        return 1;
      }
      if (opt === '-name') name = globToRegExp(val);
      else if (opt === '-iname') name = new RegExp(globToRegExp(val).source, 'i');
      else if (opt === '-type') type = val;
      else if (opt === '-maxdepth') maxdepth = Number(val);
      else if (opt === '-size') {
        const m = /^([+-]?)(\d+)([kMG]?)$/.exec(val);
        if (!m) {
          ctx.stderr.write(`find: tamanho inválido '${val}'\n`);
          return 1;
        }
        const mult = { '': 1, k: 1024, M: 1024 ** 2, G: 1024 ** 3 }[m[3]]!;
        const n = Number(m[2]) * mult;
        size = m[1] === '+' ? (x) => x > n : m[1] === '-' ? (x) => x < n : (x) => x === n;
      } else {
        ctx.stderr.write(`find: predicado desconhecido '${opt}'\n`);
        return 1;
      }
    }
    const root = ctx.shell.resolvePath(start);
    if (!ctx.kernel.vfs.exists(root)) {
      ctx.stderr.write(`find: '${start}': Arquivo ou diretório inexistente\n`);
      return 1;
    }
    const depthOf = (p: string) => (p === root ? 0 : p.slice(root.length).split('/').filter(Boolean).length);
    const show = (p: string) => (start === '.' ? '.' + p.slice(root.length) || '.' : start.replace(/\/$/, '') + p.slice(root.length));
    const match = (n: { name: string; type: string; size: number }) =>
      (!name || name.test(n.name)) && (!type || (type === 'd' ? n.type === 'dir' : n.type === 'file')) && (!size || (n.type === 'file' && size(n.size)));
    const rootNode = ctx.kernel.vfs.stat(root, ctx.creds);
    if (match({ name: basename(root), type: rootNode.type, size: rootNode.size })) ctx.stdout.write(show(root) + '\n');
    if (rootNode.type === 'dir') {
      for (const e of ctx.kernel.vfs.find(root, (e) => depthOf(e.path) <= maxdepth, ctx.creds)) {
        if (match({ name: e.name, type: e.node.type, size: e.node.size })) ctx.stdout.write(show(e.path) + '\n');
      }
    }
    return 0;
  },
};

const tree: CommandDef = {
  name: 'tree', summary: 'mostra diretórios em árvore', usage: 'tree [-a] [-d] [-L nível] [dir]', source: 'vos',
  async run(ctx) {
    const { flags, values, rest } = parseArgs(ctx.args, { bool: 'ad', value: 'L' });
    const start = rest[0] ?? '.';
    const root = ctx.shell.resolvePath(start);
    const max = values.L ? Number(values.L) : Infinity;
    let dirs = 0;
    let files = 0;
    ctx.stdout.write(`${ANSI.bold}${ANSI.brightBlue}${start}${ANSI.reset}\n`);
    const walk = (path: string, prefix: string, depth: number) => {
      if (depth > max) return;
      let entries = ctx.kernel.vfs.readdir(path, ctx.creds);
      if (!flags.has('a')) entries = entries.filter((e) => !e.name.startsWith('.'));
      if (flags.has('d')) entries = entries.filter((e) => e.node.type === 'dir');
      entries.forEach((e, i) => {
        const last = i === entries.length - 1;
        ctx.stdout.write(`${prefix}${last ? '└── ' : '├── '}${colorName(e.name, e.node, ctx.interactive, false)}\n`);
        if (e.node.type === 'dir') {
          dirs++;
          try {
            walk(e.path, prefix + (last ? '    ' : '│   '), depth + 1);
          } catch {
            /* unreadable */
          }
        } else files++;
      });
    };
    try {
      walk(root, '', 1);
    } catch (err) {
      ctx.stderr.write(`tree: ${(err as Error).message}\n`);
      return 1;
    }
    ctx.stdout.write(`\n${dirs} diretório${dirs === 1 ? '' : 's'}${flags.has('d') ? '' : `, ${files} arquivo${files === 1 ? '' : 's'}`}\n`);
    return 0;
  },
};

const chmod: CommandDef = {
  name: 'chmod', summary: 'altera permissões', usage: 'chmod [-R] modo arquivo...  (ex.: 755, u+x, go-w)', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'Rv' });
    if (rest.length < 2) {
      ctx.stderr.write('chmod: falta operando\n');
      return 1;
    }
    const spec = rest.shift()!;
    const vfs = ctx.kernel.vfs;
    return eachPath(ctx, rest, async (abs) => {
      const targets = [abs];
      if (flags.has('R') && vfs.isDir(abs)) targets.push(...vfs.find(abs, () => true, ctx.creds).map((e) => e.path));
      for (const t of targets) {
        const mode = parseChmod(spec, vfs.stat(t, ctx.creds).mode);
        if (mode === null) throw new Error(`modo inválido: '${spec}'`);
        await vfs.chmod(t, mode, ctx.creds);
      }
    });
  },
};

const chown: CommandDef = {
  name: 'chown', summary: 'altera dono e grupo', usage: 'chown [-R] dono[:grupo] arquivo...', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'Rv' });
    if (rest.length < 2) {
      ctx.stderr.write('chown: falta operando\n');
      return 1;
    }
    const [owner, group] = rest.shift()!.split(':');
    const users = await ctx.kernel.users.list();
    if (owner && !users.some((u) => u.username === owner)) {
      ctx.stderr.write(`chown: usuário inválido: '${owner}'\n`);
      return 1;
    }
    return eachPath(ctx, rest, (abs) => ctx.kernel.vfs.chown(abs, owner || null, group || null, { recursive: flags.has('R') }, ctx.creds));
  },
};

const stat: CommandDef = {
  name: 'stat', summary: 'mostra metadados de um arquivo', usage: 'stat arquivo...', source: 'vos',
  async run(ctx) {
    return eachPath(ctx, ctx.args, async (abs, raw) => {
      const n = ctx.kernel.vfs.stat(abs, ctx.creds);
      const fmt = (t: number) => new Date(t).toLocaleString();
      ctx.stdout.write(
        `  Arquivo: ${raw}\n  Tamanho: ${n.size}\tTipo: ${n.type === 'dir' ? 'diretório' : 'arquivo comum'}\n` +
          `   Acesso: (${(n.mode & 0o7777).toString(8).padStart(4, '0')}/${formatMode(n)})  Dono: ${n.owner}  Grupo: ${n.group}\n` +
          `     MIME: ${n.mime ?? '-'}\n   Acesso: ${fmt(n.atime)}\nModificado: ${fmt(n.mtime)}\n Alterado: ${fmt(n.ctime)}\n` +
          `    Inode: ${n.id}${ctx.kernel.vfs.isVirtual(abs) ? ' (arquivo virtual gerado pelo sistema)' : ''}\n`,
      );
    });
  },
};

const file: CommandDef = {
  name: 'file', summary: 'identifica o tipo de arquivo', usage: 'file arquivo...', source: 'vos',
  async run(ctx) {
    return eachPath(ctx, ctx.args, async (abs, raw) => {
      const n = ctx.kernel.vfs.stat(abs, ctx.creds);
      if (n.type === 'dir') return void ctx.stdout.write(`${raw}: diretório\n`);
      const data = await ctx.kernel.vfs.readFile(abs, ctx.creds);
      let desc = n.mime ?? 'dados';
      if (data[0] === 0x89 && data[1] === 0x50) desc = 'imagem PNG';
      else if (data[0] === 0xff && data[1] === 0xd8) desc = 'imagem JPEG';
      else if (data[0] === 0x25 && data[1] === 0x50 && data[2] === 0x44) desc = 'documento PDF';
      else if (data[0] === 0x50 && data[1] === 0x4b) desc = 'arquivo Zip';
      else if (!data.length) desc = 'vazio';
      else if (data.slice(0, 512).every((b) => b === 9 || b === 10 || b === 13 || (b >= 32 && b !== 127) || b >= 128)) {
        const text = new TextDecoder().decode(data.slice(0, 64));
        desc = text.startsWith('#!lvsh-builtin') ? 'executável interno do lvsh' : text.startsWith('#!') ? 'script de shell, texto' : 'texto UTF-8';
      }
      ctx.stdout.write(`${raw}: ${desc}\n`);
    });
  },
};

const du: CommandDef = {
  name: 'du', summary: 'uso de espaço de arquivos', usage: 'du [-sh] [caminho...]', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'shac' });
    const vfs = ctx.kernel.vfs;
    let grand = 0;
    const show = (bytes: number, p: string) => ctx.stdout.write(`${flags.has('h') ? humanSize(bytes) : Math.ceil(bytes / 1024)}\t${p}\n`);
    const status = await eachPath(ctx, rest.length ? rest : ['.'], async (abs, raw) => {
      const total = vfs.du(abs);
      grand += total;
      if (!flags.has('s') && vfs.isDir(abs)) {
        const dirs = vfs.find(abs, (e) => e.node.type === 'dir', ctx.creds).reverse();
        for (const d of dirs) show(vfs.du(d.path), raw.replace(/\/$/, '') + d.path.slice(abs.length));
      }
      show(total, raw);
    });
    if (flags.has('c')) show(grand, 'total');
    return status;
  },
};

const df: CommandDef = {
  name: 'df', summary: 'espaço do armazenamento', usage: 'df [-h]', source: 'vos',
  async run(ctx) {
    const { flags } = parseArgs(ctx.args, { bool: 'hT' });
    const vfs = ctx.kernel.vfs;
    const est = await vfs.estimate();
    const used = vfs.stats().bytes;
    const fmt = (n: number | null) => (n === null ? '?' : flags.has('h') ? humanSize(n) : String(Math.ceil(n / 1024)));
    ctx.stdout.write(`Sist. Arq.        Tipo           ${flags.has('h') ? 'Tam.' : 'Blocos-1K'}  Usado  Disp.  Uso%  Montado em\n`);
    const quota = est.quota;
    const avail = quota !== null && est.usage !== null ? quota - est.usage : null;
    const pct = quota ? `${Math.max(1, Math.round(((est.usage ?? used) / quota) * 100))}%` : '-';
    ctx.stdout.write(`lvfs              ${vfs.backendKind.padEnd(14)} ${fmt(quota).padStart(9)} ${fmt(used).padStart(6)} ${fmt(avail).padStart(6)} ${pct.padStart(5)}  /\n`);
    ctx.stdout.write(`proc              virtual        ${'0'.padStart(9)} ${'0'.padStart(6)} ${'0'.padStart(6)} ${'-'.padStart(5)}  /proc\n`);
    ctx.stdout.write(`${ANSI.dim}Tam./Disp. = cota real informada pelo navegador (navigator.storage.estimate). "Usado" = bytes dos seus arquivos no VFS.${ANSI.reset}\n`);
    return 0;
  },
};

export const fsCommands: CommandDef[] = [ls, pwd, cd, mkdir, rmdir, touch, cp, mv, rm, trash, cat, find, tree, chmod, chown, stat, file, du, df];
