import type { VFS } from '../../vfs/vfs';
import { ROOT_CREDS } from '../../vfs/types';
import { ANSI, type CommandDef } from '../types';
import { builtinCommands } from './builtins';
import { fsCommands } from './fs';
import { lvpCommands } from './lvp';
import { netCommands } from './net';
import { systemCommands } from './system';
import { textCommands } from './text';

export const COMMANDS = new Map<string, CommandDef>();

const SOURCE_LABEL: Record<CommandDef['source'], string> = {
  vos: 'implementado pelo Little Vitor OS (não é um binário Linux real)',
  browser: 'implementado pelo Little Vitor OS usando APIs reais do navegador',
  gui: 'abre/controla um aplicativo gráfico do Little Vitor OS',
};

/** Programs that exist on Linux but cannot run here (no real Linux/WebAssembly runtime is bundled). */
export const UNAVAILABLE: Record<string, string> = {
  apt: 'use "lvp" (Little Vitor Package Manager)',
  'apt-get': 'use "lvp"',
  dnf: 'use "lvp"',
  pacman: 'use "lvp"',
  snap: 'use "lvp"',
  python: 'executar Python exigiria um runtime em WebAssembly (ex.: Pyodide), que não está incluído',
  python3: 'executar Python exigiria um runtime em WebAssembly (ex.: Pyodide), que não está incluído',
  pip: 'sem runtime Python neste sistema',
  node: 'não há Node.js dentro do sistema virtual',
  npm: 'não há Node.js dentro do sistema virtual',
  java: 'não há JVM dentro do sistema virtual',
  javac: 'não há JDK dentro do sistema virtual',
  gcc: 'compilar C exigiria um toolchain em WebAssembly, não incluído',
  make: 'sem toolchain de compilação',
  git: 'sem cliente git neste sistema',
  ssh: 'navegadores não abrem conexões TCP/SSH',
  scp: 'navegadores não abrem conexões TCP/SSH',
  telnet: 'navegadores não abrem conexões TCP',
  nc: 'navegadores não abrem sockets TCP/UDP',
  nmap: 'navegadores não abrem sockets TCP/UDP',
  traceroute: 'navegadores não controlam TTL de pacotes',
  ifconfig: 'use "ip addr"',
  vi: 'use "nano" (abre o Editor de Texto)',
  emacs: 'use "nano" (abre o Editor de Texto)',
  systemctl: 'não há systemd; serviços do sistema aparecem em "ps aux"',
  mount: 'o VFS é montado automaticamente no boot',
  su: 'use "sudo comando" (o root não tem senha, como no Ubuntu)',
  useradd: 'crie usuários em Configurações › Usuários',
  adduser: 'crie usuários em Configurações › Usuários',
  ln: 'links simbólicos não são suportados pelo VFS',
  docker: 'não há containers neste sistema',
};

const help: CommandDef = {
  name: 'help', summary: 'lista os comandos disponíveis', usage: 'help', source: 'vos',
  run(ctx) {
    const groups: [string, string[]][] = [
      ['Arquivos', ['ls', 'cd', 'pwd', 'mkdir', 'rmdir', 'touch', 'cp', 'mv', 'rm', 'trash', 'cat', 'find', 'tree', 'stat', 'file', 'chmod', 'chown', 'du', 'df']],
      ['Texto', ['echo', 'grep', 'head', 'tail', 'wc', 'sort', 'uniq', 'tee', 'seq', 'rev', 'basename', 'dirname']],
      ['Sistema', ['whoami', 'id', 'groups', 'hostname', 'uname', 'date', 'cal', 'uptime', 'neofetch', 'ps', 'top', 'free', 'kill', 'jobs', 'fg', 'sleep', 'sudo', 'passwd', 'lock', 'reboot']],
      ['Rede', ['ping', 'curl', 'wget', 'ip', 'netstat']],
      ['Shell', ['history', 'env', 'export', 'unset', 'alias', 'unalias', 'source', 'sh', 'which', 'type', 'man', 'clear', 'exit']],
      ['Gráfico e pacotes', ['open', 'nano', 'notify-send', 'lvp']],
    ];
    ctx.stdout.write(`${ANSI.bold}lvsh — Little Vitor shell${ANSI.reset}\n`);
    ctx.stdout.write('Recursos: pipes (|), redirecionamento (> >> < 2> 2>&1), && || ;, jobs com &, $VAR, ~, *?[], aliases, histórico (↑ ↓ !!), Tab.\n\n');
    for (const [title, names] of groups) {
      ctx.stdout.write(`${ANSI.cyan}${title}${ANSI.reset}\n`);
      for (const n of names) {
        const c = COMMANDS.get(n);
        if (c) ctx.stdout.write(`  ${n.padEnd(12)} ${c.summary}\n`);
      }
    }
    ctx.stdout.write(`\nUse "man comando" para detalhes. Comandos são implementados pelo próprio sistema; "which comando" mostra a origem.\n`);
    return 0;
  },
};

const man: CommandDef = {
  name: 'man', summary: 'manual de um comando', usage: 'man comando', source: 'vos',
  run(ctx) {
    const name = ctx.args[0];
    if (!name) {
      ctx.stderr.write('Qual página de manual você quer? Ex.: man ls\n');
      return 1;
    }
    const c = COMMANDS.get(name);
    if (!c) {
      ctx.stderr.write(`Nenhuma entrada de manual para ${name}${UNAVAILABLE[name] ? ` (indisponível: ${UNAVAILABLE[name]})` : ''}\n`);
      return 16;
    }
    ctx.stdout.write(`${ANSI.bold}NOME${ANSI.reset}\n    ${c.name} - ${c.summary}\n\n${ANSI.bold}USO${ANSI.reset}\n    ${c.usage}\n\n`);
    if (c.manual) ctx.stdout.write(`${ANSI.bold}DESCRIÇÃO${ANSI.reset}\n${c.manual.split('\n').map((l) => '    ' + l).join('\n')}\n\n`);
    ctx.stdout.write(`${ANSI.bold}IMPLEMENTAÇÃO${ANSI.reset}\n    ${SOURCE_LABEL[c.source]}\n`);
    return 0;
  },
};

const which: CommandDef = {
  name: 'which', summary: 'mostra onde está um comando', usage: 'which [-a] comando...', source: 'vos',
  run(ctx) {
    let status = 0;
    for (const n of ctx.args.filter((a) => !a.startsWith('-'))) {
      if (COMMANDS.has(n)) ctx.stdout.write(`/bin/${n}\n`);
      else status = 1;
    }
    return status;
  },
};

const type: CommandDef = {
  name: 'type', summary: 'diz como um nome seria interpretado', usage: 'type nome...', source: 'vos',
  run(ctx) {
    let status = 0;
    for (const n of ctx.args) {
      const alias = ctx.shell.aliases.get(n);
      const c = COMMANDS.get(n);
      if (alias) ctx.stdout.write(`${n} é um alias para '${alias}'\n`);
      else if (c) ctx.stdout.write(`${n} é /bin/${n} — ${SOURCE_LABEL[c.source]}\n`);
      else if (UNAVAILABLE[n]) {
        ctx.stdout.write(`${n}: indisponível — ${UNAVAILABLE[n]}\n`);
        status = 1;
      } else {
        ctx.stderr.write(`type: ${n}: não encontrado\n`);
        status = 1;
      }
    }
    return status;
  },
};

for (const c of [...fsCommands, ...textCommands, ...systemCommands, ...netCommands, ...builtinCommands, ...lvpCommands, help, man, which, type]) {
  COMMANDS.set(c.name, c);
}

/**
 * Creates /bin/<cmd> stub files so the commands are visible in the file system
 * (ls /bin). Running a stub dispatches to the in-process implementation.
 */
export async function installBinStubs(vfs: VFS): Promise<void> {
  for (const name of COMMANDS.keys()) {
    if (!/^[a-z][\w-]*$/.test(name)) continue;
    const path = `/bin/${name}`;
    if (vfs.exists(path)) continue;
    await vfs.writeFile(path, `#!lvsh-builtin ${name}\n# ${COMMANDS.get(name)!.summary}\n`, { mode: 0o755 }, ROOT_CREDS);
  }
}
