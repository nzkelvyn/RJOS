import type { InstallPlan } from '../../packages/lvp';
import { PERMISSIONS } from '../../packages/manifest';
import { parseArgs } from '../args';
import { ANSI, type CommandContext, type CommandDef } from '../types';

const MUTATING = new Set(['install', 'remove', 'upgrade', 'autoremove', 'repository']);

async function confirmPlan(ctx: CommandContext, plan: InstallPlan, yes: boolean): Promise<boolean> {
  ctx.stdout.write('Os seguintes pacotes serão instalados/atualizados:\n');
  for (const s of plan.steps) {
    const m = s.manifest;
    ctx.stdout.write(`  ${ANSI.bold}${m.name}${ANSI.reset} ${s.upgradeFrom ? `${s.upgradeFrom} → ` : ''}${m.version}  [${s.repository}]${s.auto ? ` ${ANSI.dim}(dependência)${ANSI.reset}` : ''}\n`);
    for (const p of m.permissions) ctx.stdout.write(`      ${ANSI.yellow}permissão:${ANSI.reset} ${PERMISSIONS[p]}\n`);
  }
  if (yes) return true;
  const answer = await ctx.shell.host.prompt('Deseja continuar? [S/n] ');
  return answer !== null && (answer.trim() === '' || /^[sSyY]/.test(answer.trim()));
}

const lvp: CommandDef = {
  name: 'lvp',
  summary: 'Little Vitor Package Manager',
  usage: 'lvp install|remove|update|upgrade|search|list|info|verify|log|autoremove|repository ...',
  source: 'vos',
  manual: [
    'lvp install nome...        instala pacotes (e dependências) do repositório',
    'lvp install ./app.lvp      instala um pacote local (.lvp) após verificar o sha256',
    'lvp remove nome [--force]  remove um pacote',
    'lvp update                 atualiza os índices dos repositórios',
    'lvp upgrade                atualiza pacotes instalados',
    'lvp search termo           procura pacotes',
    'lvp list [--available]     lista instalados (ou disponíveis)',
    'lvp info nome              detalhes, versão, dependências, permissões',
    'lvp verify nome            confere integridade dos arquivos instalados',
    'lvp autoremove             remove dependências que não são mais usadas',
    'lvp log                    mostra o log de instalação',
    'lvp repository list|add NOME URL|remove NOME',
    '',
    'Operações que alteram o sistema exigem root: use "sudo lvp ...".',
    'Pacotes rodam isolados (iframe sandbox) e só acessam o que o manifesto declara.',
  ].join('\n'),
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'y', long: ['force', 'available', 'yes'] });
    const [sub, ...args] = rest;
    const pm = ctx.kernel.lvp;
    const yes = flags.has('y') || flags.has('yes');
    if (!sub || sub === 'help') {
      ctx.stdout.write(lvp.manual + '\n');
      return 0;
    }
    if (MUTATING.has(sub) && !(sub === 'repository' && (args[0] ?? 'list') === 'list') && ctx.creds.username !== 'root') {
      ctx.stderr.write(`lvp: ${sub}: permissão negada. Você é root? Tente: ${ANSI.bold}sudo lvp ${ctx.args.join(' ')}${ANSI.reset}\n`);
      return 100;
    }
    try {
      switch (sub) {
        case 'update': {
          for (const r of await pm.update()) {
            ctx.stdout.write(r.error ? `${ANSI.red}Erro${ANSI.reset} ${r.repo}: ${r.error}\n` : `Obtido ${r.repo}: ${r.packages} pacote(s)\n`);
          }
          const up = pm.upgradable();
          ctx.stdout.write(up.length ? `${up.length} pacote(s) podem ser atualizados. Rode "sudo lvp upgrade".\n` : 'Todos os pacotes estão atualizados.\n');
          return 0;
        }
        case 'install': {
          if (!args.length) throw new Error('informe o nome do pacote');
          const local = args.find((a) => a.endsWith('.lvp'));
          const manifest = local ? await pm.readLocal(ctx.shell.resolvePath(local)) : undefined;
          const names = args.map((a) => (a.endsWith('.lvp') && manifest ? manifest.name : a));
          const plan = await pm.install(names, { local: manifest, confirm: (p) => confirmPlan(ctx, p, yes) });
          if (!plan.steps.length) ctx.stdout.write('Nada a fazer: os pacotes já estão na versão mais recente.\n');
          else ctx.stdout.write(`${ANSI.green}✓${ANSI.reset} ${plan.steps.length} pacote(s) instalado(s). Eles já aparecem no menu de aplicativos.\n`);
          return 0;
        }
        case 'remove': {
          if (!args.length) throw new Error('informe o nome do pacote');
          for (const n of args) {
            await pm.remove(n, { force: flags.has('force') });
            ctx.stdout.write(`Removido ${n}\n`);
          }
          const orphans = pm.orphans();
          if (orphans.length) ctx.stdout.write(`${ANSI.dim}Dependências não usadas: ${orphans.join(', ')} (sudo lvp autoremove)${ANSI.reset}\n`);
          return 0;
        }
        case 'autoremove': {
          const removed = await pm.autoremove();
          ctx.stdout.write(removed.length ? `Removidos: ${removed.join(', ')}\n` : 'Nada para remover.\n');
          return 0;
        }
        case 'upgrade': {
          const plan = await pm.upgrade((p) => confirmPlan(ctx, p, yes));
          ctx.stdout.write(plan.steps.length ? `${plan.steps.length} pacote(s) atualizado(s).\n` : 'Todos os pacotes estão atualizados.\n');
          return 0;
        }
        case 'search': {
          const res = pm.search(args.join(' '));
          if (!res.length) ctx.stdout.write('Nenhum pacote encontrado.\n');
          for (const { manifest: m, repository } of res) {
            const inst = pm.getInstalled(m.name);
            ctx.stdout.write(`${ANSI.green}${m.name}${ANSI.reset}/${repository} ${m.version}${inst ? ` ${ANSI.cyan}[instalado ${inst.version}]${ANSI.reset}` : ''}\n  ${m.description}\n`);
          }
          return 0;
        }
        case 'list': {
          if (flags.has('available')) {
            for (const { manifest: m, repository } of pm.available()) ctx.stdout.write(`${m.name}/${repository} ${m.version}\n`);
            return 0;
          }
          const list = pm.installed.get();
          if (!list.length) ctx.stdout.write('Nenhum pacote instalado. Experimente: lvp search ""\n');
          for (const p of list) ctx.stdout.write(`${p.name}/${p.repository} ${p.version}${p.auto ? ' [automático]' : ''}\n`);
          return 0;
        }
        case 'info': {
          const name = args[0];
          if (!name) throw new Error('informe o nome do pacote');
          const inst = pm.getInstalled(name);
          const avail = pm.findAvailable(name);
          const m = avail?.manifest;
          if (!inst && !m) throw new Error(`pacote não encontrado: ${name}`);
          const row = (k: string, v: string) => ctx.stdout.write(`${ANSI.bold}${k.padEnd(14)}${ANSI.reset}${v}\n`);
          row('Pacote:', name);
          row('Nome:', inst?.displayName ?? m!.displayName);
          row('Instalado:', inst ? `${inst.version} (${new Date(inst.installedAt).toLocaleString()})` : 'não');
          row('Disponível:', m ? `${m.version} [${avail!.repository}]` : '—');
          row('Descrição:', inst?.description ?? m!.description);
          row('Categoria:', inst?.category ?? m!.category);
          if (m) row('Autor:', `${m.author} — licença ${m.license}`);
          const deps = inst?.dependencies ?? m!.dependencies;
          row('Dependências:', Object.entries(deps).map(([k, v]) => `${k} (${v})`).join(', ') || 'nenhuma');
          row('Permissões:', (inst?.permissions ?? m!.permissions).map((p) => PERMISSIONS[p]).join('; ') || 'nenhuma');
          row('SHA-256:', inst?.sha256 ?? m!.sha256);
          if (inst) row('Requerido por:', pm.dependents(name).join(', ') || 'ninguém');
          return 0;
        }
        case 'verify': {
          const names = args.length ? args : pm.installed.get().map((p) => p.name);
          let bad = 0;
          for (const n of names) {
            const ok = await pm.verify(n);
            if (!ok) bad++;
            ctx.stdout.write(`${n}: ${ok ? `${ANSI.green}OK${ANSI.reset}` : `${ANSI.red}FALHOU — arquivos alterados${ANSI.reset}`}\n`);
          }
          return bad ? 1 : 0;
        }
        case 'log': {
          ctx.stdout.write((await pm.logLines(Number(args[0] ?? 50))).join('\n') + '\n');
          return 0;
        }
        case 'repository': {
          const [action = 'list', name, url] = args;
          if (action === 'list') {
            for (const r of await pm.repositories()) ctx.stdout.write(`${r.enabled ? '✓' : '✗'} ${r.name.padEnd(12)} ${r.url}\n`);
            return 0;
          }
          if (action === 'add') {
            if (!name || !url) throw new Error('uso: lvp repository add NOME https://URL/index.json');
            await pm.addRepository(name, url);
            ctx.stdout.write(`Repositório ${name} adicionado. Rode "sudo lvp update".\n`);
            return 0;
          }
          if (action === 'remove') {
            await pm.removeRepository(name);
            ctx.stdout.write(`Repositório ${name} removido.\n`);
            return 0;
          }
          throw new Error(`ação desconhecida: ${action}`);
        }
        default:
          ctx.stderr.write(`lvp: comando desconhecido "${sub}". Veja "lvp help".\n`);
          return 1;
      }
    } catch (err) {
      ctx.stderr.write(`${ANSI.red}E:${ANSI.reset} ${(err as Error).message}\n`);
      return 100;
    }
  },
};

export const lvpCommands: CommandDef[] = [lvp];
