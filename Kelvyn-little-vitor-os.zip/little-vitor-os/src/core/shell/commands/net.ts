import { basename } from '../../vfs/path';
import { formatBytes, parseArgs } from '../args';
import { sleep } from './system';
import { ANSI, type CommandDef } from '../types';

const NOTE = `${ANSI.dim}(navegadores não enviam ICMP: medido com uma requisição HTTP real via fetch)${ANSI.reset}`;

const ping: CommandDef = {
  name: 'ping', summary: 'mede latência HTTP até um host (não ICMP)', usage: 'ping [-c N] [-i seg] host', source: 'browser',
  manual: 'Navegadores não podem enviar pacotes ICMP. Este ping faz requisições HTTPS HEAD reais\n(modo no-cors) e mede o tempo de ida e volta, incluindo DNS/TLS na primeira vez.',
  async run(ctx) {
    const { values, rest } = parseArgs(ctx.args, { value: 'ciW' });
    const host = rest[0];
    if (!host) {
      ctx.stderr.write('ping: destino de endereço necessário\n');
      return 2;
    }
    const count = values.c ? Number(values.c) : 4;
    const interval = values.i ? Number(values.i) * 1000 : 1000;
    ctx.stdout.write(`PING ${host} ${NOTE}\n`);
    const times: number[] = [];
    let sent = 0;
    try {
      for (let i = 0; i < count; i++) {
        sent++;
        const r = await ctx.kernel.net.httpPing(host, values.W ? Number(values.W) * 1000 : 5000);
        if (ctx.signal.aborted) break;
        if (r.ok) {
          times.push(r.ms);
          ctx.stdout.write(`resposta de ${host}: seq=${i + 1} tempo=${r.ms.toFixed(1)} ms\n`);
        } else ctx.stdout.write(`${host}: seq=${i + 1} falhou (${r.error})\n`);
        if (i < count - 1) await sleep(interval, ctx.signal);
      }
    } catch {
      /* Ctrl+C: still print statistics, like real ping */
    }
    const loss = sent ? Math.round(((sent - times.length) / sent) * 100) : 0;
    ctx.stdout.write(`\n--- estatísticas de ${host} ---\n${sent} enviados, ${times.length} recebidos, ${loss}% de perda\n`);
    if (times.length) {
      const avg = times.reduce((a, b) => a + b, 0) / times.length;
      ctx.stdout.write(`rtt mín/méd/máx = ${Math.min(...times).toFixed(1)}/${avg.toFixed(1)}/${Math.max(...times).toFixed(1)} ms\n`);
    }
    return times.length ? 0 : 1;
  },
};

const CORS_HINT = `${ANSI.yellow}dica:${ANSI.reset} o navegador bloqueia respostas de sites que não liberam CORS. Isso é uma regra de segurança do navegador, não um erro do comando.`;

const curl: CommandDef = {
  name: 'curl', summary: 'faz requisições HTTP reais (sujeito a CORS)', usage: 'curl [-sIiL] [-X MÉTODO] [-H "Cab: v"] [-d dados] [-o arquivo] url', source: 'browser',
  async run(ctx) {
    let p;
    try {
      p = parseArgs(ctx.args, { bool: 'sSIiLfvk', value: 'XHdoA', longValue: ['header', 'data', 'request', 'output'], long: ['silent', 'head', 'include'] });
    } catch (err) {
      ctx.stderr.write(`curl: ${(err as Error).message}\n`);
      return 2;
    }
    const { flags, values, rest } = p;
    const url = rest[0];
    if (!url) {
      ctx.stderr.write('curl: nenhuma URL especificada\n');
      return 2;
    }
    const head = flags.has('I') || flags.has('head');
    const method = values.X ?? values.request ?? (head ? 'HEAD' : values.d || values.data ? 'POST' : 'GET');
    const headers: Record<string, string> = {};
    for (const h of [values.H, values.header].filter(Boolean) as string[]) {
      const idx = h.indexOf(':');
      if (idx > 0) headers[h.slice(0, idx).trim()] = h.slice(idx + 1).trim();
    }
    try {
      const res = await ctx.kernel.net.fetchText(url, { method, headers, body: values.d ?? values.data, signal: ctx.signal });
      if (head || flags.has('i') || flags.has('include')) {
        ctx.stdout.write(`HTTP ${res.status} ${res.statusText}\n`);
        for (const [k, v] of res.headers) ctx.stdout.write(`${k}: ${v}\n`);
        ctx.stdout.write('\n');
      }
      if (!head) {
        const out = values.o ?? values.output;
        if (out) {
          await ctx.kernel.vfs.writeFile(ctx.shell.resolvePath(out), res.body, {}, ctx.creds);
          if (!flags.has('s')) ctx.stderr.write(`${formatBytes(res.body.byteLength)} salvos em ${out}\n`);
        } else ctx.stdout.write(new TextDecoder().decode(res.body));
        if (res.truncated) ctx.stderr.write('\ncurl: resposta truncada em 2 MB\n');
      }
      return flags.has('f') && res.status >= 400 ? 22 : 0;
    } catch (err) {
      if (ctx.signal.aborted) return 130;
      ctx.stderr.write(`curl: falha na requisição: ${(err as Error).message}\n${CORS_HINT}\n`);
      return 7;
    }
  },
};

const wget: CommandDef = {
  name: 'wget', summary: 'baixa um arquivo da web para o VFS (sujeito a CORS)', usage: 'wget [-O arquivo] [-q] url', source: 'browser',
  async run(ctx) {
    const { flags, values, rest } = parseArgs(ctx.args, { bool: 'q', value: 'O' });
    const url = rest[0];
    if (!url) {
      ctx.stderr.write('wget: URL faltando\n');
      return 1;
    }
    const name = values.O ?? (basename(new URL(url.includes('://') ? url : 'https://' + url).pathname) || 'index.html');
    if (!flags.has('q')) ctx.stdout.write(`--${new Date().toISOString().replace('T', ' ').slice(0, 19)}--  ${url}\n`);
    try {
      const res = await ctx.kernel.net.fetchText(url, { signal: ctx.signal }, 200 * 1024 * 1024);
      if (res.status >= 400) {
        ctx.stderr.write(`ERRO ${res.status}: ${res.statusText}\n`);
        return 8;
      }
      const target = ctx.shell.resolvePath(name);
      await ctx.kernel.vfs.writeFile(target, res.body, {}, ctx.creds);
      if (!flags.has('q')) ctx.stdout.write(`Salvando em: '${name}'  [${formatBytes(res.body.byteLength)}]\n`);
      return 0;
    } catch (err) {
      if (ctx.signal.aborted) return 130;
      ctx.stderr.write(`wget: falha: ${(err as Error).message}\n${CORS_HINT}\n`);
      return 4;
    }
  },
};

const ip: CommandDef = {
  name: 'ip', summary: 'mostra interfaces de rede (virtuais)', usage: 'ip [a|addr|link|route]', source: 'vos',
  run(ctx) {
    const sub = ctx.args[0] ?? 'addr';
    const net = ctx.kernel.net;
    const info = net.info.get();
    if (['a', 'addr', 'address', 'link', 'l'].includes(sub)) {
      net.interfaces().forEach((i, idx) => {
        ctx.stdout.write(`${idx + 1}: ${i.name}: <${i.name === 'lo' ? 'LOOPBACK,' : ''}${i.state === 'UP' ? 'UP,LOWER_UP' : 'DOWN'}> estado ${i.state}\n    link/ether ${i.mac}\n`);
        if (!sub.startsWith('l')) ctx.stdout.write(`    inet ${i.ipv4}\n`);
      });
      ctx.stdout.write(`${ANSI.dim}Interfaces virtuais: o navegador não expõe as interfaces reais do computador.\nConectividade real: ${info.online ? 'online' : 'offline'}${info.effectiveType ? `, tipo ${info.effectiveType}, ~${info.downlinkMbps} Mbps, rtt ~${info.rttMs} ms (Network Information API)` : ''}${ANSI.reset}\n`);
      return 0;
    }
    if (sub === 'r' || sub === 'route') {
      ctx.stdout.write('default via 10.0.2.2 dev lv0 (virtual)\n10.0.2.0/24 dev lv0 proto kernel scope link src 10.0.2.15 (virtual)\n');
      return 0;
    }
    ctx.stderr.write(`ip: objeto "${sub}" desconhecido; use addr, link ou route\n`);
    return 1;
  },
};

const netstat: CommandDef = {
  name: 'netstat', summary: 'conexões de rede', usage: 'netstat', source: 'vos',
  run(ctx) {
    const s = ctx.kernel.settings.user.get();
    ctx.stdout.write(`${ANSI.yellow}netstat: o navegador não expõe sockets nem portas, então não há tabela real de conexões.${ANSI.reset}\n`);
    ctx.stdout.write(`Conexões gerenciadas pelo Little Vitor OS:\n`);
    ctx.stdout.write(`  sincronização (WebSocket): ${s.syncEnabled && s.syncServer ? `configurada para ${s.syncServer}` : 'desativada'}\n`);
    ctx.stdout.write(`  rede do navegador: ${ctx.kernel.net.info.get().online ? 'online' : 'offline'}\n`);
    return 0;
  },
};

export const netCommands: CommandDef[] = [ping, curl, wget, ip, netstat];
