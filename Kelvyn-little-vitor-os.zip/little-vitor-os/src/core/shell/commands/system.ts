import { KERNEL_RELEASE, OS_NAME, OS_VERSION, memoryInfo } from '../../../kernel/info';
import { SIGNALS } from '../../process/processManager';
import { formatBytes, formatDuration, humanSize, parseArgs } from '../args';
import { ANSI, type CommandContext, type CommandDef } from '../types';

const WEEKDAYS = ['Do', 'Se', 'Te', 'Qu', 'Qu', 'Se', 'Sá'];
const MONTH_NAMES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

const whoami: CommandDef = {
  name: 'whoami', summary: 'mostra o usuário atual', usage: 'whoami', source: 'vos',
  run(ctx) {
    ctx.stdout.write(ctx.creds.username + '\n');
    return 0;
  },
};

const id: CommandDef = {
  name: 'id', summary: 'mostra identificadores do usuário', usage: 'id [usuário]', source: 'vos',
  async run(ctx) {
    const name = ctx.args[0] ?? ctx.creds.username;
    const u = await ctx.kernel.users.get(name);
    if (!u) {
      ctx.stderr.write(`id: '${name}': usuário inexistente\n`);
      return 1;
    }
    const groups = name === ctx.creds.username ? ctx.creds.groups : u.groups;
    ctx.stdout.write(`uid=${u.uid}(${u.username}) gid=${u.gid}(${groups[0] ?? u.username}) grupos=${groups.join(',')}\n`);
    return 0;
  },
};

const groups: CommandDef = {
  name: 'groups', summary: 'mostra os grupos do usuário', usage: 'groups [usuário]', source: 'vos',
  async run(ctx) {
    const u = ctx.args[0] ? await ctx.kernel.users.get(ctx.args[0]) : null;
    ctx.stdout.write((u ? u.groups : ctx.creds.groups).join(' ') + '\n');
    return 0;
  },
};

const hostname: CommandDef = {
  name: 'hostname', summary: 'mostra ou altera o nome da máquina', usage: 'hostname [novo-nome]', source: 'vos',
  async run(ctx) {
    if (ctx.args[0]) {
      if (ctx.creds.username !== 'root') {
        ctx.stderr.write('hostname: você precisa ser root para alterar o nome (use sudo)\n');
        return 1;
      }
      if (!/^[a-zA-Z0-9-]{1,63}$/.test(ctx.args[0])) {
        ctx.stderr.write('hostname: nome inválido\n');
        return 1;
      }
      await ctx.kernel.settings.saveSystem({ hostname: ctx.args[0] });
      await ctx.kernel.vfs.writeFile('/etc/hostname', ctx.args[0] + '\n', {}, ctx.creds);
      ctx.shell.env.set('HOSTNAME', ctx.args[0]);
      return 0;
    }
    ctx.stdout.write(ctx.kernel.settings.system.get().hostname + '\n');
    return 0;
  },
};

const uname: CommandDef = {
  name: 'uname', summary: 'informações do sistema', usage: 'uname [-asnrmo]', source: 'vos',
  run(ctx) {
    const { flags } = parseArgs(ctx.args, { bool: 'asnrvmo' });
    const arch = typeof navigator !== 'undefined' && /arm|aarch/i.test(navigator.userAgent) ? 'arm64' : 'wasm-host';
    const parts: string[] = [];
    const all = flags.has('a');
    if (all || flags.has('s') || flags.size === 0) parts.push('LittleVitor');
    if (all || flags.has('n')) parts.push(ctx.kernel.settings.system.get().hostname);
    if (all || flags.has('r')) parts.push(KERNEL_RELEASE);
    if (all || flags.has('v')) parts.push(`#1 ${OS_NAME} ${OS_VERSION}`);
    if (all || flags.has('m')) parts.push(arch);
    if (all || flags.has('o')) parts.push('Web/Browser');
    ctx.stdout.write(parts.join(' ') + '\n');
    return 0;
  },
};

function strftime(fmt: string, d: Date, utc: boolean): string {
  const g = (local: () => number, u: () => number) => (utc ? u() : local());
  const Y = g(() => d.getFullYear(), () => d.getUTCFullYear());
  const m = g(() => d.getMonth(), () => d.getUTCMonth());
  const day = g(() => d.getDate(), () => d.getUTCDate());
  const H = g(() => d.getHours(), () => d.getUTCHours());
  const M = g(() => d.getMinutes(), () => d.getUTCMinutes());
  const S = g(() => d.getSeconds(), () => d.getUTCSeconds());
  const wd = g(() => d.getDay(), () => d.getUTCDay());
  const p = (n: number, w = 2) => String(n).padStart(w, '0');
  const days = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
  const map: Record<string, string> = {
    Y: String(Y), y: p(Y % 100), m: p(m + 1), d: p(day), e: String(day).padStart(2), H: p(H), M: p(M), S: p(S),
    A: days[wd], a: days[wd].slice(0, 3), B: MONTH_NAMES[m], b: MONTH_NAMES[m].slice(0, 3), j: p(Math.floor((Date.UTC(Y, m, day) - Date.UTC(Y, 0, 0)) / 864e5), 3),
    s: String(Math.floor(d.getTime() / 1000)), F: `${Y}-${p(m + 1)}-${p(day)}`, T: `${p(H)}:${p(M)}:${p(S)}`,
    Z: utc ? 'UTC' : Intl.DateTimeFormat().resolvedOptions().timeZone, n: '\n', t: '\t', '%': '%',
  };
  return fmt.replace(/%([a-zA-Z%])/g, (all, k) => map[k] ?? all);
}

const date: CommandDef = {
  name: 'date', summary: 'mostra data e hora', usage: 'date [-u] [+FORMATO]', source: 'vos',
  manual: 'Formatos: %Y ano %m mês %d dia %H hora %M minuto %S segundo %A dia da semana %B mês por extenso\n%F = %Y-%m-%d  %T = %H:%M:%S  %s segundos desde 1970  %Z fuso',
  run(ctx) {
    const utc = ctx.args.includes('-u');
    const fmt = ctx.args.find((a) => a.startsWith('+'));
    const now = new Date();
    ctx.stdout.write((fmt ? strftime(fmt.slice(1), now, utc) : strftime('%a %e %b %Y %T %Z', now, utc)) + '\n');
    return 0;
  },
};

function calMonth(year: number, month: number, today?: Date): string[] {
  const title = `${MONTH_NAMES[month]} ${year}`;
  const out = [title.padStart(Math.floor((20 + title.length) / 2)).padEnd(20), WEEKDAYS.join(' ')];
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  let line = '   '.repeat(first);
  for (let d = 1; d <= days; d++) {
    const isToday = today && today.getFullYear() === year && today.getMonth() === month && today.getDate() === d;
    const cell = String(d).padStart(2);
    line += (isToday ? `\x1b[7m${cell}\x1b[0m` : cell) + ' ';
    if ((first + d) % 7 === 0) {
      out.push(line.trimEnd());
      line = '';
    }
  }
  if (line.trim()) out.push(line.trimEnd());
  return out;
}

const cal: CommandDef = {
  name: 'cal', summary: 'mostra um calendário', usage: 'cal [[mês] ano]', source: 'vos',
  run(ctx) {
    const now = new Date();
    const n = ctx.args.map(Number);
    if (n.some((x) => Number.isNaN(x))) {
      ctx.stderr.write('cal: argumento inválido\n');
      return 1;
    }
    const today = ctx.interactive ? now : undefined;
    if (n.length === 1) {
      const year = n[0];
      for (let q = 0; q < 12; q += 3) {
        const blocks = [0, 1, 2].map((i) => calMonth(year, q + i, today));
        const h = Math.max(...blocks.map((b) => b.length));
        for (let r = 0; r < h; r++) {
          ctx.stdout.write(blocks.map((b) => (b[r] ?? '').padEnd(b[r]?.includes('\x1b') ? 28 : 20)).join('  ') + '\n');
        }
        ctx.stdout.write('\n');
      }
      return 0;
    }
    const [month, year] = n.length === 2 ? [n[0] - 1, n[1]] : [now.getMonth(), now.getFullYear()];
    if (month < 0 || month > 11) {
      ctx.stderr.write('cal: mês inválido\n');
      return 1;
    }
    ctx.stdout.write(calMonth(year, month, today).join('\n') + '\n');
    return 0;
  },
};

const uptime: CommandDef = {
  name: 'uptime', summary: 'tempo desde que o sistema iniciou nesta aba', usage: 'uptime', source: 'vos',
  run(ctx) {
    const now = new Date();
    ctx.stdout.write(` ${now.toTimeString().slice(0, 8)} ativo há ${formatDuration(ctx.kernel.procs.uptimeMs())},  1 usuário,  carga média: indisponível no navegador\n`);
    return 0;
  },
};

const STAT: Record<string, string> = { running: 'R', sleeping: 'S', stopped: 'T' };

function psTable(ctx: CommandContext, all: boolean): string {
  const procs = ctx.kernel.procs.list().filter((p) => all || p.user === ctx.creds.username);
  const rows = procs.map((p) => [
    p.user, String(p.pid), String(p.ppid), STAT[p.state] + (p.kind === 'system' ? 's' : ''),
    new Date(p.startedAt).toTimeString().slice(0, 5),
    p.cpuTimeMs === null ? '—' : `${(p.cpuTimeMs / 1000).toFixed(2)}s`, p.kind, p.command,
  ]);
  const head = ['USUÁRIO', 'PID', 'PPID', 'STAT', 'INÍCIO', 'TEMPO', 'TIPO', 'COMANDO'];
  const widths = head.map((h, i) => Math.max(h.length, ...rows.map((r) => r[i].length)));
  const fmt = (r: string[]) => r.map((c, i) => (i === r.length - 1 ? c : i === 1 || i === 2 ? c.padStart(widths[i]) : c.padEnd(widths[i]))).join('  ');
  return [fmt(head), ...rows.map(fmt)].join('\n') + '\n';
}

const ps: CommandDef = {
  name: 'ps', summary: 'lista processos virtuais', usage: 'ps [aux | -e]', source: 'vos',
  manual: 'Processos do Little Vitor OS: janelas de apps, comandos do terminal e serviços do sistema.\nSão processos virtuais que compartilham a mesma aba do navegador (não são processos do SO real).\nTEMPO = tempo de execução medido do comando; "—" quando não mensurável.',
  run(ctx) {
    const all = ctx.args.some((a) => /a|e/.test(a));
    ctx.stdout.write(psTable(ctx, all));
    return 0;
  },
};

/** Measures real event-loop lag (how late a 0ms timer fires) — a genuine responsiveness metric. */
function eventLoopLag(): Promise<number> {
  const start = performance.now();
  return new Promise((r) => setTimeout(() => r(performance.now() - start), 0));
}

const top: CommandDef = {
  name: 'top', summary: 'monitor de processos ao vivo (q para sair)', usage: 'top [-b] [-n iterações]', source: 'vos',
  async run(ctx) {
    const { flags, values } = parseArgs(ctx.args, { bool: 'b', value: 'nd' });
    const iterations = values.n ? Number(values.n) : flags.has('b') || !ctx.interactive ? 1 : Infinity;
    const host = ctx.shell.host;
    const snapshot = async () => {
      const lag = await eventLoopLag();
      const mem = memoryInfo();
      const procs = ctx.kernel.procs.list();
      const count = (s: string) => procs.filter((p) => p.state === s).length;
      const lines = [
        `${ANSI.bold}top${ANSI.reset} - ${new Date().toTimeString().slice(0, 8)} ativo há ${formatDuration(ctx.kernel.procs.uptimeMs())}`,
        `Tarefas: ${procs.length} total, ${count('running')} executando, ${count('stopped')} paradas`,
        `Atraso do event loop: ${lag.toFixed(1)} ms ${ANSI.dim}(medição real)${ANSI.reset}    %CPU por processo: ${ANSI.dim}não mensurável no navegador${ANSI.reset}`,
        mem
          ? `Heap JS: ${formatBytes(mem.used)} usados / ${formatBytes(mem.total)} alocados / limite ${formatBytes(mem.limit)} ${ANSI.dim}(real, Chromium)${ANSI.reset}`
          : `Memória: ${ANSI.dim}este navegador não expõe medição de memória${ANSI.reset}`,
        '',
        psTable(ctx, true).trimEnd(),
      ];
      return lines.join('\n');
    };
    if (iterations === Infinity && host.setFullscreen && host.readKey) {
      const ac = new AbortController();
      ctx.signal.addEventListener('abort', () => ac.abort());
      const keyLoop = (async () => {
        while (!ac.signal.aborted) {
          const k = await host.readKey!(ac.signal);
          if (k === 'q' || k === 'Q' || k === 'Escape') ac.abort();
        }
      })().catch(() => undefined);
      try {
        while (!ac.signal.aborted) {
          host.setFullscreen((await snapshot()) + `\n\n${ANSI.dim}Pressione q para sair${ANSI.reset}`);
          await sleep(Number(values.d ?? 1) * 1000, ac.signal).catch(() => undefined);
        }
      } finally {
        host.setFullscreen(null);
        ac.abort();
        await keyLoop;
      }
      return 0;
    }
    for (let i = 0; i < iterations; i++) {
      ctx.stdout.write((await snapshot()) + '\n');
      if (i < iterations - 1) await sleep(Number(values.d ?? 1) * 1000, ctx.signal);
    }
    return 0;
  },
};

const free: CommandDef = {
  name: 'free', summary: 'uso de memória do ambiente', usage: 'free [-h]', source: 'vos',
  async run(ctx) {
    const h = ctx.args.includes('-h');
    const fmt = (n: number) => (h ? humanSize(n) : String(Math.round(n / 1024)));
    const mem = memoryInfo();
    if (mem) {
      ctx.stdout.write(`              total       usada       livre\n`);
      ctx.stdout.write(`Heap JS: ${fmt(mem.limit).padStart(11)} ${fmt(mem.used).padStart(11)} ${fmt(mem.limit - mem.used).padStart(11)}\n`);
      ctx.stdout.write(`${ANSI.dim}Valores reais do heap JavaScript desta aba (performance.memory). A RAM do computador não é exposta ao navegador.${ANSI.reset}\n`);
    } else {
      ctx.stdout.write('free: este navegador não informa uso de memória (performance.memory existe apenas no Chromium).\n');
    }
    const dm = (navigator as unknown as { deviceMemory?: number }).deviceMemory;
    if (dm) ctx.stdout.write(`Memória aproximada do dispositivo (navigator.deviceMemory, arredondada): ${dm} GB\n`);
    return 0;
  },
};

const kill: CommandDef = {
  name: 'kill', summary: 'envia sinal a processos', usage: 'kill [-SINAL] pid|%job...   (sinais: TERM, KILL, INT, STOP, CONT; kill -l)', source: 'vos',
  run(ctx) {
    const args = [...ctx.args];
    if (args[0] === '-l') {
      ctx.stdout.write(' 2) SIGINT   9) SIGKILL  15) SIGTERM  18) SIGCONT  19) SIGSTOP\n');
      return 0;
    }
    let signal = SIGNALS['TERM'];
    if (args[0]?.startsWith('-')) {
      const s = SIGNALS[args.shift()!.slice(1).toUpperCase()];
      if (!s) {
        ctx.stderr.write('kill: sinal inválido (use kill -l)\n');
        return 1;
      }
      signal = s;
    }
    if (!args.length) {
      ctx.stderr.write(`uso: ${kill.usage}\n`);
      return 1;
    }
    let status = 0;
    for (const a of args) {
      if (a.startsWith('%')) {
        const job = ctx.shell.jobs.find((j) => j.id === Number(a.slice(1)));
        if (!job || job.status === 'done') {
          ctx.stderr.write(`kill: ${a}: job inexistente\n`);
          status = 1;
          continue;
        }
        job.controller.abort();
        continue;
      }
      const err = ctx.kernel.procs.kill(Number(a), signal, ctx.creds.username);
      if (err) {
        ctx.stderr.write(err + '\n');
        status = 1;
      }
    }
    return status;
  },
};

const jobs: CommandDef = {
  name: 'jobs', summary: 'lista tarefas em segundo plano', usage: 'jobs', source: 'vos',
  run(ctx) {
    for (const j of ctx.shell.jobs) {
      ctx.stdout.write(`[${j.id}]  ${j.status === 'done' ? `Concluído(${j.exitCode})` : 'Executando'}\t${j.command}\n`);
    }
    ctx.shell.removeFinishedJobs();
    return 0;
  },
};

const fg: CommandDef = {
  name: 'fg', summary: 'traz um job para o primeiro plano (espera terminar)', usage: 'fg [%job]', source: 'vos',
  async run(ctx) {
    const id = ctx.args[0] ? Number(ctx.args[0].replace('%', '')) : ctx.shell.jobs.filter((j) => j.status !== 'done').pop()?.id;
    const job = ctx.shell.jobs.find((j) => j.id === id);
    if (!job) {
      ctx.stderr.write('fg: job atual inexistente\n');
      return 1;
    }
    ctx.stdout.write(job.command + '\n');
    const onAbort = () => job.controller.abort();
    ctx.signal.addEventListener('abort', onAbort);
    const code = await job.promise;
    ctx.signal.removeEventListener('abort', onAbort);
    ctx.shell.removeFinishedJobs();
    return code;
  },
};

export function sleep(ms: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) return reject(new Error('interrompido'));
    const t = setTimeout(() => {
      signal.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(t);
      reject(new Error('interrompido'));
    };
    signal.addEventListener('abort', onAbort, { once: true });
  });
}

const sleepCmd: CommandDef = {
  name: 'sleep', summary: 'espera N segundos', usage: 'sleep segundos', source: 'vos',
  async run(ctx) {
    const s = parseFloat(ctx.args[0] ?? '');
    if (Number.isNaN(s) || s < 0) {
      ctx.stderr.write('sleep: intervalo de tempo inválido\n');
      return 1;
    }
    await sleep(s * 1000, ctx.signal);
    return 0;
  },
};

const neofetch: CommandDef = {
  name: 'neofetch', summary: 'resumo do sistema com logo', usage: 'neofetch', source: 'vos',
  async run(ctx) {
    const k = ctx.kernel;
    const u = k.users.current;
    const host = k.settings.system.get().hostname;
    const st = k.vfs.stats();
    const est = await k.vfs.estimate();
    const mem = memoryInfo();
    const c = ANSI.magenta;
    const r = ANSI.reset;
    const logo = [
      `${c}   ██╗    ██╗   ██╗${r}`,
      `${c}   ██║    ██║   ██║${r}`,
      `${c}   ██║    ██║   ██║${r}`,
      `${c}   ██║    ╚██╗ ██╔╝${r}`,
      `${c}   ███████╗╚████╔╝ ${r}`,
      `${c}   ╚══════╝ ╚═══╝  ${r}`,
      '',
      '',
      '',
    ];
    const ua = typeof navigator !== 'undefined' ? navigator.userAgent : 'node';
    const browser = /Firefox\/(\S+)/.exec(ua)?.[0] ?? /Edg\/(\S+)/.exec(ua)?.[0] ?? /Chrome\/(\S+)/.exec(ua)?.[0] ?? /Safari\/(\S+)/.exec(ua)?.[0] ?? 'desconhecido';
    const info = [
      `${c}${ANSI.bold}${u?.username ?? ctx.creds.username}${r}@${c}${ANSI.bold}${host}${r}`,
      '─'.repeat((u?.username.length ?? 4) + host.length + 1),
      `${c}SO${r}: ${OS_NAME} ${OS_VERSION}`,
      `${c}Kernel${r}: ${KERNEL_RELEASE}`,
      `${c}Ativo há${r}: ${formatDuration(k.procs.uptimeMs())}`,
      `${c}Pacotes${r}: ${k.lvp.installed.get().length} (lvp)`,
      `${c}Shell${r}: lvsh`,
      `${c}Navegador${r}: ${browser.replace('/', ' ')}`,
      `${c}CPU${r}: ${navigator.hardwareConcurrency ?? '?'} núcleos lógicos`,
      `${c}Memória${r}: ${mem ? `${formatBytes(mem.used)} / ${formatBytes(mem.limit)} (heap JS)` : 'não exposta pelo navegador'}`,
      `${c}Disco${r}: ${formatBytes(st.bytes)} em ${st.files} arquivos${est.quota ? ` (cota ${formatBytes(est.quota)})` : ''}`,
    ];
    const n = Math.max(logo.length, info.length);
    for (let i = 0; i < n; i++) ctx.stdout.write(`${(logo[i] ?? '').padEnd(logo[i]?.includes('\x1b') ? 30 : 21)}  ${info[i] ?? ''}\n`);
    return 0;
  },
};

const trueCmd: CommandDef = { name: 'true', summary: 'retorna sucesso', usage: 'true', source: 'vos', run: () => 0 };
const falseCmd: CommandDef = { name: 'false', summary: 'retorna falha', usage: 'false', source: 'vos', run: () => 1 };

export const systemCommands: CommandDef[] = [
  whoami, id, groups, hostname, uname, date, cal, uptime, ps, top, free, kill, jobs, fg, sleepCmd, neofetch, trueCmd, falseCmd,
];
export { MONTH_NAMES, strftime };
