import { basename as bn, dirname as dn } from '../../vfs/path';
import { parseArgs } from '../args';
import { ANSI, type CommandContext, type CommandDef } from '../types';

/** Reads named files (or stdin when none) and returns [label, text] pairs. */
async function inputs(ctx: CommandContext, files: string[]): Promise<{ items: [string, string][]; status: number }> {
  if (!files.length) return { items: [['(entrada padrão)', ctx.stdin.read()]], status: 0 };
  const items: [string, string][] = [];
  let status = 0;
  for (const f of files) {
    if (f === '-') {
      items.push(['(entrada padrão)', ctx.stdin.read()]);
      continue;
    }
    try {
      items.push([f, await ctx.kernel.vfs.readText(ctx.shell.resolvePath(f), ctx.creds)]);
    } catch (err) {
      ctx.stderr.write(`${ctx.name}: ${f}: ${(err as Error).message.split(': ').pop()}\n`);
      status = 1;
    }
  }
  return { items, status };
}

function lines(text: string): string[] {
  const l = text.split('\n');
  if (l[l.length - 1] === '') l.pop();
  return l;
}

const echo: CommandDef = {
  name: 'echo', summary: 'mostra uma linha de texto', usage: 'echo [-n] [-e] texto...', source: 'vos',
  run(ctx) {
    let args = ctx.args;
    let newline = true;
    let escapes = false;
    while (args[0] && /^-[neE]+$/.test(args[0])) {
      if (args[0].includes('n')) newline = false;
      if (args[0].includes('e')) escapes = true;
      args = args.slice(1);
    }
    let text = args.join(' ');
    if (escapes) {
      text = text.replace(/\\(n|t|\\|e|a|0)/g, (_m, c) => ({ n: '\n', t: '\t', '\\': '\\', e: '\x1b', a: '', '0': '' })[c as string]!);
    }
    ctx.stdout.write(text + (newline ? '\n' : ''));
    return 0;
  },
};

const grep: CommandDef = {
  name: 'grep', summary: 'procura padrões em texto', usage: 'grep [-invcrlEwo] padrão [arquivo...]', source: 'vos',
  manual: 'O padrão é uma expressão regular (sintaxe JavaScript, equivalente a grep -E).\n-i ignora maiúsc./minúsc.  -n numera linhas  -v inverte  -c conta  -l só nomes de arquivo\n-r recursivo  -w palavra inteira  -o só a parte que casou  -F padrão literal',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'invcrlEwoFRHh', long: ['color'] });
    if (!rest.length) {
      ctx.stderr.write(`uso: ${grep.usage}\n`);
      return 2;
    }
    const pattern = rest.shift()!;
    let src = flags.has('F') ? pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') : pattern;
    if (flags.has('w')) src = `\\b(?:${src})\\b`;
    let re: RegExp;
    try {
      re = new RegExp(src, flags.has('i') ? 'gi' : 'g');
    } catch {
      ctx.stderr.write(`grep: expressão regular inválida: ${pattern}\n`);
      return 2;
    }
    let files = rest;
    if (flags.has('r') || flags.has('R')) {
      const roots = files.length ? files : ['.'];
      files = [];
      for (const r of roots) {
        const abs = ctx.shell.resolvePath(r);
        if (!ctx.kernel.vfs.isDir(abs)) files.push(r);
        else for (const e of ctx.kernel.vfs.find(abs, (e) => e.node.type === 'file', ctx.creds)) files.push(r.replace(/\/$/, '') + e.path.slice(abs.length));
      }
    }
    const { items, status } = await inputs(ctx, files);
    const multi = (items.length > 1 || flags.has('r')) && !flags.has('h');
    const color = ctx.interactive;
    let found = false;
    for (const [label, text] of items) {
      if (text.includes('\0')) continue; // skip binary
      let count = 0;
      lines(text).forEach((line, i) => {
        re.lastIndex = 0;
        const hit = re.test(line);
        if (hit === flags.has('v')) return;
        count++;
        found = true;
        if (flags.has('c') || flags.has('l')) return;
        const prefix = (multi ? (color ? `${ANSI.magenta}${label}${ANSI.reset}:` : `${label}:`) : '') + (flags.has('n') ? (color ? `${ANSI.green}${i + 1}${ANSI.reset}:` : `${i + 1}:`) : '');
        if (flags.has('o') && !flags.has('v')) {
          for (const m of line.matchAll(re)) ctx.stdout.write(prefix + m[0] + '\n');
          return;
        }
        const shown = color && !flags.has('v') ? line.replace(re, (m) => `${ANSI.bold}${ANSI.red}${m}${ANSI.reset}`) : line;
        ctx.stdout.write(prefix + shown + '\n');
      });
      if (flags.has('c')) ctx.stdout.write((multi ? `${label}:` : '') + count + '\n');
      if (flags.has('l') && count) ctx.stdout.write(label + '\n');
    }
    return status ? 2 : found ? 0 : 1;
  },
};

function headTail(which: 'head' | 'tail'): CommandDef {
  return {
    name: which,
    summary: which === 'head' ? 'mostra o início de arquivos' : 'mostra o final de arquivos',
    usage: `${which} [-n N] [-c N] [arquivo...]`,
    source: 'vos',
    async run(ctx) {
      // accept the old "-5" syntax
      const args = ctx.args.map((a) => (/^-\d+$/.test(a) ? `-n${a.slice(1)}` : a));
      const { flags, values, rest } = parseArgs(args, { bool: 'qvf', value: 'nc' });
      if (flags.has('f')) {
        ctx.stderr.write(`${which}: -f (acompanhar arquivo) não é suportado; use o Monitor do Sistema para eventos ao vivo\n`);
        return 1;
      }
      const n = Number(values.n ?? 10);
      const { items, status } = await inputs(ctx, rest);
      items.forEach(([label, text], idx) => {
        if (items.length > 1) ctx.stdout.write(`${idx ? '\n' : ''}==> ${label} <==\n`);
        if (values.c) {
          const c = Number(values.c);
          ctx.stdout.write(which === 'head' ? text.slice(0, c) : text.slice(-c));
          return;
        }
        const l = lines(text);
        const sel = which === 'head' ? l.slice(0, n) : l.slice(Math.max(0, l.length - n));
        if (sel.length) ctx.stdout.write(sel.join('\n') + '\n');
      });
      return status;
    },
  };
}

const wc: CommandDef = {
  name: 'wc', summary: 'conta linhas, palavras e bytes', usage: 'wc [-lwc] [arquivo...]', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'lwcm' });
    const all = !flags.has('l') && !flags.has('w') && !flags.has('c') && !flags.has('m');
    const { items, status } = await inputs(ctx, rest);
    const tot = [0, 0, 0];
    const row = (l: number, w: number, c: number, label: string) => {
      const cols = [];
      if (all || flags.has('l')) cols.push(String(l).padStart(7));
      if (all || flags.has('w')) cols.push(String(w).padStart(7));
      if (all || flags.has('c') || flags.has('m')) cols.push(String(c).padStart(7));
      ctx.stdout.write(cols.join(' ') + (rest.length ? ' ' + label : '') + '\n');
    };
    for (const [label, text] of items) {
      const l = (text.match(/\n/g) ?? []).length;
      const w = text.split(/\s+/).filter(Boolean).length;
      const c = flags.has('m') ? [...text].length : new TextEncoder().encode(text).length;
      tot[0] += l;
      tot[1] += w;
      tot[2] += c;
      row(l, w, c, label);
    }
    if (items.length > 1) row(tot[0], tot[1], tot[2], 'total');
    return status;
  },
};

const sort: CommandDef = {
  name: 'sort', summary: 'ordena linhas', usage: 'sort [-rnuf] [arquivo...]', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'rnuf' });
    const { items, status } = await inputs(ctx, rest);
    let all = items.flatMap(([, t]) => lines(t));
    if (flags.has('n')) all.sort((a, b) => parseFloat(a) - parseFloat(b) || a.localeCompare(b));
    else if (flags.has('f')) all.sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
    else all.sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
    if (flags.has('r')) all.reverse();
    if (flags.has('u')) all = all.filter((l, i) => i === 0 || l !== all[i - 1]);
    if (all.length) ctx.stdout.write(all.join('\n') + '\n');
    return status;
  },
};

const uniq: CommandDef = {
  name: 'uniq', summary: 'remove linhas repetidas adjacentes', usage: 'uniq [-cdi] [arquivo]', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'cdui' });
    const { items, status } = await inputs(ctx, rest.slice(0, 1));
    const groups: { line: string; count: number }[] = [];
    for (const line of lines(items[0]?.[1] ?? '')) {
      const last = groups[groups.length - 1];
      const same = last && (flags.has('i') ? last.line.toLowerCase() === line.toLowerCase() : last.line === line);
      if (same) last.count++;
      else groups.push({ line, count: 1 });
    }
    for (const g of groups) {
      if (flags.has('d') && g.count < 2) continue;
      if (flags.has('u') && g.count > 1) continue;
      ctx.stdout.write((flags.has('c') ? String(g.count).padStart(7) + ' ' : '') + g.line + '\n');
    }
    return status;
  },
};

const tee: CommandDef = {
  name: 'tee', summary: 'copia a entrada para arquivos e para a saída', usage: 'tee [-a] arquivo...', source: 'vos',
  async run(ctx) {
    const { flags, rest } = parseArgs(ctx.args, { bool: 'a' });
    const text = ctx.stdin.read();
    let status = 0;
    for (const f of rest) {
      try {
        await ctx.kernel.vfs.writeFile(ctx.shell.resolvePath(f), text, { append: flags.has('a') }, ctx.creds);
      } catch (err) {
        ctx.stderr.write(`tee: ${(err as Error).message}\n`);
        status = 1;
      }
    }
    ctx.stdout.write(text);
    return status;
  },
};

const seq: CommandDef = {
  name: 'seq', summary: 'imprime uma sequência de números', usage: 'seq [início [passo]] fim', source: 'vos',
  run(ctx) {
    const n = ctx.args.map(Number);
    if (!n.length || n.some(Number.isNaN)) {
      ctx.stderr.write('seq: argumento numérico inválido\n');
      return 1;
    }
    const [first, step, last] = n.length === 1 ? [1, 1, n[0]] : n.length === 2 ? [n[0], 1, n[1]] : [n[0], n[1], n[2]];
    if (step === 0) {
      ctx.stderr.write('seq: o passo não pode ser zero\n');
      return 1;
    }
    const out: number[] = [];
    for (let v = first; step > 0 ? v <= last : v >= last; v += step) {
      out.push(v);
      if (out.length > 100000) break;
    }
    ctx.stdout.write(out.join('\n') + (out.length ? '\n' : ''));
    return 0;
  },
};

const basename: CommandDef = {
  name: 'basename', summary: 'remove diretório (e sufixo) de um caminho', usage: 'basename caminho [sufixo]', source: 'vos',
  run(ctx) {
    if (!ctx.args[0]) return ctx.stderr.write('basename: falta operando\n'), 1;
    let b = bn(ctx.args[0]);
    if (ctx.args[1] && b.endsWith(ctx.args[1]) && b !== ctx.args[1]) b = b.slice(0, -ctx.args[1].length);
    ctx.stdout.write(b + '\n');
    return 0;
  },
};

const dirname: CommandDef = {
  name: 'dirname', summary: 'remove o último componente de um caminho', usage: 'dirname caminho', source: 'vos',
  run(ctx) {
    if (!ctx.args[0]) return ctx.stderr.write('dirname: falta operando\n'), 1;
    const d = ctx.args[0].includes('/') ? dn(ctx.args[0]) : '.';
    ctx.stdout.write(d + '\n');
    return 0;
  },
};

const rev: CommandDef = {
  name: 'rev', summary: 'inverte cada linha', usage: 'rev [arquivo...]', source: 'vos',
  async run(ctx) {
    const { items, status } = await inputs(ctx, ctx.args);
    for (const [, t] of items) for (const l of lines(t)) ctx.stdout.write([...l].reverse().join('') + '\n');
    return status;
  },
};

export const textCommands: CommandDef[] = [echo, grep, headTail('head'), headTail('tail'), wc, sort, uniq, tee, seq, basename, dirname, rev];
