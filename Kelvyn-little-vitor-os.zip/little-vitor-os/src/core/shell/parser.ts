/**
 * lvsh parser: a small POSIX-like shell grammar.
 *
 *   list     := pipeline ((';' | '&&' | '||' | '&') pipeline)*
 *   pipeline := command ('|' command)*
 *   command  := (NAME=value)* word* redirect*
 *   redirect := ('>' | '>>' | '<' | '2>' | '2>>' | '2>&1' | '&>') word
 *
 * Words keep quoting information so expansion (variables, ~, globs) can be
 * applied later, at execution time, with the right rules.
 */

export type Quote = 'none' | 'single' | 'double';
export interface Segment {
  text: string;
  quote: Quote;
}
export type Word = Segment[];

export interface Redirect {
  fd: 0 | 1 | 2;
  op: '>' | '>>' | '<' | '>&1' | '&>';
  target: Word;
}

export interface SimpleCommand {
  assignments: { name: string; value: Word }[];
  words: Word[];
  redirects: Redirect[];
}

export interface Pipeline {
  commands: SimpleCommand[];
}

export type ListOp = ';' | '&&' | '||' | '&';
export interface ListItem {
  pipeline: Pipeline;
  /** operator that follows this pipeline */
  op: ListOp;
}

type Token =
  | { kind: 'word'; word: Word }
  | { kind: 'op'; op: string };

export class ParseError extends Error {}

const OPERATORS = ['&&', '||', '2>>', '2>&1', '&>', '>>', '2>', '|', ';', '&', '>', '<'];

export function tokenize(input: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  let word: Word | null = null;
  let segText = '';
  let segQuote: Quote = 'none';

  const flushSeg = () => {
    if (segText || segQuote !== 'none') {
      (word ??= []).push({ text: segText, quote: segQuote });
    }
    segText = '';
    segQuote = 'none';
  };
  const flushWord = () => {
    flushSeg();
    if (word) tokens.push({ kind: 'word', word });
    word = null;
  };

  while (i < input.length) {
    const c = input[i];
    if (c === '#' && !word && !segText) {
      // comment until end of line
      while (i < input.length && input[i] !== '\n') i++;
      continue;
    }
    if (c === ' ' || c === '\t') {
      flushWord();
      i++;
      continue;
    }
    if (c === '\n') {
      flushWord();
      tokens.push({ kind: 'op', op: ';' });
      i++;
      continue;
    }
    if (c === '\\') {
      if (i + 1 < input.length) {
        flushSeg();
        (word ??= []).push({ text: input[i + 1], quote: 'single' });
      }
      i += 2;
      continue;
    }
    if (c === "'") {
      flushSeg();
      const end = input.indexOf("'", i + 1);
      if (end === -1) throw new ParseError('aspas simples não fechadas');
      (word ??= []).push({ text: input.slice(i + 1, end), quote: 'single' });
      i = end + 1;
      continue;
    }
    if (c === '"') {
      flushSeg();
      let j = i + 1;
      let text = '';
      while (j < input.length && input[j] !== '"') {
        if (input[j] === '\\' && j + 1 < input.length && '"\\$`'.includes(input[j + 1])) {
          // escaped char inside double quotes: keep it literal (not expanded)
          if (text) (word ??= []).push({ text, quote: 'double' });
          text = '';
          (word ??= []).push({ text: input[j + 1], quote: 'single' });
          j += 2;
          continue;
        }
        text += input[j++];
      }
      if (j >= input.length) throw new ParseError('aspas duplas não fechadas');
      (word ??= []).push({ text, quote: 'double' });
      i = j + 1;
      continue;
    }
    // operators (only at word boundary, except "2>" which must start a word)
    const op = OPERATORS.find((o) => input.startsWith(o, i));
    if (op && !(op.startsWith('2') && (word || segText))) {
      flushWord();
      tokens.push({ kind: 'op', op });
      i += op.length;
      continue;
    }
    segText += c;
    i++;
  }
  flushWord();
  return tokens;
}

export function parse(input: string): ListItem[] {
  const tokens = tokenize(input);
  const items: ListItem[] = [];
  let pos = 0;

  const parseCommand = (): SimpleCommand => {
    const cmd: SimpleCommand = { assignments: [], words: [], redirects: [] };
    while (pos < tokens.length) {
      const t = tokens[pos];
      if (t.kind === 'op') {
        const redir: Record<string, { fd: 0 | 1 | 2; op: Redirect['op'] }> = {
          '>': { fd: 1, op: '>' }, '>>': { fd: 1, op: '>>' }, '<': { fd: 0, op: '<' },
          '2>': { fd: 2, op: '>' }, '2>>': { fd: 2, op: '>>' }, '&>': { fd: 1, op: '&>' },
        };
        if (t.op === '2>&1') {
          cmd.redirects.push({ fd: 2, op: '>&1', target: [] });
          pos++;
          continue;
        }
        const r = redir[t.op];
        if (!r) break;
        const target = tokens[pos + 1];
        if (!target || target.kind !== 'word') throw new ParseError(`erro de sintaxe perto de "${t.op}"`);
        cmd.redirects.push({ ...r, target: target.word });
        pos += 2;
        continue;
      }
      const w = t.word;
      const assign = cmd.words.length === 0 && w[0]?.quote === 'none' ? /^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/s.exec(w[0].text) : null;
      if (assign) {
        cmd.assignments.push({ name: assign[1], value: [{ text: assign[2], quote: 'none' }, ...w.slice(1)] });
      } else cmd.words.push(w);
      pos++;
    }
    return cmd;
  };

  const parsePipeline = (): Pipeline => {
    const commands = [parseCommand()];
    while (pos < tokens.length && tokens[pos].kind === 'op' && (tokens[pos] as { op: string }).op === '|') {
      pos++;
      const next = parseCommand();
      if (!next.words.length && !next.assignments.length) throw new ParseError('erro de sintaxe perto de "|"');
      commands.push(next);
    }
    return { commands };
  };

  while (pos < tokens.length) {
    const t = tokens[pos];
    if (t.kind === 'op' && t.op === ';') {
      pos++;
      continue;
    }
    const pipeline = parsePipeline();
    const first = pipeline.commands[0];
    if (!first.words.length && !first.assignments.length && !first.redirects.length) {
      const bad = tokens[pos];
      throw new ParseError(`erro de sintaxe perto de "${bad && bad.kind === 'op' ? bad.op : '?'}"`);
    }
    let op: ListOp = ';';
    const next = tokens[pos];
    if (next && next.kind === 'op' && [';', '&&', '||', '&'].includes(next.op)) {
      op = next.op as ListOp;
      pos++;
      if ((op === '&&' || op === '||') && pos >= tokens.length) throw new ParseError(`erro de sintaxe: comando faltando após "${op}"`);
    }
    items.push({ pipeline, op });
  }
  return items;
}

/** Concatenated raw text of a word (no expansion) — used for display. */
export function wordText(w: Word): string {
  return w.map((s) => s.text).join('');
}
