import type { Kernel } from '../../kernel/kernel';
import { basename, dirname, join, normalize, resolve } from '../vfs/path';
import { VfsError, type Credentials } from '../vfs/types';
import { COMMANDS, UNAVAILABLE } from './commands';
import { globToRegExp, stripAnsi } from './glob';
import { parse, ParseError, tokenize, type ListItem, type SimpleCommand, type Word } from './parser';
import {
  ANSI,
  type CommandContext,
  type InputStream,
  type OutputStream,
  type ShellHost,
} from './types';

export interface Job {
  id: number;
  pids: number[];
  command: string;
  status: 'running' | 'done' | 'stopped';
  exitCode?: number;
  promise: Promise<number>;
  controller: AbortController;
}

const HISTORY_LIMIT = 1000;
const MAX_SCRIPT_DEPTH = 16;

/**
 * lvsh — the Little Vitor shell. Parses command lines, expands words,
 * wires pipes/redirections and dispatches to the command registry.
 */
export class Shell {
  readonly env = new Map<string, string>();
  readonly aliases = new Map<string, string>();
  history: string[] = [];
  cwd: string;
  lastStatus = 0;
  readonly jobs: Job[] = [];
  private nextJobId = 1;
  private foreground: AbortController | null = null;
  private notices: string[] = [];
  private depth = 0;
  private sudoUntil = 0;
  private readonly creds: Credentials;

  constructor(
    readonly kernel: Kernel,
    readonly host: ShellHost,
    readonly out: OutputStream,
    readonly err: OutputStream = out,
  ) {
    const user = kernel.users.current;
    this.creds = kernel.users.credentials();
    const home = user?.home ?? '/';
    this.cwd = kernel.vfs.exists(home) ? home : '/';
    const sys = kernel.settings.system.get();
    const set = (k: string, v: string) => this.env.set(k, v);
    set('USER', this.creds.username);
    set('LOGNAME', this.creds.username);
    set('HOME', home);
    set('PWD', this.cwd);
    set('OLDPWD', this.cwd);
    set('SHELL', '/bin/lvsh');
    set('PATH', '/bin:/usr/bin:/sbin');
    set('HOSTNAME', sys.hostname);
    set('LANG', sys.language.replace('-', '_') + '.UTF-8');
    set('TERM', 'xterm-256color');
    set('EDITOR', 'textedit');
    this.aliases.set('ll', 'ls -l');
    this.aliases.set('la', 'ls -la');
    this.aliases.set('l', 'ls -CF');
    this.aliases.set('..', 'cd ..');
    this.aliases.set('vi', 'nano');
    this.aliases.set('vim', 'nano');
    this.aliases.set('xdg-open', 'open');
  }

  get user(): Credentials {
    return this.creds;
  }

  get home(): string {
    return this.env.get('HOME') ?? '/';
  }

  /** Loads ~/.lvsh_history and runs ~/.lvshrc. */
  async init(): Promise<void> {
    const histPath = join(this.home, '.lvsh_history');
    if (this.kernel.settings.user.get().terminalHistory && this.kernel.vfs.exists(histPath)) {
      try {
        this.history = (await this.kernel.vfs.readText(histPath, this.creds)).split('\n').filter(Boolean).slice(-HISTORY_LIMIT);
      } catch {
        /* unreadable history */
      }
    }
    const rc = join(this.home, '.lvshrc');
    if (this.kernel.vfs.exists(rc)) {
      try {
        await this.runScript(await this.kernel.vfs.readText(rc, this.creds), [], this.creds);
      } catch {
        /* a broken rc file must not break the terminal */
      }
    }
  }

  prompt(): string {
    const host = this.env.get('HOSTNAME') ?? 'littlevitor';
    const home = this.home;
    let dir = this.cwd;
    if (dir === home) dir = '~';
    else if (dir.startsWith(home + '/')) dir = '~' + dir.slice(home.length);
    const root = this.creds.username === 'root';
    return `${ANSI.brightGreen}${ANSI.bold}${this.creds.username}@${host}${ANSI.reset}:${ANSI.brightBlue}${ANSI.bold}${dir}${ANSI.reset}${root ? '#' : '$'} `;
  }

  takeNotices(): string[] {
    const n = this.notices;
    this.notices = [];
    return n;
  }

  interrupt(): void {
    this.foreground?.abort();
  }

  get busy(): boolean {
    return !!this.foreground;
  }

  // ------------------------------------------------------------------ run

  /** Runs a line typed by the user. */
  async run(line: string): Promise<number> {
    const trimmed = line.trim();
    if (!trimmed) return this.lastStatus;
    let input = trimmed;
    // history expansion: !! and !n
    if (input.includes('!!') && this.history.length) {
      input = input.replace(/!!/g, this.history[this.history.length - 1]);
      this.out.write(input + '\n');
    } else if (/^!\d+$/.test(input)) {
      const entry = this.history[Number(input.slice(1)) - 1];
      if (!entry) {
        this.err.write(`lvsh: ${input}: evento não encontrado\n`);
        return (this.lastStatus = 1);
      }
      input = entry;
      this.out.write(input + '\n');
    }
    this.addHistory(input);
    return this.execString(input, this.creds);
  }

  private addHistory(line: string) {
    if (this.history[this.history.length - 1] === line) return;
    this.history.push(line);
    if (this.history.length > HISTORY_LIMIT) this.history.shift();
    if (!this.kernel.settings.user.get().terminalHistory) return;
    const histPath = join(this.home, '.lvsh_history');
    void this.kernel.vfs.writeFile(histPath, this.history.join('\n') + '\n', { mode: 0o600 }, this.creds).catch(() => undefined);
  }

  async clearHistory(): Promise<void> {
    this.history = [];
    const histPath = join(this.home, '.lvsh_history');
    if (this.kernel.vfs.exists(histPath)) await this.kernel.vfs.writeFile(histPath, '', {}, this.creds);
  }

  async execString(input: string, creds: Credentials, io?: { stdout?: OutputStream; stderr?: OutputStream }): Promise<number> {
    let list: ListItem[];
    try {
      list = parse(input);
    } catch (err) {
      if (err instanceof ParseError) {
        (io?.stderr ?? this.err).write(`lvsh: ${err.message}\n`);
        return (this.lastStatus = 2);
      }
      throw err;
    }
    let status = this.lastStatus;
    let skip = false;
    for (const item of list) {
      if (!skip) {
        if (item.op === '&') this.startJob(item, creds);
        else status = this.lastStatus = await this.runForeground(item, creds, io);
      }
      // decide whether the NEXT pipeline runs
      if (item.op === '&&') skip = status !== 0;
      else if (item.op === '||') skip = status === 0;
      else skip = false;
    }
    return status;
  }

  private async runForeground(item: ListItem, creds: Credentials, io?: { stdout?: OutputStream; stderr?: OutputStream }): Promise<number> {
    const nested = !!this.foreground;
    const controller = nested ? this.foreground! : new AbortController();
    if (!nested) this.foreground = controller;
    try {
      return await this.runPipeline(item, creds, controller, io);
    } finally {
      if (!nested) this.foreground = null;
    }
  }

  private startJob(item: ListItem, creds: Credentials) {
    const controller = new AbortController();
    const id = this.nextJobId++;
    const text = item.pipeline.commands.map((c) => c.words.map((w) => w.map((s) => s.text).join('')).join(' ')).join(' | ');
    const job: Job = { id, pids: [], command: text, status: 'running', controller, promise: Promise.resolve(0) };
    job.promise = this.runPipeline(item, creds, controller, undefined, job).then(
      (code) => {
        job.status = 'done';
        job.exitCode = code;
        this.notices.push(`[${id}]+  ${code === 0 ? 'Concluído' : `Saída ${code}`}\t${text}`);
        return code;
      },
      () => {
        job.status = 'done';
        job.exitCode = 1;
        return 1;
      },
    );
    this.jobs.push(job);
    // let the pipeline register its processes before printing
    queueMicrotask(() => this.out.write(`[${id}] ${job.pids.join(' ')}\n`));
  }

  removeFinishedJobs(): void {
    for (let i = this.jobs.length - 1; i >= 0; i--) if (this.jobs[i].status === 'done') this.jobs.splice(i, 1);
  }

  // ------------------------------------------------------------------ pipeline

  private async runPipeline(
    item: ListItem,
    creds: Credentials,
    controller: AbortController,
    io?: { stdout?: OutputStream; stderr?: OutputStream },
    job?: Job,
  ): Promise<number> {
    const cmds = item.pipeline.commands;
    let piped: string | null = null;
    let status = 0;
    for (let i = 0; i < cmds.length; i++) {
      if (controller.signal.aborted) return 130;
      const last = i === cmds.length - 1;
      let buffer = '';
      const pipeOut: OutputStream = { write: (t) => void (buffer += t) };
      status = await this.runSimple(cmds[i], {
        creds,
        controller,
        stdin: piped,
        stdout: last ? io?.stdout ?? this.out : pipeOut,
        stderr: io?.stderr ?? this.err,
        toTerminal: last && !io?.stdout,
        job,
      });
      piped = last ? null : buffer;
    }
    return status;
  }

  private async runSimple(
    cmd: SimpleCommand,
    o: {
      creds: Credentials;
      controller: AbortController;
      stdin: string | null;
      stdout: OutputStream;
      stderr: OutputStream;
      toTerminal: boolean;
      job?: Job;
    },
  ): Promise<number> {
    // aliases (only for unquoted first word)
    cmd = this.applyAliases(cmd);
    const vfs = this.kernel.vfs;
    let argv: string[];
    try {
      argv = [];
      for (const w of cmd.words) argv.push(...this.expandWord(w, true));
    } catch (err) {
      o.stderr.write(`lvsh: ${(err as Error).message}\n`);
      return 1;
    }
    // prefix assignments without a command set shell variables
    const assigned = cmd.assignments.map((a) => [a.name, this.expandWord(a.value, false).join('')] as const);
    if (!argv.length) {
      for (const [k, v] of assigned) this.env.set(k, v);
      if (!cmd.redirects.length) return 0;
    }

    // redirections
    let stdinText = o.stdin;
    let stdout = o.stdout;
    let stderr = o.stderr;
    let toTerminal = o.toTerminal;
    const fileWrites: { path: string; append: boolean; getText: () => string }[] = [];
    for (const r of cmd.redirects) {
      if (r.op === '>&1') {
        stderr = stdout;
        continue;
      }
      const target = this.expandWord(r.target, false).join('');
      const path = resolve(this.cwd, target, this.home);
      if (r.op === '<') {
        try {
          stdinText = await vfs.readText(path, o.creds);
        } catch (err) {
          o.stderr.write(`lvsh: ${errMsg(err)}\n`);
          return 1;
        }
        continue;
      }
      let buf = '';
      const stream: OutputStream = { write: (t) => void (buf += t) };
      if (r.fd === 1 || r.op === '&>') {
        stdout = stream;
        toTerminal = false;
      }
      if (r.fd === 2 || r.op === '&>') stderr = stream;
      if (r.op === '&>') {
        stdout = stream;
        stderr = stream;
      }
      fileWrites.push({ path, append: r.op === '>>', getText: () => buf });
      // truncate/create immediately, like a real shell does before running
      try {
        if (r.op !== '>>' || !vfs.exists(path)) await vfs.writeFile(path, '', {}, o.creds);
      } catch (err) {
        o.stderr.write(`lvsh: ${errMsg(err)}\n`);
        return 1;
      }
    }

    let status = 0;
    if (argv.length) {
      const saved = assigned.map(([k]) => [k, this.env.get(k)] as const);
      for (const [k, v] of assigned) this.env.set(k, v);
      try {
        status = await this.dispatch(argv, {
          creds: o.creds,
          controller: o.controller,
          stdin: stdinText,
          stdout: stripIfNotTTY(stdout, toTerminal),
          stderr,
          interactive: toTerminal,
          job: o.job,
        });
      } finally {
        for (const [k, v] of saved) {
          if (v === undefined) this.env.delete(k);
          else this.env.set(k, v);
        }
      }
    }
    for (const fw of fileWrites) {
      try {
        await vfs.writeFile(fw.path, stripAnsi(fw.getText()), { append: true }, o.creds);
      } catch (err) {
        o.stderr.write(`lvsh: ${errMsg(err)}\n`);
        status = 1;
      }
    }
    return status;
  }

  private applyAliases(cmd: SimpleCommand): SimpleCommand {
    const seen = new Set<string>();
    let current = cmd;
    while (current.words.length) {
      const first = current.words[0];
      if (first.length !== 1 || first[0].quote !== 'none') break;
      const alias = this.aliases.get(first[0].text);
      if (!alias || seen.has(first[0].text)) break;
      seen.add(first[0].text);
      const words = tokenize(alias).filter((t) => t.kind === 'word').map((t) => (t as { word: Word }).word);
      current = { ...current, words: [...words, ...current.words.slice(1)] };
    }
    return current;
  }

  /** Runs argv: builtin/registered command, script file or "not found". */
  async dispatch(
    argv: string[],
    o: {
      creds: Credentials;
      controller: AbortController;
      stdin: string | null;
      stdout: OutputStream;
      stderr: OutputStream;
      interactive: boolean;
      job?: Job;
    },
  ): Promise<number> {
    const [name, ...args] = argv;
    const stdin: InputStream = { read: () => o.stdin ?? '', isTTY: o.stdin === null };

    // explicit path: ./script.sh, /bin/ls, ~/x
    if (name.includes('/')) {
      const path = resolve(this.cwd, name, this.home);
      const vfs = this.kernel.vfs;
      if (!vfs.exists(path)) {
        o.stderr.write(`lvsh: ${name}: Arquivo ou diretório inexistente\n`);
        return 127;
      }
      if (vfs.isDir(path)) {
        o.stderr.write(`lvsh: ${name}: É um diretório\n`);
        return 126;
      }
      if (!vfs.canAccess(path, 'x', o.creds)) {
        o.stderr.write(`lvsh: ${name}: Permissão negada\n`);
        return 126;
      }
      const text = await vfs.readText(path, o.creds);
      const builtin = /^#!lvsh-builtin (\S+)/.exec(text);
      if (builtin) return this.dispatch([builtin[1], ...args], o);
      return this.runScript(text, [path, ...args], o.creds, { stdout: o.stdout, stderr: o.stderr });
    }

    const def = COMMANDS.get(name);
    if (!def) {
      const why = UNAVAILABLE[name];
      if (why) {
        o.stderr.write(`${ANSI.yellow}lvsh: ${name}: comando indisponível no Little Vitor OS${ANSI.reset} — ${why}\n`);
        return 127;
      }
      o.stderr.write(`lvsh: ${name}: comando não encontrado\n`);
      return 127;
    }

    const started = performance.now();
    const proc = this.kernel.procs.spawn(
      { ppid: 0, name, command: argv.join(' ').slice(0, 200), user: o.creds.username, kind: 'command' },
      () => o.controller.abort(),
    );
    o.job?.pids.push(proc.pid);
    const ctx: CommandContext = {
      name,
      args,
      stdin,
      stdout: o.stdout,
      stderr: o.stderr,
      shell: this,
      kernel: this.kernel,
      creds: o.creds,
      signal: o.controller.signal,
      interactive: o.interactive,
    };
    try {
      const code = await def.run(ctx);
      return o.controller.signal.aborted ? 130 : code;
    } catch (err) {
      if (o.controller.signal.aborted) {
        o.stdout.write('^C\n');
        return 130;
      }
      o.stderr.write(`${name}: ${errMsg(err)}\n`);
      return 1;
    } finally {
      this.kernel.procs.update(proc.pid, { cpuTimeMs: performance.now() - started });
      this.kernel.procs.exit(proc.pid);
    }
  }

  /** Executes script text line by line, with $0..$9 positional parameters. */
  async runScript(
    text: string,
    positional: string[],
    creds: Credentials,
    io?: { stdout?: OutputStream; stderr?: OutputStream },
  ): Promise<number> {
    if (this.depth >= MAX_SCRIPT_DEPTH) {
      (io?.stderr ?? this.err).write('lvsh: profundidade máxima de scripts atingida\n');
      return 1;
    }
    this.depth++;
    const saved = new Map<string, string | undefined>();
    const setPos = (k: string, v: string) => {
      if (!saved.has(k)) saved.set(k, this.env.get(k));
      this.env.set(k, v);
    };
    positional.forEach((p, i) => setPos(String(i), p));
    if (positional.length) {
      setPos('#', String(positional.length - 1));
      setPos('@', positional.slice(1).join(' '));
    }
    try {
      const body = text.replace(/^#!.*\n/, '');
      return await this.execString(body, creds, io);
    } finally {
      this.depth--;
      for (const [k, v] of saved) {
        if (v === undefined) this.env.delete(k);
        else this.env.set(k, v);
      }
    }
  }

  // ------------------------------------------------------------------ sudo

  /** Returns true if the user authenticated (cached for 5 minutes, like sudo). */
  async authenticateSudo(stderr: OutputStream): Promise<boolean> {
    const u = this.kernel.users;
    if (this.creds.username === 'root') return true;
    if (!this.creds.groups.includes('sudo')) {
      stderr.write(`${this.creds.username} não está no arquivo sudoers. Este incidente será relatado.\n`);
      this.kernel.events.emit('log', { level: 'warn', source: 'sudo', message: `tentativa de sudo por ${this.creds.username}` });
      return false;
    }
    if (Date.now() < this.sudoUntil) return true;
    for (let attempt = 0; attempt < 3; attempt++) {
      const pw = await this.host.prompt(`[sudo] senha para ${this.creds.username}: `, true);
      if (pw === null) return false;
      try {
        if (await u.verify(this.creds.username, pw)) {
          this.sudoUntil = Date.now() + 5 * 60_000;
          return true;
        }
      } catch (err) {
        stderr.write(`sudo: ${(err as Error).message}\n`);
        return false;
      }
      stderr.write('Desculpe, tente novamente.\n');
    }
    stderr.write('sudo: 3 tentativas incorretas de senha\n');
    return false;
  }

  // ------------------------------------------------------------------ expansion

  expandVars(text: string): string {
    return text.replace(/\$(\{([A-Za-z_][A-Za-z0-9_]*)\}|([A-Za-z_][A-Za-z0-9_]*)|([?$#@0-9]))/g, (_m, _all, braced, plain, special) => {
      const key = braced ?? plain ?? special;
      if (key === '?') return String(this.lastStatus);
      if (key === '$') return '4242';
      if (key === 'PWD') return this.cwd;
      return this.env.get(key) ?? '';
    });
  }

  /** Expands one word: variables, tilde and (optionally) globs. */
  expandWord(word: Word, glob: boolean): string[] {
    let text = '';
    let pattern = '';
    let hasGlob = false;
    word.forEach((seg, i) => {
      let t = seg.text;
      if (seg.quote === 'none') {
        if (i === 0 && (t === '~' || t.startsWith('~/'))) t = this.home + t.slice(1);
        t = this.expandVars(t);
        if (/[*?[]/.test(t)) hasGlob = true;
        pattern += t;
      } else {
        if (seg.quote === 'double') t = this.expandVars(t);
        pattern += t.replace(/[*?[\]\\]/g, '\\$&');
      }
      text += t;
    });
    if (glob && hasGlob) {
      const matches = this.glob(pattern);
      if (matches.length) return matches;
    }
    return [text];
  }

  /** Expands a glob pattern against the VFS (relative patterns stay relative). */
  glob(pattern: string): string[] {
    const absolute = pattern.startsWith('/');
    const parts = pattern.split('/').filter(Boolean);
    let candidates = [absolute ? '/' : ''];
    for (const part of parts) {
      const next: string[] = [];
      const hasMeta = /(^|[^\\])[*?[]/.test(part);
      for (const base of candidates) {
        const dir = resolve(this.cwd, base || '.', this.home);
        if (!hasMeta) {
          const lit = part.replace(/\\(.)/g, '$1');
          const candidate = base ? (base === '/' ? '/' + lit : base + '/' + lit) : lit;
          if (this.kernel.vfs.exists(resolve(this.cwd, candidate, this.home))) next.push(candidate);
          continue;
        }
        const re = globToRegExp(part);
        let entries;
        try {
          entries = this.kernel.vfs.readdir(dir, this.creds);
        } catch {
          continue;
        }
        for (const e of entries) {
          if (e.name.startsWith('.') && !part.startsWith('.')) continue;
          if (re.test(e.name)) next.push(base ? (base === '/' ? '/' + e.name : base + '/' + e.name) : e.name);
        }
      }
      candidates = next;
      if (!candidates.length) break;
    }
    return candidates.sort();
  }

  // ------------------------------------------------------------------ cd / paths

  resolvePath(p: string): string {
    return resolve(this.cwd, p, this.home);
  }

  cd(target: string | undefined, stderr: OutputStream): number {
    let dest: string;
    if (!target || target === '~') dest = this.home;
    else if (target === '-') {
      dest = this.env.get('OLDPWD') ?? this.cwd;
      this.out.write(dest + '\n');
    } else dest = this.resolvePath(target);
    try {
      const st = this.kernel.vfs.stat(dest, this.creds);
      if (st.type !== 'dir') {
        stderr.write(`cd: ${target}: Não é um diretório\n`);
        return 1;
      }
      if (!this.kernel.vfs.canAccess(dest, 'x', this.creds)) {
        stderr.write(`cd: ${target}: Permissão negada\n`);
        return 1;
      }
    } catch (err) {
      stderr.write(`cd: ${target}: ${err instanceof VfsError ? err.message.split(': ').pop() : errMsg(err)}\n`);
      return 1;
    }
    this.env.set('OLDPWD', this.cwd);
    this.cwd = normalize(dest);
    this.env.set('PWD', this.cwd);
    return 0;
  }

  // ------------------------------------------------------------------ completion

  /** Tab completion: commands for the first word, paths for the rest. */
  complete(line: string): { replacement: string; options: string[] } {
    const m = /(\S*)$/.exec(line)!;
    const fragment = m[1];
    const before = line.slice(0, line.length - fragment.length);
    const isFirst = !before.trim() || /(\||&&|\|\||;)\s*$/.test(before) || /^sudo\s+$/.test(before.trim() + ' ');
    let options: string[];
    if (isFirst && !fragment.includes('/')) {
      options = [...new Set([...COMMANDS.keys(), ...this.aliases.keys()])].filter((c) => c.startsWith(fragment)).sort();
    } else {
      const expanded = fragment.startsWith('~') ? this.home + fragment.slice(1) : fragment;
      const dirPart = expanded.includes('/') ? expanded.slice(0, expanded.lastIndexOf('/') + 1) : '';
      const namePart = expanded.slice(dirPart.length);
      const dir = this.resolvePath(dirPart || '.');
      let entries: { name: string; isDir: boolean }[] = [];
      try {
        entries = this.kernel.vfs.readdir(dir, this.creds).map((e) => ({ name: e.name, isDir: e.node.type === 'dir' }));
      } catch {
        /* nothing */
      }
      const shownDir = fragment.slice(0, fragment.length - namePart.length);
      options = entries
        .filter((e) => e.name.startsWith(namePart) && (namePart.startsWith('.') || !e.name.startsWith('.')))
        .map((e) => shownDir + e.name.replace(/ /g, '\\ ') + (e.isDir ? '/' : ''));
    }
    if (!options.length) return { replacement: line, options: [] };
    const common = options.reduce((a, b) => {
      let i = 0;
      while (i < a.length && a[i] === b[i]) i++;
      return a.slice(0, i);
    });
    let completed = common;
    if (options.length === 1 && !completed.endsWith('/')) completed += ' ';
    return { replacement: before + completed, options: options.length > 1 ? options : [] };
  }
}

function stripIfNotTTY(stream: OutputStream, tty: boolean): OutputStream {
  return tty ? stream : { write: (t) => stream.write(stripAnsi(t)) };
}

export function errMsg(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

export { basename, dirname, globToRegExp, stripAnsi };
export type { CommandContext };
