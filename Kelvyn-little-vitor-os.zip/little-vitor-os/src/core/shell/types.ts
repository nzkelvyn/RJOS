import type { Kernel } from '../../kernel/kernel';
import type { Credentials } from '../vfs/types';
import type { Shell } from './shell';

export interface OutputStream {
  write(text: string): void;
}

/** Text written by the previous command of a pipeline (or a `<` file). */
export interface InputStream {
  read(): string;
  readonly isTTY: boolean;
}

/**
 * Where a command really runs:
 * - "vos":     implemented by the Little Vitor OS itself (JS operating on the VFS / kernel tables)
 * - "browser": performs a real browser operation (e.g. fetch for curl/wget/ping)
 * - "gui":     opens or controls a graphical app
 * No command is executed by a real Linux kernel (no WebAssembly Linux is bundled).
 */
export type CommandSource = 'vos' | 'browser' | 'gui';

export interface CommandContext {
  name: string;
  args: string[];
  stdin: InputStream;
  stdout: OutputStream;
  stderr: OutputStream;
  shell: Shell;
  kernel: Kernel;
  creds: Credentials;
  signal: AbortSignal;
  /** true when stdout goes to the terminal (not a pipe or file) */
  interactive: boolean;
}

export interface CommandDef {
  name: string;
  summary: string;
  usage: string;
  source: CommandSource;
  /** longer manual text for `man` */
  manual?: string;
  run(ctx: CommandContext): Promise<number> | number;
}

/** Host hooks implemented by the terminal UI. */
export interface ShellHost {
  clear(): void;
  exit(): void;
  /** asks the user a question in the terminal; secret hides input */
  prompt(question: string, secret?: boolean): Promise<string | null>;
  openPath(path: string, appId?: string): void;
  openApp(appId: string, args?: Record<string, string>): void;
  /** full-screen mode for programs like `top` (rendered until it resolves) */
  setFullscreen?(text: string | null): void;
  /** resolves when the user presses one of the keys (used by top) */
  readKey?(signal: AbortSignal): Promise<string>;
  columns(): number;
}

export const ANSI = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m',
  brightBlue: '\x1b[94m',
  brightGreen: '\x1b[92m',
};
