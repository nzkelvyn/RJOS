import type { Kernel } from '../../kernel/kernel';
import { Store } from '../../kernel/store';
import { sha256Hex } from '../users/crypto';

/**
 * Cloud sync client (talks to /server). Syncs the user's home directory with
 * last-writer-wins by modification time, keeping a local record of the last
 * synced state to detect deletions on both sides.
 *
 * Auth: cookie session (HttpOnly) + CSRF token sent in X-CSRF-Token.
 * Realtime: WebSocket /ws pushes "file-changed" events from other devices.
 */
export type SyncPhase = 'off' | 'disconnected' | 'needs-login' | 'syncing' | 'idle' | 'error';

export interface SyncStatus {
  phase: SyncPhase;
  server: string;
  account: string | null;
  lastSync: number | null;
  message: string | null;
  uploaded: number;
  downloaded: number;
  realtime: boolean;
}

interface RemoteFile {
  path: string;
  type: 'file' | 'dir';
  mode: number;
  mtime: number;
  size: number;
  sha256: string | null;
  deleted: boolean;
}

type SyncState = Record<string, { mtime: number; sha256: string | null }>;

const EXCLUDE = [/\/\.local\/share\/Trash(\/|$)/, /\/\.cache(\/|$)/, /\/\.lvsh_history$/, /\/\.config\/lvos\/sync-state\.json$/];
const MAX_SYNC_FILE = 25 * 1024 * 1024;

export const syncStatus = new Store<SyncStatus>({
  phase: 'off', server: '', account: null, lastSync: null, message: null, uploaded: 0, downloaded: 0, realtime: false,
});

let active: SyncEngine | null = null;

/** Identifies this tab so the server does not echo our own changes back over the WebSocket. */
const CLIENT_ID = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : String(Math.random()).slice(2);

export function startSync(kernel: Kernel, server: string): void {
  if (active && active.server === server) return;
  active?.stop();
  active = new SyncEngine(kernel, server.replace(/\/$/, ''));
  void active.start();
}

export function stopSync(): void {
  active?.stop();
  active = null;
  syncStatus.set({ ...syncStatus.get(), phase: 'off', realtime: false });
}

export function syncEngine(): SyncEngine | null {
  return active;
}

export class SyncEngine {
  private csrf: string | null = null;
  private ws: WebSocket | null = null;
  private unsub: (() => void) | null = null;
  private pending = new Set<string>();
  private timer: ReturnType<typeof setTimeout> | null = null;
  private applyingRemote = false;
  private stopped = false;
  private retry = 0;

  constructor(
    private kernel: Kernel,
    readonly server: string,
  ) {}

  private get home(): string {
    return this.kernel.users.current?.home ?? '/nonexistent';
  }

  private set(p: Partial<SyncStatus>) {
    syncStatus.set({ ...syncStatus.get(), server: this.server, ...p });
  }

  private async api(path: string, init: RequestInit = {}): Promise<Response> {
    const headers = new Headers(init.headers);
    headers.set('X-Client-Id', CLIENT_ID);
    if (this.csrf && init.method && init.method !== 'GET') headers.set('X-CSRF-Token', this.csrf);
    return fetch(this.server + path, { ...init, headers, credentials: 'include', cache: 'no-store' });
  }

  async start(): Promise<void> {
    this.set({ phase: 'syncing', message: 'Conectando ao servidor…' });
    try {
      const me = await this.api('/api/auth/me');
      if (me.status === 401) return this.set({ phase: 'needs-login', message: 'Entre com sua conta do servidor de sincronização.' });
      if (!me.ok) throw new Error(`HTTP ${me.status}`);
      const body = (await me.json()) as { username: string; csrf: string };
      this.csrf = body.csrf;
      this.set({ account: body.username });
      await this.fullSync();
      this.watch();
      this.connectRealtime();
    } catch (err) {
      this.set({ phase: 'disconnected', message: `Servidor indisponível: ${(err as Error).message}` });
    }
  }

  async login(username: string, password: string, register = false): Promise<void> {
    const res = await this.api(register ? '/api/auth/register' : '/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string; csrf?: string };
    if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`);
    this.csrf = data.csrf ?? null;
    await this.start();
  }

  async logout(): Promise<void> {
    await this.api('/api/auth/logout', { method: 'POST' }).catch(() => undefined);
    this.ws?.close();
    this.set({ phase: 'needs-login', account: null, realtime: false });
  }

  stop(): void {
    this.stopped = true;
    this.unsub?.();
    this.ws?.close();
    if (this.timer) clearTimeout(this.timer);
  }

  // -------------------------------------------------------------- sync

  private excluded(path: string): boolean {
    return !path.startsWith(this.home + '/') || EXCLUDE.some((re) => re.test(path));
  }

  private rel(path: string): string {
    return path.slice(this.home.length);
  }

  private abs(rel: string): string {
    return this.home + rel;
  }

  private statePath(): string {
    return `${this.home}/.config/lvos/sync-state.json`;
  }

  private async loadState(): Promise<SyncState> {
    try {
      return JSON.parse(await this.kernel.vfs.readText(this.statePath()));
    } catch {
      return {};
    }
  }

  private async saveState(s: SyncState) {
    await this.kernel.vfs.mkdir(`${this.home}/.config/lvos`, { parents: true });
    await this.kernel.vfs.writeFile(this.statePath(), JSON.stringify(s));
  }

  async fullSync(): Promise<void> {
    const vfs = this.kernel.vfs;
    this.set({ phase: 'syncing', message: 'Sincronizando…' });
    const res = await this.api('/api/files');
    if (res.status === 401) return this.set({ phase: 'needs-login', message: 'Sessão expirada.' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const remote = new Map(((await res.json()) as RemoteFile[]).map((f) => [f.path, f]));
    const state = await this.loadState();
    const local = new Map(vfs.find(this.home, (e) => !this.excluded(e.path)).map((e) => [this.rel(e.path), e.node]));
    let up = 0;
    let down = 0;
    this.applyingRemote = true;
    try {
      // dirs first so files have parents
      const remoteSorted = [...remote.values()].sort((a, b) => a.path.length - b.path.length);
      for (const r of remoteSorted) {
        const l = local.get(r.path);
        const known = state[r.path];
        if (r.deleted) {
          if (l && known && l.mtime <= known.mtime) {
            await vfs.rm(this.abs(r.path), { recursive: true }).catch(() => undefined);
            delete state[r.path];
            down++;
          }
          continue;
        }
        if (!l) {
          if (known) {
            // deleted locally since last sync -> propagate deletion
            await this.api(`/api/files?path=${encodeURIComponent(r.path)}`, { method: 'DELETE' });
            delete state[r.path];
            up++;
            continue;
          }
          await this.download(r);
          state[r.path] = { mtime: r.mtime, sha256: r.sha256 };
          down++;
          continue;
        }
        if (r.type === 'file' && l.type === 'file' && r.mtime > l.mtime && (!known || known.sha256 !== r.sha256)) {
          await this.download(r);
          state[r.path] = { mtime: r.mtime, sha256: r.sha256 };
          down++;
        }
      }
      for (const [rel, node] of local) {
        const r = remote.get(rel);
        if (r && !r.deleted && (node.type === 'dir' || node.mtime <= r.mtime)) {
          state[rel] ??= { mtime: r.mtime, sha256: r.sha256 };
          continue;
        }
        // missing remotely, newer locally, or removed remotely before we ever synced it: upload
        if (await this.upload(rel)) {
          state[rel] = { mtime: node.mtime, sha256: null };
          up++;
        }
      }
      await this.saveState(state);
    } finally {
      this.applyingRemote = false;
    }
    const s = syncStatus.get();
    this.set({ phase: 'idle', lastSync: Date.now(), message: null, uploaded: s.uploaded + up, downloaded: s.downloaded + down });
  }

  private async download(r: RemoteFile): Promise<void> {
    const vfs = this.kernel.vfs;
    const path = this.abs(r.path);
    if (r.type === 'dir') {
      await vfs.mkdir(path, { parents: true });
      return;
    }
    const res = await this.api(`/api/files/content?path=${encodeURIComponent(r.path)}`);
    if (!res.ok) throw new Error(`download ${r.path}: HTTP ${res.status}`);
    const data = new Uint8Array(await res.arrayBuffer());
    const dir = path.slice(0, path.lastIndexOf('/'));
    await vfs.mkdir(dir, { parents: true });
    await vfs.writeFile(path, data, { mode: r.mode & 0o777 });
  }

  private async upload(rel: string): Promise<boolean> {
    const vfs = this.kernel.vfs;
    const path = this.abs(rel);
    if (!vfs.exists(path)) return false;
    const node = vfs.stat(path);
    const headers: Record<string, string> = { 'X-Mtime': String(node.mtime), 'X-Mode': String(node.mode & 0o777), 'X-Type': node.type };
    let body: Uint8Array | undefined;
    if (node.type === 'file') {
      if (node.size > MAX_SYNC_FILE) return false;
      body = await vfs.readFile(path);
      headers['X-Sha256'] = await sha256Hex(body);
    }
    const res = await this.api(`/api/files/content?path=${encodeURIComponent(rel)}`, {
      method: 'PUT',
      headers: { ...headers, 'Content-Type': 'application/octet-stream' },
      body: body as BodyInit | undefined,
    });
    if (!res.ok) throw new Error(`upload ${rel}: HTTP ${res.status}`);
    return true;
  }

  /** Uploads local changes shortly after they happen. */
  private watch() {
    this.unsub?.();
    this.unsub = this.kernel.events.on('fs:change', (e) => {
      if (this.applyingRemote || this.excluded(e.path)) return;
      this.pending.add(e.path);
      if (this.timer) clearTimeout(this.timer);
      this.timer = setTimeout(() => void this.flush(), 1500);
    });
  }

  private async flush() {
    const paths = [...this.pending];
    this.pending.clear();
    try {
      const state = await this.loadState();
      for (const p of paths) {
        const rel = this.rel(p);
        if (this.kernel.vfs.exists(p)) {
          if (await this.upload(rel)) state[rel] = { mtime: this.kernel.vfs.stat(p).mtime, sha256: null };
        } else {
          await this.api(`/api/files?path=${encodeURIComponent(rel)}`, { method: 'DELETE' });
          for (const k of Object.keys(state)) if (k === rel || k.startsWith(rel + '/')) delete state[k];
        }
      }
      await this.saveState(state);
      this.set({ phase: 'idle', lastSync: Date.now(), uploaded: syncStatus.get().uploaded + paths.length });
    } catch (err) {
      this.set({ phase: 'error', message: (err as Error).message });
    }
  }

  private connectRealtime() {
    if (this.stopped) return;
    const url = this.server.replace(/^http/, 'ws') + '/ws?client=' + encodeURIComponent(CLIENT_ID);
    try {
      this.ws = new WebSocket(url);
    } catch {
      return;
    }
    this.ws.onopen = () => {
      this.retry = 0;
      this.set({ realtime: true });
    };
    this.ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(String(ev.data)) as { type: string };
        if (msg.type === 'file-changed') {
          if (this.timer) clearTimeout(this.timer);
          this.timer = setTimeout(() => void this.fullSync().catch((err: Error) => this.set({ phase: 'error', message: err.message })), 400);
        }
      } catch {
        /* ignore malformed */
      }
    };
    this.ws.onclose = () => {
      this.set({ realtime: false });
      if (this.stopped) return;
      const delay = Math.min(30_000, 1000 * 2 ** this.retry++);
      setTimeout(() => this.connectRealtime(), delay);
    };
  }
}
