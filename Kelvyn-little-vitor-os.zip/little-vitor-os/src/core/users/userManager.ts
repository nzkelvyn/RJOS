import { EventBus } from '../../kernel/events';
import { Store } from '../../kernel/store';
import type { VFS } from '../vfs/vfs';
import { ROOT_CREDS, type Credentials } from '../vfs/types';
import { hashPassword, verifyPassword } from './crypto';

export interface UserAccount {
  username: string;
  uid: number;
  gid: number;
  fullName: string;
  avatar: string; // emoji or 1-2 letters
  home: string;
  shell: string;
  groups: string[];
}

export interface SessionInfo {
  username: string;
  startedAt: number;
  lastActive: number;
  locked: boolean;
}

export interface SessionState {
  user: UserAccount | null;
  session: SessionInfo | null;
}

const USERNAME_RE = /^[a-z_][a-z0-9_-]{0,31}$/;
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 30_000;

/**
 * User management backed by Linux-style files inside the VFS:
 *   /etc/passwd  (0644)  name:x:uid:gid:gecos:home:shell
 *   /etc/group   (0644)  name:x:gid:member1,member2
 *   /etc/shadow  (0600)  name:pbkdf2-hash
 */
export class UserManager {
  readonly state = new Store<SessionState>({ user: null, session: null });
  private failures = new Map<string, { count: number; until: number }>();

  constructor(
    private vfs: VFS,
    private events: EventBus,
  ) {}

  // ------------------------------------------------------------ persistence

  private async readLines(path: string): Promise<string[]> {
    if (!this.vfs.exists(path)) return [];
    return (await this.vfs.readText(path, ROOT_CREDS)).split('\n').filter((l) => l.trim());
  }

  async list(): Promise<UserAccount[]> {
    const passwd = await this.readLines('/etc/passwd');
    const groups = await this.readGroups();
    return passwd.map((line) => {
      const [username, , uid, gid, gecos = '', home, shell] = line.split(':');
      const [fullName = username, avatar = ''] = gecos.split(',');
      return {
        username, uid: Number(uid), gid: Number(gid), fullName,
        avatar: avatar || username.slice(0, 1).toUpperCase(), home, shell,
        // primary group first (it is the group given to new files), then supplementary groups
        groups: [
          ...groups.filter((g) => g.gid === Number(gid)),
          ...groups.filter((g) => g.gid !== Number(gid) && g.members.includes(username)),
        ].map((g) => g.name),
      };
    });
  }

  /** Human users (uid >= 1000), shown on the login screen. */
  async humans(): Promise<UserAccount[]> {
    return (await this.list()).filter((u) => u.uid >= 1000);
  }

  async get(username: string): Promise<UserAccount | undefined> {
    return (await this.list()).find((u) => u.username === username);
  }

  private async readGroups() {
    return (await this.readLines('/etc/group')).map((line) => {
      const [name, , gid, members = ''] = line.split(':');
      return { name, gid: Number(gid), members: members.split(',').filter(Boolean) };
    });
  }

  private async writeGroups(groups: { name: string; gid: number; members: string[] }[]) {
    await this.vfs.writeFile(
      '/etc/group',
      groups.map((g) => `${g.name}:x:${g.gid}:${g.members.join(',')}`).join('\n') + '\n',
      { mode: 0o644 }, ROOT_CREDS,
    );
  }

  private async writePasswd(users: UserAccount[]) {
    await this.vfs.writeFile(
      '/etc/passwd',
      users.map((u) => `${u.username}:x:${u.uid}:${u.gid}:${u.fullName.replace(/[:,\n]/g, ' ')},${u.avatar}:${u.home}:${u.shell}`).join('\n') + '\n',
      { mode: 0o644 }, ROOT_CREDS,
    );
  }

  private async readShadow(): Promise<Map<string, string>> {
    const map = new Map<string, string>();
    for (const line of await this.readLines('/etc/shadow')) {
      const idx = line.indexOf(':');
      map.set(line.slice(0, idx), line.slice(idx + 1));
    }
    return map;
  }

  private async writeShadow(map: Map<string, string>) {
    await this.vfs.writeFile(
      '/etc/shadow',
      [...map].map(([u, h]) => `${u}:${h}`).join('\n') + '\n',
      { mode: 0o600 }, ROOT_CREDS,
    );
    await this.vfs.chmod('/etc/shadow', 0o600, ROOT_CREDS);
  }

  /** Creates root + system groups on first boot. Idempotent. */
  async bootstrap(): Promise<void> {
    if (this.vfs.exists('/etc/passwd')) return;
    await this.writePasswd([
      { username: 'root', uid: 0, gid: 0, fullName: 'root', avatar: 'R', home: '/root', shell: '/bin/lvsh', groups: ['root'] },
    ]);
    await this.writeGroups([
      { name: 'root', gid: 0, members: [] },
      { name: 'sudo', gid: 27, members: [] },
      { name: 'users', gid: 100, members: [] },
    ]);
    // root has no usable password: "!" locks it, like most distros. Use sudo instead.
    await this.writeShadow(new Map([['root', '!']]));
  }

  // ------------------------------------------------------------ CRUD

  async create(input: {
    username: string;
    password: string;
    fullName?: string;
    avatar?: string;
    admin?: boolean;
  }): Promise<UserAccount> {
    const username = input.username.trim().toLowerCase();
    if (!USERNAME_RE.test(username)) {
      throw new Error('Nome de usuário inválido: use letras minúsculas, números, _ ou - (máx. 32).');
    }
    if (input.password.length < 4) throw new Error('A senha precisa ter pelo menos 4 caracteres.');
    const users = await this.list();
    // The very first human account is created by the setup wizard; after that only admins can add users.
    if (users.some((u) => u.uid >= 1000)) this.requireAdmin();
    if (users.some((u) => u.username === username)) throw new Error(`O usuário ${username} já existe.`);
    const uid = Math.max(999, ...users.map((u) => u.uid)) + 1;
    const groups = await this.readGroups();
    groups.push({ name: username, gid: uid, members: [] });
    const usersGroup = groups.find((g) => g.name === 'users');
    usersGroup?.members.push(username);
    if (input.admin) groups.find((g) => g.name === 'sudo')?.members.push(username);
    const account: UserAccount = {
      username, uid, gid: uid,
      fullName: (input.fullName || username).trim().slice(0, 64),
      avatar: (input.avatar || username.slice(0, 1).toUpperCase()).slice(0, 4),
      home: `/home/${username}`, shell: '/bin/lvsh',
      groups: [username, 'users', ...(input.admin ? ['sudo'] : [])],
    };
    await this.writeGroups(groups);
    await this.writePasswd([...users, account]);
    const shadow = await this.readShadow();
    shadow.set(username, await hashPassword(input.password));
    await this.writeShadow(shadow);
    await this.createHome(account);
    return account;
  }

  private async createHome(u: UserAccount) {
    const creds = { username: u.username, groups: u.groups };
    await this.vfs.mkdir(u.home, { parents: true, mode: 0o750, owner: u.username, group: u.username }, ROOT_CREDS);
    for (const d of ['Desktop', 'Documents', 'Downloads', 'Music', 'Pictures', 'Videos', 'Projects', '.config', '.local/share']) {
      await this.vfs.mkdir(`${u.home}/${d}`, { parents: true }, creds);
    }
    await this.vfs.writeFile(
      `${u.home}/Documents/Bem-vindo.txt`,
      `Olá, ${u.fullName}!\n\nEste é o seu diretório pessoal no Little Vitor OS.\n` +
        `Tudo o que você salva aqui fica guardado no navegador (IndexedDB/OPFS).\n\n` +
        `Dicas:\n  Super+T  abre o Terminal\n  Super+E  abre os Arquivos\n  Alt+Tab  alterna janelas\n  digite "help" no terminal para ver os comandos\n`,
      {}, creds,
    );
    await this.vfs.writeFile(`${u.home}/.lvshrc`, '# executado ao abrir o terminal\nexport EDITOR=textedit\n', {}, creds);
  }

  async update(
    username: string,
    patch: Partial<Pick<UserAccount, 'fullName' | 'avatar'>> & { admin?: boolean },
  ): Promise<void> {
    this.requireSelfOrAdmin(username);
    const users = await this.list();
    const u = users.find((x) => x.username === username);
    if (!u) throw new Error('Usuário não encontrado.');
    if (patch.fullName !== undefined) u.fullName = patch.fullName.trim().slice(0, 64) || u.username;
    if (patch.avatar !== undefined) u.avatar = patch.avatar.slice(0, 4) || u.username[0].toUpperCase();
    await this.writePasswd(users);
    if (patch.admin !== undefined) {
      this.requireAdmin();
      const groups = await this.readGroups();
      const sudo = groups.find((g) => g.name === 'sudo')!;
      sudo.members = sudo.members.filter((m) => m !== username);
      if (patch.admin) sudo.members.push(username);
      await this.writeGroups(groups);
    }
    if (this.current?.username === username) await this.refreshCurrent();
  }

  async changePassword(username: string, oldPassword: string | null, newPassword: string): Promise<void> {
    if (newPassword.length < 4) throw new Error('A senha precisa ter pelo menos 4 caracteres.');
    const shadow = await this.readShadow();
    const isSelf = this.current?.username === username;
    if (isSelf || !this.isAdmin()) {
      if (!isSelf) throw new Error('Permissão negada.');
      if (!oldPassword || !(await verifyPassword(oldPassword, shadow.get(username) ?? ''))) {
        throw new Error('Senha atual incorreta.');
      }
    }
    shadow.set(username, await hashPassword(newPassword));
    await this.writeShadow(shadow);
  }

  async remove(username: string, removeHome = true): Promise<void> {
    this.requireAdmin();
    if (username === 'root') throw new Error('Não é possível remover o root.');
    if (this.current?.username === username) throw new Error('Não é possível remover o usuário logado.');
    const users = await this.list();
    const u = users.find((x) => x.username === username);
    if (!u) throw new Error('Usuário não encontrado.');
    await this.writePasswd(users.filter((x) => x.username !== username));
    const groups = (await this.readGroups())
      .filter((g) => g.name !== username)
      .map((g) => ({ ...g, members: g.members.filter((m) => m !== username) }));
    await this.writeGroups(groups);
    const shadow = await this.readShadow();
    shadow.delete(username);
    await this.writeShadow(shadow);
    if (removeHome && this.vfs.exists(u.home)) await this.vfs.rm(u.home, { recursive: true }, ROOT_CREDS);
  }

  // ------------------------------------------------------------ sessions

  get current(): UserAccount | null {
    return this.state.get().user;
  }

  credentials(): Credentials {
    const u = this.current;
    return u ? { username: u.username, groups: u.groups } : { username: 'nobody', groups: ['nogroup'] };
  }

  isAdmin(): boolean {
    return !!this.current?.groups.includes('sudo');
  }

  private requireAdmin() {
    if (!this.isAdmin()) throw new Error('Permissão negada: requer privilégios de administrador (grupo sudo).');
  }

  private requireSelfOrAdmin(username: string) {
    if (this.current?.username !== username && !this.isAdmin()) throw new Error('Permissão negada.');
  }

  lockoutRemaining(username: string): number {
    const f = this.failures.get(username);
    return f && f.until > Date.now() ? f.until - Date.now() : 0;
  }

  async verify(username: string, password: string): Promise<boolean> {
    const wait = this.lockoutRemaining(username);
    if (wait) throw new Error(`Muitas tentativas. Aguarde ${Math.ceil(wait / 1000)}s.`);
    const hash = (await this.readShadow()).get(username);
    const ok = !!hash && hash !== '!' && (await verifyPassword(password, hash));
    if (ok) this.failures.delete(username);
    else {
      const f = this.failures.get(username) ?? { count: 0, until: 0 };
      f.count++;
      if (f.count >= MAX_ATTEMPTS) {
        f.until = Date.now() + LOCKOUT_MS;
        f.count = 0;
      }
      this.failures.set(username, f);
    }
    return ok;
  }

  async login(username: string, password: string): Promise<UserAccount> {
    const user = await this.get(username);
    if (!user || !(await this.verify(username, password))) throw new Error('Usuário ou senha incorretos.');
    const now = Date.now();
    this.state.set({ user, session: { username, startedAt: now, lastActive: now, locked: false } });
    this.events.emit('user:login', { username });
    return user;
  }

  /** Session restore without password (used only for the "remember session" flag in the same browser tab). */
  async resume(username: string): Promise<UserAccount | null> {
    const user = await this.get(username);
    if (!user) return null;
    const now = Date.now();
    this.state.set({ user, session: { username, startedAt: now, lastActive: now, locked: true } });
    return user;
  }

  private async refreshCurrent() {
    const s = this.state.get();
    if (!s.user) return;
    const user = await this.get(s.user.username);
    if (user) this.state.set({ ...s, user });
  }

  lock(): void {
    const s = this.state.get();
    if (!s.session) return;
    this.state.set({ ...s, session: { ...s.session, locked: true } });
    this.events.emit('session:lock', {});
  }

  async unlock(password: string): Promise<boolean> {
    const s = this.state.get();
    if (!s.user || !s.session) return false;
    if (!(await this.verify(s.user.username, password))) return false;
    this.state.set({ ...s, session: { ...s.session, locked: false, lastActive: Date.now() } });
    return true;
  }

  touch(): void {
    const s = this.state.get();
    if (s.session && !s.session.locked) s.session.lastActive = Date.now();
  }

  logout(): void {
    const username = this.current?.username;
    this.state.set({ user: null, session: null });
    if (username) this.events.emit('user:logout', { username });
  }
}
