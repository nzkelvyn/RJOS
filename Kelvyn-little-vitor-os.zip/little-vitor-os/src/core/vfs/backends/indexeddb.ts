import type { StorageBackend, VNode } from '../types';

const DB_NAME = 'little-vitor-vfs';
const DB_VERSION = 1;

function req<T>(r: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

/**
 * Persistent backend.
 * - Metadata (VNode) always lives in IndexedDB.
 * - File contents go to OPFS (Origin Private File System) when the browser
 *   supports it, otherwise to an IndexedDB object store.
 */
export class IndexedDBBackend implements StorageBackend {
  kind = 'indexeddb';
  private db!: IDBDatabase;
  private opfs: FileSystemDirectoryHandle | null = null;

  constructor(private preferOpfs = true) {}

  async init(): Promise<void> {
    if (this.db) return; // idempotent: main.tsx probes it before the kernel mounts
    this.db = await new Promise<IDBDatabase>((resolve, reject) => {
      const open = indexedDB.open(DB_NAME, DB_VERSION);
      open.onupgradeneeded = () => {
        const db = open.result;
        if (!db.objectStoreNames.contains('nodes')) db.createObjectStore('nodes', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('data')) db.createObjectStore('data');
      };
      open.onsuccess = () => resolve(open.result);
      open.onerror = () => reject(open.error);
      open.onblocked = () => reject(new Error('IndexedDB bloqueado por outra aba'));
    });
    if (this.preferOpfs) {
      try {
        const root = await navigator.storage?.getDirectory?.();
        if (root) {
          this.opfs = await root.getDirectoryHandle('lvos-data', { create: true });
          // createWritable is required for writes; older Safari lacks it.
          const probe = await this.opfs.getFileHandle('.probe', { create: true });
          if (!('createWritable' in probe)) this.opfs = null;
        }
      } catch {
        this.opfs = null;
      }
    }
    this.kind = this.opfs ? 'indexeddb+opfs' : 'indexeddb';
    try {
      await navigator.storage?.persist?.();
    } catch {
      /* persistence is best-effort */
    }
  }

  async loadNodes(): Promise<VNode[]> {
    const tx = this.db.transaction('nodes', 'readonly');
    return req(tx.objectStore('nodes').getAll() as IDBRequest<VNode[]>);
  }

  async putNode(node: VNode): Promise<void> {
    return this.putNodes([node]);
  }

  async putNodes(nodes: VNode[]): Promise<void> {
    const real = nodes.filter((n) => !n.id.startsWith('virtual:'));
    if (!real.length) return;
    const tx = this.db.transaction('nodes', 'readwrite');
    const store = tx.objectStore('nodes');
    for (const n of real) store.put({ ...n });
    await txDone(tx);
  }

  async deleteNode(id: string): Promise<void> {
    const tx = this.db.transaction('nodes', 'readwrite');
    tx.objectStore('nodes').delete(id);
    await txDone(tx);
  }

  async getData(id: string): Promise<Uint8Array | undefined> {
    if (this.opfs) {
      try {
        const fh = await this.opfs.getFileHandle(id);
        return new Uint8Array(await (await fh.getFile()).arrayBuffer());
      } catch {
        // fall through to IndexedDB (data written before OPFS was available)
      }
    }
    const tx = this.db.transaction('data', 'readonly');
    const v = await req(tx.objectStore('data').get(id));
    return v ? new Uint8Array(v as ArrayBuffer) : undefined;
  }

  async putData(id: string, data: Uint8Array): Promise<void> {
    if (this.opfs) {
      const fh = await this.opfs.getFileHandle(id, { create: true });
      const w = await fh.createWritable();
      await w.write(data as unknown as FileSystemWriteChunkType);
      await w.close();
      return;
    }
    const tx = this.db.transaction('data', 'readwrite');
    tx.objectStore('data').put(data.slice().buffer, id);
    await txDone(tx);
  }

  async deleteData(id: string): Promise<void> {
    if (this.opfs) {
      try {
        await this.opfs.removeEntry(id);
      } catch {
        /* not there */
      }
    }
    const tx = this.db.transaction('data', 'readwrite');
    tx.objectStore('data').delete(id);
    await txDone(tx);
  }

  async estimate() {
    try {
      const e = await navigator.storage?.estimate?.();
      return { usage: e?.usage ?? null, quota: e?.quota ?? null };
    } catch {
      return { usage: null, quota: null };
    }
  }

  async clear(): Promise<void> {
    const tx = this.db.transaction(['nodes', 'data'], 'readwrite');
    tx.objectStore('nodes').clear();
    tx.objectStore('data').clear();
    await txDone(tx);
    if (this.opfs) {
      const root = await navigator.storage.getDirectory();
      await root.removeEntry('lvos-data', { recursive: true }).catch(() => undefined);
      this.opfs = await root.getDirectoryHandle('lvos-data', { create: true });
    }
  }
}
