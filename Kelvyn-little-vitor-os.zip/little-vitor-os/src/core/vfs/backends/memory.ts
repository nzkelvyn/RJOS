import type { StorageBackend, VNode } from '../types';

/** In-memory backend: used by unit tests and as a fallback when IndexedDB is unavailable. */
export class MemoryBackend implements StorageBackend {
  readonly kind = 'memory';
  private nodes = new Map<string, VNode>();
  private data = new Map<string, Uint8Array>();

  async init(): Promise<void> {}
  async loadNodes(): Promise<VNode[]> {
    return [...this.nodes.values()].map((n) => ({ ...n }));
  }
  async putNode(node: VNode): Promise<void> {
    if (node.id.startsWith('virtual:')) return;
    this.nodes.set(node.id, { ...node });
  }
  async putNodes(nodes: VNode[]): Promise<void> {
    for (const n of nodes) await this.putNode(n);
  }
  async deleteNode(id: string): Promise<void> {
    this.nodes.delete(id);
  }
  async getData(id: string): Promise<Uint8Array | undefined> {
    return this.data.get(id);
  }
  async putData(id: string, data: Uint8Array): Promise<void> {
    this.data.set(id, data.slice());
  }
  async deleteData(id: string): Promise<void> {
    this.data.delete(id);
  }
  async estimate() {
    let usage = 0;
    for (const d of this.data.values()) usage += d.byteLength;
    return { usage, quota: null };
  }
  async clear(): Promise<void> {
    this.nodes.clear();
    this.data.clear();
  }
}
