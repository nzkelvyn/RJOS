/** POSIX-style path helpers for the virtual file system. */

export function normalize(path: string): string {
  const absolute = path.startsWith('/');
  const parts: string[] = [];
  for (const seg of path.split('/')) {
    if (!seg || seg === '.') continue;
    if (seg === '..') {
      if (parts.length) parts.pop();
      continue;
    }
    parts.push(seg);
  }
  const joined = parts.join('/');
  return absolute ? '/' + joined : joined || '.';
}

export function join(...segments: string[]): string {
  return normalize(segments.filter(Boolean).join('/'));
}

/** Resolve `target` against `cwd`, expanding `~` to `home`. Always absolute. */
export function resolve(cwd: string, target: string, home = '/root'): string {
  if (target === '~') return normalize(home);
  if (target.startsWith('~/')) return normalize(home + target.slice(1));
  if (target.startsWith('/')) return normalize(target);
  return normalize(cwd + '/' + target);
}

export function dirname(path: string): string {
  const n = normalize(path);
  if (n === '/') return '/';
  const idx = n.lastIndexOf('/');
  return idx <= 0 ? '/' : n.slice(0, idx);
}

export function basename(path: string): string {
  const n = normalize(path);
  if (n === '/') return '/';
  return n.slice(n.lastIndexOf('/') + 1);
}

export function extname(path: string): string {
  const b = basename(path);
  const idx = b.lastIndexOf('.');
  return idx > 0 ? b.slice(idx).toLowerCase() : '';
}

export function isInside(child: string, parent: string): boolean {
  const c = normalize(child);
  const p = normalize(parent);
  return c === p || c.startsWith(p === '/' ? '/' : p + '/');
}

/** Valid file name: non-empty, no slash, no NUL, not . or .., max 255 chars. */
export function isValidName(name: string): boolean {
  return (
    name.length > 0 &&
    name.length <= 255 &&
    name !== '.' &&
    name !== '..' &&
    !name.includes('/') &&
    !name.includes('\0')
  );
}
