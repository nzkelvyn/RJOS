import type { Credentials, VNode } from './types';

export type Access = 'r' | 'w' | 'x';
const BIT: Record<Access, number> = { r: 4, w: 2, x: 1 };

export const SETUID = 0o4000;
export const SETGID = 0o2000;
export const STICKY = 0o1000;

export function isRoot(c: Credentials): boolean {
  return c.username === 'root';
}

/** Linux-style permission check: owner bits, then group bits, then other bits. */
export function canAccess(node: VNode, creds: Credentials, access: Access): boolean {
  if (isRoot(creds)) {
    // root may read/write anything; execute only if any x bit is set (or it's a dir)
    if (access !== 'x' || node.type === 'dir') return true;
    return (node.mode & 0o111) !== 0;
  }
  const bit = BIT[access];
  if (node.owner === creds.username) return ((node.mode >> 6) & bit) !== 0;
  if (creds.groups.includes(node.group)) return ((node.mode >> 3) & bit) !== 0;
  return (node.mode & bit) !== 0;
}

/**
 * Sticky bit rule (e.g. /tmp): inside a sticky directory only the file owner,
 * the directory owner or root may delete/rename an entry.
 */
export function canRemoveFromDir(dir: VNode, child: VNode, creds: Credentials): boolean {
  if (!canAccess(dir, creds, 'w') || !canAccess(dir, creds, 'x')) return false;
  if ((dir.mode & STICKY) === 0 || isRoot(creds)) return true;
  return child.owner === creds.username || dir.owner === creds.username;
}

/** Formats a node mode as `drwxr-xr-x`, including s/S/t/T special bits. */
export function formatMode(node: Pick<VNode, 'type' | 'mode'>): string {
  const m = node.mode;
  const triplet = (shift: number, special: boolean, specialChar: string) => {
    const r = m & (4 << shift) ? 'r' : '-';
    const w = m & (2 << shift) ? 'w' : '-';
    const xSet = (m & (1 << shift)) !== 0;
    let x = xSet ? 'x' : '-';
    if (special) x = xSet ? specialChar : specialChar.toUpperCase();
    return r + w + x;
  };
  return (
    (node.type === 'dir' ? 'd' : '-') +
    triplet(6, (m & SETUID) !== 0, 's') +
    triplet(3, (m & SETGID) !== 0, 's') +
    triplet(0, (m & STICKY) !== 0, 't')
  );
}

/**
 * Parses chmod modes: octal ("755", "1777") or symbolic ("u+x", "go-w", "a=r", "+x").
 * Returns the new numeric mode or null if invalid.
 */
export function parseChmod(spec: string, current: number): number | null {
  if (/^[0-7]{1,4}$/.test(spec)) return parseInt(spec, 8);
  let mode = current;
  for (const clause of spec.split(',')) {
    const m = /^([ugoa]*)([+\-=])([rwxst]*)$/.exec(clause);
    if (!m) return null;
    const who = m[1] || 'a';
    const op = m[2];
    const perms = m[3];
    let mask = 0;
    const targets = new Set(who.includes('a') ? ['u', 'g', 'o'] : who.split(''));
    for (const t of targets) {
      const shift = t === 'u' ? 6 : t === 'g' ? 3 : 0;
      for (const p of perms) {
        if (p === 'r') mask |= 4 << shift;
        if (p === 'w') mask |= 2 << shift;
        if (p === 'x') mask |= 1 << shift;
        if (p === 's' && t === 'u') mask |= SETUID;
        if (p === 's' && t === 'g') mask |= SETGID;
        if (p === 't') mask |= STICKY;
      }
    }
    if (op === '+') mode |= mask;
    else if (op === '-') mode &= ~mask;
    else {
      let clear = 0;
      for (const t of targets) clear |= 7 << (t === 'u' ? 6 : t === 'g' ? 3 : 0);
      mode = (mode & ~clear) | mask;
    }
  }
  return mode & 0o7777;
}
