export type NodeType = 'file' | 'dir';

export interface VNode {
  id: string;
  type: NodeType;
  name: string;
  /** id of the parent directory; root has parent === null */
  parent: string | null;
  /** permission bits, e.g. 0o755. Special bits: 0o4000 setuid, 0o2000 setgid, 0o1000 sticky */
  mode: number;
  owner: string;
  group: string;
  size: number;
  ctime: number;
  mtime: number;
  atime: number;
  mime?: string;
}

export interface Credentials {
  username: string;
  groups: string[];
}

export const ROOT_CREDS: Credentials = { username: 'root', groups: ['root'] };

export interface StorageBackend {
  readonly kind: string;
  init(): Promise<void>;
  loadNodes(): Promise<VNode[]>;
  putNode(node: VNode): Promise<void>;
  putNodes(nodes: VNode[]): Promise<void>;
  deleteNode(id: string): Promise<void>;
  getData(id: string): Promise<Uint8Array | undefined>;
  putData(id: string, data: Uint8Array): Promise<void>;
  deleteData(id: string): Promise<void>;
  estimate(): Promise<{ usage: number | null; quota: number | null }>;
  /** Removes everything (used by "reset system"). */
  clear(): Promise<void>;
}

export type VfsErrorCode =
  | 'ENOENT'
  | 'EEXIST'
  | 'ENOTDIR'
  | 'EISDIR'
  | 'EACCES'
  | 'EPERM'
  | 'ENOTEMPTY'
  | 'EINVAL'
  | 'EBUSY'
  | 'EFBIG';

const MESSAGES: Record<VfsErrorCode, string> = {
  ENOENT: 'Arquivo ou diretório inexistente',
  EEXIST: 'Arquivo já existe',
  ENOTDIR: 'Não é um diretório',
  EISDIR: 'É um diretório',
  EACCES: 'Permissão negada',
  EPERM: 'Operação não permitida',
  ENOTEMPTY: 'Diretório não vazio',
  EINVAL: 'Argumento inválido',
  EBUSY: 'Recurso ocupado',
  EFBIG: 'Arquivo grande demais',
};

export class VfsError extends Error {
  constructor(
    public readonly code: VfsErrorCode,
    public readonly path: string,
  ) {
    super(`${path}: ${MESSAGES[code]}`);
    this.name = 'VfsError';
  }
}

export interface DirEntry {
  name: string;
  path: string;
  node: VNode;
}

export interface TrashEntry {
  id: string;
  originalPath: string;
  deletedAt: number;
  name: string;
  type: NodeType;
  size: number;
}
