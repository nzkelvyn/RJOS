import { EventBus } from '../../kernel/events';
import { mimeFor } from './mime';
import { basename, dirname, isInside, isValidName, join, normalize } from './path';
import { canAccess, canRemoveFromDir, isRoot } from './permissions';
import {
  ROOT_CREDS,
  VfsError,
  type Credentials,
  type DirEntry,
  type StorageBackend,
  type TrashEntry,
  type VNode,
} from './types';

export const MAX_FILE_SIZE = 256 * 1024 * 1024; // resource limit: 256 MB per file
const enc = new TextEncoder();
const dec = new TextDecoder();

export function uid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export interface VirtualFile {
  read: () => string | Uint8Array;
  write?: (data: Uint8Array) => void;
}

export interface VfsStats {
  files: number;
  dirs: number;
  bytes: number;
}

/**
 * Virtual File System.
 * Metadata (VNode) lives in memory and is mirrored to the storage backend;
 * file contents are loaded lazily from the backend.
 */
export class VFS {
  private nodes = new Map<string, VNode>();
  private children = new Map<string, Map<string, string>>();
  private cache = new Map<string, Uint8Array>();
  private virtual = new Map<string, VirtualFile>();
  private rootId = '';

  constructor(
    private backend: StorageBackend,
    private events: EventBus,
    private getCreds: () => Credentials = () => ROOT_CREDS,
  ) {}

  get backendKind(): string {
    return this.backend.kind;
  }

  /** Loads the tree from storage. Returns true if the FS was freshly created. */
  async mount(): Promise<boolean> {
    await this.backend.init();
    const all = await this.backend.loadNodes();
    for (const n of all) this.index(n);
    const root = all.find((n) => n.parent === null);
    if (root) {
      this.rootId = root.id;
      return false;
    }
    const now = Date.now();
    const r: VNode = {
      id: uid(), type: 'dir', name: '/', parent: null, mode: 0o755,
      owner: 'root', group: 'root', size: 0, ctime: now, mtime: now, atime: now,
    };
    this.index(r);
    this.rootId = r.id;
    await this.backend.putNode(r);
    return true;
  }

  setCredentialsProvider(fn: () => Credentials): void {
    this.getCreds = fn;
  }

  // ---------------------------------------------------------------- lookup

  private index(n: VNode): void {
    this.nodes.set(n.id, n);
    if (n.type === 'dir' && !this.children.has(n.id)) this.children.set(n.id, new Map());
    if (n.parent) {
      let map = this.children.get(n.parent);
      if (!map) {
        map = new Map();
        this.children.set(n.parent, map);
      }
      map.set(n.name, n.id);
    }
  }

  private unindex(n: VNode): void {
    this.nodes.delete(n.id);
    this.children.delete(n.id);
    if (n.parent) this.children.get(n.parent)?.delete(n.name);
    this.cache.delete(n.id);
  }

  private lookup(path: string): VNode | undefined {
    const p = normalize(path);
    let node = this.nodes.get(this.rootId);
    if (p === '/') return node;
    for (const seg of p.split('/').filter(Boolean)) {
      if (!node || node.type !== 'dir') return undefined;
      const id = this.children.get(node.id)?.get(seg);
      node = id ? this.nodes.get(id) : undefined;
    }
    return node;
  }

  /** Walks a path verifying search (x) permission on every ancestor directory. */
  private resolveChecked(path: string, creds: Credentials): VNode {
    const p = normalize(path);
    let node = this.nodes.get(this.rootId)!;
    for (const seg of p.split('/').filter(Boolean)) {
      if (node.type !== 'dir') throw new VfsError('ENOTDIR', p);
      if (!canAccess(node, creds, 'x')) throw new VfsError('EACCES', p);
      const id = this.children.get(node.id)?.get(seg);
      const next = id ? this.nodes.get(id) : undefined;
      if (!next) throw new VfsError('ENOENT', p);
      node = next;
    }
    return node;
  }

  pathOf(node: VNode): string {
    const parts: string[] = [];
    let cur: VNode | undefined = node;
    while (cur && cur.parent) {
      parts.unshift(cur.name);
      cur = this.nodes.get(cur.parent);
    }
    return '/' + parts.join('/');
  }

  exists(path: string): boolean {
    return !!this.lookup(path);
  }

  stat(path: string, creds = this.getCreds()): VNode {
    return { ...this.resolveChecked(path, creds) };
  }

  isDir(path: string): boolean {
    return this.lookup(path)?.type === 'dir';
  }

  canAccess(path: string, access: 'r' | 'w' | 'x', creds = this.getCreds()): boolean {
    const n = this.lookup(path);
    return !!n && canAccess(n, creds, access);
  }

  readdir(path: string, creds = this.getCreds()): DirEntry[] {
    const dir = this.resolveChecked(path, creds);
    if (dir.type !== 'dir') throw new VfsError('ENOTDIR', path);
    if (!canAccess(dir, creds, 'r')) throw new VfsError('EACCES', path);
    const base = normalize(path);
    const out: DirEntry[] = [];
    for (const [name, id] of this.children.get(dir.id) ?? []) {
      const node = this.nodes.get(id);
      if (node) out.push({ name, path: join(base, name), node: { ...node } });
    }
    return out.sort((a, b) => a.name.localeCompare(b.name));
  }

  // ---------------------------------------------------------------- create

  async mkdir(
    path: string,
    opts: { parents?: boolean; mode?: number; owner?: string; group?: string } = {},
    creds = this.getCreds(),
  ): Promise<VNode> {
    const p = normalize(path);
    const existing = this.lookup(p);
    if (existing) {
      if (opts.parents && existing.type === 'dir') return existing;
      throw new VfsError('EEXIST', p);
    }
    const parentPath = dirname(p);
    if (!this.lookup(parentPath)) {
      if (!opts.parents) throw new VfsError('ENOENT', parentPath);
      await this.mkdir(parentPath, { ...opts }, creds);
    }
    return this.createNode(p, 'dir', opts.mode ?? 0o755, creds, opts.owner, opts.group);
  }

  private async createNode(
    p: string,
    type: 'file' | 'dir',
    mode: number,
    creds: Credentials,
    owner?: string,
    group?: string,
  ): Promise<VNode> {
    const name = basename(p);
    if (!isValidName(name)) throw new VfsError('EINVAL', p);
    const parent = this.resolveChecked(dirname(p), creds);
    if (parent.type !== 'dir') throw new VfsError('ENOTDIR', dirname(p));
    if (!canAccess(parent, creds, 'w') || !canAccess(parent, creds, 'x')) {
      throw new VfsError('EACCES', p);
    }
    if (this.children.get(parent.id)?.has(name)) throw new VfsError('EEXIST', p);
    // only root may create files owned by someone else
    const own = owner && isRoot(creds) ? owner : creds.username;
    const grp = group && isRoot(creds) ? group : creds.groups[0] ?? own;
    const now = Date.now();
    const node: VNode = {
      id: uid(), type, name, parent: parent.id, mode, owner: own, group: grp,
      size: 0, ctime: now, mtime: now, atime: now,
      mime: type === 'file' ? mimeFor(name) : undefined,
    };
    this.index(node);
    parent.mtime = now;
    await this.backend.putNodes([node, parent]);
    this.events.emit('fs:change', { path: p, kind: 'create' });
    return node;
  }

  // ---------------------------------------------------------------- read/write

  async readFile(path: string, creds = this.getCreds()): Promise<Uint8Array> {
    const p = normalize(path);
    const v = this.virtual.get(p);
    if (v) {
      const data = v.read();
      return typeof data === 'string' ? enc.encode(data) : data;
    }
    const node = this.resolveChecked(p, creds);
    if (node.type === 'dir') throw new VfsError('EISDIR', p);
    if (!canAccess(node, creds, 'r')) throw new VfsError('EACCES', p);
    node.atime = Date.now();
    const cached = this.cache.get(node.id);
    if (cached) return cached;
    const data = (await this.backend.getData(node.id)) ?? new Uint8Array();
    if (data.byteLength < 1024 * 1024) this.cache.set(node.id, data);
    return data;
  }

  async readText(path: string, creds = this.getCreds()): Promise<string> {
    return dec.decode(await this.readFile(path, creds));
  }

  async writeFile(
    path: string,
    content: string | Uint8Array,
    opts: { append?: boolean; mode?: number } = {},
    creds = this.getCreds(),
  ): Promise<VNode> {
    const p = normalize(path);
    let data = typeof content === 'string' ? enc.encode(content) : content;
    const v = this.virtual.get(p);
    if (v) {
      if (!v.write) throw new VfsError('EPERM', p);
      v.write(data);
      return this.lookup(p)!;
    }
    let node = this.lookup(p);
    if (!node) node = await this.createNode(p, 'file', opts.mode ?? 0o644, creds);
    else {
      this.resolveChecked(p, creds);
      if (node.type === 'dir') throw new VfsError('EISDIR', p);
      if (!canAccess(node, creds, 'w')) throw new VfsError('EACCES', p);
    }
    if (opts.append) {
      const prev = await this.readFile(p, creds);
      const merged = new Uint8Array(prev.byteLength + data.byteLength);
      merged.set(prev, 0);
      merged.set(data, prev.byteLength);
      data = merged;
    }
    if (data.byteLength > MAX_FILE_SIZE) throw new VfsError('EFBIG', p);
    node.size = data.byteLength;
    node.mtime = Date.now();
    await this.backend.putData(node.id, data);
    await this.backend.putNode(node);
    if (data.byteLength < 1024 * 1024) this.cache.set(node.id, data);
    else this.cache.delete(node.id);
    this.events.emit('fs:change', { path: p, kind: 'write' });
    return { ...node };
  }

  async touch(path: string, creds = this.getCreds()): Promise<void> {
    const node = this.lookup(path);
    if (!node) {
      await this.writeFile(path, '', {}, creds);
      return;
    }
    this.resolveChecked(path, creds);
    if (!canAccess(node, creds, 'w') && node.owner !== creds.username && !isRoot(creds)) {
      throw new VfsError('EACCES', path);
    }
    node.mtime = Date.now();
    await this.backend.putNode(node);
  }

  // ---------------------------------------------------------------- delete

  async unlink(path: string, creds = this.getCreds()): Promise<void> {
    const p = normalize(path);
    const node = this.resolveChecked(p, creds);
    if (node.type === 'dir') throw new VfsError('EISDIR', p);
    this.assertRemovable(node, p, creds);
    await this.destroy(node);
    this.events.emit('fs:change', { path: p, kind: 'delete' });
  }

  async rmdir(path: string, creds = this.getCreds()): Promise<void> {
    const p = normalize(path);
    const node = this.resolveChecked(p, creds);
    if (node.type !== 'dir') throw new VfsError('ENOTDIR', p);
    if (node.id === this.rootId) throw new VfsError('EBUSY', p);
    if ((this.children.get(node.id)?.size ?? 0) > 0) throw new VfsError('ENOTEMPTY', p);
    this.assertRemovable(node, p, creds);
    await this.destroy(node);
    this.events.emit('fs:change', { path: p, kind: 'delete' });
  }

  async rm(path: string, opts: { recursive?: boolean } = {}, creds = this.getCreds()): Promise<void> {
    const p = normalize(path);
    const node = this.resolveChecked(p, creds);
    if (node.type === 'file') return this.unlink(p, creds);
    if (!opts.recursive) throw new VfsError('EISDIR', p);
    if (node.id === this.rootId) throw new VfsError('EPERM', p);
    this.assertRemovable(node, p, creds);
    // Check the whole subtree first so we never leave a half-deleted tree.
    this.walk(node, (child, childPath) => {
      if (child.type === 'dir' && !(canAccess(child, creds, 'w') && canAccess(child, creds, 'x'))) {
        throw new VfsError('EACCES', childPath);
      }
    }, p);
    await this.destroy(node);
    this.events.emit('fs:change', { path: p, kind: 'delete' });
  }

  private assertRemovable(node: VNode, p: string, creds: Credentials): void {
    const parent = node.parent ? this.nodes.get(node.parent) : undefined;
    if (!parent || !canRemoveFromDir(parent, node, creds)) throw new VfsError('EACCES', p);
  }

  private walk(node: VNode, fn: (n: VNode, path: string) => void, path: string): void {
    for (const [name, id] of this.children.get(node.id) ?? []) {
      const child = this.nodes.get(id);
      if (!child) continue;
      const cp = join(path, name);
      fn(child, cp);
      if (child.type === 'dir') this.walk(child, fn, cp);
    }
  }

  private async destroy(node: VNode): Promise<void> {
    const all: VNode[] = [node];
    this.walk(node, (n) => all.push(n), '/');
    const parent = node.parent ? this.nodes.get(node.parent) : undefined;
    for (const n of all.reverse()) {
      this.unindex(n);
      await this.backend.deleteNode(n.id);
      if (n.type === 'file') await this.backend.deleteData(n.id);
    }
    if (parent) {
      parent.mtime = Date.now();
      await this.backend.putNode(parent);
    }
  }

  // ---------------------------------------------------------------- move/copy

  async move(src: string, dest: string, creds = this.getCreds()): Promise<string> {
    const s = normalize(src);
    let d = normalize(dest);
    const node = this.resolveChecked(s, creds);
    if (node.id === this.rootId) throw new VfsError('EBUSY', s);
    const destNode = this.lookup(d);
    if (destNode?.type === 'dir') d = join(d, node.name);
    if (s === d) return d;
    if (node.type === 'dir' && isInside(d, s)) throw new VfsError('EINVAL', d);
    const newName = basename(d);
    if (!isValidName(newName)) throw new VfsError('EINVAL', d);
    const newParent = this.resolveChecked(dirname(d), creds);
    if (newParent.type !== 'dir') throw new VfsError('ENOTDIR', dirname(d));
    this.assertRemovable(node, s, creds);
    if (!canAccess(newParent, creds, 'w') || !canAccess(newParent, creds, 'x')) {
      throw new VfsError('EACCES', d);
    }
    const existingId = this.children.get(newParent.id)?.get(newName);
    if (existingId) {
      const existing = this.nodes.get(existingId)!;
      if (existing.type === 'dir') throw new VfsError('EEXIST', d);
      await this.destroy(existing); // overwrite file like mv does
    }
    const oldParent = this.nodes.get(node.parent!)!;
    this.children.get(oldParent.id)?.delete(node.name);
    node.name = newName;
    node.parent = newParent.id;
    if (node.type === 'file') node.mime = mimeFor(newName);
    this.children.get(newParent.id)!.set(newName, node.id);
    const now = Date.now();
    oldParent.mtime = now;
    newParent.mtime = now;
    await this.backend.putNodes([node, oldParent, newParent]);
    this.events.emit('fs:change', { path: d, kind: 'move' });
    return d;
  }

  async copy(
    src: string,
    dest: string,
    opts: { recursive?: boolean } = {},
    creds = this.getCreds(),
  ): Promise<string> {
    const s = normalize(src);
    let d = normalize(dest);
    const node = this.resolveChecked(s, creds);
    const destNode = this.lookup(d);
    if (destNode?.type === 'dir') d = join(d, node.name);
    if (node.type === 'dir') {
      if (!opts.recursive) throw new VfsError('EISDIR', s);
      if (isInside(d, s)) throw new VfsError('EINVAL', d);
      if (!canAccess(node, creds, 'r')) throw new VfsError('EACCES', s);
      await this.mkdir(d, { mode: node.mode & 0o777 }, creds);
      for (const entry of this.readdir(s, creds)) {
        await this.copy(entry.path, join(d, entry.name), opts, creds);
      }
      return d;
    }
    const data = await this.readFile(s, creds);
    await this.writeFile(d, data, { mode: node.mode & 0o777 }, creds);
    return d;
  }

  /** Returns a non-colliding path, e.g. "file (2).txt". */
  uniquePath(path: string): string {
    if (!this.exists(path)) return normalize(path);
    const dir = dirname(path);
    const base = basename(path);
    const dot = base.lastIndexOf('.');
    const stem = dot > 0 ? base.slice(0, dot) : base;
    const ext = dot > 0 ? base.slice(dot) : '';
    for (let i = 2; ; i++) {
      const candidate = join(dir, `${stem} (${i})${ext}`);
      if (!this.exists(candidate)) return candidate;
    }
  }

  // ---------------------------------------------------------------- metadata

  async chmod(path: string, mode: number, creds = this.getCreds()): Promise<void> {
    const node = this.resolveChecked(path, creds);
    if (!isRoot(creds) && node.owner !== creds.username) throw new VfsError('EPERM', path);
    node.mode = mode & 0o7777;
    node.ctime = Date.now();
    await this.backend.putNode(node);
    this.events.emit('fs:change', { path: normalize(path), kind: 'chmod' });
  }

  async chown(
    path: string,
    owner: string | null,
    group: string | null,
    opts: { recursive?: boolean } = {},
    creds = this.getCreds(),
  ): Promise<void> {
    const node = this.resolveChecked(path, creds);
    // Like Linux: only root may change ownership; the owner may change the group
    // to one of their own groups.
    if (!isRoot(creds)) {
      if (owner && owner !== node.owner) throw new VfsError('EPERM', path);
      if (node.owner !== creds.username) throw new VfsError('EPERM', path);
      if (group && !creds.groups.includes(group)) throw new VfsError('EPERM', path);
    }
    const apply = (n: VNode) => {
      if (owner) n.owner = owner;
      if (group) n.group = group;
      n.ctime = Date.now();
    };
    const touched: VNode[] = [node];
    apply(node);
    if (opts.recursive && node.type === 'dir') {
      this.walk(node, (n) => {
        apply(n);
        touched.push(n);
      }, normalize(path));
    }
    await this.backend.putNodes(touched);
    this.events.emit('fs:change', { path: normalize(path), kind: 'chmod' });
  }

  // ---------------------------------------------------------------- search

  find(
    start: string,
    predicate: (entry: DirEntry) => boolean,
    creds = this.getCreds(),
    limit = 5000,
  ): DirEntry[] {
    const out: DirEntry[] = [];
    const visit = (path: string) => {
      let entries: DirEntry[];
      try {
        entries = this.readdir(path, creds);
      } catch {
        return; // unreadable dirs are skipped, like `find` printing an error
      }
      for (const e of entries) {
        if (out.length >= limit) return;
        if (predicate(e)) out.push(e);
        if (e.node.type === 'dir') visit(e.path);
      }
    };
    visit(normalize(start));
    return out;
  }

  stats(): VfsStats {
    let files = 0;
    let dirs = 0;
    let bytes = 0;
    for (const n of this.nodes.values()) {
      if (n.type === 'dir') dirs++;
      else {
        files++;
        bytes += n.size;
      }
    }
    return { files, dirs, bytes };
  }

  du(path: string): number {
    const node = this.lookup(path);
    if (!node) throw new VfsError('ENOENT', path);
    if (node.type === 'file') return node.size;
    let total = 0;
    this.walk(node, (n) => {
      if (n.type === 'file') total += n.size;
    }, normalize(path));
    return total;
  }

  estimate() {
    return this.backend.estimate();
  }

  // ---------------------------------------------------------------- virtual files

  /** Registers a non-persistent file such as /proc/uptime or /dev/null. */
  async registerVirtual(path: string, file: VirtualFile, mode = 0o444): Promise<void> {
    const p = normalize(path);
    this.virtual.set(p, file);
    if (!this.lookup(dirname(p))) await this.mkdir(dirname(p), { parents: true }, ROOT_CREDS);
    if (this.lookup(p)) return;
    const parent = this.lookup(dirname(p))!;
    const now = Date.now();
    // Index only — never persisted.
    this.index({
      id: 'virtual:' + p, type: 'file', name: basename(p), parent: parent.id, mode,
      owner: 'root', group: 'root', size: 0, ctime: now, mtime: now, atime: now,
      mime: 'text/plain',
    });
  }

  isVirtual(path: string): boolean {
    return this.virtual.has(normalize(path));
  }

  // ---------------------------------------------------------------- trash

  trashDir(username: string): string {
    return username === 'root' ? '/root/.local/share/Trash' : `/home/${username}/.local/share/Trash`;
  }

  async moveToTrash(path: string, creds = this.getCreds()): Promise<TrashEntry> {
    const p = normalize(path);
    const node = this.resolveChecked(p, creds);
    const trash = this.trashDir(creds.username);
    if (isInside(p, trash)) throw new VfsError('EINVAL', p);
    await this.mkdir(join(trash, 'files'), { parents: true, mode: 0o700 }, creds);
    await this.mkdir(join(trash, 'info'), { parents: true, mode: 0o700 }, creds);
    const id = uid();
    const entry: TrashEntry = {
      id, originalPath: p, deletedAt: Date.now(), name: node.name,
      type: node.type, size: node.type === 'file' ? node.size : this.du(p),
    };
    await this.move(p, join(trash, 'files', id), creds);
    await this.writeFile(join(trash, 'info', id + '.trashinfo'), JSON.stringify(entry), {}, creds);
    return entry;
  }

  async listTrash(creds = this.getCreds()): Promise<TrashEntry[]> {
    const info = join(this.trashDir(creds.username), 'info');
    if (!this.exists(info)) return [];
    const out: TrashEntry[] = [];
    for (const e of this.readdir(info, creds)) {
      try {
        out.push(JSON.parse(await this.readText(e.path, creds)) as TrashEntry);
      } catch {
        /* corrupted info file — ignore */
      }
    }
    return out.sort((a, b) => b.deletedAt - a.deletedAt);
  }

  async restoreFromTrash(id: string, creds = this.getCreds()): Promise<string> {
    const trash = this.trashDir(creds.username);
    const infoPath = join(trash, 'info', id + '.trashinfo');
    const entry = JSON.parse(await this.readText(infoPath, creds)) as TrashEntry;
    const parent = dirname(entry.originalPath);
    if (!this.exists(parent)) await this.mkdir(parent, { parents: true }, creds);
    const target = this.uniquePath(entry.originalPath);
    await this.move(join(trash, 'files', id), target, creds);
    await this.unlink(infoPath, creds);
    return target;
  }

  async deleteFromTrash(id: string, creds = this.getCreds()): Promise<void> {
    const trash = this.trashDir(creds.username);
    const filePath = join(trash, 'files', id);
    if (this.exists(filePath)) await this.rm(filePath, { recursive: true }, creds);
    const infoPath = join(trash, 'info', id + '.trashinfo');
    if (this.exists(infoPath)) await this.unlink(infoPath, creds);
  }

  async emptyTrash(creds = this.getCreds()): Promise<number> {
    const items = await this.listTrash(creds);
    for (const i of items) await this.deleteFromTrash(i.id, creds);
    return items.length;
  }

  /** Wipes every node (factory reset). */
  async format(): Promise<void> {
    await this.backend.clear();
    this.nodes.clear();
    this.children.clear();
    this.cache.clear();
    this.virtual.clear();
  }
}
