import { useEffect, useRef } from 'react';
import { WindowLayer, WindowSwitcher } from '../wm/WindowLayer';
import { useIsMobile, useKernel, useKernelEvent, useStore } from '../ui/hooks';
import { CalendarPopover, DialogHost, Launcher, NotificationCenter, QuickSettings, SystemPanel, Toasts } from './Panels';
import { DesktopArea, Wallpaper } from './DesktopArea';
import { Dock } from './Dock';
import { TopBar } from './TopBar';
import { useSession } from './sessionContext';
import { useGlobalShortcuts } from './shortcuts';
import { loadEvents, saveEvents, dateKey } from '../apps/calendarStore';

const TOP = 36;

export function Desktop({ onLogout, locked }: { onLogout: () => void; locked: boolean }) {
  const kernel = useKernel();
  const session = useSession();
  const settings = useStore(kernel.settings.user);
  const mobile = useIsMobile();
  const rootRef = useRef<HTMLDivElement>(null);

  // keep the window manager's viewport in sync with the screen and dock size
  useEffect(() => {
    const update = () => {
      const el = rootRef.current;
      if (!el) return;
      const dockSize = { small: 38, medium: 46, large: 56 }[settings.iconSize] + 26;
      const leftDock = settings.dockPosition === 'left' && !mobile;
      session.wm.setViewport({
        width: el.clientWidth,
        height: el.clientHeight,
        top: TOP,
        bottom: mobile ? 70 : leftDock || settings.dockAutoHide ? 0 : dockSize,
        left: leftDock ? dockSize : 0,
      });
    };
    update();
    const ro = new ResizeObserver(update);
    if (rootRef.current) ro.observe(rootRef.current);
    return () => ro.disconnect();
  }, [session, settings.iconSize, settings.dockPosition, settings.dockAutoHide, mobile]);

  useEffect(() => {
    session.wm.animations = settings.animations && !settings.reduceMotion;
  }, [session, settings.animations, settings.reduceMotion]);

  useGlobalShortcuts(session, !locked);

  // auto-lock after inactivity
  useEffect(() => {
    if (!settings.lockAfterMinutes || locked) return;
    let last = Date.now();
    const bump = () => (last = Date.now());
    const events = ['pointerdown', 'keydown', 'pointermove', 'wheel'];
    events.forEach((ev) => window.addEventListener(ev, bump, { passive: true }));
    const t = setInterval(() => {
      if (Date.now() - last > settings.lockAfterMinutes * 60_000) kernel.users.lock();
    }, 5000);
    return () => {
      clearInterval(t);
      events.forEach((ev) => window.removeEventListener(ev, bump));
    };
  }, [settings.lockAfterMinutes, locked, kernel]);

  // calendar reminders (checked every 30 s while logged in)
  useEffect(() => {
    const check = async () => {
      const events = await loadEvents(kernel).catch(() => []);
      const now = new Date();
      const today = dateKey(now);
      const hhmm = now.toTimeString().slice(0, 5);
      let changed = false;
      for (const ev of events) {
        if (!ev.reminder || ev.notified || ev.date !== today || (ev.time && ev.time > hhmm)) continue;
        kernel.notifications.push({ app: 'calendar', appName: 'Calendário', title: ev.title, body: ev.time ? `Hoje às ${ev.time}` : 'Hoje', level: 'info' });
        ev.notified = true;
        changed = true;
      }
      if (changed) await saveEvents(kernel, events);
    };
    void check();
    const t = setInterval(check, 30_000);
    return () => clearInterval(t);
  }, [kernel]);

  // autostart apps once per login
  useEffect(() => {
    if (session.autostarted) return;
    session.autostarted = true;
    for (const id of kernel.settings.user.get().autostart) session.launch(id);
  }, [kernel, session]);

  useKernelEvent('pkg:install', (e) => kernel.notifications.push({ app: 'appcenter', appName: 'Central de Apps', title: `${e.name} instalado`, body: `Versão ${e.version}. Já está no menu de aplicativos.`, level: 'success' }));

  return (
    <div ref={rootRef} className="relative h-full w-full overflow-hidden" data-testid="desktop-root">
      <Wallpaper />
      <TopBar mobile={mobile} />
      <DesktopArea />
      <WindowLayer mobile={mobile} />
      <Dock mobile={mobile} />
      <Launcher />
      <NotificationCenter />
      <QuickSettings />
      <CalendarPopover />
      <SystemPanel onLogout={onLogout} />
      <WindowSwitcher />
      <Toasts />
      <DialogHost />
    </div>
  );
}
