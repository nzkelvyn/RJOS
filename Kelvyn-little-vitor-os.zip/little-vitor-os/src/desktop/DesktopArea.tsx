import { useEffect, useState } from 'react';
import { kindOf } from '../core/vfs/mime';
import type { DirEntry } from '../core/vfs/types';
import { importFiles, useFileUrl } from '../ui/blob';
import { useFsVersion, useKernel, useStore } from '../ui/hooks';
import { Icon } from '../ui/icons';
import { cx, useContextMenu } from '../ui/components';
import { useSession } from './sessionContext';
import { wallpaperCss } from './wallpapers';

export function fileIcon(entry: { name: string; node: { type: string; mime?: string } }): { icon: string; color: string } {
  if (entry.node.type === 'dir') return { icon: 'folder', color: '#60a5fa' };
  const kind = kindOf(entry.name, entry.node.mime);
  return (
    {
      image: { icon: 'image', color: '#f472b6' },
      pdf: { icon: 'pdf', color: '#f87171' },
      audio: { icon: 'music', color: '#fb7185' },
      video: { icon: 'video', color: '#a78bfa' },
      archive: { icon: 'archive', color: '#d97706' },
      text: { icon: 'file-text', color: '#94a3b8' },
      binary: { icon: 'file', color: '#94a3b8' },
    } as const
  )[kind];
}

export function Wallpaper() {
  const kernel = useKernel();
  const s = useStore(kernel.settings.user);
  const preset = wallpaperCss(s.wallpaper);
  const custom = useFileUrl(kernel, preset ? null : s.wallpaper);
  const background = preset ?? (custom.url ? `center / cover no-repeat url("${custom.url}")` : wallpaperCss('aurora')!);
  return <div className="absolute inset-0" style={{ background }} aria-hidden="true" />;
}

export function DesktopArea() {
  const kernel = useKernel();
  const session = useSession();
  const settings = useStore(kernel.settings.user);
  const home = kernel.users.current?.home ?? '/';
  const desk = `${home}/Desktop`;
  const v = useFsVersion(desk);
  const [entries, setEntries] = useState<DirEntry[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const menu = useContextMenu();

  useEffect(() => {
    try {
      setEntries(kernel.vfs.exists(desk) ? kernel.vfs.readdir(desk).filter((e) => !e.name.startsWith('.')) : []);
    } catch {
      setEntries([]);
    }
  }, [kernel, desk, v]);

  const newItem = async (type: 'file' | 'dir') => {
    const name = await session.prompt(type === 'dir' ? 'Nova pasta' : 'Novo arquivo', type === 'dir' ? 'Nova pasta' : 'novo.txt', { confirmLabel: 'Criar' });
    if (!name) return;
    try {
      const path = kernel.vfs.uniquePath(`${desk}/${name}`);
      if (type === 'dir') await kernel.vfs.mkdir(path);
      else await kernel.vfs.writeFile(path, '');
    } catch (err) {
      kernel.notifications.system('Não foi possível criar', (err as Error).message, 'error');
    }
  };

  const onDesktopMenu = (e: React.MouseEvent) => {
    menu.open(e, [
      { label: 'Nova pasta', icon: 'folder', onClick: () => void newItem('dir') },
      { label: 'Novo arquivo de texto', icon: 'file-text', onClick: () => void newItem('file') },
      { separator: true },
      { label: 'Abrir terminal aqui', icon: 'terminal', onClick: () => session.launch('terminal', { cwd: desk }) },
      { label: 'Abrir pasta Área de Trabalho', icon: 'folder-open', onClick: () => session.launch('files', { path: desk }) },
      { label: 'Organizar janelas lado a lado', icon: 'columns', onClick: () => session.wm.tileSideBySide() },
      { separator: true },
      { label: 'Alterar papel de parede…', icon: 'image', onClick: () => session.launch('settings', { page: 'appearance' }) },
      { label: 'Configurações', icon: 'settings', onClick: () => session.launch('settings') },
    ]);
  };

  const itemMenu = (e: React.MouseEvent, entry: DirEntry) => {
    setSelected(entry.path);
    menu.open(e, [
      { label: 'Abrir', icon: 'folder-open', onClick: () => session.openPath(entry.path) },
      { label: 'Abrir com Editor de Texto', icon: 'edit', disabled: entry.node.type === 'dir', onClick: () => session.openPath(entry.path, 'editor') },
      { separator: true },
      {
        label: 'Renomear…', icon: 'edit', onClick: async () => {
          const name = await session.prompt('Renomear', entry.name, { confirmLabel: 'Renomear' });
          if (name && name !== entry.name) await kernel.vfs.move(entry.path, `${desk}/${name}`).catch((err: Error) => kernel.notifications.system('Erro ao renomear', err.message, 'error'));
        },
      },
      { label: 'Mover para a lixeira', icon: 'trash', danger: true, onClick: () => void kernel.vfs.moveToTrash(entry.path).catch((err: Error) => kernel.notifications.system('Erro', err.message, 'error')) },
    ]);
  };

  const fixed = [
    { key: 'home', label: 'Pasta pessoal', icon: 'home', color: '#60a5fa', open: () => session.launch('files', { path: home }) },
    { key: 'trash', label: 'Lixeira', icon: 'trash', color: '#94a3b8', open: () => session.launch('files', { view: 'trash' }) },
  ];
  const size = { small: 40, medium: 48, large: 60 }[settings.iconSize];

  return (
    <div
      className="absolute inset-0"
      onContextMenu={onDesktopMenu}
      onPointerDown={(e) => e.target === e.currentTarget && setSelected(null)}
      onDragOver={(e) => {
        if (e.dataTransfer.types.includes('Files')) {
          e.preventDefault();
          setDragOver(true);
        }
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={async (e) => {
        e.preventDefault();
        setDragOver(false);
        if (!e.dataTransfer.files.length) return;
        const r = await importFiles(kernel, e.dataTransfer.files, desk);
        if (r.imported.length) kernel.notifications.push({ app: 'files', appName: 'Arquivos', title: `${r.imported.length} arquivo(s) importado(s)`, body: 'Salvos na Área de Trabalho', level: 'success' });
        if (r.rejected.length) kernel.notifications.push({ app: 'files', appName: 'Arquivos', title: 'Alguns arquivos não foram importados', body: r.rejected.join(', '), level: 'warning' });
      }}
      data-testid="desktop"
    >
      {dragOver && <div className="pointer-events-none absolute inset-3 rounded-2xl border-2 border-dashed border-accent bg-accent/10" />}
      {settings.desktopIcons && (
        <div className="absolute left-2 top-11 flex max-h-[calc(100%-130px)] flex-col flex-wrap content-start gap-1">
          {fixed.map((f) => (
            <DesktopIcon key={f.key} label={f.label} icon={f.icon} color={f.color} size={size} selected={selected === f.key} onSelect={() => setSelected(f.key)} onOpen={f.open} />
          ))}
          {entries.map((e) => {
            const fi = fileIcon(e);
            return (
              <DesktopIcon
                key={e.path}
                label={e.name}
                icon={fi.icon}
                color={fi.color}
                size={size}
                selected={selected === e.path}
                onSelect={() => setSelected(e.path)}
                onOpen={() => session.openPath(e.path)}
                onMenu={(ev) => itemMenu(ev, e)}
              />
            );
          })}
        </div>
      )}
      {menu.element}
    </div>
  );
}

function DesktopIcon(p: { label: string; icon: string; color: string; size: number; selected: boolean; onSelect: () => void; onOpen: () => void; onMenu?: (e: React.MouseEvent) => void }) {
  return (
    <button
      className={cx('flex w-[86px] flex-col items-center gap-1 rounded-lg p-1.5 text-center outline-none', p.selected ? 'bg-white/20' : 'hover:bg-white/10')}
      onClick={(e) => {
        e.stopPropagation();
        p.onSelect();
      }}
      onDoubleClick={p.onOpen}
      onKeyDown={(e) => e.key === 'Enter' && p.onOpen()}
      onContextMenu={(e) => {
        if (p.onMenu) p.onMenu(e);
        else {
          e.preventDefault();
          e.stopPropagation();
        }
      }}
      title={p.label}
    >
      <span style={{ color: p.color, filter: 'drop-shadow(0 2px 3px rgba(0,0,0,.4))' }}>
        <Icon name={p.icon} size={p.size} strokeWidth={1.3} />
      </span>
      <span className="line-clamp-2 break-all text-[0.8rem] text-white [text-shadow:0_1px_3px_rgba(0,0,0,.8)]">{p.label}</span>
    </button>
  );
}
