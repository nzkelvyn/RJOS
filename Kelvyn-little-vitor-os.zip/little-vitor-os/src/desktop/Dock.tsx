import { useKernel, useStore } from '../ui/hooks';
import { AppIcon, Icon } from '../ui/icons';
import { useContextMenu, cx } from '../ui/components';
import { useSession } from './sessionContext';
import { useAllApps } from './Panels';

export function Dock({ mobile }: { mobile: boolean }) {
  const kernel = useKernel();
  const session = useSession();
  const settings = useStore(kernel.settings.user);
  const wm = useStore(session.wm.state);
  const apps = useAllApps();
  const menu = useContextMenu();
  const pinned = settings.dockApps.map((id) => apps.find((a) => a.id === id)).filter((a): a is NonNullable<typeof a> => !!a);
  const runningExtra = [...new Set(wm.windows.map((w) => w.appId))].filter((id) => !settings.dockApps.includes(id)).map((id) => apps.find((a) => a.id === id)).filter((a): a is NonNullable<typeof a> => !!a);
  const size = mobile ? 40 : { small: 38, medium: 46, large: 56 }[settings.iconSize];
  const left = settings.dockPosition === 'left' && !mobile;

  const clickApp = (appId: string) => {
    const wins = wm.windows.filter((w) => w.appId === appId);
    if (!wins.length) return void session.launch(appId);
    const focusedWin = wins.find((w) => w.id === wm.focused);
    if (focusedWin && wins.length === 1) session.wm.minimize(focusedWin.id);
    else {
      // cycle through this app's windows
      const idx = focusedWin ? wins.indexOf(focusedWin) : -1;
      session.wm.focus(wins[(idx + 1) % wins.length].id);
    }
  };

  const appMenu = (e: React.MouseEvent, appId: string, name: string) => {
    const isPinned = settings.dockApps.includes(appId);
    const wins = wm.windows.filter((w) => w.appId === appId);
    menu.open(e, [
      { label: 'Nova janela', icon: 'plus', onClick: () => session.launch(appId) },
      ...wins.map((w) => ({ label: w.title, icon: 'square' as const, onClick: () => session.wm.focus(w.id) })),
      { separator: true },
      { label: isPinned ? 'Remover do dock' : 'Fixar no dock', icon: 'star', onClick: () => kernel.settings.update({ dockApps: isPinned ? settings.dockApps.filter((x) => x !== appId) : [...settings.dockApps, appId] }) },
      ...(wins.length ? [{ label: wins.length > 1 ? `Fechar ${wins.length} janelas` : `Fechar ${name}`, icon: 'x' as const, danger: true, onClick: () => wins.forEach((w) => session.closeWindow(w.id)) }] : []),
    ]);
  };

  const item = (a: (typeof apps)[number]) => {
    const wins = wm.windows.filter((w) => w.appId === a.id);
    const focused = wins.some((w) => w.id === wm.focused);
    return (
      <button
        key={a.id}
        className="dock-item"
        onClick={() => clickApp(a.id)}
        onContextMenu={(e) => appMenu(e, a.id, a.name)}
        aria-label={a.name}
        data-testid={`dock-${a.id}`}
      >
        <AppIcon icon={a.icon} color={a.color} emoji={a.emoji} size={size} />
        {wins.length > 0 && <span className="dock-dot" data-focused={focused} style={left ? { bottom: 'auto', left: -7, top: '50%', marginLeft: 0 } : undefined} />}
        {!mobile && <span className="tooltip">{a.name}</span>}
      </button>
    );
  };

  return (
    <nav
      className={cx(
        'glass absolute z-[50] flex items-center gap-2 border border-line p-2 shadow-xl',
        left ? 'left-2 top-1/2 -translate-y-1/2 flex-col rounded-2xl' : 'bottom-2 left-1/2 -translate-x-1/2 rounded-2xl',
        mobile && 'bottom-1 max-w-[calc(100vw-8px)] overflow-x-auto',
      )}
      style={{ transition: 'transform .2s' }}
      aria-label="Dock"
      data-testid="dock"
    >
      {pinned.map(item)}
      {runningExtra.length > 0 && <div className={left ? 'my-0.5 h-px w-8 bg-line' : 'mx-0.5 h-8 w-px bg-line'} />}
      {runningExtra.map(item)}
      <div className={left ? 'my-0.5 h-px w-8 bg-line' : 'mx-0.5 h-8 w-px bg-line'} />
      <button className="dock-item" onClick={() => session.togglePanel('launcher')} aria-label="Todos os aplicativos">
        <div className="grid place-items-center rounded-[26%] bg-surface-3" style={{ width: size, height: size }}>
          <Icon name="grid" size={size * 0.45} />
        </div>
        {!mobile && <span className="tooltip">Aplicativos</span>}
      </button>
      {menu.element}
    </nav>
  );
}
