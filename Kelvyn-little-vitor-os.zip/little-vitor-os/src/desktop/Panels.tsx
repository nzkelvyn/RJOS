import { useEffect, useMemo, useRef, useState } from 'react';
import { APPS, packageApp, type AppDef } from '../apps/registry';
import { useDismiss, useKernel, useNow, useStore } from '../ui/hooks';
import { AppIcon, Icon } from '../ui/icons';
import { Toggle, cx } from '../ui/components';
import { useSession } from './sessionContext';
import { loadEvents, type CalendarEvent } from '../apps/calendarStore';

function usePanel(name: string) {
  const session = useSession();
  const panel = useStore(session.panel);
  const ref = useRef<HTMLDivElement>(null);
  useDismiss(ref, panel === name, () => session.panel.set(null));
  return { open: panel === name, ref, close: () => session.panel.set(null) };
}

export function useAllApps(): AppDef[] {
  const kernel = useKernel();
  const installed = useStore(kernel.lvp.installed);
  return useMemo(() => [...APPS, ...installed.filter((p) => p.entry).map(packageApp)], [installed]);
}

// ---------------------------------------------------------------- launcher

export function Launcher() {
  const { open, ref, close } = usePanel('launcher');
  const session = useSession();
  const kernel = useKernel();
  const apps = useAllApps();
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(0);
  useEffect(() => {
    if (open) {
      setQ('');
      setSel(0);
    }
  }, [open]);
  if (!open) return null;
  const query = q.trim().toLowerCase();
  const filtered = apps.filter((a) => !a.hidden && (!query || `${a.name} ${a.description} ${a.keywords ?? ''} ${a.id}`.toLowerCase().includes(query)));
  const categories = [...new Set(filtered.map((a) => a.category))];
  const ordered = query ? filtered : categories.flatMap((c) => filtered.filter((a) => a.category === c));
  const user = kernel.users.current;
  return (
    <div className="fixed inset-0 z-[70] flex items-start justify-center bg-black/30 pt-12 fade-in">
      <div ref={ref} className="glass pop-in flex max-h-[min(640px,80vh)] w-[min(720px,94vw)] flex-col overflow-hidden rounded-2xl border border-line shadow-2xl" role="dialog" aria-label="Aplicativos">
        <div className="flex items-center gap-2 border-b border-line p-3">
          <Icon name="search" size={18} className="text-muted" />
          <input
            autoFocus
            className="flex-1 bg-transparent text-[1.05rem] outline-none placeholder:text-muted"
            placeholder="Buscar aplicativos…"
            value={q}
            data-testid="launcher-search"
            onChange={(e) => {
              setQ(e.target.value);
              setSel(0);
            }}
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown' || e.key === 'ArrowRight') setSel((s) => Math.min(ordered.length - 1, s + 1));
              if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') setSel((s) => Math.max(0, s - 1));
              if (e.key === 'Enter' && ordered[sel]) session.launch(ordered[sel].id);
            }}
          />
        </div>
        <div className="min-h-0 flex-1 overflow-auto p-3">
          {!ordered.length && <div className="p-8 text-center text-muted">Nenhum aplicativo encontrado para “{q}”.</div>}
          {(query ? ['Resultados'] : categories).map((cat) => (
            <section key={cat} className="mb-3">
              <h3 className="mb-1 px-2 text-[0.75rem] font-semibold uppercase tracking-wider text-muted">{cat}</h3>
              <div className="grid grid-cols-[repeat(auto-fill,minmax(104px,1fr))] gap-1">
                {(query ? ordered : ordered.filter((a) => a.category === cat)).map((a) => {
                  const idx = ordered.indexOf(a);
                  return (
                    <button
                      key={a.id}
                      className={cx('flex flex-col items-center gap-1.5 rounded-xl p-2.5 text-center hover:bg-hover', idx === sel && query && 'bg-hover ring-1 ring-accent')}
                      onClick={() => session.launch(a.id)}
                      title={a.description}
                      data-testid={`launch-${a.id}`}
                    >
                      <AppIcon icon={a.icon} color={a.color} emoji={a.emoji} size={46} />
                      <span className="line-clamp-2 text-[0.82rem] leading-tight">{a.name}</span>
                    </button>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
        <div className="flex items-center gap-2 border-t border-line p-2 px-3 text-[0.85rem]">
          <div className="grid h-7 w-7 place-items-center rounded-full bg-accent text-[0.9rem] text-accent-fg">{user?.avatar}</div>
          <span className="flex-1 truncate">{user?.fullName}</span>
          <button className="btn btn-ghost btn-icon" title="Bloquear (Super+L)" aria-label="Bloquear" onClick={() => { close(); kernel.users.lock(); }}><Icon name="lock" size={16} /></button>
          <button className="btn btn-ghost btn-icon" title="Configurações" aria-label="Configurações" onClick={() => session.launch('settings')}><Icon name="settings" size={16} /></button>
          <button className="btn btn-ghost btn-icon" title="Desligar / sair" aria-label="Sair" onClick={() => session.panel.set('system')}><Icon name="power" size={16} /></button>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- notifications

function timeAgo(ts: number): string {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return 'agora';
  if (s < 3600) return `${Math.floor(s / 60)} min`;
  if (s < 86400) return `${Math.floor(s / 3600)} h`;
  return new Date(ts).toLocaleDateString('pt-BR');
}

const LEVEL_ICON = { info: 'info', success: 'check-circle', warning: 'alert', error: 'x-circle' } as const;
const LEVEL_COLOR = { info: 'var(--accent)', success: 'var(--success)', warning: 'var(--warning)', error: 'var(--danger)' };

export function NotificationCenter() {
  const { open, ref } = usePanel('notifications');
  const kernel = useKernel();
  const state = useStore(kernel.notifications.state);
  useNow(30000);
  useEffect(() => {
    if (open) kernel.notifications.markAllRead();
  }, [open, kernel, state.items.length]);
  if (!open) return null;
  const toggleDnd = (v: boolean) => {
    kernel.notifications.setDnd(v);
    kernel.settings.update({ notificationsDnd: v });
  };
  return (
    <div ref={ref} className="glass pop-in fixed right-2 top-11 z-[70] flex max-h-[75vh] w-[min(380px,calc(100vw-16px))] flex-col rounded-2xl border border-line shadow-2xl" role="dialog" aria-label="Central de notificações">
      <div className="flex items-center justify-between border-b border-line p-3">
        <div className="font-semibold">Notificações</div>
        <label className="flex items-center gap-2 text-[0.85rem] text-muted">
          Não perturbe <Toggle checked={state.dnd} onChange={toggleDnd} label="Não perturbe" />
        </label>
      </div>
      <div className="min-h-0 flex-1 overflow-auto p-2">
        {!state.items.length && <div className="p-8 text-center text-muted">Sem notificações</div>}
        {state.items.map((n) => (
          <div key={n.id} className="group mb-1.5 flex gap-2.5 rounded-xl bg-surface-2/70 p-2.5">
            <Icon name={LEVEL_ICON[n.level]} size={18} style={{ color: LEVEL_COLOR[n.level], flexShrink: 0, marginTop: 2 }} />
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline gap-2">
                <div className="flex-1 truncate text-[0.9rem] font-medium">{n.title}</div>
                <div className="text-[0.72rem] text-muted">{timeAgo(n.at)}</div>
              </div>
              {n.body && <div className="selectable text-[0.84rem] text-muted [overflow-wrap:anywhere]">{n.body}</div>}
              <div className="mt-0.5 text-[0.72rem] text-muted">{n.appName}</div>
            </div>
            <button className="win-btn opacity-0 group-hover:opacity-100" aria-label="Dispensar" onClick={() => kernel.notifications.dismiss(n.id)}>
              <Icon name="x" size={13} />
            </button>
          </div>
        ))}
      </div>
      {state.items.length > 0 && (
        <div className="border-t border-line p-2 text-right">
          <button className="btn btn-ghost" onClick={() => kernel.notifications.clear()}>Limpar tudo</button>
        </div>
      )}
    </div>
  );
}

export function Toasts() {
  const kernel = useKernel();
  const state = useStore(kernel.notifications.state);
  const items = state.toasts.map((id) => state.items.find((i) => i.id === id)).filter(Boolean);
  return (
    <div className="pointer-events-none fixed right-3 top-12 z-[80] flex w-[min(360px,calc(100vw-24px))] flex-col gap-2" aria-live="polite">
      {items.map((n) => (
        <div key={n!.id} className="glass slide-up pointer-events-auto flex gap-2.5 rounded-xl border border-line p-3 shadow-xl" role="status" data-testid="toast">
          <Icon name={LEVEL_ICON[n!.level]} size={18} style={{ color: LEVEL_COLOR[n!.level], flexShrink: 0, marginTop: 1 }} />
          <div className="min-w-0 flex-1">
            <div className="text-[0.9rem] font-medium">{n!.title}</div>
            {n!.body && <div className="line-clamp-3 text-[0.84rem] text-muted [overflow-wrap:anywhere]">{n!.body}</div>}
          </div>
          <button className="win-btn" aria-label="Fechar notificação" onClick={() => kernel.notifications.hideToast(n!.id)}>
            <Icon name="x" size={13} />
          </button>
        </div>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------- quick settings

export const volumeStore = { value: 0.8, listeners: new Set<() => void>() };

export function QuickSettings() {
  const { open, ref, close } = usePanel('quick');
  const kernel = useKernel();
  const session = useSession();
  const s = useStore(kernel.settings.user);
  const net = useStore(kernel.net.info);
  const notes = useStore(kernel.notifications.state);
  const [volume, setVolume] = useState(volumeStore.value);
  if (!open) return null;
  const user = kernel.users.current;
  const tile = (active: boolean, icon: string, label: string, onClick: () => void, sub?: string) => (
    <button onClick={onClick} className={cx('flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-left', active ? 'bg-accent text-accent-fg' : 'bg-surface-3 hover:bg-hover')}>
      <Icon name={icon} size={17} />
      <span className="min-w-0">
        <span className="block truncate text-[0.88rem] font-medium">{label}</span>
        {sub && <span className="block truncate text-[0.72rem] opacity-75">{sub}</span>}
      </span>
    </button>
  );
  return (
    <div ref={ref} className="glass pop-in fixed right-2 top-11 z-[70] w-[min(360px,calc(100vw-16px))] rounded-2xl border border-line p-3 shadow-2xl" role="dialog" aria-label="Configurações rápidas">
      <div className="mb-3 flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-full bg-accent text-[1.2rem] text-accent-fg">{user?.avatar}</div>
        <div className="min-w-0 flex-1">
          <div className="truncate font-semibold">{user?.fullName}</div>
          <div className="truncate text-[0.8rem] text-muted">{user?.username}@{kernel.settings.system.get().hostname}</div>
        </div>
        <button className="btn btn-ghost btn-icon" title="Configurações" aria-label="Abrir configurações" onClick={() => { close(); session.launch('settings'); }}><Icon name="settings" size={17} /></button>
        <button className="btn btn-ghost btn-icon" title="Bloquear" aria-label="Bloquear sessão" onClick={() => { close(); kernel.users.lock(); }}><Icon name="lock" size={17} /></button>
        <button className="btn btn-ghost btn-icon" title="Desligar" aria-label="Opções de energia" onClick={() => session.panel.set('system')}><Icon name="power" size={17} /></button>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {tile(net.online, net.online ? 'wifi' : 'wifi-off', 'Rede', () => session.launch('settings', { page: 'network' }), net.online ? `Online${net.effectiveType ? ' · ' + net.effectiveType : ''}` : 'Offline')}
        {tile(s.theme === 'dark', s.theme === 'dark' ? 'moon' : 'sun', 'Modo escuro', () => kernel.settings.update({ theme: s.theme === 'dark' ? 'light' : 'dark' }), s.theme === 'auto' ? 'Automático' : undefined)}
        {tile(notes.dnd, 'bell-off', 'Não perturbe', () => { kernel.notifications.setDnd(!notes.dnd); kernel.settings.update({ notificationsDnd: !notes.dnd }); })}
        {tile(s.animations, 'sparkle', 'Animações', () => kernel.settings.update({ animations: !s.animations }))}
      </div>
      <div className="mt-3 flex items-center gap-3 rounded-xl bg-surface-3 px-3 py-2">
        <Icon name={volume === 0 ? 'volume-x' : 'volume'} size={17} />
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={volume}
          aria-label="Volume do sistema"
          className="flex-1 accent-[var(--accent)]"
          onChange={(e) => {
            volumeStore.value = Number(e.target.value);
            setVolume(volumeStore.value);
            volumeStore.listeners.forEach((l) => l());
          }}
        />
        <span className="w-9 text-right text-[0.8rem] tabular-nums text-muted">{Math.round(volume * 100)}%</span>
      </div>
      <div className="mt-2 text-[0.72rem] text-muted">O volume vale para os players do sistema (Música e Vídeos).</div>
    </div>
  );
}

// ---------------------------------------------------------------- calendar popover

export function CalendarPopover() {
  const { open, ref } = usePanel('calendar');
  const kernel = useKernel();
  const session = useSession();
  const now = useNow(60000);
  const [offset, setOffset] = useState(0);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  useEffect(() => {
    if (!open) return;
    setOffset(0);
    loadEvents(kernel).then(setEvents).catch(() => setEvents([]));
  }, [open, kernel]);
  if (!open) return null;
  const view = new Date(now.getFullYear(), now.getMonth() + offset, 1);
  const first = view.getDay();
  const days = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
  const todayKey = now.toDateString();
  const upcoming = events.filter((e) => new Date(e.date + 'T23:59') >= now).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time)).slice(0, 4);
  const hasEvent = (d: number) => events.some((e) => e.date === `${view.getFullYear()}-${String(view.getMonth() + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`);
  return (
    <div ref={ref} className="glass pop-in fixed left-1/2 top-11 z-[70] w-[min(340px,calc(100vw-16px))] -translate-x-1/2 rounded-2xl border border-line p-4 shadow-2xl" role="dialog" aria-label="Calendário">
      <div className="text-[0.85rem] text-muted">{now.toLocaleDateString('pt-BR', { weekday: 'long' })}</div>
      <div className="mb-3 text-[1.3rem] font-semibold">{now.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' })}</div>
      <div className="mb-2 flex items-center justify-between">
        <button className="btn btn-ghost btn-icon" aria-label="Mês anterior" onClick={() => setOffset((o) => o - 1)}><Icon name="chevron-left" size={16} /></button>
        <span className="font-medium capitalize">{view.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</span>
        <button className="btn btn-ghost btn-icon" aria-label="Próximo mês" onClick={() => setOffset((o) => o + 1)}><Icon name="chevron-right" size={16} /></button>
      </div>
      <div className="grid grid-cols-7 gap-0.5 text-center text-[0.82rem]">
        {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((d, i) => <div key={i} className="py-1 text-muted">{d}</div>)}
        {Array.from({ length: first }, (_, i) => <div key={'e' + i} />)}
        {Array.from({ length: days }, (_, i) => {
          const d = i + 1;
          const isToday = new Date(view.getFullYear(), view.getMonth(), d).toDateString() === todayKey;
          return (
            <div key={d} className={cx('relative grid h-8 place-items-center rounded-full tabular-nums', isToday && 'bg-accent font-semibold text-accent-fg')}>
              {d}
              {hasEvent(d) && <span className="absolute bottom-0.5 h-1 w-1 rounded-full" style={{ background: isToday ? 'var(--accent-fg)' : 'var(--accent)' }} />}
            </div>
          );
        })}
      </div>
      <div className="mt-3 border-t border-line pt-3">
        <div className="mb-1 flex items-center justify-between text-[0.8rem] font-semibold uppercase tracking-wider text-muted">
          Próximos eventos
          <button className="btn btn-ghost h-6 px-2 text-[0.75rem] normal-case tracking-normal" onClick={() => session.launch('calendar')}>Abrir agenda</button>
        </div>
        {!upcoming.length && <div className="text-[0.85rem] text-muted">Nenhum evento agendado.</div>}
        {upcoming.map((e) => (
          <div key={e.id} className="flex gap-2 py-1 text-[0.86rem]">
            <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: e.color }} />
            <span className="flex-1 truncate">{e.title}</span>
            <span className="text-muted tabular-nums">{e.date.slice(8)}/{e.date.slice(5, 7)} {e.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- system panel (Ctrl+Alt+End)

export function SystemPanel({ onLogout }: { onLogout: () => void }) {
  const { open, ref, close } = usePanel('system');
  const kernel = useKernel();
  const session = useSession();
  if (!open) return null;
  const item = (icon: string, label: string, onClick: () => void, danger = false) => (
    <button className="flex items-center gap-3 rounded-xl px-4 py-3 text-left hover:bg-hover" style={danger ? { color: 'var(--danger)' } : undefined} onClick={onClick}>
      <Icon name={icon} size={19} />
      <span>{label}</span>
    </button>
  );
  return (
    <div className="fixed inset-0 z-[90] grid place-items-center bg-black/55 backdrop-blur-sm fade-in">
      <div ref={ref} className="pop-in flex w-[min(360px,92vw)] flex-col rounded-2xl border border-line bg-surface p-3 shadow-2xl" role="dialog" aria-label="Painel do sistema">
        <div className="px-4 pb-2 pt-1 text-[1.05rem] font-semibold">{kernel.users.current?.fullName}</div>
        {item('lock', 'Bloquear', () => { close(); kernel.users.lock(); })}
        {item('users', 'Trocar de usuário', () => { close(); onLogout(); })}
        {item('tasks', 'Gerenciador de Tarefas', () => { close(); session.launch('taskmanager'); })}
        {item('log-out', 'Encerrar sessão', () => { close(); onLogout(); })}
        {item('refresh', 'Reiniciar o sistema', async () => {
          close();
          await kernel.settings.flush();
          location.reload();
        }, true)}
        <button className="btn mt-2" onClick={close}>Cancelar</button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- dialogs

export function DialogHost() {
  const session = useSession();
  const dialogs = useStore(session.dialogs);
  const d = dialogs[0];
  const [value, setValue] = useState('');
  useEffect(() => setValue(d?.defaultValue ?? ''), [d?.id, d?.defaultValue]);
  if (!d) return null;
  const cancel = () => d.resolve(d.kind === 'prompt' ? null : false);
  const ok = () => d.resolve(d.kind === 'prompt' ? value : true);
  return (
    <div className="fixed inset-0 z-[9800] grid place-items-center bg-black/45 fade-in" onKeyDown={(e) => e.key === 'Escape' && cancel()}>
      <form
        className="pop-in w-[min(440px,92vw)] rounded-2xl border border-line bg-surface p-5 shadow-2xl"
        role="alertdialog"
        aria-label={d.title}
        onSubmit={(e) => {
          e.preventDefault();
          ok();
        }}
      >
        <div className="mb-1 text-[1.05rem] font-semibold">{d.title}</div>
        {d.message && <div className="selectable mb-3 whitespace-pre-wrap text-[0.9rem] text-muted [overflow-wrap:anywhere]">{d.message}</div>}
        {d.details && (
          <ul className="mb-3 max-h-48 overflow-auto rounded-lg bg-surface-2 p-2 text-[0.85rem]">
            {d.details.map((x, i) => <li key={i} className="py-0.5">• {x}</li>)}
          </ul>
        )}
        {d.kind === 'prompt' && (
          <input autoFocus className="field mb-4 w-full" type={d.secret ? 'password' : 'text'} value={value} onChange={(e) => setValue(e.target.value)} onFocus={(e) => {
            const dot = e.target.value.lastIndexOf('.');
            e.target.setSelectionRange(0, dot > 0 ? dot : e.target.value.length);
          }} data-testid="dialog-input" />
        )}
        <div className="flex justify-end gap-2">
          {d.kind !== 'alert' && <button type="button" className="btn" onClick={cancel}>Cancelar</button>}
          <button type="submit" autoFocus={d.kind !== 'prompt'} className={cx('btn', d.danger ? 'btn-danger' : 'btn-primary')} data-testid="dialog-ok">
            {d.confirmLabel ?? 'OK'}
          </button>
        </div>
      </form>
    </div>
  );
}
