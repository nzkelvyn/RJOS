import { useEffect, useState } from 'react';
import { useKernel, useNow, useStore } from '../ui/hooks';
import { Icon } from '../ui/icons';
import { useSession } from './sessionContext';

interface BatteryInfo {
  level: number;
  charging: boolean;
  real: boolean;
}

interface BatteryManagerLike extends EventTarget {
  level: number;
  charging: boolean;
}

/** Real battery via the Battery Status API (Chromium); otherwise a clearly-labelled simulated value. */
export function useBattery(): BatteryInfo {
  const [b, setB] = useState<BatteryInfo>({ level: 1, charging: true, real: false });
  useEffect(() => {
    const nav = navigator as Navigator & { getBattery?: () => Promise<BatteryManagerLike> };
    if (!nav.getBattery) return;
    let mgr: BatteryManagerLike | null = null;
    const update = () => mgr && setB({ level: mgr.level, charging: mgr.charging, real: true });
    nav.getBattery().then((m) => {
      mgr = m;
      update();
      m.addEventListener('levelchange', update);
      m.addEventListener('chargingchange', update);
    }).catch(() => undefined);
    return () => {
      mgr?.removeEventListener('levelchange', update);
      mgr?.removeEventListener('chargingchange', update);
    };
  }, []);
  return b;
}

export function TopBar({ mobile }: { mobile: boolean }) {
  const kernel = useKernel();
  const session = useSession();
  const settings = useStore(kernel.settings.user);
  const wm = useStore(session.wm.state);
  const net = useStore(kernel.net.info);
  const notes = useStore(kernel.notifications.state);
  const panel = useStore(session.panel);
  const now = useNow(1000);
  const battery = useBattery();
  const focused = wm.windows.find((w) => w.id === wm.focused);
  const unread = notes.items.filter((i) => !i.read).length;

  const clock = now.toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
    second: settings.showSeconds ? '2-digit' : undefined,
    hour12: !settings.clock24h,
  });
  const day = now.toLocaleDateString('pt-BR', { weekday: 'short', day: 'numeric', month: 'short' });

  const pill = (active: boolean) =>
    `flex h-7 items-center gap-1.5 rounded-full px-2.5 text-[0.88rem] transition-colors ${active ? 'bg-[color-mix(in_oklab,var(--fg)_16%,transparent)]' : 'hover:bg-[color-mix(in_oklab,var(--fg)_10%,transparent)]'}`;

  return (
    <header className="glass relative z-[60] flex h-9 shrink-0 items-center gap-1 border-b border-line px-2" role="banner">
      <button className={pill(panel === 'launcher')} onClick={() => session.togglePanel('launcher')} aria-label="Menu de aplicativos" data-testid="launcher-button">
        <span className="grid h-4 w-4 place-items-center rounded-[5px] text-[9px] font-black text-white" style={{ background: 'conic-gradient(from 210deg,#7c6cff,#22d3ee,#34d399,#7c6cff)' }}>LV</span>
        {!mobile && <span className="font-medium">Atividades</span>}
      </button>
      {!mobile && focused && <div className="ml-1 truncate text-[0.88rem] font-semibold">{focused.title}</div>}

      <div className="absolute left-1/2 -translate-x-1/2">
        <button className={pill(panel === 'calendar')} onClick={() => session.togglePanel('calendar')} aria-label="Relógio e calendário" data-testid="clock">
          {!mobile && <span className="text-muted">{day}</span>}
          <span className="font-semibold tabular-nums">{clock}</span>
        </button>
      </div>

      <div className="ml-auto flex items-center gap-0.5">
        <button className={pill(panel === 'notifications')} onClick={() => session.togglePanel('notifications')} aria-label={`Notificações (${unread} não lidas)`} data-testid="notifications-button">
          <Icon name={notes.dnd ? 'bell-off' : 'bell'} size={15} />
          {unread > 0 && <span className="min-w-4 rounded-full bg-accent px-1 text-[0.7rem] font-bold text-accent-fg">{unread}</span>}
        </button>
        <button className={pill(panel === 'quick')} onClick={() => session.togglePanel('quick')} aria-label="Configurações rápidas" data-testid="quick-button">
          <span title={net.online ? 'Conectado (estado real do navegador)' : 'Sem conexão'}>
            <Icon name={net.online ? 'wifi' : 'wifi-off'} size={15} />
          </span>
          <span className="flex items-center gap-0.5" title={battery.real ? `Bateria ${Math.round(battery.level * 100)}%${battery.charging ? ' (carregando)' : ''}` : 'Bateria: o navegador não informa (indicador simulado)'}>
            <BatteryGlyph level={battery.level} charging={battery.charging} simulated={!battery.real} />
            {!mobile && battery.real && <span className="text-[0.78rem] tabular-nums">{Math.round(battery.level * 100)}%</span>}
          </span>
          <Icon name="power" size={15} />
        </button>
      </div>
    </header>
  );
}

function BatteryGlyph({ level, charging, simulated }: { level: number; charging: boolean; simulated: boolean }) {
  const color = level < 0.15 && !charging ? 'var(--danger)' : 'currentColor';
  return (
    <svg width="22" height="14" viewBox="0 0 22 14" aria-hidden="true" style={{ opacity: simulated ? 0.55 : 1 }}>
      <rect x="1" y="1.5" width="17" height="11" rx="2.5" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <rect x="19" y="5" width="2" height="4" rx="1" fill="currentColor" />
      <rect x="3" y="3.5" width={Math.max(1, 13 * level)} height="7" rx="1.2" fill={color} />
      {charging && <path d="M10.5 3 8 7.5h3L9.5 11" fill="none" stroke="var(--bg)" strokeWidth="1.3" strokeLinejoin="round" />}
    </svg>
  );
}
