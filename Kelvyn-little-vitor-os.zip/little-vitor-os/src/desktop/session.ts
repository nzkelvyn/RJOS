import type { Kernel } from '../kernel/kernel';
import { Store } from '../kernel/store';
import { kindOf } from '../core/vfs/mime';
import { basename } from '../core/vfs/path';
import { WindowManager } from '../wm/windowManager';
import { getApp, packageApp, type AppDef } from '../apps/registry';

export type Panel = 'launcher' | 'notifications' | 'quick' | 'calendar' | 'system' | null;

export interface DialogRequest {
  id: number;
  kind: 'confirm' | 'prompt' | 'alert';
  title: string;
  message?: string;
  details?: string[];
  defaultValue?: string;
  confirmLabel?: string;
  danger?: boolean;
  secret?: boolean;
  resolve: (value: string | boolean | null) => void;
}

export interface FileClipboard {
  paths: string[];
  mode: 'copy' | 'cut';
}

/**
 * UI-level session: owns the window manager and glues the kernel to the
 * desktop (launching apps, opening files, system dialogs, panels).
 */
export class Session {
  readonly wm: WindowManager;
  readonly panel = new Store<Panel>(null);
  readonly dialogs = new Store<DialogRequest[]>([]);
  readonly clipboard = new Store<FileClipboard | null>(null);
  private dialogSeq = 0;
  /** guards autostart against React StrictMode double effects */
  autostarted = false;

  constructor(readonly kernel: Kernel) {
    this.wm = new WindowManager({ width: 1280, height: 800, top: 36, bottom: 76, left: 0 });
  }

  // ----------------------------------------------------------- apps

  launch(appId: string, args: Record<string, string> = {}): string | null {
    let app: AppDef | undefined = getApp(appId);
    if (!app && appId.startsWith('pkg:')) {
      const pkg = this.kernel.lvp.getInstalled(appId.slice(4));
      if (pkg?.entry) app = packageApp(pkg);
    }
    if (!app) {
      this.kernel.notifications.system('Aplicativo não encontrado', appId, 'error');
      return null;
    }
    if (app.singleton) {
      const existing = this.wm.windows.find((w) => w.appId === app!.id);
      if (existing) {
        if (Object.keys(args).length) this.wm.setArgs(existing.id, { ...args, _t: String(Date.now()) });
        this.wm.focus(existing.id);
        return existing.id;
      }
    }
    const user = this.kernel.users.current?.username ?? 'nobody';
    let winId = '';
    const proc = this.kernel.procs.spawn(
      { ppid: 1, name: app.id.replace(/^pkg:/, ''), command: app.name, user, kind: 'app' },
      () => {
        // SIGTERM / SIGKILL from kill or the Task Manager closes the window
        if (winId) this.closeWindow(winId);
      },
    );
    const win = this.wm.open({
      appId: app.id,
      title: app.name,
      icon: app.icon,
      color: app.color,
      emoji: app.emoji,
      width: app.size?.[0],
      height: app.size?.[1],
      minWidth: app.minSize?.[0],
      minHeight: app.minSize?.[1],
      args,
      pid: proc.pid,
    });
    winId = win.id;
    this.kernel.procs.update(proc.pid, { windowId: win.id });
    this.panel.set(null);
    return win.id;
  }

  closeWindow(id: string): void {
    const w = this.wm.get(id);
    if (!w) return;
    this.wm.close(id);
    if (w.pid) this.kernel.procs.exit(w.pid);
  }

  /** Opens a file or folder with the default app for its type. */
  openPath(path: string, appId?: string): void {
    const vfs = this.kernel.vfs;
    if (!vfs.exists(path)) {
      this.kernel.notifications.system('Arquivo não encontrado', path, 'error');
      return;
    }
    if (vfs.isDir(path)) {
      this.launch(appId ?? 'files', { path });
      return;
    }
    if (path.endsWith('.lvp')) {
      this.launch('appcenter', { install: path });
      return;
    }
    const kind = kindOf(path, vfs.stat(path).mime);
    const defaults = this.kernel.settings.user.get().defaultApps;
    const target = appId ?? defaults[kind] ?? (kind === 'binary' ? null : 'editor');
    if (!target) {
      void this.alert('Não há aplicativo para este arquivo', `${basename(path)} é um arquivo binário. Você pode abri-lo no Editor de Texto pelo menu "Abrir com".`);
      return;
    }
    this.launch(target, { path });
  }

  // ----------------------------------------------------------- dialogs

  private ask(req: Omit<DialogRequest, 'id' | 'resolve'>): Promise<string | boolean | null> {
    return new Promise((resolve) => {
      const id = ++this.dialogSeq;
      this.dialogs.set((d) => [
        ...d,
        {
          ...req,
          id,
          resolve: (v) => {
            this.dialogs.set((list) => list.filter((x) => x.id !== id));
            resolve(v);
          },
        },
      ]);
    });
  }

  async confirm(title: string, message?: string, opts: { confirmLabel?: string; danger?: boolean; details?: string[] } = {}): Promise<boolean> {
    return (await this.ask({ kind: 'confirm', title, message, ...opts })) === true;
  }

  async prompt(title: string, defaultValue = '', opts: { message?: string; confirmLabel?: string; secret?: boolean } = {}): Promise<string | null> {
    const v = await this.ask({ kind: 'prompt', title, defaultValue, ...opts });
    return typeof v === 'string' ? v : null;
  }

  async alert(title: string, message?: string): Promise<void> {
    await this.ask({ kind: 'alert', title, message });
  }

  togglePanel(p: Exclude<Panel, null>): void {
    this.panel.set((cur) => (cur === p ? null : p));
  }
}
