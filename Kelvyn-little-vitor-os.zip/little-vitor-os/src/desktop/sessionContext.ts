import { createContext, useContext } from 'react';
import type { Session } from './session';

export const SessionContext = createContext<Session | null>(null);

export function useSession(): Session {
  const s = useContext(SessionContext);
  if (!s) throw new Error('SessionContext ausente');
  return s;
}
