import { useEffect } from 'react';
import type { Session } from './session';

export const SHORTCUTS: [string, string][] = [
  ['Super  (ou Alt+F1)', 'Abrir o menu de aplicativos'],
  ['Super+E  (ou Ctrl+Alt+E)', 'Abrir o gerenciador de arquivos'],
  ['Super+T  (ou Ctrl+Alt+T)', 'Abrir o terminal'],
  ['Super+L  (ou Ctrl+Alt+L)', 'Bloquear a sessão'],
  ['Super+D  (ou Ctrl+Alt+D)', 'Mostrar a área de trabalho'],
  ['Alt+Tab  (ou Alt+`)', 'Alternar entre janelas'],
  ['Super+← / Super+→', 'Encaixar a janela à esquerda/direita'],
  ['Super+↑ / Super+↓', 'Maximizar / minimizar a janela'],
  ['Ctrl+Alt+W', 'Fechar a janela em foco'],
  ['Ctrl+Alt+Delete  (ou Ctrl+Alt+End)', 'Abrir o painel do sistema'],
];

/**
 * Global keyboard shortcuts. Browsers and host operating systems reserve some
 * combinations (e.g. Alt+Tab or Ctrl+Alt+Del on Windows), so each shortcut has
 * an alternative that the page can actually receive.
 */
export function useGlobalShortcuts(session: Session, enabled: boolean): void {
  useEffect(() => {
    if (!enabled) return;
    let metaAlone = false;
    const wm = session.wm;
    const focused = () => wm.state.get().focused;

    const down = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (e.key === 'Meta' || e.key === 'OS') {
        metaAlone = true;
        return;
      }
      metaAlone = false;
      const superMod = e.metaKey;
      const ctrlAlt = e.ctrlKey && e.altKey && !e.metaKey;
      const run = (fn: () => void) => {
        e.preventDefault();
        e.stopPropagation();
        fn();
      };

      if ((superMod || ctrlAlt) && key === 'e') return run(() => session.launch('files'));
      if ((superMod || ctrlAlt) && key === 't') return run(() => session.launch('terminal'));
      if ((superMod || ctrlAlt) && key === 'l') return run(() => session.kernel.users.lock());
      if ((superMod || ctrlAlt) && key === 'd') return run(() => wm.showDesktop());
      if (ctrlAlt && key === 'w') return run(() => {
        const id = focused();
        if (id) session.closeWindow(id);
      });
      if (ctrlAlt && (key === 'delete' || key === 'end')) return run(() => session.panel.set('system'));
      if (e.altKey && key === 'f1') return run(() => session.togglePanel('launcher'));
      if (superMod && ['arrowleft', 'arrowright', 'arrowup', 'arrowdown'].includes(key)) {
        return run(() => {
          const id = focused();
          if (!id) return;
          if (key === 'arrowleft') wm.snap(id, 'left');
          else if (key === 'arrowright') wm.snap(id, 'right');
          else if (key === 'arrowup') {
            if (!wm.get(id)?.maximized) wm.toggleMaximize(id);
          } else wm.minimize(id);
        });
      }
      if (e.altKey && !e.ctrlKey && (key === 'tab' || e.code === 'Backquote')) {
        return run(() => wm.switcherNext(e.shiftKey));
      }
      if (e.key === 'Escape' && wm.state.get().switcher !== null) return run(() => wm.switcherCancel());
    };

    const up = (e: KeyboardEvent) => {
      if (e.key === 'Alt' && wm.state.get().switcher !== null) wm.switcherCommit();
      if ((e.key === 'Meta' || e.key === 'OS') && metaAlone) {
        metaAlone = false;
        session.togglePanel('launcher');
      }
    };
    const blur = () => {
      metaAlone = false;
      if (wm.state.get().switcher !== null) wm.switcherCommit();
    };
    window.addEventListener('keydown', down, true);
    window.addEventListener('keyup', up, true);
    window.addEventListener('blur', blur);
    return () => {
      window.removeEventListener('keydown', down, true);
      window.removeEventListener('keyup', up, true);
      window.removeEventListener('blur', blur);
    };
  }, [session, enabled]);
}
