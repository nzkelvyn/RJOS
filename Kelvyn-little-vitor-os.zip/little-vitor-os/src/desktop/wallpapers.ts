/** Built-in wallpapers: pure CSS, so they cost nothing to download. */
export const WALLPAPERS: { id: string; name: string; css: string }[] = [
  {
    id: 'aurora',
    name: 'Aurora',
    css: 'radial-gradient(1200px 700px at 15% 20%, #5b47e0aa, transparent 60%), radial-gradient(900px 600px at 85% 30%, #0ea5e9aa, transparent 60%), radial-gradient(1000px 700px at 60% 100%, #10b98188, transparent 60%), linear-gradient(160deg, #0b0d1a, #121735 55%, #0b1f2a)',
  },
  {
    id: 'dusk',
    name: 'Crepúsculo',
    css: 'radial-gradient(900px 500px at 70% 75%, #f97316cc, transparent 60%), radial-gradient(1100px 700px at 20% 30%, #be185daa, transparent 65%), linear-gradient(180deg, #1e1b4b, #4c1d95 50%, #9d174d)',
  },
  {
    id: 'forest',
    name: 'Floresta',
    css: 'radial-gradient(1000px 600px at 25% 80%, #15803dbb, transparent 60%), radial-gradient(800px 500px at 80% 20%, #a3e63566, transparent 60%), linear-gradient(170deg, #052e16, #0f3d2e 60%, #134e4a)',
  },
  {
    id: 'ocean',
    name: 'Oceano',
    css: 'radial-gradient(1000px 650px at 80% 85%, #06b6d4bb, transparent 60%), radial-gradient(800px 600px at 10% 10%, #3b82f699, transparent 60%), linear-gradient(200deg, #082f49, #0c4a6e 50%, #164e63)',
  },
  {
    id: 'sunrise',
    name: 'Amanhecer',
    css: 'radial-gradient(900px 500px at 50% 110%, #fde68a, transparent 60%), radial-gradient(1200px 700px at 20% 0%, #93c5fd, transparent 60%), linear-gradient(180deg, #bfdbfe, #fbcfe8 60%, #fed7aa)',
  },
  {
    id: 'graphite',
    name: 'Grafite',
    css: 'radial-gradient(900px 600px at 30% 30%, #ffffff12, transparent 60%), linear-gradient(160deg, #18181b, #27272a 60%, #1f2937)',
  },
];

export function wallpaperCss(id: string): string | null {
  return WALLPAPERS.find((w) => w.id === id)?.css ?? null;
}
