/**
 * Kernel event bus. Every module publishes through here so that the
 * System Monitor and the notification service can observe the system
 * without modules depending on each other directly.
 */
export interface KernelEventMap {
  'fs:change': { path: string; kind: 'create' | 'write' | 'delete' | 'move' | 'chmod' };
  'proc:spawn': { pid: number; name: string };
  'proc:exit': { pid: number; name: string; code: number };
  'user:login': { username: string };
  'user:logout': { username: string };
  'session:lock': Record<string, never>;
  'settings:change': { key: string };
  'pkg:install': { name: string; version: string };
  'pkg:remove': { name: string };
  'net:status': { online: boolean };
  'notify': { id: string };
  'log': { level: 'info' | 'warn' | 'error'; source: string; message: string };
}

export type KernelEvent = keyof KernelEventMap;
type Handler<K extends KernelEvent> = (payload: KernelEventMap[K]) => void;

export interface LoggedEvent {
  at: number;
  type: KernelEvent;
  summary: string;
}

export class EventBus {
  private handlers = new Map<KernelEvent, Set<Handler<KernelEvent>>>();
  private history: LoggedEvent[] = [];
  private readonly historyLimit = 200;

  on<K extends KernelEvent>(type: K, handler: Handler<K>): () => void {
    let set = this.handlers.get(type);
    if (!set) {
      set = new Set();
      this.handlers.set(type, set);
    }
    set.add(handler as Handler<KernelEvent>);
    return () => set!.delete(handler as Handler<KernelEvent>);
  }

  emit<K extends KernelEvent>(type: K, payload: KernelEventMap[K]): void {
    this.history.push({ at: Date.now(), type, summary: summarize(type, payload) });
    if (this.history.length > this.historyLimit) this.history.shift();
    const set = this.handlers.get(type);
    if (!set) return;
    for (const h of [...set]) {
      try {
        (h as Handler<K>)(payload);
      } catch (err) {
        // A failing listener must never break the emitter.
        console.error(`[events] handler for ${type} failed`, err);
      }
    }
  }

  recent(limit = 50): LoggedEvent[] {
    return this.history.slice(-limit).reverse();
  }
}

function summarize(type: KernelEvent, payload: unknown): string {
  const p = payload as Record<string, unknown>;
  switch (type) {
    case 'fs:change':
      return `${p.kind} ${p.path}`;
    case 'proc:spawn':
      return `pid ${p.pid} iniciado (${p.name})`;
    case 'proc:exit':
      return `pid ${p.pid} encerrado (${p.name}) código ${p.code}`;
    case 'pkg:install':
      return `pacote ${p.name}@${p.version} instalado`;
    case 'pkg:remove':
      return `pacote ${p.name} removido`;
    case 'log':
      return `[${p.source}] ${p.message}`;
    default:
      return JSON.stringify(payload);
  }
}
