/** Static OS identity and real browser metrics helpers. */
export const OS_NAME = 'Little Vitor OS';
export const OS_VERSION = '1.0.0';
export const KERNEL_RELEASE = '1.0.0-lvos-web';

export interface MemoryInfo {
  used: number;
  total: number;
  limit: number;
}

/** Real JS heap numbers (Chromium only). Returns null where unavailable. */
export function memoryInfo(): MemoryInfo | null {
  const m = (typeof performance !== 'undefined'
    ? (performance as unknown as { memory?: { usedJSHeapSize: number; totalJSHeapSize: number; jsHeapSizeLimit: number } }).memory
    : undefined);
  if (!m) return null;
  return { used: m.usedJSHeapSize, total: m.totalJSHeapSize, limit: m.jsHeapSizeLimit };
}
