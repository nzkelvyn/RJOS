import { NetworkManager } from '../core/network/network';
import { NotificationService } from '../core/notifications/notifications';
import { PackageManager } from '../core/packages/lvp';
import { ProcessManager } from '../core/process/processManager';
import { SettingsService } from '../core/settings/settings';
import { UserManager } from '../core/users/userManager';
import { MemoryBackend } from '../core/vfs/backends/memory';
import { ROOT_CREDS, type StorageBackend } from '../core/vfs/types';
import { VFS } from '../core/vfs/vfs';
import { EventBus } from './events';
import { KERNEL_RELEASE, OS_NAME, OS_VERSION, memoryInfo } from './info';
import { installBinStubs } from '../core/shell/commands';

export { KERNEL_RELEASE, OS_NAME, OS_VERSION, memoryInfo };
export type { MemoryInfo } from './info';


export interface BootStep {
  id: string;
  label: string;
}

export const BOOT_STEPS: BootStep[] = [
  { id: 'vfs', label: 'Montando sistema de arquivos virtual' },
  { id: 'fhs', label: 'Verificando hierarquia de diretórios' },
  { id: 'proc', label: 'Iniciando gerenciador de processos' },
  { id: 'users', label: 'Carregando contas de usuário' },
  { id: 'settings', label: 'Lendo configurações do sistema' },
  { id: 'net', label: 'Iniciando gerenciador de rede' },
  { id: 'notify', label: 'Iniciando serviço de notificações' },
  { id: 'lvp', label: 'Carregando gerenciador de pacotes LVP' },
];

const FHS = ['bin', 'boot', 'dev', 'etc', 'home', 'lib', 'media', 'mnt', 'opt', 'proc', 'root', 'run', 'sbin', 'tmp', 'usr', 'usr/bin', 'usr/share', 'var', 'var/log', 'var/lib'];

/**
 * The kernel wires every module together. Each module only depends on the
 * EventBus and the modules explicitly passed to it.
 */
export class Kernel {
  readonly events = new EventBus();
  readonly vfs: VFS;
  readonly procs: ProcessManager;
  readonly users: UserManager;
  readonly settings: SettingsService;
  readonly net: NetworkManager;
  readonly notifications: NotificationService;
  readonly lvp: PackageManager;
  freshInstall = false;
  booted = false;

  constructor(backend: StorageBackend = new MemoryBackend()) {
    this.vfs = new VFS(backend, this.events);
    this.procs = new ProcessManager(this.events);
    this.users = new UserManager(this.vfs, this.events);
    this.vfs.setCredentialsProvider(() => this.users.credentials());
    this.settings = new SettingsService(this.vfs, this.events);
    this.net = new NetworkManager(this.events);
    this.notifications = new NotificationService(this.events);
    this.lvp = new PackageManager(this.vfs, this.events, () => this.users.isAdmin());
  }

  private bootPromise: Promise<void> | null = null;
  private stepListeners = new Set<(step: BootStep, index: number) => void>();

  /** Boots once; later calls (e.g. React StrictMode re-running effects) share the same promise. */
  boot(onStep?: (step: BootStep, index: number) => void): Promise<void> {
    if (onStep) this.stepListeners.add(onStep);
    return (this.bootPromise ??= this.doBoot());
  }

  private async doBoot(): Promise<void> {
    const step = (i: number) => this.stepListeners.forEach((l) => l(BOOT_STEPS[i], i));

    step(0);
    this.freshInstall = await this.vfs.mount();

    step(1);
    for (const d of FHS) await this.vfs.mkdir('/' + d, { parents: true }, ROOT_CREDS);
    await this.vfs.chmod('/tmp', 0o1777, ROOT_CREDS); // sticky + world writable, like Linux
    await this.vfs.chmod('/root', 0o700, ROOT_CREDS);
    if (!this.vfs.exists('/etc/os-release')) {
      await this.vfs.writeFile('/etc/os-release',
        `NAME="${OS_NAME}"\nVERSION="${OS_VERSION}"\nID=littlevitor\nPRETTY_NAME="${OS_NAME} ${OS_VERSION}"\nHOME_URL="about:blank"\n`,
        { mode: 0o644 }, ROOT_CREDS);
      await this.vfs.writeFile('/etc/motd',
        `Bem-vindo ao ${OS_NAME}!\nDigite "help" para ver os comandos disponíveis.\n`, { mode: 0o644 }, ROOT_CREDS);
      await this.vfs.writeFile('/boot/README',
        'O Little Vitor OS roda no navegador: não há kernel Linux real nem bootloader.\nEste diretório existe para manter a hierarquia FHS.\n',
        { mode: 0o644 }, ROOT_CREDS);
    }
    await installBinStubs(this.vfs);
    await this.registerVirtualFiles();

    step(2);
    const sys = (name: string) => this.procs.spawn({ ppid: 0, name, command: name, user: 'root', kind: 'system' });
    sys('init');
    for (const s of ['lvos-vfsd', 'lvos-wm', 'lvos-notifyd', 'lvos-netd', 'lvp-daemon']) {
      this.procs.spawn({ ppid: 1, name: s, command: '/sbin/' + s, user: 'root', kind: 'system' });
    }

    step(3);
    await this.users.bootstrap();

    step(4);
    const system = await this.settings.loadSystem();
    if (!this.vfs.exists('/etc/hostname') || this.freshInstall) {
      await this.vfs.writeFile('/etc/hostname', system.hostname + '\n', { mode: 0o644 }, ROOT_CREDS);
    }

    step(5);
    step(6);
    step(7);
    try {
      await this.lvp.init();
    } catch (err) {
      this.events.emit('log', { level: 'error', source: 'lvp', message: (err as Error).message });
    }
    this.booted = true;
  }

  private async registerVirtualFiles(): Promise<void> {
    const v = this.vfs;
    await v.registerVirtual('/dev/null', { read: () => '', write: () => {} }, 0o666);
    await v.registerVirtual('/dev/zero', { read: () => new Uint8Array(1024) }, 0o666);
    await v.registerVirtual('/dev/random', { read: () => crypto.getRandomValues(new Uint8Array(512)) }, 0o444);
    await v.registerVirtual('/dev/urandom', { read: () => crypto.getRandomValues(new Uint8Array(512)) }, 0o444);
    await v.registerVirtual('/proc/uptime', { read: () => `${(this.procs.uptimeMs() / 1000).toFixed(2)}\n` });
    await v.registerVirtual('/proc/version', {
      read: () => `${OS_NAME} version ${KERNEL_RELEASE} (navegador: ${typeof navigator !== 'undefined' ? navigator.userAgent : 'node'})\n`,
    });
    await v.registerVirtual('/proc/cpuinfo', {
      read: () => {
        const n = typeof navigator !== 'undefined' ? navigator.hardwareConcurrency || 1 : 1;
        return Array.from({ length: n }, (_, i) => `processor\t: ${i}\nmodel name\t: núcleo lógico informado pelo navegador\n`).join('\n');
      },
    });
    await v.registerVirtual('/proc/meminfo', {
      read: () => {
        const m = memoryInfo();
        return m
          ? `JSHeapTotal:\t${Math.round(m.total / 1024)} kB\nJSHeapUsed:\t${Math.round(m.used / 1024)} kB\nJSHeapLimit:\t${Math.round(m.limit / 1024)} kB\n`
          : 'Memória: o navegador não expõe essa medição (somente Chromium tem performance.memory)\n';
      },
    });
    await v.registerVirtual('/proc/loadavg', { read: () => 'indisponível no navegador\n' });
  }

  /** Called after a successful login/unlock. Loads per-user state. */
  async startSession(): Promise<void> {
    const u = this.users.current;
    if (!u) return;
    const s = await this.settings.loadUser(u.home, this.users.credentials());
    this.notifications.setDnd(s.notificationsDnd);
    this.notifications.setMuted(s.mutedApps);
  }

  async endSession(): Promise<void> {
    await this.settings.flush();
    this.settings.unloadUser();
    this.users.logout();
  }

  /** Factory reset: wipes the persistent storage. */
  async factoryReset(): Promise<void> {
    await this.vfs.format();
    try {
      localStorage.removeItem('lvos:theme');
      localStorage.removeItem('lvos:last-user');
      sessionStorage.clear();
    } catch {
      /* ignore */
    }
  }
}

