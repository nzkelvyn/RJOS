/**
 * Minimal observable store. Framework-agnostic so core modules stay testable
 * in Node; React binds to it via useSyncExternalStore (see ui/hooks.ts).
 */
export class Store<T> {
  private listeners = new Set<() => void>();
  constructor(private state: T) {}

  get = (): T => this.state;

  set = (next: T | ((prev: T) => T)): void => {
    const value = typeof next === 'function' ? (next as (p: T) => T)(this.state) : next;
    if (Object.is(value, this.state)) return;
    this.state = value;
    for (const l of [...this.listeners]) l();
  };

  subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  };
}
