import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './App';
import { Kernel } from './kernel/kernel';
import { IndexedDBBackend } from './core/vfs/backends/indexeddb';
import { MemoryBackend } from './core/vfs/backends/memory';
import type { StorageBackend } from './core/vfs/types';
import './styles.css';

async function pickBackend(): Promise<StorageBackend> {
  try {
    if (typeof indexedDB === 'undefined') throw new Error('IndexedDB indisponível');
    const b = new IndexedDBBackend(true);
    await b.init();
    return b;
  } catch (err) {
    // Private windows in some browsers block IndexedDB: run in memory and say so.
    console.warn('[lvos] usando armazenamento em memória:', err);
    const m = new MemoryBackend();
    (m as { kind: string }).kind = 'memory (não persistente)';
    return m;
  }
}

async function start() {
  const backend = await pickBackend();
  const kernel = new Kernel(backend);
  // expose for debugging in DevTools: window.lvos.kernel
  (window as unknown as { lvos: { kernel: Kernel } }).lvos = { kernel };
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App kernel={kernel} />
    </StrictMode>,
  );
}

void start();
