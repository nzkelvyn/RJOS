import { useEffect, useState } from 'react';
import type { Kernel } from '../kernel/kernel';
import { mimeFor } from '../core/vfs/mime';

/** Loads a VFS file as an object URL (revoked automatically). */
export function useFileUrl(kernel: Kernel, path: string | null | undefined, version = 0): { url: string | null; error: string | null; loading: boolean } {
  const [state, setState] = useState<{ url: string | null; error: string | null; loading: boolean }>({ url: null, error: null, loading: !!path });
  useEffect(() => {
    if (!path) {
      setState({ url: null, error: null, loading: false });
      return;
    }
    let url: string | null = null;
    let alive = true;
    setState((s) => ({ ...s, loading: true, error: null }));
    kernel.vfs
      .readFile(path)
      .then((data) => {
        if (!alive) return;
        url = URL.createObjectURL(new Blob([data as BlobPart], { type: kernel.vfs.stat(path).mime ?? mimeFor(path) }));
        setState({ url, error: null, loading: false });
      })
      .catch((err: Error) => alive && setState({ url: null, error: err.message, loading: false }));
    return () => {
      alive = false;
      if (url) URL.revokeObjectURL(url);
    };
  }, [kernel, path, version]);
  return state;
}

/** Triggers a browser download of a VFS file (export to the real computer). */
export async function downloadFile(kernel: Kernel, path: string): Promise<void> {
  const data = await kernel.vfs.readFile(path);
  const blob = new Blob([data as BlobPart], { type: kernel.vfs.stat(path).mime ?? 'application/octet-stream' });
  downloadBlob(blob, path.slice(path.lastIndexOf('/') + 1));
}

export function downloadBlob(blob: Blob, name: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

const MAX_IMPORT = 200 * 1024 * 1024;

/**
 * Imports files chosen by the user from the real computer into a VFS folder.
 * Only files the user explicitly picked/dropped are read (browser security model).
 */
export async function importFiles(kernel: Kernel, files: FileList | File[], dir: string): Promise<{ imported: string[]; rejected: string[] }> {
  const imported: string[] = [];
  const rejected: string[] = [];
  for (const f of Array.from(files)) {
    const safeName = f.name.replace(/[/\0]/g, '_').slice(0, 255) || 'arquivo';
    if (f.size > MAX_IMPORT) {
      rejected.push(`${f.name} (maior que 200 MB)`);
      continue;
    }
    try {
      const target = kernel.vfs.uniquePath(`${dir === '/' ? '' : dir}/${safeName}`);
      await kernel.vfs.writeFile(target, new Uint8Array(await f.arrayBuffer()));
      imported.push(target);
    } catch (err) {
      rejected.push(`${f.name} (${(err as Error).message})`);
    }
  }
  return { imported, rejected };
}

export function pickFiles(accept?: string, multiple = true): Promise<FileList | null> {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = multiple;
    if (accept) input.accept = accept;
    input.onchange = () => resolve(input.files);
    input.oncancel = () => resolve(null);
    input.click();
  });
}
