import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { Icon, type IconName } from './icons';

export function cx(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(' ');
}

export function Toggle({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label?: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className="relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors disabled:opacity-40"
      style={{ background: checked ? 'var(--accent)' : 'var(--surface-3)', border: '1px solid var(--line)' }}
    >
      <span
        className="inline-block h-[18px] w-[18px] rounded-full bg-white shadow transition-transform"
        style={{ transform: `translateX(${checked ? 22 : 3}px)` }}
      />
    </button>
  );
}

export function Segmented<T extends string>({ value, options, onChange }: { value: T; options: { value: T; label: string; icon?: IconName }[]; onChange: (v: T) => void }) {
  return (
    <div className="inline-flex rounded-lg border border-line bg-surface-2 p-0.5">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cx('flex h-7 items-center gap-1.5 rounded-md px-3 text-[0.9rem]', o.value === value ? 'bg-accent text-accent-fg' : 'hover:bg-hover')}
        >
          {o.icon && <Icon name={o.icon} size={15} />}
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Spinner({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className="animate-spin" aria-label="Carregando">
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeOpacity="0.2" strokeWidth="3" />
      <path d="M21 12a9 9 0 0 0-9-9" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function Empty({ icon, title, children }: { icon: IconName; title: string; children?: ReactNode }) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-2 p-6 text-center text-muted">
      <Icon name={icon} size={40} strokeWidth={1.4} />
      <div className="text-[1.05rem] font-medium text-fg">{title}</div>
      {children && <div className="max-w-sm text-[0.9rem]">{children}</div>}
    </div>
  );
}

export interface MenuItem {
  label?: string;
  icon?: IconName;
  shortcut?: string;
  disabled?: boolean;
  danger?: boolean;
  separator?: boolean;
  onClick?: () => void;
}

/** Context menu positioned at (x, y), kept inside the viewport. */
export function ContextMenu({ x, y, items, onClose }: { x: number; y: number; items: MenuItem[]; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x, y });
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setPos({
      x: Math.max(4, Math.min(x, window.innerWidth - r.width - 4)),
      y: Math.max(4, Math.min(y, window.innerHeight - r.height - 4)),
    });
  }, [x, y]);
  useEffect(() => {
    const down = (e: PointerEvent) => {
      if (!ref.current?.contains(e.target as Node)) onClose();
    };
    const key = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('pointerdown', down, true);
    window.addEventListener('keydown', key);
    window.addEventListener('blur', onClose);
    return () => {
      window.removeEventListener('pointerdown', down, true);
      window.removeEventListener('keydown', key);
      window.removeEventListener('blur', onClose);
    };
  }, [onClose]);
  return (
    <div ref={ref} role="menu" className="menu pop-in fixed z-[10000]" style={{ left: pos.x, top: pos.y }} onContextMenu={(e) => e.preventDefault()}>
      {items.map((it, i) =>
        it.separator ? (
          <div key={i} className="menu-sep" />
        ) : (
          <button
            key={i}
            role="menuitem"
            className="menu-item"
            disabled={it.disabled}
            style={it.danger ? { color: 'var(--danger)' } : undefined}
            onClick={() => {
              onClose();
              it.onClick?.();
            }}
          >
            <span className="w-4 shrink-0">{it.icon && <Icon name={it.icon} size={16} />}</span>
            <span className="flex-1">{it.label}</span>
            {it.shortcut && <span className="text-[0.75rem] opacity-60">{it.shortcut}</span>}
          </button>
        ),
      )}
    </div>
  );
}

/** Hook helper for components that open a context menu. */
export function useContextMenu() {
  const [menu, setMenu] = useState<{ x: number; y: number; items: MenuItem[] } | null>(null);
  return {
    open: (e: { clientX: number; clientY: number; preventDefault: () => void; stopPropagation?: () => void }, items: MenuItem[]) => {
      e.preventDefault();
      e.stopPropagation?.();
      setMenu({ x: e.clientX, y: e.clientY, items });
    },
    element: menu ? <ContextMenu {...menu} onClose={() => setMenu(null)} /> : null,
  };
}

export function Toolbar({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cx('flex h-11 shrink-0 items-center gap-1 border-b border-line bg-surface-2 px-2', className)}>{children}</div>;
}

export function ToolButton({ icon, label, onClick, disabled, active }: { icon: IconName; label: string; onClick?: () => void; disabled?: boolean; active?: boolean }) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
      className={cx('btn btn-ghost btn-icon', active && 'bg-hover text-accent')}
    >
      <Icon name={icon} size={17} />
    </button>
  );
}

export function SettingRow({ title, desc, children }: { title: string; desc?: ReactNode; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-line py-3 last:border-b-0">
      <div className="min-w-0">
        <div className="text-[0.95rem]">{title}</div>
        {desc && <div className="text-[0.82rem] text-muted">{desc}</div>}
      </div>
      <div className="flex shrink-0 items-center gap-2">{children}</div>
    </div>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cx('rounded-xl border border-line bg-surface-2 px-4', className)}>{children}</div>;
}

export function Badge({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'neutral' | 'accent' | 'warn' | 'ok' | 'danger' }) {
  const colors = {
    neutral: 'var(--surface-3)',
    accent: 'color-mix(in oklab, var(--accent) 30%, transparent)',
    warn: 'color-mix(in oklab, var(--warning) 28%, transparent)',
    ok: 'color-mix(in oklab, var(--success) 28%, transparent)',
    danger: 'color-mix(in oklab, var(--danger) 28%, transparent)',
  };
  return <span className="inline-flex items-center rounded-md px-1.5 py-0.5 text-[0.72rem] font-medium" style={{ background: colors[tone] }}>{children}</span>;
}

export function formatDate(ts: number): string {
  return new Date(ts).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
