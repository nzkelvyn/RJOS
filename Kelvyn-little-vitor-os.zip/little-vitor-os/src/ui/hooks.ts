import { createContext, useContext, useEffect, useRef, useState, useSyncExternalStore } from 'react';
import type { Kernel } from '../kernel/kernel';
import type { Store } from '../kernel/store';
import type { KernelEvent, KernelEventMap } from '../kernel/events';

export const KernelContext = createContext<Kernel | null>(null);

export function useKernel(): Kernel {
  const k = useContext(KernelContext);
  if (!k) throw new Error('KernelContext ausente');
  return k;
}

export function useStore<T>(store: Store<T>): T {
  return useSyncExternalStore(store.subscribe, store.get, store.get);
}

export function useKernelEvent<K extends KernelEvent>(type: K, handler: (p: KernelEventMap[K]) => void): void {
  const k = useKernel();
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => k.events.on(type, (p) => ref.current(p)), [k, type]);
}

/** Re-renders whenever the file system changes under `path` (or anywhere when omitted). */
export function useFsVersion(path?: string): number {
  const [v, setV] = useState(0);
  useKernelEvent('fs:change', (e) => {
    if (!path || e.path === path || e.path.startsWith(path === '/' ? '/' : path + '/') || path.startsWith(e.path + '/')) {
      setV((x) => x + 1);
    }
  });
  return v;
}

export function useNow(intervalMs = 1000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

export function useInterval(fn: () => void, ms: number | null): void {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    if (ms === null) return;
    const t = setInterval(() => ref.current(), ms);
    return () => clearInterval(t);
  }, [ms]);
}

/** Closes popovers when clicking outside of `ref` or pressing Escape. */
export function useDismiss(ref: React.RefObject<HTMLElement | null>, open: boolean, onClose: () => void): void {
  useEffect(() => {
    if (!open) return;
    const down = (e: PointerEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    const t = setTimeout(() => window.addEventListener('pointerdown', down, true), 0);
    window.addEventListener('keydown', key);
    return () => {
      clearTimeout(t);
      window.removeEventListener('pointerdown', down, true);
      window.removeEventListener('keydown', key);
    };
  }, [open, onClose, ref]);
}

export function useMediaQuery(q: string): boolean {
  const get = () => (typeof window !== 'undefined' ? window.matchMedia(q).matches : false);
  const [m, setM] = useState(get);
  useEffect(() => {
    const mq = window.matchMedia(q);
    const fn = () => setM(mq.matches);
    mq.addEventListener('change', fn);
    return () => mq.removeEventListener('change', fn);
  }, [q]);
  return m;
}

export function useIsMobile(): boolean {
  return useMediaQuery('(max-width: 720px), (pointer: coarse) and (max-width: 900px)');
}
