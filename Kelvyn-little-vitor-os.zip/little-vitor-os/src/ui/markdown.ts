import DOMPurify from 'dompurify';

function escape(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
}

function inline(s: string): string {
  return escape(s)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*])\*([^*]+)\*/g, '$1<em>$2</em>')
    .replace(/~~([^~]+)~~/g, '<del>$1</del>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
}

/**
 * Small Markdown renderer (headings, lists, task lists, code blocks, quotes,
 * links, emphasis). Output is always passed through DOMPurify (XSS protection).
 */
export function renderMarkdown(src: string): string {
  const out: string[] = [];
  let list: 'ul' | 'ol' | null = null;
  let code = false;
  const closeList = () => {
    if (list) out.push(`</${list}>`);
    list = null;
  };
  for (const line of src.split('\n')) {
    if (line.startsWith('```')) {
      closeList();
      out.push(code ? '</code></pre>' : '<pre><code>');
      code = !code;
      continue;
    }
    if (code) {
      out.push(escape(line));
      continue;
    }
    const h = /^(#{1,6})\s+(.*)/.exec(line);
    const ul = /^\s*[-*+]\s+(.*)/.exec(line);
    const ol = /^\s*\d+[.)]\s+(.*)/.exec(line);
    if (h) {
      closeList();
      out.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`);
    } else if (ul || ol) {
      const kind = ul ? 'ul' : 'ol';
      if (list !== kind) {
        closeList();
        out.push(`<${kind}>`);
        list = kind;
      }
      let item = (ul ?? ol)![1];
      const task = /^\[( |x)\]\s+(.*)/i.exec(item);
      if (task) item = `<input type="checkbox" disabled ${task[1].toLowerCase() === 'x' ? 'checked' : ''}>${inline(task[2])}`;
      else item = inline(item);
      out.push(`<li>${item}</li>`);
    } else if (line.startsWith('>')) {
      closeList();
      out.push(`<blockquote>${inline(line.replace(/^>\s?/, ''))}</blockquote>`);
    } else if (/^---+$/.test(line.trim())) {
      closeList();
      out.push('<hr>');
    } else if (line.trim()) {
      closeList();
      out.push(`<p>${inline(line)}</p>`);
    } else closeList();
  }
  closeList();
  if (code) out.push('</code></pre>');
  return DOMPurify.sanitize(out.join('\n'), { ADD_ATTR: ['target'] });
}
