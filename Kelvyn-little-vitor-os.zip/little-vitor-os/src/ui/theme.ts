import { useEffect } from 'react';
import type { UserSettings } from '../core/settings/settings';
import { useMediaQuery } from './hooks';

/** Picks black or white text for a given accent color (WCAG relative luminance). */
export function contrastText(hex: string): string {
  const n = parseInt(hex.slice(1), 16);
  const ch = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  });
  const L = 0.2126 * ch[0] + 0.7152 * ch[1] + 0.0722 * ch[2];
  return L > 0.45 ? '#111318' : '#ffffff';
}

export function useApplyTheme(s: Pick<UserSettings, 'theme' | 'accent' | 'fontScale' | 'highContrast' | 'transparency' | 'animations' | 'reduceMotion'>): void {
  const prefersDark = useMediaQuery('(prefers-color-scheme: dark)');
  const systemReduce = useMediaQuery('(prefers-reduced-motion: reduce)');
  useEffect(() => {
    const root = document.documentElement;
    const theme = s.theme === 'auto' ? (prefersDark ? 'dark' : 'light') : s.theme;
    root.dataset.theme = theme;
    root.dataset.contrast = s.highContrast ? 'high' : 'normal';
    root.dataset.transparency = s.transparency ? 'on' : 'off';
    root.style.setProperty('--accent', s.accent);
    root.style.setProperty('--accent-fg', contrastText(s.accent));
    root.style.setProperty('--font-scale', String(s.fontScale));
    document.body.classList.toggle('anim', s.animations && !s.reduceMotion && !systemReduce);
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#0f1117' : '#e9ecf3');
  }, [s.theme, s.accent, s.fontScale, s.highContrast, s.transparency, s.animations, s.reduceMotion, prefersDark, systemReduce]);
}

/** Theme cached in localStorage so the boot screen matches the last session. */
export function cachedTheme(): { theme: UserSettings['theme']; accent: string } {
  try {
    const v = JSON.parse(localStorage.getItem('lvos:theme') ?? 'null');
    if (v && typeof v.accent === 'string' && /^#[0-9a-f]{6}$/i.test(v.accent) && ['light', 'dark', 'auto'].includes(v.theme)) return v;
  } catch {
    /* ignore */
  }
  return { theme: 'dark', accent: '#7c6cff' };
}
