import { Component, Suspense, useCallback, useRef, useState, type ErrorInfo, type ReactNode } from 'react';
import { getApp, packageApp } from '../apps/registry';
import { useSession } from '../desktop/sessionContext';
import { useKernel } from '../ui/hooks';
import { AppIcon, Icon } from '../ui/icons';
import { Spinner } from '../ui/components';
import type { WindowState } from './windowManager';

type Edge = 'n' | 's' | 'e' | 'w' | 'ne' | 'nw' | 'se' | 'sw';

class AppErrorBoundary extends Component<{ children: ReactNode; onError: (e: Error) => void }, { error: Error | null }> {
  override state: { error: Error | null } = { error: null };
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  override componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('[app crash]', error, info.componentStack);
    this.props.onError(error);
  }
  override render() {
    if (this.state.error) {
      return (
        <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center">
          <Icon name="alert" size={36} style={{ color: 'var(--warning)' }} />
          <div className="font-medium">O aplicativo parou de responder</div>
          <code className="selectable max-w-full overflow-auto rounded bg-surface-3 px-2 py-1 text-[0.8rem] text-muted">{this.state.error.message}</code>
          <button className="btn" onClick={() => this.setState({ error: null })}>Tentar novamente</button>
        </div>
      );
    }
    return this.props.children;
  }
}

export function WindowFrame({ win, focused, mobile }: { win: WindowState; focused: boolean; mobile: boolean }) {
  const session = useSession();
  const kernel = useKernel();
  const wm = session.wm;
  const [snapHint, setSnapHint] = useState<'left' | 'right' | 'max' | null>(null);
  const [dragging, setDragging] = useState(false);
  const frameRef = useRef<HTMLDivElement>(null);

  let app = getApp(win.appId);
  if (!app && win.appId.startsWith('pkg:')) {
    const pkg = kernel.lvp.getInstalled(win.appId.slice(4));
    if (pkg) app = packageApp(pkg);
  }
  const AppComponent = app?.component;

  const onTitlePointerDown = useCallback(
    (e: React.PointerEvent) => {
      if (mobile || e.button !== 0 || (e.target as HTMLElement).closest('button')) return;
      wm.focus(win.id);
      const startX = e.clientX;
      const startY = e.clientY;
      let current = wm.get(win.id)!;
      let offsetX = startX - current.x;
      const offsetY = startY - current.y;
      let moved = false;
      const target = e.currentTarget as HTMLElement;
      target.setPointerCapture(e.pointerId);
      const move = (ev: PointerEvent) => {
        if (!moved && Math.hypot(ev.clientX - startX, ev.clientY - startY) < 4) return;
        if (!moved) {
          moved = true;
          setDragging(true);
          current = wm.get(win.id)!;
          if (current.maximized || current.snapped) {
            // keep the pointer at the same relative spot of the restored title bar
            const restoreW = current.restore?.w ?? current.w;
            offsetX = Math.min(restoreW - 60, Math.max(60, (offsetX / current.w) * restoreW));
          }
        }
        wm.move(win.id, ev.clientX - offsetX, ev.clientY - offsetY);
        const v = wm.viewport;
        setSnapHint(ev.clientY <= v.top + 2 ? 'max' : ev.clientX <= 4 ? 'left' : ev.clientX >= v.width - 4 ? 'right' : null);
      };
      const up = (ev: PointerEvent) => {
        target.releasePointerCapture(e.pointerId);
        target.removeEventListener('pointermove', move);
        target.removeEventListener('pointerup', up);
        target.removeEventListener('pointercancel', up);
        setDragging(false);
        const v = wm.viewport;
        if (moved) {
          if (ev.clientY <= v.top + 2) wm.toggleMaximize(win.id);
          else if (ev.clientX <= 4) wm.snap(win.id, 'left');
          else if (ev.clientX >= v.width - 4) wm.snap(win.id, 'right');
        }
        setSnapHint(null);
      };
      target.addEventListener('pointermove', move);
      target.addEventListener('pointerup', up);
      target.addEventListener('pointercancel', up);
    },
    [mobile, wm, win.id],
  );

  const onResizeDown = (edge: Edge) => (e: React.PointerEvent) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    wm.focus(win.id);
    const start = { x: e.clientX, y: e.clientY };
    const g = { ...wm.get(win.id)! };
    const target = e.currentTarget as HTMLElement;
    target.setPointerCapture(e.pointerId);
    setDragging(true);
    const move = (ev: PointerEvent) => {
      const dx = ev.clientX - start.x;
      const dy = ev.clientY - start.y;
      const r = { x: g.x, y: g.y, w: g.w, h: g.h };
      if (edge.includes('e')) r.w = g.w + dx;
      if (edge.includes('s')) r.h = g.h + dy;
      if (edge.includes('w')) {
        r.w = g.w - dx;
        r.x = g.x + dx;
      }
      if (edge.includes('n')) {
        r.h = g.h - dy;
        r.y = Math.max(wm.viewport.top, g.y + dy);
        if (r.y === wm.viewport.top) r.h = g.h + (g.y - wm.viewport.top);
      }
      wm.resize(win.id, r);
    };
    const up = () => {
      target.removeEventListener('pointermove', move);
      target.removeEventListener('pointerup', up);
      setDragging(false);
    };
    target.addEventListener('pointermove', move);
    target.addEventListener('pointerup', up);
  };

  const v = wm.viewport;
  const geom = mobile
    ? { left: 0, top: v.top, width: v.width, height: v.height - v.top - v.bottom }
    : { left: win.x, top: win.y, width: win.w, height: win.h };
  const hidden = win.minimized || (mobile && !focused);
  const animate = !dragging && !win.opening;

  return (
    <>
      {snapHint && (
        <div
          className="snap-preview"
          style={
            snapHint === 'max'
              ? { left: 6, top: v.top + 6, width: v.width - 12, height: v.height - v.top - v.bottom - 12 }
              : { left: snapHint === 'left' ? 6 : v.width / 2 + 3, top: v.top + 6, width: v.width / 2 - 9, height: v.height - v.top - v.bottom - 12 }
          }
        />
      )}
      <div
        ref={frameRef}
        className={['window', win.opening && 'window-open', win.closing && 'window-close', animate && 'window-geom'].filter(Boolean).join(' ')}
        data-focused={focused}
        data-maximized={win.maximized || mobile}
        data-window-id={win.id}
        data-app={win.appId}
        role="dialog"
        aria-label={win.title}
        style={{ ...geom, zIndex: win.z, display: hidden ? 'none' : 'flex' }}
        onPointerDownCapture={() => !focused && wm.focus(win.id)}
      >
        <div className="window-titlebar" onPointerDown={onTitlePointerDown} onDoubleClick={(e) => !mobile && !(e.target as HTMLElement).closest('button') && wm.toggleMaximize(win.id)}>
          <AppIcon icon={win.icon} color={win.color} emoji={win.emoji} size={20} />
          <div className="min-w-0 flex-1 truncate text-[0.9rem] font-medium" data-testid="window-title">{win.title}</div>
          {!mobile && (
            <>
              <button className="win-btn" aria-label="Minimizar" title="Minimizar" onClick={() => wm.minimize(win.id)}>
                <Icon name="minus" size={15} />
              </button>
              <button className="win-btn" aria-label={win.maximized ? 'Restaurar' : 'Maximizar'} title={win.maximized ? 'Restaurar' : 'Maximizar'} onClick={() => wm.toggleMaximize(win.id)}>
                <Icon name={win.maximized || win.snapped ? 'restore' : 'square'} size={13} />
              </button>
            </>
          )}
          <button className="win-btn close" aria-label="Fechar" title="Fechar" onClick={() => session.closeWindow(win.id)}>
            <Icon name="x" size={15} />
          </button>
        </div>
        <div className="relative min-h-0 flex-1 overflow-hidden" style={{ pointerEvents: dragging ? 'none' : undefined }}>
          <AppErrorBoundary onError={(err) => kernel.notifications.push({ app: win.appId, appName: win.title, title: `${win.title} encontrou um erro`, body: err.message, level: 'error' })}>
            <Suspense fallback={<div className="grid h-full place-items-center text-muted"><Spinner /></div>}>
              {AppComponent ? <AppComponent windowId={win.id} args={win.args} /> : <div className="p-6 text-muted">Aplicativo indisponível: {win.appId}</div>}
            </Suspense>
          </AppErrorBoundary>
        </div>
        {!mobile && !win.maximized && (
          <>
            {(['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw'] as Edge[]).map((edge) => (
              <div key={edge} className="resize-handle" onPointerDown={onResizeDown(edge)} style={handleStyle(edge)} />
            ))}
          </>
        )}
      </div>
    </>
  );
}

function handleStyle(edge: Edge): React.CSSProperties {
  const s = 6;
  const c = 12;
  const cursor = { n: 'ns-resize', s: 'ns-resize', e: 'ew-resize', w: 'ew-resize', ne: 'nesw-resize', sw: 'nesw-resize', nw: 'nwse-resize', se: 'nwse-resize' }[edge];
  const base: React.CSSProperties = { cursor };
  if (edge === 'n') return { ...base, top: -2, left: c, right: c, height: s };
  if (edge === 's') return { ...base, bottom: -2, left: c, right: c, height: s };
  if (edge === 'e') return { ...base, right: -2, top: c, bottom: c, width: s };
  if (edge === 'w') return { ...base, left: -2, top: c, bottom: c, width: s };
  return {
    ...base,
    width: c,
    height: c,
    ...(edge.includes('n') ? { top: -2 } : { bottom: -2 }),
    ...(edge.includes('w') ? { left: -2 } : { right: -2 }),
  };
}
