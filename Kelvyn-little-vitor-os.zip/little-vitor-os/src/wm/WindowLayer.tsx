import { useSession } from '../desktop/sessionContext';
import { useStore } from '../ui/hooks';
import { AppIcon } from '../ui/icons';
import { WindowFrame } from './WindowFrame';

export function WindowLayer({ mobile }: { mobile: boolean }) {
  const session = useSession();
  const state = useStore(session.wm.state);
  return (
    <div className="pointer-events-none absolute inset-0" style={{ zIndex: 20 }}>
      <div className="pointer-events-auto">
        {state.windows.map((w) => (
          <WindowFrame key={w.id} win={w} focused={state.focused === w.id} mobile={mobile} />
        ))}
      </div>
    </div>
  );
}

/** Alt+Tab overlay. */
export function WindowSwitcher() {
  const session = useSession();
  const state = useStore(session.wm.state);
  if (state.switcher === null) return null;
  const list = session.wm.mruOrder();
  if (!list.length) return null;
  return (
    <div className="pointer-events-none fixed inset-0 z-[9500] grid place-items-center">
      <div className="glass pop-in flex max-w-[90vw] flex-wrap justify-center gap-2 rounded-2xl border border-line p-3 shadow-2xl" role="listbox" aria-label="Alternar janelas">
        {list.map((w, i) => (
          <div
            key={w.id}
            role="option"
            aria-selected={i === state.switcher}
            className="flex w-28 flex-col items-center gap-2 rounded-xl p-3"
            style={{ background: i === state.switcher ? 'color-mix(in oklab, var(--accent) 30%, transparent)' : undefined }}
          >
            <AppIcon icon={w.icon} color={w.color} emoji={w.emoji} size={48} />
            <div className="w-full truncate text-center text-[0.8rem]">{w.title}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
