import { Store } from '../kernel/store';

export type Snap = 'left' | 'right' | null;

export interface WindowState {
  id: string;
  appId: string;
  title: string;
  icon: string;
  color: string;
  emoji?: string;
  x: number;
  y: number;
  w: number;
  h: number;
  minW: number;
  minH: number;
  z: number;
  minimized: boolean;
  maximized: boolean;
  snapped: Snap;
  /** geometry to restore after maximize/snap */
  restore: { x: number; y: number; w: number; h: number } | null;
  args: Record<string, string>;
  pid: number | null;
  /** true while the open animation runs */
  opening: boolean;
  closing: boolean;
}

export interface Viewport {
  width: number;
  height: number;
  /** space reserved by the top bar */
  top: number;
  /** space reserved by the dock */
  bottom: number;
  left: number;
}

export interface WMState {
  windows: WindowState[];
  focused: string | null;
  /** Alt+Tab overlay: index into the MRU list, or null when hidden */
  switcher: number | null;
  /** windows hidden by "show desktop" (restored on the next toggle) */
  shownDesktop: string[] | null;
}

export interface OpenOptions {
  appId: string;
  title: string;
  icon: string;
  color: string;
  emoji?: string;
  width?: number;
  height?: number;
  minWidth?: number;
  minHeight?: number;
  args?: Record<string, string>;
  pid?: number | null;
}

let seq = 0;

/**
 * Window manager state machine. Pure TypeScript (no DOM) so it is unit-tested;
 * the React layer (WindowLayer/WindowFrame) renders this state and calls these
 * methods from pointer/keyboard handlers.
 */
export class WindowManager {
  readonly state = new Store<WMState>({ windows: [], focused: null, switcher: null, shownDesktop: null });
  private zTop = 10;
  /** most-recently-used order of window ids (index 0 = most recent) */
  private mru: string[] = [];
  animations = true;

  constructor(public viewport: Viewport) {}

  setViewport(v: Viewport): void {
    this.viewport = v;
    // keep maximized/snapped windows fitted and others reachable
    this.patchAll((w) => {
      if (w.maximized) return { ...w, ...this.maxRect() };
      if (w.snapped) return { ...w, ...this.snapRect(w.snapped) };
      return { ...w, ...this.clamp(w) };
    });
  }

  get windows(): WindowState[] {
    return this.state.get().windows;
  }

  get(id: string): WindowState | undefined {
    return this.windows.find((w) => w.id === id);
  }

  // ------------------------------------------------------------- open/close

  open(o: OpenOptions): WindowState {
    const v = this.viewport;
    const usableW = v.width - v.left;
    const usableH = v.height - v.top - v.bottom;
    const w = Math.min(o.width ?? 760, usableW - 16);
    const h = Math.min(o.height ?? 500, usableH - 16);
    // cascade new windows
    const n = this.windows.filter((x) => !x.minimized).length;
    const x = v.left + Math.max(8, Math.round((usableW - w) / 2) + ((n % 6) - 2) * 28);
    const y = v.top + Math.max(8, Math.round((usableH - h) / 2) + ((n % 6) - 2) * 24);
    const win: WindowState = {
      id: `w${++seq}`,
      appId: o.appId,
      title: o.title,
      icon: o.icon,
      color: o.color,
      emoji: o.emoji,
      ...this.clamp({ x, y, w, h }),
      minW: Math.min(o.minWidth ?? 280, w),
      minH: Math.min(o.minHeight ?? 180, h),
      z: ++this.zTop,
      minimized: false,
      maximized: false,
      snapped: null,
      restore: null,
      args: o.args ?? {},
      pid: o.pid ?? null,
      opening: this.animations,
      closing: false,
    };
    this.state.set((s) => ({ ...s, windows: [...s.windows, win], focused: win.id, shownDesktop: null }));
    this.touchMru(win.id);
    if (this.animations) setTimeout(() => this.patch(win.id, { opening: false }), 180);
    return win;
  }

  /** Starts the close animation; `finalize` removes it. */
  close(id: string): void {
    if (!this.get(id)) return;
    if (!this.animations) return this.finalizeClose(id);
    this.patch(id, { closing: true });
    setTimeout(() => this.finalizeClose(id), 140);
  }

  finalizeClose(id: string): void {
    this.mru = this.mru.filter((m) => m !== id);
    this.state.set((s) => {
      const windows = s.windows.filter((w) => w.id !== id);
      const focused = s.focused === id ? this.topVisible(windows) : s.focused;
      return { ...s, windows, focused };
    });
  }

  closeAll(): void {
    this.mru = [];
    this.state.set({ windows: [], focused: null, switcher: null, shownDesktop: null });
  }

  // ------------------------------------------------------------- focus/z-order

  focus(id: string): void {
    const w = this.get(id);
    if (!w) return;
    this.touchMru(id);
    this.state.set((s) => ({
      ...s,
      focused: id,
      shownDesktop: null,
      windows: s.windows.map((x) => (x.id === id ? { ...x, z: ++this.zTop, minimized: false } : x)),
    }));
  }

  private topVisible(list: WindowState[]): string | null {
    const visible = list.filter((w) => !w.minimized).sort((a, b) => b.z - a.z);
    return visible[0]?.id ?? null;
  }

  private touchMru(id: string) {
    this.mru = [id, ...this.mru.filter((m) => m !== id)];
  }

  mruOrder(): WindowState[] {
    return this.mru.map((id) => this.get(id)).filter((w): w is WindowState => !!w);
  }

  // ------------------------------------------------------------- min/max/snap

  minimize(id: string): void {
    this.state.set((s) => {
      const windows = s.windows.map((w) => (w.id === id ? { ...w, minimized: true } : w));
      return { ...s, windows, focused: s.focused === id ? this.topVisible(windows) : s.focused };
    });
  }

  toggleMinimize(id: string): void {
    const w = this.get(id);
    if (!w) return;
    if (w.minimized || this.state.get().focused !== id) this.focus(id);
    else this.minimize(id);
  }

  private maxRect() {
    const v = this.viewport;
    return { x: v.left, y: v.top, w: v.width - v.left, h: v.height - v.top - v.bottom };
  }

  private snapRect(side: 'left' | 'right') {
    const r = this.maxRect();
    const half = Math.floor(r.w / 2);
    return side === 'left' ? { x: r.x, y: r.y, w: half, h: r.h } : { x: r.x + half, y: r.y, w: r.w - half, h: r.h };
  }

  toggleMaximize(id: string): void {
    const w = this.get(id);
    if (!w) return;
    if (w.maximized || w.snapped) {
      const r = w.restore ?? { x: w.x + 40, y: w.y + 40, w: Math.round(w.w * 0.7), h: Math.round(w.h * 0.7) };
      this.patch(id, { ...this.clamp(r), maximized: false, snapped: null, restore: null });
    } else {
      this.patch(id, { ...this.maxRect(), maximized: true, snapped: null, restore: { x: w.x, y: w.y, w: w.w, h: w.h } });
    }
    this.focus(id);
  }

  snap(id: string, side: Snap): void {
    const w = this.get(id);
    if (!w) return;
    if (!side) {
      if (w.snapped) this.toggleMaximize(id);
      return;
    }
    const restore = w.maximized || w.snapped ? w.restore : { x: w.x, y: w.y, w: w.w, h: w.h };
    this.patch(id, { ...this.snapRect(side), snapped: side, maximized: false, restore });
    this.focus(id);
  }

  /** Arranges the two most recent visible windows side by side. */
  tileSideBySide(): void {
    const visible = this.mruOrder().filter((w) => !w.minimized).slice(0, 2);
    if (visible[0]) this.snap(visible[0].id, 'left');
    if (visible[1]) this.snap(visible[1].id, 'right');
  }

  // ------------------------------------------------------------- move/resize

  move(id: string, x: number, y: number): void {
    const w = this.get(id);
    if (!w) return;
    if (w.maximized || w.snapped) {
      // dragging a maximized window restores it under the pointer
      const r = w.restore ?? { x, y, w: w.w, h: w.h };
      this.patch(id, { ...this.clamp({ ...r, x, y }), maximized: false, snapped: null, restore: null });
      return;
    }
    this.patch(id, this.clamp({ x, y, w: w.w, h: w.h }));
  }

  resize(id: string, rect: { x: number; y: number; w: number; h: number }): void {
    const win = this.get(id);
    if (!win) return;
    const w = Math.max(win.minW, rect.w);
    const h = Math.max(win.minH, rect.h);
    // keep the opposite edge fixed when hitting the minimum size from the left/top
    const x = rect.w < win.minW && rect.x !== win.x ? win.x + win.w - w : rect.x;
    const y = rect.h < win.minH && rect.y !== win.y ? win.y + win.h - h : rect.y;
    this.patch(id, { x, y, w, h, maximized: false, snapped: null });
  }

  /** Keeps at least part of the title bar on screen. */
  private clamp(r: { x: number; y: number; w: number; h: number }) {
    const v = this.viewport;
    const w = Math.min(r.w, v.width - v.left);
    const h = Math.min(r.h, v.height - v.top - v.bottom);
    const x = Math.min(Math.max(r.x, v.left - w + 80), v.width - 80);
    const y = Math.min(Math.max(r.y, v.top), v.height - v.bottom - 32);
    return { x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) };
  }

  // ------------------------------------------------------------- desktop & switcher

  showDesktop(): void {
    const s = this.state.get();
    if (s.shownDesktop) {
      const ids = s.shownDesktop;
      this.state.set({ ...s, shownDesktop: null, windows: s.windows.map((w) => (ids.includes(w.id) ? { ...w, minimized: false } : w)) });
      if (ids[0]) this.focus(ids[0]);
      return;
    }
    const ids = s.windows.filter((w) => !w.minimized).map((w) => w.id);
    this.state.set({ ...s, shownDesktop: ids, focused: null, windows: s.windows.map((w) => ({ ...w, minimized: true })) });
  }

  /** Alt+Tab: first press shows the overlay at index 1, further presses advance. */
  switcherNext(backwards = false): void {
    const list = this.mruOrder();
    if (!list.length) return;
    const s = this.state.get();
    const cur = s.switcher ?? 0;
    const next = (cur + (backwards ? -1 : 1) + list.length) % list.length;
    this.state.set({ ...s, switcher: next });
  }

  switcherCommit(): void {
    const s = this.state.get();
    if (s.switcher === null) return;
    const target = this.mruOrder()[s.switcher];
    this.state.set({ ...s, switcher: null });
    if (target) this.focus(target.id);
  }

  switcherCancel(): void {
    this.state.set({ ...this.state.get(), switcher: null });
  }

  setTitle(id: string, title: string): void {
    this.patch(id, { title });
  }

  setArgs(id: string, args: Record<string, string>): void {
    this.patch(id, { args });
  }

  // ------------------------------------------------------------- helpers

  patch(id: string, p: Partial<WindowState>): void {
    this.state.set((s) => ({ ...s, windows: s.windows.map((w) => (w.id === id ? { ...w, ...p } : w)) }));
  }

  private patchAll(fn: (w: WindowState) => WindowState): void {
    this.state.set((s) => ({ ...s, windows: s.windows.map(fn) }));
  }
}
