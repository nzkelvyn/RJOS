// End-to-end test: boots the real build in Chromium and drives the UI.
// Usage: npm run build && node tests/e2e/run.mjs   (CHROME_PATH=/path/to/chrome optional)
import { chromium } from 'playwright';
import path from 'node:path';
import assert from 'node:assert/strict';
import { serve } from './serve.mjs';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
const server = await serve(path.join(root, 'dist'));
const base = `http://127.0.0.1:${server.address().port}/`;
const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || undefined, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1366, height: 820 } });
const page = await context.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
page.on('console', (m) => m.type() === 'error' && errors.push(`console: ${m.text()}`));

const results = [];
async function step(name, fn) {
  const t = Date.now();
  try {
    await fn();
    results.push(['ok', name, Date.now() - t]);
    console.log(`  ✓ ${name}`);
  } catch (err) {
    results.push(['FAIL', name, Date.now() - t, err.message]);
    console.log(`  ✗ ${name}\n      ${err.message.split('\n')[0]}`);
    await page.screenshot({ path: path.join(root, `tests/e2e/fail-${results.length}.png`) }).catch(() => {});
  }
}

const term = async (cmd) => {
  const input = page.locator('[data-testid="terminal-input"]:visible').first();
  await input.fill(cmd);
  await input.press('Enter');
  await page.waitForTimeout(250);
};
const termText = () => page.locator('[data-testid="terminal-output"]:visible').first().innerText();

await step('boot screen then setup wizard', async () => {
  await page.goto(base);
  await page.getByTestId('setup').waitFor({ timeout: 15000 });
});

await step('complete setup (create admin user)', async () => {
  await page.getByTestId('setup-next').click(); // welcome
  await page.getByTestId('setup-next').click(); // language
  await page.getByTestId('setup-fullname').fill('Vitor Teste');
  await page.getByTestId('setup-username').fill('vitor');
  await page.getByTestId('setup-password').fill('senha123');
  await page.getByTestId('setup-password2').fill('senha123');
  await page.getByTestId('setup-next').click(); // account
  await page.getByTestId('setup-next').click(); // appearance
  await page.getByTestId('setup-next').click(); // storage
  await page.getByTestId('setup-finish').click();
  await page.getByTestId('desktop-root').waitFor({ timeout: 15000 });
});

await step('desktop shows top bar, dock and desktop icons', async () => {
  await page.getByTestId('dock').waitFor();
  await page.getByTestId('clock').waitFor();
  await page.getByText('Pasta pessoal').first().waitFor();
});

await step('terminal opens via Ctrl+Alt+T and runs commands', async () => {
  await page.keyboard.press('Control+Alt+t');
  await page.locator('[data-app="terminal"]').waitFor();
  await page.waitForTimeout(400);
  await term('echo olá mundo | wc -c');
  await term('mkdir -p proj && cd proj && echo "conteudo" > a.txt && ls -l');
  await term('pwd');
  const text = await termText();
  assert.match(text, /a\.txt/);
  assert.match(text, /\/home\/vitor\/proj/);
  assert.match(text, /^\s*11$/m); // "olá mundo\n" = 11 bytes in UTF-8
});

await step('terminal: unknown vs unavailable commands, sudo prompt', async () => {
  await term('python3');
  await term('sudo whoami');
  await page.waitForTimeout(200);
  await term('senha123'); // password prompt
  await page.waitForTimeout(800);
  const text = await termText();
  assert.match(text, /indisponível/);
  assert.match(text, /\nroot\n/);
});

await step('terminal: lvp install via sudo with confirmation', async () => {
  await term('sudo lvp install snake');
  await page.waitForTimeout(300);
  await term('s');
  await page.waitForTimeout(1200);
  const text = await termText();
  assert.match(text, /instalado/);
});

await step('terminal: top fullscreen and quit with q', async () => {
  await term('top');
  await page.getByTestId('terminal-fullscreen').waitFor();
  await page.keyboard.press('q');
  await page.getByTestId('terminal-fullscreen').waitFor({ state: 'detached', timeout: 4000 });
});

await step('window manager: maximize, minimize, restore from dock', async () => {
  const win = page.locator('[data-app="terminal"]');
  await win.locator('button[aria-label="Maximizar"]').click();
  await page.waitForTimeout(300);
  const box = await win.boundingBox();
  assert.ok(box.width > 1300, `width ${box.width}`);
  await win.locator('button[aria-label="Minimizar"]').click();
  await page.waitForTimeout(200);
  assert.equal(await win.isVisible(), false);
  await page.getByTestId('dock-terminal').click();
  await win.waitFor({ state: 'visible' });
});

await step('window manager: drag window by title bar', async () => {
  const win = page.locator('[data-app="terminal"]');
  await win.locator('button[aria-label="Restaurar"]').click();
  await page.waitForTimeout(300);
  const before = await win.boundingBox();
  const bar = win.locator('.window-titlebar');
  const b = await bar.boundingBox();
  await page.mouse.move(b.x + 120, b.y + 15);
  await page.mouse.down();
  await page.mouse.move(b.x + 220, b.y + 95, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(300);
  const after = await win.boundingBox();
  assert.ok(Math.abs(after.x - before.x - 100) < 6 && Math.abs(after.y - before.y - 80) < 6, `moved ${after.x - before.x},${after.y - before.y}`);
});

await step('launcher opens with search and launches Files', async () => {
  await page.getByTestId('launcher-button').click();
  await page.getByTestId('launcher-search').fill('arquiv');
  await page.keyboard.press('Enter');
  await page.locator('[data-app="files"]').waitFor();
});

await step('file manager shows the file created in the terminal', async () => {
  const fm = page.locator('[data-app="files"]');
  await fm.getByTestId('file-proj').dblclick();
  await fm.getByTestId('file-a.txt').waitFor();
});

await step('file manager: open a text file in the editor, edit and save', async () => {
  const fm = page.locator('[data-app="files"]');
  await fm.getByTestId('file-a.txt').dblclick();
  const ed = page.locator('[data-app="editor"]');
  await ed.waitFor();
  const ta = ed.getByTestId('editor-textarea');
  await ta.waitFor();
  await page.waitForTimeout(300);
  assert.equal((await ta.inputValue()).trim(), 'conteudo');
  await ta.fill('conteudo editado');
  await ta.press('Control+s');
  await page.waitForTimeout(400);
  const saved = await page.evaluate(() => window.lvos.kernel.vfs.readText('/home/vitor/proj/a.txt'));
  assert.equal(saved, 'conteudo editado');
});

await step('file manager: move to trash and restore', async () => {
  const fm = page.locator('[data-app="files"]');
  await fm.click({ position: { x: 400, y: 20 } }).catch(() => {});
  await fm.getByTestId('file-a.txt').click({ button: 'right' });
  await page.getByRole('menuitem', { name: /Mover para a lixeira/ }).click();
  await page.waitForTimeout(300);
  assert.equal(await page.evaluate(() => window.lvos.kernel.vfs.exists('/home/vitor/proj/a.txt')), false);
  await fm.getByRole('button', { name: 'Lixeira' }).click();
  await fm.getByRole('button', { name: /Restaurar/ }).first().click();
  await page.waitForTimeout(300);
  assert.equal(await page.evaluate(() => window.lvos.kernel.vfs.exists('/home/vitor/proj/a.txt')), true);
});

await step('package app (snake) runs sandboxed', async () => {
  await page.evaluate(() => document.querySelector('[data-app="files"] button[aria-label="Fechar"]')?.click());
  await page.getByTestId('launcher-button').click();
  await page.getByTestId('launcher-search').fill('snake');
  await page.keyboard.press('Enter');
  const frame = page.locator('[data-app="pkg:snake"] [data-testid="package-frame"]');
  await frame.waitFor({ timeout: 8000 });
  assert.equal(await frame.getAttribute('sandbox'), 'allow-scripts');
  const inner = page.frameLocator('[data-app="pkg:snake"] [data-testid="package-frame"]');
  await inner.locator('canvas').waitFor();
});

await step('App Center installs pomodoro after confirmation dialog', async () => {
  await page.getByTestId('dock-appcenter').click();
  const ac = page.locator('[data-app="appcenter"]');
  await ac.getByTestId('install-pomodoro').click();
  await page.getByTestId('dialog-ok').click();
  await page.waitForFunction(() => !!window.lvos.kernel.lvp.getInstalled('pomodoro'), null, { timeout: 8000 });
});

await step('settings: switch to light theme and accent', async () => {
  await page.getByTestId('dock-settings').click();
  const st = page.locator('[data-app="settings"]');
  await st.getByRole('button', { name: 'Claro' }).click();
  await page.waitForTimeout(200);
  assert.equal(await page.evaluate(() => document.documentElement.dataset.theme), 'light');
});

await step('apps open without crashing (calculator, calendar, clock, monitor, notes, task manager, browser, archive, music, video, images, pdf)', async () => {
  for (const id of ['calculator', 'calendar', 'clock', 'monitor', 'notes', 'taskmanager', 'browser', 'archive', 'music', 'video', 'images', 'pdf']) {
    await page.getByTestId('launcher-button').click();
    await page.getByTestId(`launch-${id}`).click();
    await page.locator(`[data-app="${id}"]`).first().waitFor({ timeout: 8000 });
    await page.waitForTimeout(250);
    const crashed = await page.locator(`[data-app="${id}"] >> text=O aplicativo parou de responder`).count();
    assert.equal(crashed, 0, `${id} crashed`);
  }
});

await step('calculator evaluates an expression', async () => {
  await page.getByTestId('dock-calculator').click(); // bring it to the front
  const calc = page.locator('[data-app="calculator"]');
  for (const k of ['7', '×', '6', '=']) await calc.getByRole('button', { name: k, exact: true }).click();
  assert.equal((await calc.getByTestId('calc-result').innerText()).trim(), '42');
});

await step('notifications: toast appears and center lists it', async () => {
  await page.evaluate(() => window.lvos.kernel.notifications.push({ app: 'test', appName: 'Teste', title: 'Olá do teste', level: 'info' }));
  await page.getByTestId('toast').filter({ hasText: 'Olá do teste' }).waitFor();
  await page.getByTestId('notifications-button').click();
  await page.getByRole('dialog', { name: 'Central de notificações' }).getByText('Olá do teste').waitFor();
  await page.keyboard.press('Escape');
});

await step('Alt+` window switcher cycles windows', async () => {
  await page.keyboard.down('Alt');
  await page.keyboard.press('Backquote');
  await page.getByRole('listbox', { name: 'Alternar janelas' }).waitFor();
  await page.keyboard.up('Alt');
  await page.getByRole('listbox', { name: 'Alternar janelas' }).waitFor({ state: 'detached' });
});

await step('lock screen (Ctrl+Alt+L) and unlock with password', async () => {
  await page.keyboard.press('Control+Alt+l');
  await page.getByTestId('lock-screen').waitFor();
  await page.getByTestId('lock-screen').click();
  await page.getByTestId('login-password').fill('errada');
  await page.getByTestId('login-submit').click();
  await page.getByText('Senha incorreta.').waitFor();
  await page.getByTestId('login-password').fill('senha123');
  await page.getByTestId('login-submit').click();
  await page.getByTestId('lock-screen').waitFor({ state: 'detached' });
});

await step('persistence: reload keeps files, session resumes locked', async () => {
  await page.reload();
  await page.getByTestId('lock-screen').waitFor({ timeout: 15000 });
  await page.getByTestId('lock-screen').click();
  await page.getByTestId('login-password').fill('senha123');
  await page.getByTestId('login-submit').click();
  await page.getByTestId('desktop-root').waitFor();
  assert.equal(await page.evaluate(() => window.lvos.kernel.vfs.readText('/home/vitor/proj/a.txt')), 'conteudo editado');
  assert.ok(await page.evaluate(() => !!window.lvos.kernel.lvp.getInstalled('snake')));
  assert.equal(await page.evaluate(() => document.documentElement.dataset.theme), 'light');
});

await step('new tab of the browser: login screen appears (sessions are per tab)', async () => {
  const p2 = await context.newPage();
  await p2.goto(base);
  await p2.getByTestId('login-screen').waitFor({ timeout: 15000 });
  await p2.close();
});

await step('mobile viewport: windows open full screen', async () => {
  await page.setViewportSize({ width: 390, height: 780 });
  await page.waitForTimeout(400);
  await page.getByTestId('launcher-button').click();
  await page.getByTestId('launch-files').click();
  await page.waitForTimeout(400); // let the open animation (scale) finish
  const box = await page.locator('[data-app="files"]').boundingBox();
  assert.ok(box && box.width >= 385, `width ${box?.width}`);
  await page.screenshot({ path: path.join(root, 'tests/e2e/mobile.png') });
  await page.setViewportSize({ width: 1366, height: 820 });
});

await page.screenshot({ path: path.join(root, 'tests/e2e/desktop.png') });
await browser.close();
server.close();

const relevantErrors = errors.filter((e) => !/favicon|ERR_BLOCKED_BY_RESPONSE|ERR_NAME_NOT_RESOLVED|net::ERR|Failed to load resource/.test(e));
console.log(`\n${results.filter((r) => r[0] === 'ok').length}/${results.length} passos OK`);
if (relevantErrors.length) console.log('Erros no console:\n  ' + relevantErrors.slice(0, 20).join('\n  '));
process.exit(results.some((r) => r[0] === 'FAIL') || relevantErrors.length ? 1 : 0);
