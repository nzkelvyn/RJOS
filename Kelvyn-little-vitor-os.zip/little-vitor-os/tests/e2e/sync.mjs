// End-to-end test of cloud sync between two "devices" (two isolated browser profiles).
// Requires the backend running and allowing origin http://127.0.0.1:5180:
//   cd server && ALLOWED_ORIGINS=http://127.0.0.1:5180 DATABASE_URL=... npm start
//   SYNC_SERVER=http://127.0.0.1:4000 node tests/e2e/sync.mjs
import { chromium } from 'playwright';
import path from 'node:path';
import assert from 'node:assert/strict';
import { serve } from './serve.mjs';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
const SERVER = process.env.SYNC_SERVER ?? 'http://127.0.0.1:4000';
const httpServer = await serve(path.join(root, 'dist'), 5180);
const base = 'http://127.0.0.1:5180/';
const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || undefined, args: ['--no-sandbox'] });

async function device(name, register) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log(`[${name}] pageerror`, e.message));
  await page.goto(base);
  await page.getByTestId('setup').waitFor({ timeout: 15000 });
  await page.getByTestId('setup-next').click();
  await page.getByTestId('setup-next').click();
  await page.getByTestId('setup-password').fill('senha123');
  await page.getByTestId('setup-password2').fill('senha123');
  for (let i = 0; i < 3; i++) await page.getByTestId('setup-next').click();
  await page.getByTestId('setup-finish').click();
  await page.getByTestId('desktop-root').waitFor();
  await page.evaluate((s) => window.lvos.kernel.settings.update({ syncServer: s }), SERVER);
  await page.getByTestId('dock-settings').click();
  await page.getByTestId('settings-sync').click();
  const st = page.locator('[data-app="settings"]');
  await st.getByRole('switch', { name: 'Sincronização' }).click();
  await st.getByPlaceholder('usuário').waitFor({ timeout: 10000 });
  await st.getByPlaceholder('usuário').fill('vitorcloud');
  await st.getByPlaceholder('senha (mín. 8)').fill('senha-forte-123');
  await st.getByRole('button', { name: register ? 'Criar conta no servidor' : 'Entrar' }).click();
  await page.getByText('Sincronizada').waitFor({ timeout: 15000 });
  return page;
}

let failed = false;
const check = async (name, fn) => {
  try {
    await fn();
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed = true;
    console.log(`  ✗ ${name}\n      ${err.message.split('\n')[0]}`);
  }
};

const A = await device('A', true);
await check('device A uploads a new file', async () => {
  await A.evaluate(() => window.lvos.kernel.vfs.writeFile('/home/vitor/Documents/sync.txt', 'escrito no aparelho A'));
  await A.waitForTimeout(2500); // debounce 1.5 s + upload
  const list = await (await fetch(`${SERVER}/api/health`)).json();
  assert.ok(list.ok);
});

const B = await device('B', false);
await check('device B receives the file on first sync', async () => {
  await B.waitForFunction(() => window.lvos.kernel.vfs.exists('/home/vitor/Documents/sync.txt'), null, { timeout: 10000 });
  assert.equal(await B.evaluate(() => window.lvos.kernel.vfs.readText('/home/vitor/Documents/sync.txt')), 'escrito no aparelho A');
});

await check('edit on B reaches A in real time (WebSocket)', async () => {
  await B.evaluate(() => window.lvos.kernel.vfs.writeFile('/home/vitor/Documents/sync.txt', 'editado no aparelho B'));
  await A.waitForFunction(async () => (await window.lvos.kernel.vfs.readText('/home/vitor/Documents/sync.txt')) === 'editado no aparelho B', null, { timeout: 15000, polling: 500 });
});

await check('deletion on A propagates to B', async () => {
  await A.evaluate(() => window.lvos.kernel.vfs.unlink('/home/vitor/Documents/sync.txt'));
  await B.waitForFunction(() => !window.lvos.kernel.vfs.exists('/home/vitor/Documents/sync.txt'), null, { timeout: 15000, polling: 500 });
});

await browser.close();
httpServer.close();
console.log(failed ? '\nSINCRONIZAÇÃO: FALHOU' : '\nSINCRONIZAÇÃO: OK');
process.exit(failed ? 1 : 0);
