import { Kernel } from '../../src/kernel/kernel';
import { MemoryBackend } from '../../src/core/vfs/backends/memory';
import { Shell } from '../../src/core/shell/shell';
import { stripAnsi } from '../../src/core/shell/glob';
import type { ShellHost } from '../../src/core/shell/types';

export async function bootedKernel(opts: { user?: boolean; admin?: boolean } = {}) {
  const backend = new MemoryBackend();
  const kernel = new Kernel(backend);
  await kernel.boot();
  if (opts.user !== false) {
    await kernel.users.create({ username: 'vitor', password: 'senha123', fullName: 'Vitor', admin: opts.admin ?? true });
    await kernel.users.login('vitor', 'senha123');
    await kernel.startSession();
  }
  return { kernel, backend };
}

export interface TestTerminal {
  shell: Shell;
  output: () => string;
  reset: () => void;
  run: (line: string) => Promise<{ code: number; out: string }>;
  answers: string[];
  opened: string[];
}

export async function terminal(kernel: Kernel): Promise<TestTerminal> {
  let buf = '';
  const answers: string[] = [];
  const opened: string[] = [];
  const host: ShellHost = {
    clear: () => (buf = ''),
    exit: () => {},
    prompt: async (q) => {
      buf += q;
      return answers.shift() ?? null;
    },
    openPath: (p) => opened.push(p),
    openApp: (id, args) => opened.push(`${id}:${args?.path ?? ''}`),
    columns: () => 80,
  };
  const out = { write: (t: string) => void (buf += t) };
  const shell = new Shell(kernel, host, out);
  await shell.init();
  return {
    shell,
    answers,
    opened,
    output: () => stripAnsi(buf),
    reset: () => (buf = ''),
    async run(line: string) {
      buf = '';
      const code = await shell.run(line);
      return { code, out: stripAnsi(buf) };
    },
  };
}
