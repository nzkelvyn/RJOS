import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeHash, satisfies, compareVersions, validateManifest, type PackageManifest } from '../../src/core/packages/manifest';
import { PackageManager } from '../../src/core/packages/lvp';
import { builtinPackages } from '../../src/core/packages/builtinRepo';
import { bootedKernel, terminal } from './helpers';

test('semver helpers', () => {
  assert.ok(compareVersions('1.10.0', '1.9.9') > 0);
  assert.ok(satisfies('1.2.3', '^1.0.0'));
  assert.ok(!satisfies('2.0.0', '^1.0.0'));
  assert.ok(satisfies('1.2.9', '~1.2.0'));
  assert.ok(!satisfies('1.3.0', '~1.2.0'));
  assert.ok(satisfies('3.0.0', '>=1.0.0'));
  assert.ok(satisfies('1.0.0', '*'));
});

test('builtin repository packages are valid and hashed', async () => {
  const pkgs = await builtinPackages();
  assert.ok(pkgs.length >= 7);
  for (const p of pkgs) {
    const m = validateManifest(p);
    assert.equal(await computeHash(m.files), m.sha256, m.name);
  }
});

test('manifest validation rejects bad input', () => {
  const base = { lvp: 1, name: 'ok-app', version: '1.0.0', displayName: 'x', description: 'x', files: { 'i.html': '' }, entry: 'i.html', sha256: 'x' };
  assert.doesNotThrow(() => validateManifest(base));
  assert.throws(() => validateManifest({ ...base, name: 'Bad Name' }), /nome/);
  assert.throws(() => validateManifest({ ...base, version: 'v1' }), /versão/);
  assert.throws(() => validateManifest({ ...base, permissions: ['root'] }), /permissão/);
  assert.throws(() => validateManifest({ ...base, files: { '../evil': '' } }), /caminho/);
  assert.throws(() => validateManifest({ ...base, entry: 'missing.html' }), /entry/);
});

test('install resolves dependencies, needs confirmation and admin, then removes', async () => {
  const { kernel } = await bootedKernel();
  const pm = kernel.lvp;
  await assert.rejects(pm.install(['snake']), /cancelada/); // no confirm callback
  await assert.rejects(pm.install(['snake'], { confirm: async () => false }), /cancelada/);
  const plan = await pm.install(['snake'], { confirm: async () => true });
  assert.deepEqual(plan.steps.map((s) => s.manifest.name), ['lvp-runtime', 'snake']);
  assert.ok(pm.getInstalled('lvp-runtime')?.auto);
  assert.ok(kernel.vfs.exists('/usr/share/lvp/snake/index.html'));
  assert.ok(await pm.verify('snake'));
  await assert.rejects(pm.remove('lvp-runtime'), /dependência/);
  await pm.remove('snake');
  assert.deepEqual(pm.orphans(), ['lvp-runtime']);
  assert.deepEqual(await pm.autoremove(), ['lvp-runtime']);
  assert.match((await pm.logLines()).join('\n'), /instalado snake@1\.0\.0/);
});

test('non-admins cannot install', async () => {
  const { kernel } = await bootedKernel({ admin: false });
  await assert.rejects(kernel.lvp.install(['snake'], { confirm: async () => true }), /permissão negada/);
});

test('tampered installed files fail verification', async () => {
  const { kernel } = await bootedKernel();
  await kernel.lvp.install(['pomodoro'], { confirm: async () => true });
  await kernel.vfs.writeFile('/usr/share/lvp/pomodoro/index.html', '<script>evil()</script>', {}, { username: 'root', groups: ['root'] });
  assert.equal(await kernel.lvp.verify('pomodoro'), false);
});

test('remote repository: integrity check, upgrade flow', async () => {
  const { kernel } = await bootedKernel();
  const mk = async (version: string, body: string): Promise<PackageManifest> => {
    const files = { 'index.html': body };
    return { lvp: 1, name: 'hello', version, displayName: 'Hello', description: 'd', author: 'a', license: 'MIT', icon: '👋', category: 'x', permissions: [], dependencies: {}, entry: 'index.html', files, sha256: await computeHash(files) };
  };
  let index: unknown = { packages: [await mk('1.0.0', 'v1')] };
  const pm = new PackageManager(kernel.vfs, kernel.events, () => true, async () => index);
  await pm.init();
  await assert.rejects(pm.addRepository('extra', 'http://inseguro'), /https/);
  await pm.addRepository('extra', 'https://example.org/index.json');
  await pm.update();
  await pm.install(['hello'], { confirm: async () => true });
  assert.equal(pm.getInstalled('hello')?.version, '1.0.0');
  const tampered = await mk('1.2.0', 'v2');
  tampered.files['index.html'] = 'malicioso';
  index = { packages: [await mk('1.1.0', 'v1.1'), tampered] };
  await pm.update();
  assert.deepEqual(pm.upgradable(), [{ name: 'hello', from: '1.0.0', to: '1.1.0' }]); // tampered 1.2.0 ignored
  await pm.upgrade(async () => true);
  assert.equal(pm.getInstalled('hello')?.version, '1.1.0');
});

test('lvp from the terminal requires sudo and asks for confirmation', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  const denied = await t.run('lvp install snake');
  assert.equal(denied.code, 100);
  assert.match(denied.out, /sudo lvp install snake/);
  t.answers.push('senha123', 's');
  const ok = await t.run('sudo lvp install snake');
  assert.equal(ok.code, 0, ok.out);
  assert.match(ok.out, /Deseja continuar/);
  assert.match((await t.run('lvp list')).out, /snake\/core 1\.0\.0/);
  assert.match((await t.run('lvp info snake')).out, /Requerido por/);
  assert.match((await t.run('lvp search jogo')).out, /snake/);
  t.answers.push('n');
  const cancel = await t.run('sudo lvp install paint');
  assert.equal(cancel.code, 100);
  assert.match(cancel.out, /cancelada/);
});

test('local .lvp files are validated before install', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  const files = { 'index.html': '<p>local</p>' };
  const manifest = { lvp: 1, name: 'local-app', version: '0.1.0', displayName: 'Local', description: 'x', entry: 'index.html', files, sha256: await computeHash(files) };
  await kernel.vfs.writeFile('/home/vitor/app.lvp', JSON.stringify(manifest));
  await kernel.vfs.writeFile('/home/vitor/bad.lvp', JSON.stringify({ ...manifest, sha256: 'deadbeef' }));
  t.answers.push('senha123');
  const bad = await t.run('sudo lvp install ./bad.lvp -y');
  assert.match(bad.out, /integridade/);
  const good = await t.run('sudo lvp install ./app.lvp -y');
  assert.equal(good.code, 0, good.out);
  assert.equal(kernel.lvp.getInstalled('local-app')?.repository, 'local');
});
