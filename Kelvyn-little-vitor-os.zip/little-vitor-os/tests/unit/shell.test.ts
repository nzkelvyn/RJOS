import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parse, tokenize, ParseError } from '../../src/core/shell/parser';
import { globToRegExp } from '../../src/core/shell/glob';
import { parseArgs } from '../../src/core/shell/args';
import { bootedKernel, terminal } from './helpers';

test('parser: quotes, operators, redirects, assignments', () => {
  const list = parse(`FOO=1 echo "a b" 'c $d' > out.txt && ls | grep x; sleep 1 &`);
  assert.equal(list.length, 3);
  assert.equal(list[0].op, '&&');
  assert.equal(list[0].pipeline.commands[0].assignments[0].name, 'FOO');
  assert.equal(list[0].pipeline.commands[0].redirects[0].op, '>');
  assert.equal(list[1].pipeline.commands.length, 2);
  assert.equal(list[2].op, '&');
  assert.throws(() => parse('echo "aberto'), ParseError);
  assert.throws(() => parse('| ls'), ParseError);
  assert.throws(() => parse('ls &&'), ParseError);
  const t = tokenize('echo a\\ b # comentário');
  assert.equal(t.length, 2);
});

test('glob and args helpers', () => {
  assert.ok(globToRegExp('*.txt').test('a.txt'));
  assert.ok(!globToRegExp('*.txt').test('a.md'));
  assert.ok(globToRegExp('f?le[0-9]').test('file7'));
  const p = parseArgs(['-la', '-n', '5', '--', '-x'], { bool: 'la', value: 'n' });
  assert.deepEqual([...p.flags], ['l', 'a']);
  assert.equal(p.values.n, '5');
  assert.deepEqual(p.rest, ['-x']);
  assert.throws(() => parseArgs(['-z'], { bool: 'a' }));
});

test('basic navigation and file commands', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  assert.equal((await t.run('pwd')).out, '/home/vitor\n');
  await t.run('mkdir -p proj/src && cd proj');
  assert.equal((await t.run('pwd')).out, '/home/vitor/proj\n');
  await t.run('echo "linha 1" > a.txt');
  await t.run('echo linha 2 >> a.txt');
  assert.equal((await t.run('cat a.txt')).out, 'linha 1\nlinha 2\n');
  assert.equal((await t.run('cat -n a.txt')).out, '     1\tlinha 1\n     2\tlinha 2\n');
  await t.run('cp a.txt b.txt && mv b.txt src/');
  assert.equal((await t.run('ls src')).out.trim(), 'b.txt');
  assert.match((await t.run('ls -l')).out, /-rw-r--r-- 1 vitor vitor\s+16 .* a\.txt/);
  await t.run('cd -');
  assert.equal(t.shell.cwd, '/home/vitor');
  const r = await t.run('cat nao-existe');
  assert.equal(r.code, 1);
  assert.match(r.out, /Arquivo ou diretório inexistente/);
});

test('pipes, grep, sort, uniq, wc, head, tail', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  await t.run('printf_free=1; seq 1 10 > n.txt');
  assert.equal((await t.run('cat n.txt | grep 1 | wc -l')).out.trim(), '2');
  assert.equal((await t.run('head -n 3 n.txt')).out, '1\n2\n3\n');
  assert.equal((await t.run('tail -2 n.txt')).out, '9\n10\n');
  assert.equal((await t.run('sort -rn n.txt | head -1')).out, '10\n');
  await t.run('echo b > d.txt; echo a >> d.txt; echo b >> d.txt; echo b >> d.txt');
  assert.equal((await t.run('sort d.txt | uniq -c')).out, '      1 a\n      3 b\n');
  assert.equal((await t.run('grep -c b d.txt')).out, '3\n');
  const miss = await t.run('grep zzz d.txt');
  assert.equal(miss.code, 1);
});

test('variables, &&/||, $?, aliases, globbing, history expansion', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  await t.run('export NOME=Vitor');
  assert.equal((await t.run('echo "Olá $NOME" \'$NOME\'')).out, 'Olá Vitor $NOME\n');
  assert.equal((await t.run('false || echo falhou')).out, 'falhou\n');
  assert.equal((await t.run('false && echo nao')).out, '');
  await t.run('false');
  assert.equal((await t.run('echo $?')).out, '1\n');
  await t.run("alias oi='echo oi'");
  assert.equal((await t.run('oi mundo')).out, 'oi mundo\n');
  await t.run('touch x1.log x2.log y.txt');
  assert.equal((await t.run('echo *.log')).out, 'x1.log x2.log\n');
  assert.equal((await t.run('echo "*.log"')).out, '*.log\n');
  assert.equal((await t.run('echo ~')).out, '/home/vitor\n');
  await t.run('echo repetir');
  assert.equal((await t.run('!!')).out, 'echo repetir\nrepetir\n');
});

test('redirection of stderr and input', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  await t.run('cat inexistente 2> err.txt');
  assert.match(await kernel.vfs.readText('/home/vitor/err.txt'), /inexistente/);
  await t.run('echo conteudo > in.txt');
  assert.equal((await t.run('wc -c < in.txt')).out.trim(), '9');
  await t.run('ls inexistente > all.txt 2>&1');
  assert.match(await kernel.vfs.readText('/home/vitor/all.txt'), /não foi possível acessar/);
});

test('permissions from the shell: chmod, executing scripts, /etc/shadow', async () => {
  const { kernel } = await bootedKernel({ admin: false });
  const t = await terminal(kernel);
  await t.run('echo \'echo "arg: $1"\' > s.sh');
  const denied = await t.run('./s.sh x');
  assert.equal(denied.code, 126);
  await t.run('chmod +x s.sh');
  assert.equal((await t.run('./s.sh hello')).out, 'arg: hello\n');
  const shadow = await t.run('cat /etc/shadow');
  assert.equal(shadow.code, 1);
  assert.match(shadow.out, /Permissão negada/);
  const sudo = await t.run('sudo ls');
  assert.equal(sudo.code, 1);
  assert.match(sudo.out, /sudoers/);
});

test('sudo asks the password and runs as root', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  t.answers.push('errada', 'senha123');
  const r = await t.run('sudo cat /etc/shadow');
  assert.equal(r.code, 0);
  assert.match(r.out, /Desculpe, tente novamente/);
  assert.match(r.out, /vitor:pbkdf2\$/);
  // cached: no prompt the second time
  assert.equal((await t.run('sudo whoami')).out, 'root\n');
});

test('unknown vs unavailable commands are distinguished', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  const a = await t.run('python3');
  assert.equal(a.code, 127);
  assert.match(a.out, /indisponível/);
  const b = await t.run('qwertyuiop');
  assert.match(b.out, /comando não encontrado/);
  assert.match((await t.run('type ls')).out, /implementado pelo Little Vitor OS/);
  assert.equal((await t.run('which ls')).out, '/bin/ls\n');
  assert.ok(kernel.vfs.exists('/bin/ls'));
  assert.equal((await t.run('/bin/echo via stub')).out, 'via stub\n');
});

test('processes: ps lists, kill refuses system processes, jobs run in background', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  assert.match((await t.run('ps aux')).out, /init/);
  assert.match((await t.run('kill 1')).out, /não permitida/); // not the owner, like Linux
  kernel.procs.list(); // root gets a clearer message:
  assert.match(kernel.procs.kill(1, 'SIGTERM', 'root')!, /protegido/);
  await t.run('sleep 0.05 &');
  assert.equal(t.shell.jobs.length, 1);
  await t.shell.jobs[0].promise;
  assert.equal(t.shell.jobs[0].status, 'done');
  // Ctrl+C interrupts a foreground command
  const p = t.shell.run('sleep 5');
  setTimeout(() => t.shell.interrupt(), 20);
  assert.equal(await p, 130);
});

test('tab completion for commands and paths', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  assert.equal(t.shell.complete('pw').replacement, 'pwd ');
  assert.equal(t.shell.complete('cd Doc').replacement, 'cd Documents/');
  assert.ok(t.shell.complete('cd D').options.length >= 3);
});

test('history persists in ~/.lvsh_history', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  await t.run('echo um');
  await t.run('echo dois');
  await new Promise((r) => setTimeout(r, 10));
  const t2 = await terminal(kernel);
  assert.deepEqual(t2.shell.history.slice(-2), ['echo um', 'echo dois']);
});

test('find, tree, du, stat, date, cal, uname, neofetch run', async () => {
  const { kernel } = await bootedKernel();
  const t = await terminal(kernel);
  assert.match((await t.run('find . -name "*.txt"')).out, /Documents\/Bem-vindo\.txt/);
  assert.match((await t.run('tree -L 1')).out, /Documents/);
  assert.match((await t.run('date +%Y')).out, /^\d{4}\n$/);
  assert.match((await t.run('cal 2 2024')).out, /fevereiro 2024/);
  assert.match((await t.run('cal 2 2024')).out, /29/);
  assert.match((await t.run('uname -a')).out, /LittleVitor/);
  assert.equal((await t.run('neofetch')).code, 0);
  assert.equal((await t.run('stat Documents')).code, 0);
  assert.equal((await t.run('cat /proc/uptime')).code, 0);
});
