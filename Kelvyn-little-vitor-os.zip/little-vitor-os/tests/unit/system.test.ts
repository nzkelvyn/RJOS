import { test } from 'node:test';
import assert from 'node:assert/strict';
import { hashPassword, verifyPassword } from '../../src/core/users/crypto';
import { sanitizeUser, sanitizeSystem } from '../../src/core/settings/settings';
import { ProcessManager } from '../../src/core/process/processManager';
import { NotificationService } from '../../src/core/notifications/notifications';
import { EventBus } from '../../src/kernel/events';
import { Kernel } from '../../src/kernel/kernel';
import { MemoryBackend } from '../../src/core/vfs/backends/memory';
import { bootedKernel } from './helpers';

test('password hashing never stores plain text', async () => {
  const h = await hashPassword('segredo', 1000);
  assert.ok(h.startsWith('pbkdf2$1000$'));
  assert.ok(!h.includes('segredo'));
  assert.ok(await verifyPassword('segredo', h));
  assert.ok(!(await verifyPassword('outra', h)));
  assert.ok(!(await verifyPassword('x', 'lixo')));
});

test('boot creates the FHS tree and system files', async () => {
  const { kernel } = await bootedKernel({ user: false });
  for (const d of ['/bin', '/etc', '/home', '/proc', '/tmp', '/usr', '/var']) assert.ok(kernel.vfs.isDir(d), d);
  assert.equal(kernel.vfs.stat('/tmp').mode, 0o1777);
  assert.ok(kernel.vfs.exists('/etc/passwd'));
  assert.equal(kernel.vfs.stat('/etc/shadow').mode & 0o777, 0o600);
  assert.ok(kernel.freshInstall);
});

test('users: create, login, wrong password lockout, lock/unlock, admin rules', async () => {
  const { kernel } = await bootedKernel({ user: false });
  const u = kernel.users;
  await u.create({ username: 'vitor', password: 'abcd1234', admin: true });
  await assert.rejects(u.create({ username: 'Inválido!', password: 'abcd' }));
  assert.ok(kernel.vfs.isDir('/home/vitor/Documents'));
  assert.equal(kernel.vfs.stat('/home/vitor').owner, 'vitor');
  await assert.rejects(u.login('vitor', 'errada'), /incorretos/);
  await u.login('vitor', 'abcd1234');
  assert.equal(u.current?.username, 'vitor');
  assert.ok(u.isAdmin());
  // admin can create a second, non-admin user
  await u.create({ username: 'ana', password: 'abcd1234' });
  u.lock();
  assert.ok(u.state.get().session?.locked);
  assert.ok(!(await u.unlock('nope')));
  assert.ok(await u.unlock('abcd1234'));
  await u.changePassword('vitor', 'abcd1234', 'nova-senha');
  u.logout();
  await assert.rejects(u.login('vitor', 'abcd1234'));
  await u.login('vitor', 'nova-senha');
  u.logout();
  // non-admin cannot create users
  await u.login('ana', 'abcd1234');
  await assert.rejects(u.create({ username: 'zeca', password: 'abcd1234' }), /Permissão negada/);
  u.logout();
  // lockout after 5 failures
  for (let i = 0; i < 5; i++) await u.login('ana', 'x').catch(() => undefined);
  await assert.rejects(u.login('ana', 'abcd1234'), /Muitas tentativas/);
});

test('remove user deletes the account and its home', async () => {
  const { kernel } = await bootedKernel();
  await kernel.users.create({ username: 'temp', password: 'abcd1234' });
  assert.ok(kernel.vfs.exists('/home/temp'));
  await kernel.users.remove('temp');
  assert.ok(!kernel.vfs.exists('/home/temp'));
  assert.equal(await kernel.users.get('temp'), undefined);
  await assert.rejects(kernel.users.remove('vitor'), /logado/);
});

test('settings: persisted per user, sanitized on load', async () => {
  const { kernel, backend } = await bootedKernel();
  kernel.settings.update({ theme: 'light', accent: '#10b981' });
  await kernel.settings.flush();
  const saved = JSON.parse(await kernel.vfs.readText('/home/vitor/.config/lvos/settings.json'));
  assert.equal(saved.theme, 'light');
  assert.deepEqual(sanitizeUser({ theme: 'neon', accent: 'red', fontScale: 9 }), { fontScale: 1.5 });
  assert.deepEqual(sanitizeSystem({ hostname: 'bad host!' }), {});
  await kernel.settings.saveSystem({ setupDone: true, hostname: 'meupc' });
  // reboot on the same storage keeps everything
  const k2 = new Kernel(backend);
  await k2.boot();
  assert.equal(k2.freshInstall, false);
  assert.equal(k2.settings.system.get().hostname, 'meupc');
  await k2.users.login('vitor', 'senha123');
  await k2.startSession();
  assert.equal(k2.settings.user.get().theme, 'light');
});

test('process manager: spawn, signals, ownership', () => {
  const pm = new ProcessManager(new EventBus());
  let got = '';
  const p = pm.spawn({ ppid: 0, name: 'app', command: 'app', user: 'vitor', kind: 'app' }, (s) => (got = s));
  assert.equal(pm.kill(p.pid, 'SIGTERM', 'ana'), `kill: (${p.pid}) - Operação não permitida`);
  assert.equal(pm.kill(p.pid, 'SIGSTOP', 'vitor'), null);
  assert.equal(pm.get(p.pid)?.state, 'stopped');
  assert.equal(pm.kill(p.pid, 'SIGTERM', 'vitor'), null);
  assert.equal(got, 'SIGTERM');
  assert.ok(pm.get(p.pid), 'process with a handler decides when to exit on SIGTERM');
  pm.kill(p.pid, 'SIGKILL', 'root');
  assert.equal(pm.get(p.pid), undefined);
  assert.match(pm.kill(999, 'SIGTERM', 'root')!, /inexistente/);
});

test('notifications: DND and muting suppress toasts but keep history', () => {
  const n = new NotificationService(new EventBus());
  n.push({ app: 'a', appName: 'A', title: 't1', level: 'info' });
  assert.equal(n.state.get().toasts.length, 1);
  n.setDnd(true);
  n.push({ app: 'a', appName: 'A', title: 't2', level: 'info' });
  assert.equal(n.state.get().toasts.length, 1);
  n.system('sistema ignora DND');
  assert.equal(n.state.get().toasts.length, 2);
  n.setDnd(false);
  n.setMuted(['b']);
  n.push({ app: 'b', appName: 'B', title: 't3', level: 'info' });
  assert.equal(n.state.get().items.length, 4);
  assert.equal(n.unreadCount(), 4);
  n.markAllRead();
  assert.equal(n.unreadCount(), 0);
});

test('kernel boot works with an empty in-memory backend twice (idempotent)', async () => {
  const backend = new MemoryBackend();
  await new Kernel(backend).boot();
  const k = new Kernel(backend);
  await k.boot();
  assert.equal(k.freshInstall, false);
});
