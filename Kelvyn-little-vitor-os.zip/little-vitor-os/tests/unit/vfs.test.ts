import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventBus } from '../../src/kernel/events';
import { VFS } from '../../src/core/vfs/vfs';
import { MemoryBackend } from '../../src/core/vfs/backends/memory';
import { basename, dirname, isInside, normalize, resolve } from '../../src/core/vfs/path';
import { canAccess, formatMode, parseChmod } from '../../src/core/vfs/permissions';
import { ROOT_CREDS, VfsError, type VNode } from '../../src/core/vfs/types';

const alice = { username: 'alice', groups: ['alice', 'users'] };
const bob = { username: 'bob', groups: ['bob', 'users'] };

async function fresh() {
  const backend = new MemoryBackend();
  const vfs = new VFS(backend, new EventBus());
  await vfs.mount();
  await vfs.mkdir('/home/alice', { parents: true, owner: 'alice', group: 'alice', mode: 0o750 }, ROOT_CREDS);
  await vfs.mkdir('/tmp', { mode: 0o1777 }, ROOT_CREDS);
  await vfs.chmod('/tmp', 0o1777, ROOT_CREDS);
  return { vfs, backend };
}

test('path helpers', () => {
  assert.equal(normalize('/a/./b/../c//'), '/a/c');
  assert.equal(normalize('/../..'), '/');
  assert.equal(resolve('/home/x', '../y', '/home/x'), '/home/y');
  assert.equal(resolve('/tmp', '~/docs', '/home/x'), '/home/x/docs');
  assert.equal(dirname('/a/b/c.txt'), '/a/b');
  assert.equal(basename('/a/b/c.txt'), 'c.txt');
  assert.ok(isInside('/a/b', '/a'));
  assert.ok(!isInside('/ab', '/a'));
});

test('permissions: mode bits, chmod parsing, formatting', () => {
  const node = { type: 'file', mode: 0o640, owner: 'alice', group: 'users' } as VNode;
  assert.ok(canAccess(node, alice, 'w'));
  assert.ok(canAccess(node, bob, 'r'));
  assert.ok(!canAccess(node, bob, 'w'));
  assert.ok(!canAccess(node, { username: 'eve', groups: ['eve'] }, 'r'));
  assert.ok(canAccess(node, ROOT_CREDS, 'w'));
  assert.ok(!canAccess(node, ROOT_CREDS, 'x'), 'root cannot execute a file with no x bit');
  assert.equal(parseChmod('755', 0), 0o755);
  assert.equal(parseChmod('u+x', 0o644), 0o744);
  assert.equal(parseChmod('go-r', 0o644), 0o600);
  assert.equal(parseChmod('a=r', 0o777), 0o444);
  assert.equal(parseChmod('+t', 0o777), 0o1777);
  assert.equal(parseChmod('lixo', 0o644), null);
  assert.equal(formatMode({ type: 'dir', mode: 0o1777 }), 'drwxrwxrwt');
  assert.equal(formatMode({ type: 'file', mode: 0o4755 }), '-rwsr-xr-x');
});

test('create, read, write, append and list', async () => {
  const { vfs } = await fresh();
  await vfs.writeFile('/home/alice/a.txt', 'olá', {}, alice);
  await vfs.writeFile('/home/alice/a.txt', ' mundo', { append: true }, alice);
  assert.equal(await vfs.readText('/home/alice/a.txt', alice), 'olá mundo');
  const st = vfs.stat('/home/alice/a.txt', alice);
  assert.equal(st.owner, 'alice');
  assert.equal(st.size, new TextEncoder().encode('olá mundo').length);
  assert.equal(st.mime, 'text/plain');
  await vfs.mkdir('/home/alice/x/y/z', { parents: true }, alice);
  assert.deepEqual(vfs.readdir('/home/alice', alice).map((e) => e.name), ['a.txt', 'x']);
});

test('permission errors are enforced', async () => {
  const { vfs } = await fresh();
  await vfs.writeFile('/home/alice/secret.txt', 'x', { mode: 0o600 }, alice);
  await assert.rejects(vfs.readText('/home/alice/secret.txt', bob), (e: VfsError) => e.code === 'EACCES');
  await assert.rejects(vfs.writeFile('/etc-nope/x', 'y', {}, alice), (e: VfsError) => e.code === 'ENOENT');
  await assert.rejects(vfs.mkdir('/forbidden', {}, alice), (e: VfsError) => e.code === 'EACCES');
  await assert.rejects(vfs.chmod('/home/alice/secret.txt', 0o777, bob), (e: VfsError) => e.code === 'EACCES' || e.code === 'EPERM');
  await assert.rejects(vfs.chown('/home/alice/secret.txt', 'bob', null, {}, alice), (e: VfsError) => e.code === 'EPERM');
});

test('sticky bit on /tmp protects other users files', async () => {
  const { vfs } = await fresh();
  await vfs.writeFile('/tmp/alice.txt', 'a', { mode: 0o666 }, alice);
  await assert.rejects(vfs.unlink('/tmp/alice.txt', bob), (e: VfsError) => e.code === 'EACCES');
  await vfs.unlink('/tmp/alice.txt', alice);
  assert.ok(!vfs.exists('/tmp/alice.txt'));
});

test('copy, move, rename, rm -r and invalid moves', async () => {
  const { vfs } = await fresh();
  await vfs.mkdir('/home/alice/src/sub', { parents: true }, alice);
  await vfs.writeFile('/home/alice/src/sub/f.txt', 'conteúdo', {}, alice);
  await vfs.copy('/home/alice/src', '/home/alice/dst', { recursive: true }, alice);
  assert.equal(await vfs.readText('/home/alice/dst/sub/f.txt', alice), 'conteúdo');
  await vfs.move('/home/alice/dst/sub/f.txt', '/home/alice/g.md', alice);
  assert.equal(vfs.stat('/home/alice/g.md', alice).mime, 'text/markdown');
  await assert.rejects(vfs.move('/home/alice/src', '/home/alice/src/sub/inside', alice), (e: VfsError) => e.code === 'EINVAL');
  await assert.rejects(vfs.rmdir('/home/alice/src', alice), (e: VfsError) => e.code === 'ENOTEMPTY');
  await vfs.rm('/home/alice/src', { recursive: true }, alice);
  assert.ok(!vfs.exists('/home/alice/src'));
  assert.equal(vfs.uniquePath('/home/alice/g.md'), '/home/alice/g (2).md');
});

test('trash: move, list, restore and empty', async () => {
  const { vfs } = await fresh();
  await vfs.writeFile('/home/alice/doc.txt', 'importante', {}, alice);
  const entry = await vfs.moveToTrash('/home/alice/doc.txt', alice);
  assert.ok(!vfs.exists('/home/alice/doc.txt'));
  assert.equal((await vfs.listTrash(alice))[0].originalPath, '/home/alice/doc.txt');
  const restored = await vfs.restoreFromTrash(entry.id, alice);
  assert.equal(restored, '/home/alice/doc.txt');
  assert.equal(await vfs.readText(restored, alice), 'importante');
  await vfs.moveToTrash('/home/alice/doc.txt', alice);
  assert.equal(await vfs.emptyTrash(alice), 1);
  assert.equal((await vfs.listTrash(alice)).length, 0);
});

test('persistence: a second VFS on the same backend sees the same tree', async () => {
  const { vfs, backend } = await fresh();
  await vfs.writeFile('/home/alice/keep.txt', 'persistido', {}, alice);
  const again = new VFS(backend, new EventBus());
  assert.equal(await again.mount(), false);
  assert.equal(await again.readText('/home/alice/keep.txt', alice), 'persistido');
  assert.equal(again.stat('/home/alice/keep.txt', alice).owner, 'alice');
});

test('virtual files are readable but never persisted', async () => {
  const { vfs, backend } = await fresh();
  let written = '';
  await vfs.registerVirtual('/dev/sink', { read: () => 'abc', write: (d) => void (written = new TextDecoder().decode(d)) }, 0o666);
  assert.equal(await vfs.readText('/dev/sink'), 'abc');
  await vfs.writeFile('/dev/sink', 'xyz');
  assert.equal(written, 'xyz');
  assert.ok(!(await backend.loadNodes()).some((n) => n.id.startsWith('virtual:')));
});

test('file names are validated', async () => {
  const { vfs } = await fresh();
  await assert.rejects(vfs.writeFile('/home/alice/' + 'a'.repeat(300), 'x', {}, alice), (e: VfsError) => e.code === 'EINVAL');
});
