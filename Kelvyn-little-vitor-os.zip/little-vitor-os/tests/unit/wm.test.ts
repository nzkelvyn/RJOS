import { test } from 'node:test';
import assert from 'node:assert/strict';
import { WindowManager } from '../../src/wm/windowManager';
import { evaluate } from '../../src/apps/calculatorLogic';

const vp = { width: 1200, height: 800, top: 36, bottom: 70, left: 0 };

function wm() {
  const m = new WindowManager(vp);
  m.animations = false;
  return m;
}

test('open focuses the new window and stacks z-order', () => {
  const m = wm();
  const a = m.open({ appId: 'a', title: 'A', icon: 'x', color: '#000' });
  const b = m.open({ appId: 'b', title: 'B', icon: 'x', color: '#000' });
  assert.equal(m.state.get().focused, b.id);
  assert.ok(m.get(b.id)!.z > m.get(a.id)!.z);
  m.focus(a.id);
  assert.equal(m.state.get().focused, a.id);
  assert.ok(m.get(a.id)!.z > m.get(b.id)!.z);
});

test('windows always fit and stay reachable', () => {
  const m = wm();
  const w = m.open({ appId: 'a', title: 'A', icon: 'x', color: '#000', width: 5000, height: 5000 });
  const g = m.get(w.id)!;
  assert.ok(g.w <= vp.width && g.h <= vp.height - vp.top - vp.bottom);
  m.move(w.id, -10000, -10000);
  assert.ok(m.get(w.id)!.y >= vp.top, 'title bar never goes under the top bar');
  m.move(w.id, 99999, 99999);
  assert.ok(m.get(w.id)!.x <= vp.width - 80);
});

test('maximize / restore keeps the previous geometry', () => {
  const m = wm();
  const w = m.open({ appId: 'a', title: 'A', icon: 'x', color: '#000', width: 500, height: 300 });
  const before = { ...m.get(w.id)! };
  m.toggleMaximize(w.id);
  const max = m.get(w.id)!;
  assert.deepEqual([max.x, max.y, max.w, max.h], [0, 36, 1200, 800 - 36 - 70]);
  m.toggleMaximize(w.id);
  const r = m.get(w.id)!;
  assert.deepEqual([r.x, r.y, r.w, r.h], [before.x, before.y, before.w, before.h]);
});

test('snap left/right and tile side by side', () => {
  const m = wm();
  const a = m.open({ appId: 'a', title: 'A', icon: 'x', color: '#000' });
  const b = m.open({ appId: 'b', title: 'B', icon: 'x', color: '#000' });
  m.tileSideBySide();
  const [ga, gb] = [m.get(a.id)!, m.get(b.id)!];
  assert.equal(gb.snapped, 'left');
  assert.equal(ga.snapped, 'right');
  assert.equal(gb.x + gb.w, ga.x);
  assert.equal(gb.w + ga.w, 1200);
});

test('minimize moves focus; show desktop toggles everything', () => {
  const m = wm();
  const a = m.open({ appId: 'a', title: 'A', icon: 'x', color: '#000' });
  const b = m.open({ appId: 'b', title: 'B', icon: 'x', color: '#000' });
  m.minimize(b.id);
  assert.equal(m.state.get().focused, a.id);
  m.showDesktop();
  assert.ok(m.windows.every((w) => w.minimized));
  m.showDesktop();
  assert.equal(m.get(a.id)!.minimized, false);
});

test('resize respects minimum size', () => {
  const m = wm();
  const w = m.open({ appId: 'a', title: 'A', icon: 'x', color: '#000', width: 600, height: 400, minWidth: 300, minHeight: 200 });
  m.resize(w.id, { x: 100, y: 100, w: 10, h: 10 });
  assert.equal(m.get(w.id)!.w, 300);
  assert.equal(m.get(w.id)!.h, 200);
});

test('Alt+Tab switcher follows most-recently-used order', () => {
  const m = wm();
  const a = m.open({ appId: 'a', title: 'A', icon: 'x', color: '#000' });
  const b = m.open({ appId: 'b', title: 'B', icon: 'x', color: '#000' });
  const c = m.open({ appId: 'c', title: 'C', icon: 'x', color: '#000' });
  m.switcherNext(); // shows overlay, selects previous window
  m.switcherCommit();
  assert.equal(m.state.get().focused, b.id);
  m.switcherNext();
  m.switcherCommit();
  assert.equal(m.state.get().focused, c.id);
  m.close(a.id);
  assert.equal(m.windows.length, 2);
});

test('calculator: safe evaluator (no eval)', () => {
  assert.equal(evaluate('2+3*4'), 14);
  assert.equal(evaluate('(2+3)*4'), 20);
  assert.equal(evaluate('2^3^2'), 512);
  assert.equal(evaluate('-3+5'), 2);
  assert.equal(evaluate('5!'), 120);
  assert.equal(evaluate('sqrt(16)+abs(-2)'), 6);
  assert.ok(Math.abs(evaluate('sin(90)', true) - 1) < 1e-12);
  assert.throws(() => evaluate('alert(1)'));
  assert.throws(() => evaluate('(1+2'));
});
